Stellar Cyber Log Relay 1.1.68  (build 89ae1a7)

This tool manages and monitors the syslog-ng and/or nginx you ALREADY RUN on this host as a Stellar Cyber
multi-tenant log relay. It does not install syslog-ng or nginx: install them first (Ubuntu:
apt install syslog-ng-core syslog-ng-scl syslog-ng-mod-add-contextual-data / apt install nginx), then:

    sudo bash install.sh                  detects what is on the host and asks which one(s) to manage
    sudo bash install.sh --method both    no question; see --help for the unattended options

The choice is not final: sudo stellar-relay add nginx | remove nginx (or syslog) at any time. Nothing the
other method has - tenants, maps, settings, the console's accounts - is touched.

Files:
    stellar-relay-monitor_1.1.68_all.deb   the Log Relay Manager web console + the stellar-relay command (always)
    stellar-relay-syslog_1.1.68_all.deb    Method 3: manage an existing syslog-ng as the relay
    stellar-relay-nginx_1.1.68_all.deb     Method 5: manage an existing nginx as the relay
    stellar-relay_1.1.68_all.deb           metapackage: all three
    EULA.txt, THIRD-PARTY-NOTICES.txt        the End User Notice (it points at stellarcyber.ai/eua) and the
                                             third-party programs this works with, under their own licenses
    internal-code.sha256                     Stellar Cyber internal: the hash of the code that unlocks a full install
    SHA256SUMS                               checksums of every file above

After install: open https://<this host>:8444 (self-signed certificate) and sign in with the password you gave.

Permissions: install.sh runs as root (sudo) to install the packages, create the unprivileged service user
"stellarlab", write under /opt/stellar-lab, /etc/stellar-lab, /etc/stellar-relay and /etc/sudoers.d, and enable
the relay-monitor service. Afterwards the console runs as stellarlab and may run only the allow-listed
stellar-relay-* helpers and reload/restart syslog-ng or nginx through sudo (/etc/sudoers.d/stellar-relay-*).
Open TCP 8444 to the console from your browser.

This bundle is SIGNED. Its SHA256SUMS.sig is an Ed25519 signature by Stellar Cyber's
release key over SHA256SUMS, which covers every other file here. A console installs it
only if that signature verifies against the public key installed on the host.
