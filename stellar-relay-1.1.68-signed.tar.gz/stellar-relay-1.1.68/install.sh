#!/usr/bin/env bash
#############################################################################
# Stellar Cyber Log Relay Manager - installer for Ubuntu / Debian
#
# This tool MANAGES AND MONITORS the syslog-ng and/or nginx already installed on this host as a Stellar Cyber
# multi-tenant log relay. It does not install syslog-ng or nginx; a method whose program is missing is refused
# with the command that installs it. (Stellar Cyber staff: --full-install with the internal code also
# installs the program from Ubuntu.)
#
#   sudo bash install.sh                         detects what is on the host and asks which one(s) to manage
#   sudo bash install.sh --method syslog|nginx|both [options]
#   sudo bash install.sh --add nginx | --remove nginx      (or syslog) on an installed host
#
# Options (all optional; anything not given is asked for at a terminal, or left for later when unattended):
#   --method M            syslog (your syslog-ng), nginx (your nginx) or both
#   --console-only        install the console alone, on a host where syslog-ng / nginx is not there yet;
#                         print what an administrator has to do, then add the method later with
#                         sudo stellar-relay add syslog|nginx
#   --prereq M            print what an administrator must do to get syslog-ng (or nginx) ready on this
#                         host, check this host against it, and exit. Changes nothing.
#   --full-install        Stellar Cyber internal: also install syslog-ng / nginx from Ubuntu when missing; needs the
#                         internal code in $STELLAR_INTERNAL_CODE (or typed at the prompt), checked against internal-code.sha256
#   --check-code          say whether the code in $STELLAR_INTERNAL_CODE (or typed) is the internal code, and exit
#   --advanced            Stellar Cyber internal: the advanced console (nginx, HA, alerts, Ingest Studio,
#                         every field); needs the advanced code in $STELLAR_ADVANCED_CODE or typed. Without
#                         this flag an install is the standard console and editions are never mentioned.
#   --accept-eula         you have read EULA.txt and accept it (otherwise you are asked)
#   --sensor-ip IP        the Modular Sensor's address or host name; without it you are asked, or set it up
#                         later: sudo stellar-relay setup <method> ...
#   --sensor-ip-2 IP      a second Modular Sensor (a deployment may have two); interactively you are asked
#                         how many first, then for each address in turn
#   --sensor-mode MODE    with two sensors: split (the default - each log source pinned to the sensor in
#                         its map row; a down sensor's records wait in its disk buffer) or failover (everything to sensor 1,
#                         sensor 2 only while sensor 1 is down, so a tenant is never split across them)
#   --default-tenant ID   nginx only: 32-character tenant ID for clients not in the map (the catch-all tenant)
#   --transport tls|tcp   syslog-ng -> sensor (default tls); --upstream https|http  nginx -> sensor (default https)
#   --debug-log           keep a copy of every forwarded record on this host (the DEFAULT): the console's "Last seen",
#   --no-debug-log        its Log flow picture and its log explorer read it; capped at 200 MB by a logrotate rule.
#                         Interactively you are asked. --no-debug-log for a host that must not hold log content.
#   --monitor-port N      the web console's port (default 8444)
#   --unattended          never ask anything; the console password comes from $STELLAR_ADMIN_PASSWORD or stays
#                         the generated one in /etc/stellar-lab/relay-monitor.initial-password
#   --add M / --remove M  add or remove one method later; --purge with --remove also deletes its map and settings
#
# THE CHOICE IS NEVER FINAL. Adding or removing a method later (sudo stellar-relay add|remove <method>, or this
# script with --add/--remove) leaves the other method, every tenant, map, setting and console account as it is.
#############################################################################
set -euo pipefail

# The releases this is tested on. This script ships ALONE in the bundle - it cannot source
# apps/common/install-lib.sh, which is why the list is written out twice; a packaging test holds the
# two copies equal. 22.04 was dropped on 2 Oct 2026 (Paul).
SUPPORTED_UBUNTU="Ubuntu 24.04, 26.04"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_CACHE=/var/lib/stellar-relay/packages
EULA_RECORD=/etc/stellar-relay/eula-accepted

METHOD=""; CONSOLE_ONLY=no; PREREQ=""; ACCEPT=no; SENSOR_IP=""; DEFAULT_TENANT=""; TRANSPORT=""; UPSTREAM=""; DEBUG_LOG=yes; MONITOR_PORT=""; UNATTENDED=no
SENSOR_IP_2=""; SENSOR_MODE=""; SENSOR_COUNT=""
ADD=""; REMOVE=""; PURGE=no; FULL=no; CHECK_CODE=no; WANT_ADVANCED=no
usage() { sed -n '3,/^#####/p' "$0" | sed '$d' | sed 's/^# \{0,1\}//'; exit "${1:-0}"; }
while [[ $# -gt 0 ]]; do
  case "$1" in
    --method) METHOD="$2"; shift 2 ;;
    --console-only) CONSOLE_ONLY=yes; shift ;;
    --prereq) PREREQ="$2"; shift 2 ;;
    --accept-eula) ACCEPT=yes; shift ;;
    --sensor-ip) SENSOR_IP="$2"; shift 2 ;;
    --sensor-ip-2) SENSOR_IP_2="$2"; SENSOR_COUNT=2; shift 2 ;;
    --sensor-mode) SENSOR_MODE="$2"; shift 2 ;;
    --default-tenant) DEFAULT_TENANT="$2"; shift 2 ;;
    --transport) TRANSPORT="$2"; shift 2 ;;
    --upstream) UPSTREAM="$2"; shift 2 ;;
    --debug-log) DEBUG_LOG=yes; shift ;;
    --no-debug-log) DEBUG_LOG=no; shift ;;
    --monitor-port) MONITOR_PORT="$2"; shift 2 ;;
    --unattended) UNATTENDED=yes; shift ;;
    --add) ADD="$2"; shift 2 ;;
    --remove) REMOVE="$2"; shift 2 ;;
    --purge) PURGE=yes; shift ;;
    --full-install) FULL=yes; shift ;;
    --check-code) CHECK_CODE=yes; shift ;;
    --advanced) WANT_ADVANCED=yes; shift ;;
    -h|--help) usage 0 ;;
    *) echo "Unknown option: $1" >&2; usage 1 ;;
  esac
done

read_secret() {
  local prompt="$1" out="" ch saved=""
  if [[ ! -r /dev/tty ]]; then read -r out; printf '%s' "$out"; return; fi
  # Echo is turned off ONCE for the whole loop. Using read -s per character toggles it between
  # characters, and anything typed ahead in that window is echoed in the clear - measured.
  saved=$(stty -g </dev/tty 2>/dev/null) || saved=""
  [[ -n "$saved" ]] && stty -echo </dev/tty 2>/dev/null
  printf '%s' "$prompt" >&2
  while IFS= read -r -n1 ch </dev/tty; do
    [[ -z "$ch" ]] && break
    if [[ "$ch" == $'\177' || "$ch" == $'\b' ]]; then
      [[ -n "$out" ]] && { out="${out%?}"; printf '\b \b' >&2; }
    else
      out+="$ch"; printf '*' >&2
    fi
  done
  [[ -n "$saved" ]] && stty "$saved" </dev/tty 2>/dev/null
  printf '\n' >&2
  printf '%s' "$out"
}

bold() { printf '\n\033[1m%s\033[0m\n' "$*"; }
log() { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
die() { printf '\033[1;31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }
tty_ok() { [[ $UNATTENDED == no && -t 0 ]]; }
ask() { local v; read -r -p "$1" v; echo "$v"; }
# The agreement, paged like more(1). The notice is hand-wrapped at 80 columns and carries its own rules,
# headings and indents, so on a terminal at least that wide it is printed EXACTLY as written (the short
# End User Notice replaced the standalone EULA, whose lines were ~100 characters). Reflowing is now only
# for a terminal narrower than the document: those long lines, printed with a 4-space indent on a
# 100-column terminal, each wrapped one to four characters onto a line of its own - what read as "a blank
# line after every line" (Paul, 24 Sep 2026). Paragraphs are separated by blank lines; a rule and a
# heading in capitals stand alone (a capitals line is a HEADING only when a blank line or a rule follows
# it - the notice has a whole paragraph in capitals, and the file is read twice for that one-line
# lookahead) and a numbered clause starts a new paragraph, so only the lines inside one paragraph are
# joined before wrapping. Either way NOT ONE WORD CHANGES - it is a legal document.
# EULA_PAGE (lines per page) and EULA_COLS (the width) are for the tests.
show_eula() {
  local cols lines width page
  cols=${EULA_COLS:-$(tput cols 2>/dev/null || echo 80)}; lines=$(tput lines 2>/dev/null || echo 24)
  [[ "$cols" =~ ^[0-9]+$ ]] || cols=80; [[ "$lines" =~ ^[0-9]+$ ]] || lines=24
  (( cols > 100 )) && cols=100; (( cols < 40 )) && cols=80
  width=$((cols - 2)); page=${EULA_PAGE:-$((lines - 4))}; (( page < 8 )) && page=8
  # every line already fits this terminal: show the document as it is written, rules and indents and all
  if awk -v w="$cols" 'length($0) > w { exit 1 }' "$1"; then cat "$1"; else
  awk -v w="$width" '
    NR == FNR { nl[FNR] = $0; last = FNR; next }            # pass 1: the lines, for a one-line lookahead
    function flush() { if (buf == "") return; n = split(buf, wd, " "); line = ""
      for (i = 1; i <= n; i++) { if (line == "") line = wd[i]; else if (length(line) + 1 + length(wd[i]) <= w) line = line " " wd[i]; else { print line; line = wd[i] } }
      if (line != "") print line; buf = "" }
    function alone(i) { return i >= last || nl[i + 1] ~ /^[[:space:]]*$/ || nl[i + 1] ~ /^[=_-][=_-][=_-]+/ }
    /^[[:space:]]*$/ { flush(); print ""; next }
    /^[=_-][=_-][=_-]+[[:space:]]*$/ { flush(); print; next }
    /^[0-9]+\.[[:space:]]+[A-Z][A-Z0-9 &,.:;()"-]*$/ { flush(); print; next }
    /^([0-9]+(\.[0-9]+)*|\([a-z]\))[[:space:]]/ { flush(); buf = $0; next }
    buf == "" && length($0) <= 70 && $0 ~ /^[A-Z][A-Z0-9 &,.:;()"-]*$/ && alone(FNR) { print; next }
    { sub(/^[[:space:]]+/, ""); buf = (buf == "" ? $0 : buf " " $0) }
    END { flush() }' "$1" "$1"
  fi | {
    local n=0 l k
    while IFS= read -r l; do
      printf '%s\n' "$l"; n=$((n + 1))
      if (( n % page == 0 )); then
        printf -- '-- More -- (Enter or space: next page, q: to the end) '
        IFS= read -rsn1 k </dev/tty 2>/dev/null || k=q
        printf '\r%*s\r' 60 ''
        if [[ $k == q || $k == Q ]]; then cat >/dev/null; break; fi
      fi
    done
  }
}

# A sensor address, checked before it reaches the relay helper - which would otherwise die mid-install and
# leave the console installed with no destination. Same rule as the helper's own sensor_addr_ok: an IPv4
# address, or a plain host name. A name that does not resolve here is a WARNING, not a refusal: DNS may
# arrive after the install, the relay re-resolves the name every time it loads its configuration, and
# refusing would be worse than telling the truth about it.
own_addresses() {   # every address that IS this host, including the cloud public one (not on any interface)
  ip -o -4 addr show 2>/dev/null | awk '$2 != "lo" && $3 == "inet" {split($4, a, "/"); print a[1]}'
  local tok pub
  tok=$(curl -s --max-time 1 -X PUT "http://169.254.169.254/latest/api/token" \
        -H "X-aws-ec2-metadata-token-ttl-seconds: 60" 2>/dev/null) || return 0
  [[ -n "$tok" ]] || return 0
  pub=$(curl -s --max-time 1 -H "X-aws-ec2-metadata-token: $tok" \
        "http://169.254.169.254/latest/meta-data/public-ipv4" 2>/dev/null) || return 0
  [[ "$pub" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && printf '%s\n' "$pub"
  return 0
}
own_address() {
  local a
  while read -r a; do [[ "$a" == "$1" ]] && return 0; done < <(own_addresses)
  return 1
}

sensor_addr_ok() {
  [[ "$1" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && return 0
  [[ "$1" =~ ^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?$ ]] && return 0
  return 1
}
ask_sensor() {   # ask_sensor <prompt> <address already taken, or empty>
  local v
  while true; do
    v=$(ask "$1")
    [[ -z "$v" ]] && { printf ''; return; }
    if ! sensor_addr_ok "$v"; then
      echo "  '$v' is neither an IPv4 address nor a host name. Try 10.0.1.50 or sensor1.example.com." >&2
      continue
    fi
    if [[ -n "$2" && "$v" == "$2" ]]; then
      echo "  that is the same address as the other sensor; give the second sensor's own address" >&2
      continue
    fi
    if [[ "$v" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && own_address "$v"; then
      echo "  $v is this host's own address. A relay cannot forward to itself - give the Modular Sensor's" >&2
      echo "  address. This host answers to: $(own_addresses | tr '\n' ' ')" >&2
      continue
    fi
    if [[ ! "$v" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && ! getent hosts "$v" >/dev/null 2>&1; then
      echo "  note: $v does not resolve on this host yet. It is written as the NAME and looked up again every" >&2
      echo "  time the relay loads its configuration, so this is fine if DNS is still to come - but nothing" >&2
      echo "  will be delivered until it resolves." >&2
    fi
    printf '%s' "$v"; return
  done
}

# ---------------------------------------------------------------- what this host needs, and what it has
# Every figure here was MEASURED on a 2 vCPU / 2 GB host running syslog-ng 4.8.1 with the configuration this
# tool generates (docs/relay-sizing.md in the kit). Nothing here stops the install: it is the customer's host
# and a small one is right for a trial. It is printed FIRST because a host that is too small fails later,
# quietly, as dropped records - and the disk is the figure people get wrong.
host_requirements() {
  local cpu mem_kb mem_gb disk_gb os_ok="?" warn=0
  cpu=$(nproc 2>/dev/null || echo "?")
  mem_kb=$(awk '/MemTotal/{print $2}' /proc/meminfo 2>/dev/null || echo 0)
  mem_gb=$(awk -v k="$mem_kb" 'BEGIN{printf "%.1f", k/1048576}')
  disk_gb=$(df -BG --output=avail /var 2>/dev/null | tail -1 | tr -dc '0-9' || true)
  [[ -z "$disk_gb" ]] && disk_gb=0
  # 22.04 was dropped on 2 Oct 2026 (Paul): it is not a release this is tested on any more. This
  # warns rather than refuses, as every other row here does - the administrator owns the host.
  case "${VERSION_ID:-}" in 24.04|26.04) os_ok=yes ;; *) os_ok=no ;; esac

  bold "What this host needs"
  printf '  %-22s %-28s %s\n' "" "Needed" "This host"
  printf '  %-22s %-28s %s' "Operating system" "$SUPPORTED_UBUNTU" "${PRETTY_NAME:-unknown}"
  if [[ $os_ok == yes ]]; then echo "  [ok]"; else echo "  [not tested]"; warn=1; fi
  printf '  %-22s %-28s %s' "Processor" "2 vCPU" "$cpu vCPU"
  if [[ "$cpu" != "?" && "$cpu" -ge 2 ]]; then echo "  [ok]"; else echo "  [TOO SMALL]"; warn=1; fi
  printf '  %-22s %-28s %s' "Memory" "2 GB" "$mem_gb GB"
  if [[ "$mem_kb" -ge 1900000 ]]; then echo "  [ok]"; else echo "  [TOO SMALL]"; warn=1; fi
  printf '  %-22s %-28s %s' "Free disk on /var" "20 GB" "$disk_gb GB"
  if [[ "$disk_gb" -ge 20 ]]; then echo "  [ok]"; else echo "  [TOO SMALL]"; warn=1; fi
  cat <<'SIZING'

  What those figures carry, measured, not estimated:
    2 vCPU / 2 GB      2,000 records/s at 13% of one core; the ceiling on 2 vCPU is about 40,000/s.
                       For a sustained 10,000/s give it 4 GB; past 25,000/s use two relays, not a bigger host.
    20 GB              the system, this console and its backups, with room for the disk buffers below.
    The disk buffers   Each sensor port keeps up to 512 MB of logs while the sensor is unreachable, and a
                       queued record costs about three times its own size. At 1,000 records/s that default
                       holds under five minutes - fine for a reload, not for an outage. If the sensor may be
                       unreachable for hours, add disk: a 4-hour outage at 1,000 records/s needs about 26 GB
                       per sensor port. The files are not preallocated, so it is spent only during an outage.
    A burstable cloud instance (AWS t3/t4g and the like) sustains about 6,400 records/s on its baseline
    credits; above that turn on unlimited mode or use a non-burstable instance.
SIZING
  if [[ $warn == 1 ]]; then
    echo
    echo "  This host is under one or more of those. It will install and run; on a small host watch the"
    echo "  console's Health page and the dropped counter on each sensor port, which is what a host that"
    echo "  cannot keep up looks like."
  fi
}

# ---------------------------------------------------------------- the internal code (Stellar Cyber staff only)
# Its SHA-256 travels with the bundle; the code itself never does. A full install (this tool + syslog-ng / nginx
# from Ubuntu) is unlocked by it, so a customer's host never gets a program installed by accident.
code_ok() {
  local code="${STELLAR_INTERNAL_CODE:-}" want
  [[ -f "$HERE/internal-code.sha256" ]] || return 1
  want=$(tr -d ' \n' < "$HERE/internal-code.sha256")
  if [[ -z "$code" ]] && tty_ok; then code=$(read_secret "Stellar Cyber internal code: "); fi
  [[ -n "$code" ]] || return 1
  [[ "$(printf '%s' "$code" | python3 -c 'import hashlib,sys; print(hashlib.sha256(sys.stdin.buffer.read()).hexdigest())')" == "$want" ]]
}
# ---------------------------------------------------------------- the console edition (advanced-code.sha256 travels with the bundle)
# A customer install is the STANDARD console: syslog-ng only, the simple pages, one way per firewall. The advanced
# code (given by Stellar Cyber, $STELLAR_ADVANCED_CODE or typed) unlocks the ADVANCED console: nginx, HA, alerts,
# Ingest Studio access, every field. Later: sudo stellar-relay edition standard|advanced.
advanced_code_ok() {
  local code="${STELLAR_ADVANCED_CODE:-}" want
  [[ -f "$HERE/advanced-code.sha256" ]] || return 1
  want=$(tr -d ' \n' < "$HERE/advanced-code.sha256")
  # only reached when --advanced was given or STELLAR_ADVANCED_CODE is set: the asker already knows it exists
  if [[ -z "$code" ]] && tty_ok; then code=$(read_secret "Advanced code: "); fi
  [[ -n "$code" ]] || return 1
  [[ "$(printf '%s' "$code" | python3 -c 'import hashlib,sys; print(hashlib.sha256(sys.stdin.buffer.read()).hexdigest())')" == "$want" ]]
}
if [[ $CHECK_CODE == yes ]]; then
  if code_ok; then echo "code accepted: --full-install may install syslog-ng / nginx from Ubuntu"; exit 0; else echo "code rejected" >&2; exit 1; fi
fi
program_present() { case "$1" in syslog) command -v syslog-ng >/dev/null 2>&1 ;; nginx) command -v nginx >/dev/null 2>&1 ;; esac; }
program_version() { case "$1" in syslog) syslog-ng --version 2>/dev/null | head -1 ;; nginx) nginx -v 2>&1 | head -1 ;; esac; }
install_hint() { case "$1" in syslog) echo "sudo apt install syslog-ng-core syslog-ng-scl syslog-ng-mod-add-contextual-data" ;; nginx) echo "sudo apt install nginx" ;; esac; }
program_pkgs() { case "$1" in syslog) echo "syslog-ng-core syslog-ng-scl syslog-ng-mod-add-contextual-data" ;; nginx) echo "nginx" ;; esac; }
methods_of() { case "$1" in both) echo "syslog nginx" ;; syslog|nginx) echo "$1" ;; *) echo "" ;; esac; }
# What an administrator has to do to get the program ready, with this host checked against each step. One
# source for it: apps/common/prereq.py, shipped beside this script and installed with the console.
prereq_text() {
  local f=""
  # the bundle (beside this script), an installed console, or a checkout of the kit
  for c in "$HERE/prereq.py" /opt/stellar-lab/common/prereq.py "$HERE/../apps/common/prereq.py"; do
    [[ -f "$c" ]] && { f="$c"; break; }
  done
  if [[ -n "$f" ]] && command -v python3 >/dev/null; then
    echo; python3 "$f" "$1" --check || true
  else
    echo; echo "  $(program_of_name "$1") is not installed. Install it first:  $(install_hint "$1")"
  fi
}
program_of_name() { case "$1" in syslog) echo syslog-ng ;; nginx) echo nginx ;; esac; }
if [[ -n "$PREREQ" ]]; then
  [[ "$PREREQ" =~ ^(syslog|nginx)$ ]] || die "--prereq takes syslog or nginx"
  prereq_text "$PREREQ"; exit 0
fi
# A method may be managed only where its program exists. With --full-install and the code, install it first.
require_program() {
  local m=$1
  program_present "$m" && return 0
  if [[ $FULL == yes ]]; then
    [[ "${CODE_OK:-}" == yes ]] || { code_ok && CODE_OK=yes || die "--full-install needs the Stellar Cyber internal code (STELLAR_INTERNAL_CODE, or type it at the prompt); a customer install manages an existing $m only"; }
    log "Full install: installing $(program_pkgs "$m") from Ubuntu (internal code accepted)"
    apt_install $(program_pkgs "$m")
    mkdir -p /etc/stellar-relay; echo "full install: $(program_pkgs "$m") installed $(date -Is) by ${SUDO_USER:-root} with the internal code" >> /etc/stellar-relay/full-install
    return 0
  fi
  return 1        # the program is not here; the caller prints the steps and offers the console alone
}

[[ $EUID -eq 0 ]] || die "run as root: sudo bash $0 ..."
command -v apt-get >/dev/null || die "this installer is for Ubuntu / Debian (apt). Other distributions: see the handbook."
[[ -f /etc/os-release ]] && . /etc/os-release || true
DEBS=("$HERE"/stellar-relay-monitor_*.deb "$HERE"/stellar-relay-syslog_*.deb "$HERE"/stellar-relay-nginx_*.deb)
for d in "${DEBS[@]}"; do [[ -f "$d" ]] || die "package missing next to this script: $d (unpack the whole bundle)"; done
VERSION=$(basename "$HERE"/stellar-relay-monitor_*.deb | sed -E 's/^stellar-relay-monitor_(.*)_all\.deb$/\1/')
installed() { dpkg-query -W -f '${Status}' "$1" 2>/dev/null | grep -q "install ok installed"; }

wait_for_apt() {
  local waited=0
  while fuser /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/lib/apt/lists/lock >/dev/null 2>&1; do
    [[ $waited -eq 0 ]] && echo "    apt is busy (unattended-upgrades / apt-daily); waiting up to 15 min ..."
    sleep 5; waited=$((waited+5))
    [[ $waited -ge 900 ]] && { echo "    still locked after 15 min; see: ps -ef | grep -E 'apt|dpkg'" >&2; return 1; }
  done
  return 0
}
apt_install() {
  export DEBIAN_FRONTEND=noninteractive
  wait_for_apt || exit 1
  apt-get update -qq || echo "    (apt-get update reported a problem; continuing with the lists it has)"
  apt-get install -y "$@"
}
cache_debs() { mkdir -p "$PKG_CACHE"; cp -f "$HERE"/stellar-relay-*_"$VERSION"_all.deb "$PKG_CACHE"/; }
pkg_of() { case "$1" in syslog) echo stellar-relay-syslog ;; nginx) echo stellar-relay-nginx ;; esac; }
deb_of() { echo "$HERE/$(pkg_of "$1")_${VERSION}_all.deb"; }
remove_kit_copies() {
  # a host set up earlier with the kit's own scripts keeps copies in /usr/local that would shadow the package's on PATH
  local moved=0
  for f in /usr/local/sbin/stellar-relay-map /usr/local/sbin/stellar-relay-config /usr/local/sbin/stellar-relay-capture /usr/local/sbin/stellar-relay-backup \
           /usr/local/sbin/stellar-relay-firewall /usr/local/sbin/stellar-relay-packages /usr/local/sbin/stellar-relay-secret \
           /usr/local/sbin/stellar-syslog-relay /usr/local/sbin/stellar-nginx-relay; do
    [[ -f "$f" ]] || continue
    local pkgd="/usr/sbin/$(basename "$f")"
    if [[ -f "$pkgd" ]]; then mkdir -p /usr/local/lib/stellar-relay/replaced-by-package; mv -f "$f" /usr/local/lib/stellar-relay/replaced-by-package/; moved=1; fi
  done
  [[ $moved == 1 ]] && echo "    earlier kit copies moved from /usr/local/sbin to /usr/local/lib/stellar-relay/replaced-by-package (the packages own them now)"
  rm -f /etc/sudoers.d/stellar-relay-monitor.kit 2>/dev/null || true
  return 0
}

# ---------------------------------------------------------------- add / remove on an installed host
if [[ -n "$REMOVE" ]]; then
  [[ "$REMOVE" =~ ^(syslog|nginx)$ ]] || die "--remove takes syslog or nginx"
  command -v stellar-relay >/dev/null || die "stellar-relay-monitor is not installed here"
  if [[ $PURGE == yes ]]; then stellar-relay remove "$REMOVE" --purge; else stellar-relay remove "$REMOVE"; fi
  exit 0
fi
if [[ -n "$ADD" ]]; then
  [[ "$ADD" =~ ^(syslog|nginx|both)$ ]] || die "--add takes syslog, nginx or both"
  installed stellar-relay-monitor || die "stellar-relay-monitor is not installed here; run this script without --add first"
  cache_debs
  for m in $(methods_of "$ADD"); do
    require_program "$m" || { prereq_text "$m"
      die "$(program_of_name "$m") is not installed on this host, so there is nothing to manage yet. The steps above get it ready; then run this again."; }
  done
  stellar-relay add "$ADD"
  METHOD="$ADD"; ADDING=yes
else
  ADDING=no
fi

# The STANDARD console is what an install IS. The advanced console exists for Stellar Cyber staff and is
# asked for EXPLICITLY - --advanced, or $STELLAR_ADVANCED_CODE in the environment. It is never offered,
# never prompted for and never named: a customer must not learn that a hidden edition exists, or be asked
# for a code they were never given and cannot have.
EDITION=${EDITION:-}
if [[ -z "$EDITION" ]]; then
  EDITION=standard
  if [[ $WANT_ADVANCED == yes || -n "${STELLAR_ADVANCED_CODE:-}" ]]; then
    advanced_code_ok || die "the advanced code was not accepted (Stellar Cyber staff only; without --advanced this installs the standard console)"
    EDITION=advanced
    echo "  -> advanced console"
  fi
fi

if [[ $ADDING == no ]]; then
bold "Stellar Cyber Log Relay Manager $VERSION  -  ${PRETTY_NAME:-$(uname -s)}"
if [[ "$EDITION" == standard ]]; then
cat <<'INTRO'
This installs the Log Relay Manager, a web console that manages and monitors the syslog-ng ALREADY
INSTALLED on this host as a Stellar Cyber multi-tenant log relay: firewalls send their ordinary syslog
here, each log is wrapped with the tenant it belongs to, and it is forwarded to the parser's own port on
the Modular Sensor.

This tool does not install syslog-ng, upgrade it or remove it. If it is missing, install it from your
distribution first (the command is printed) and run this again.
INTRO
else
cat <<'INTRO'
This installs the Log Relay Manager (a web console) to manage and monitor, as a Stellar Cyber multi-tenant
log relay, the program(s) ALREADY INSTALLED on this host:
  syslog   your syslog-ng. Firewalls send syslog here; each log is wrapped with its tenant and
           forwarded to the parser's port on the Modular Sensor. Most firewalls use this.
  nginx    your nginx. Log sources that POST webhook JSON (PAN-OS HTTP profiles, Meraki webhooks,
           CrowdStrike, Okta, cloud services) send here; the tenant goes in an HTTP header.
  both     both, side by side on this host.
This tool does not install syslog-ng or nginx. If one you need is missing, install it from your distribution
first (the command is printed) and run this again.

You can change this choice at any time later (sudo stellar-relay add nginx | remove nginx, and the same
for syslog). Nothing the other method has - tenants, maps, settings, console accounts - is affected.
INTRO
fi
host_requirements

bold "Found on this host"
for m in $([[ "$EDITION" == standard ]] && echo syslog || echo syslog nginx); do
  if program_present "$m"; then printf '  %-7s %s\n' "$m" "$(program_version "$m")"; else printf '  %-7s NOT INSTALLED  (what to do: sudo bash install.sh --prereq %s)\n' "$m" "$m"; fi
done
echo
echo "  This tool configures and tests syslog-ng / nginx. It never installs, upgrades or removes them:"
echo "  the program, its license, its version and its service stay yours."

# What this host already had BEFORE this run. The three questions below - the licence, the console
# password and the sensors - are each skipped once they have been answered, which is right for an upgrade
# or a re-run and baffling in silence: Paul re-ran install.sh on a host that already carried 1.0.9, was
# asked nothing at all, and got "Sign in: admin" with no password he knew (1 Oct 2026). The summary at the
# end now says which were skipped, when, and the command that changes each.
PRE_EULA=""; PRE_PASSWORD=no; PRE_SENSOR=""
[[ -f "$EULA_RECORD" ]] && PRE_EULA=$(head -1 "$EULA_RECORD" 2>/dev/null)
[[ -f /etc/stellar-lab/relay-monitor.env && ! -f /etc/stellar-lab/relay-monitor.initial-password ]] && PRE_PASSWORD=yes
# `set -o pipefail` + a sed on a file that is not there = a pipeline that returns 2, an assignment
# that fails, and `set -e` ending the script with NOTHING printed. On a FRESH host none of these three
# files exists, which is why this only ever bit a first install (Keem Loh, 2 Oct 2026: install.sh
# stopped dead after "Found on this host" on two clean 1.1.4 hosts). Not finding a value is a normal
# answer here - every reader below has a ${VAR:-default} - so each one says so.
PRE_SENSOR=$(sed -n 's/^SENSOR_IP=//p' /etc/stellar-relay/syslog-ng.env 2>/dev/null | tr -d '"' | head -1 || true)

# ---------------------------------------------------------------- EULA
# Not here any more (1.0.12). The agreement is read and accepted in the console at first sign-in, where
# there is room for it and nothing can be done until it is: `request_policy` in app.py refuses every
# other route until the record below exists. --accept-eula still writes it, for an unattended install
# where no one will ever open the page.
if [[ ! -f "$EULA_RECORD" && $ACCEPT == no ]]; then
  echo
  echo "  License: the End User Notice is in $HERE/EULA.txt, and after this install in"
  echo "           /usr/share/doc/stellar-relay-monitor/EULA.txt. It binds use of this software to the"
  echo "           Stellar Cyber End User Agreement at https://stellarcyber.ai/eua (or your executed"
  echo "           master agreement). You will be shown the notice in the console at first sign-in and"
  echo "           asked to accept it; until then the console does nothing else."
fi

# ---------------------------------------------------------------- which edition, then which method
# the standard console manages syslog-ng only: no method question
[[ "$EDITION" == standard && -z "$METHOD" && $CONSOLE_ONLY == no ]] && METHOD=syslog
if [[ "$EDITION" == standard && "$METHOD" =~ ^(nginx|both)$ ]]; then
  echo "note: this console manages syslog-ng (--method $METHOD ignored, syslog kept)" >&2; METHOD=syslog
fi
if [[ -z "$METHOD" && $CONSOLE_ONLY == no ]]; then
  tty_ok || die "--method syslog|nginx|both is required when unattended (or --console-only for the console alone)"
  bold "Which deployment should this console manage?"
  echo "  1) syslog   - the syslog-ng on this host (firewalls sending syslog)$(program_present syslog || echo '   [not installed here]')"
  echo "  2) nginx    - the nginx on this host (log sources posting webhook JSON)$(program_present nginx || echo '   [not installed here]')"
  echo "  3) both"
  echo "  (this can be changed later at any time; the console is installed in every case)"
  while true; do
    ans=$(ask "Choice [1/2/3]: ")
    case "$ans" in 1|syslog) METHOD=syslog; break ;; 2|nginx) METHOD=nginx; break ;; 3|both) METHOD=both; break ;; *) echo "  type 1, 2 or 3" ;; esac
  done
fi
[[ $CONSOLE_ONLY == yes ]] && METHOD=""
[[ -z "$METHOD" || "$METHOD" =~ ^(syslog|nginx|both)$ ]] || die "--method must be syslog, nginx or both"

# ---------------------------------------------------------------- is the program each chosen method manages actually here?
# It is not this tool's job to install syslog-ng or nginx. When one is missing, say exactly what an
# administrator has to do, and offer to install the console alone so the method can be added the moment
# the program is ready (sudo stellar-relay add syslog|nginx) - nothing is lost by installing it now.
MISSING=""; KEEP=""
for m in $(methods_of "$METHOD"); do
  if require_program "$m"; then KEEP="$KEEP $m"; else MISSING="$MISSING $m"; fi
done
MISSING=${MISSING# }; KEEP=${KEEP# }
if [[ -n "$MISSING" ]]; then
  for m in $MISSING; do prereq_text "$m"; done
  bold "So: $(for m in $MISSING; do printf '%s ' "$(program_of_name "$m")"; done)is not on this host"
  echo "This tool configures and tests it; installing it is the administrator's own step, above."
  if [[ -n "$KEEP" ]]; then
    echo "Continuing with what IS here: $KEEP. Add the rest later: $(for m in $MISSING; do printf 'sudo stellar-relay add %s  ' "$m"; done)"
    METHOD=$([[ "$KEEP" == *" "* ]] && echo both || echo "$KEEP")
  else
    echo "The console itself can be installed now and manage $MISSING the moment it is ready:"
    echo "    sudo stellar-relay add $(echo "$MISSING" | awk '{print $1}')      (after the steps above)"
    if [[ $CONSOLE_ONLY == yes ]]; then
      METHOD=""
    elif tty_ok; then
      ans=$(ask "Install the console on its own now? [y/N]: ")
      [[ "${ans,,}" =~ ^y ]] || die "nothing was installed. Follow the steps above, then run this installer again."
      METHOD=""
    else
      die "nothing was installed: $MISSING is not on this host. Follow the steps above (sudo bash install.sh --prereq $(echo "$MISSING" | awk '{print $1}')), or re-run with --console-only to install the console alone."
    fi
  fi
fi

# ---------------------------------------------------------------- install the packages (this tool only; syslog-ng / nginx are already here)
log "Installing the packages ($METHOD)"
PKGS=("$HERE/stellar-relay-monitor_${VERSION}_all.deb")
case $METHOD in syslog) PKGS+=("$(deb_of syslog)") ;; nginx) PKGS+=("$(deb_of nginx)") ;; both) PKGS+=("$(deb_of syslog)" "$(deb_of nginx)" "$HERE/stellar-relay_${VERSION}_all.deb") ;; esac
apt_install "${PKGS[@]}"
cache_debs
remove_kit_copies
mkdir -p /etc/stellar-relay
# ONLY with --accept-eula: otherwise the console asks at first sign-in, and a record written here would
# mean nobody is ever asked at all.
[[ $ACCEPT == yes && ! -f "$EULA_RECORD" ]] && echo "accepted $(date -Is) by ${SUDO_USER:-root} on $(hostname) with --accept-eula, version $VERSION, method $METHOD" > "$EULA_RECORD"
# where this bundle was unpacked: `stellar-relay reset` removes that directory too, so a test from the start begins
# with a fresh unpack (only a directory named stellar-relay-<x.y.z> holding install.sh and SHA256SUMS is ever removed)
mkdir -p /etc/stellar-relay && echo "$HERE" > /etc/stellar-relay/install-source
# the console edition, as a file the console itself can change (its hidden Settings card) and stellar-relay edition reads
STATE_DIR=$(sed -n 's/^STATE_DIR=//p' /etc/stellar-lab/relay-monitor.env 2>/dev/null | tr -d '"'); [[ -n "$STATE_DIR" ]] || STATE_DIR=/var/lib/stellar-lab/relay-monitor
mkdir -p "$STATE_DIR"
printf '{"edition": "%s", "by": "%s", "how": "install.sh", "at": %s}\n' "$EDITION" "${SUDO_USER:-root}" "$(date +%s)" > "$STATE_DIR/edition.json"
chown stellarlab:stellarlab "$STATE_DIR/edition.json" 2>/dev/null || true; chmod 640 "$STATE_DIR/edition.json"

# ---------------------------------------------------------------- console port and password
if [[ -n "$MONITOR_PORT" ]]; then
  sed -i "s/^LISTEN_PORT=.*/LISTEN_PORT=$MONITOR_PORT/" /etc/stellar-lab/relay-monitor.env && systemctl restart relay-monitor || true
fi
if [[ -f /etc/stellar-lab/relay-monitor.initial-password ]]; then
  if [[ -n "${STELLAR_ADMIN_PASSWORD:-}" ]]; then
    if [[ -n "${STELLAR_ADMIN_USER:-}" && ! "${STELLAR_ADMIN_USER}" =~ ^[A-Za-z0-9._-]{1,32}$ ]]; then
      die "STELLAR_ADMIN_USER must be letters, digits, dot, underscore or hyphen, up to 32 characters"
    fi
    printf '%s\n%s\n' "$STELLAR_ADMIN_PASSWORD" "$STELLAR_ADMIN_PASSWORD" | stellar-relay admin-password ${STELLAR_ADMIN_USER:+--user "$STELLAR_ADMIN_USER"}
  elif tty_ok; then
    bold "Console sign-in"
    echo "The account you will sign in to the console with - a username, and a password of at least 12 characters."
    echo "It is the only thing this installer asks for: the license agreement and where the logs go are both"
    echo "asked in the console itself, at first sign-in."
    echo
    ADMIN_NAME=""
    while true; do
      ADMIN_NAME=$(ask "Administrator username [admin]: "); ADMIN_NAME=${ADMIN_NAME:-admin}
      # written into a settings file and used as an account name: keep it to characters that can mean
      # nothing anywhere else
      [[ "$ADMIN_NAME" =~ ^[A-Za-z0-9._-]{1,32}$ ]] && break
      echo "  letters, digits, dot, underscore or hyphen, up to 32 characters"
    done
    stellar-relay admin-password --user "$ADMIN_NAME" </dev/tty
    systemctl restart relay-monitor 2>/dev/null || true
  else
    echo "    console password: the generated one in /etc/stellar-lab/relay-monitor.initial-password (root only); change it with: sudo stellar-relay admin-password"
  fi
fi
fi   # ADDING == no

# ---------------------------------------------------------------- set the relay(s) up: sensor address and what each method needs
setup_syslog() {
  local args=(--sensor-ip "$SENSOR_IP")
  # With two sensors an install sets SPLIT (Paul, 24 Sep 2026): each log source is pinned to the sensor
  # named in its map row; a sensor that is unreachable keeps its records in the disk buffer until it returns. That is how
  # these deployments are actually run - the firewalls are assigned to sensors by hand - and it makes the
  # Sensor column on the Log sources & tenants page mean something from the start. The Sensors page switches to failover
  # (everything to sensor 1, sensor 2 only while it is down) for a site that would rather never have one
  # tenant's logs arrive on two sensors.
  [[ -n "$SENSOR_IP_2" ]] && args+=(--sensor-ip-2 "$SENSOR_IP_2" --sensor-mode "${SENSOR_MODE:-split}")
  [[ -n "$TRANSPORT" ]] && args+=(--transport "$TRANSPORT")
  if [[ $DEBUG_LOG == yes ]]; then args+=(--debug-log); else args+=(--no-debug-log); fi
  stellar-syslog-relay setup "${args[@]}"
}
setup_nginx() {
  local args=(--sensor-ip "$SENSOR_IP" --default-tenant "$DEFAULT_TENANT")
  [[ -n "$SENSOR_IP_2" ]] && args+=(--sensor-ip-2 "$SENSOR_IP_2")
  [[ -n "$UPSTREAM" ]] && args+=(--upstream "$UPSTREAM")
  stellar-nginx-relay setup "${args[@]}"
}
need_syslog=no; need_nginx=no
[[ "$METHOD" =~ ^(syslog|both)$ ]] && { grep -qsE '^SENSOR_IP=.+' /etc/stellar-relay/syslog-ng.env || need_syslog=yes; }
[[ "$METHOD" =~ ^(nginx|both)$ ]] && { [[ -f /etc/nginx/conf.d/stellar-tenant-proxy.conf ]] || need_nginx=yes; }
if [[ $need_syslog == yes || $need_nginx == yes ]]; then
  if [[ -n "$SENSOR_IP" ]]; then
    if [[ $need_syslog == yes ]]; then log "Setting up syslog-ng"; setup_syslog; fi
    if [[ $need_nginx == yes ]]; then
      if [[ -z "$DEFAULT_TENANT" ]] && tty_ok; then
        echo "nginx needs a default tenant: the 32-character tenant ID (Stellar Cyber, System > Tenants) for clients not in the map."
        DEFAULT_TENANT=$(ask "Default tenant ID: ")
      fi
      if [[ -n "$DEFAULT_TENANT" ]]; then log "Setting up nginx"; setup_nginx
      else echo "    nginx not set up yet (no default tenant): sudo stellar-relay setup nginx --sensor-ip $SENSOR_IP --default-tenant <id>"; fi
    fi
  else
    echo "    Where the logs go is asked in the console, at first sign-in, with the licence."
    echo "    From a shell instead: sudo stellar-relay setup syslog --sensor-ip <sensor>"
  fi
fi

# ---------------------------------------------------------------- summary
IP=$(ip -o -4 route get 1.1.1.1 2>/dev/null | sed -n 's/.*src \([0-9.]*\).*/\1/p' | head -1 || true)
# The address a browser can actually reach. On a cloud instance the interface address is private
# and useless to the person who will open the console, so ask the instance metadata service for the
# public one and print that, with the private address named beside it. Never guessed: if the host
# has no metadata service, or no public address, only the interface address is printed.
public_ip() {
  local tok ip
  tok=$(curl -s --max-time 1 -X PUT "http://169.254.169.254/latest/api/token" \
        -H "X-aws-ec2-metadata-token-ttl-seconds: 60" 2>/dev/null) || return 1
  [[ -n "$tok" ]] || return 1
  ip=$(curl -s --max-time 1 -H "X-aws-ec2-metadata-token: $tok" \
       "http://169.254.169.254/latest/meta-data/public-ipv4" 2>/dev/null) || return 1
  [[ "$ip" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || return 1
  printf '%s' "$ip"
}
PUB_IP=$(public_ip || true)
BROWSER_IP=${PUB_IP:-$IP}
PORT=$(sed -n 's/^LISTEN_PORT=//p' /etc/stellar-lab/relay-monitor.env 2>/dev/null | head -1 || true)
bold "Done"
echo "  Console"
echo "    inside the network:   https://${IP:-<this host>}:${PORT:-8444}"
if [[ -n "$PUB_IP" && "$PUB_IP" != "$IP" ]]; then
  echo "    from outside it:      https://$PUB_IP:${PORT:-8444}"
  echo "    Both reach the same console. The outside address works only while TCP ${PORT:-8444} is allowed to"
  echo "    this host from your browser's address (in AWS, the instance's security group)."
else
  echo "    This host has no public address of its own, so reach it from inside the network or over a VPN."
fi
echo "    The certificate is self-signed, so the browser warns once. Settings -> This console's HTTPS"
echo "    certificate replaces it with one your own CA signs, without a restart."
ADMIN_NAME=$(sed -n 's/^ADMIN_USER=//p' /etc/stellar-lab/relay-monitor.env 2>/dev/null | head -1 || true)
if [[ -f /etc/stellar-lab/relay-monitor.initial-password ]]; then
  echo "  Sign in:   $ADMIN_NAME  (password in /etc/stellar-lab/relay-monitor.initial-password, root only; change: sudo stellar-relay admin-password)"
elif [[ $PRE_PASSWORD == yes ]]; then
  # never silently: someone re-running the installer on a host they did not set up has no way to guess this
  echo "  Sign in:   $ADMIN_NAME  (the password this host already had - it was NOT asked for or changed by this run)"
  echo "             do not know it?  sudo stellar-relay admin-password   sets a new one"
else
  echo "  Sign in:   $ADMIN_NAME  (the password you just set)"
fi
if [[ "$EDITION" == standard ]]; then
  echo "  Manages:   syslog-ng on this host"
  echo "  Firewall:  allow TCP ${PORT:-8444} to the console from your browser, and udp/tcp 514, tcp 601, tcp 6514 from your log sources"
else
  echo "  Methods:   $(for m in syslog nginx; do installed "$(pkg_of $m)" && printf '%s ' "$m"; done)- change any time: sudo stellar-relay add|remove syslog|nginx"
  echo "  Firewall:  allow TCP ${PORT:-8444} to the console from your browser; the log listeners per method: syslog udp/tcp 514, tcp 601, tcp 6514; nginx tcp 80 (443 with --front-tls)"
fi
echo "  Status:    sudo stellar-relay status"
[[ "$METHOD" =~ ^(syslog|both)$ ]] && echo "  Copy:      forwarded records $([[ $DEBUG_LOG == yes ]] && echo "kept in /var/log/stellar-relay/forwarded.jsonl, capped at 200 MB" || echo "NOT kept - the console's Last seen and log explorer show nothing (Sensors page > Copy of forwarded records turns it on)")"
# Why you were not asked anything. Each of these is skipped once answered, which is correct on an upgrade
# and silent to the point of looking broken on a host someone else set up.
if [[ -n "$PRE_EULA" || $PRE_PASSWORD == yes || -n "$PRE_SENSOR" ]]; then
  echo
  bold "Already set up on this host, so these were not asked again"
  [[ -n "$PRE_EULA" ]] && echo "  licence    $PRE_EULA
             read it again: sudo stellar-relay eula"
  [[ $PRE_PASSWORD == yes ]] && echo "  password   set on this host before this run
             change it:     sudo stellar-relay admin-password"
  [[ -n "$PRE_SENSOR" ]] && echo "  sensor     $PRE_SENSOR$([[ -n "$(sed -n 's/^SENSOR_IP_2=//p' /etc/stellar-relay/syslog-ng.env 2>/dev/null | tr -d '\"' | head -1)" ]] && echo " and $(sed -n 's/^SENSOR_IP_2=//p' /etc/stellar-relay/syslog-ng.env | tr -d '\"' | head -1)")
             change it:     the console's Sensors page, or sudo stellar-relay setup syslog --sensor-ip <address>"
  echo "  To be asked everything again, this host has to be put back to before any of it:"
  echo "    sudo stellar-relay reset        keeps the accounts and the audit log (Stellar Cyber staff: needs the internal code)"
fi
if [[ -z "$METHOD" ]]; then
  bold "The console is installed; no relay method is managed yet"
  echo "  This host has neither syslog-ng nor nginx set up for this tool to manage. What to do:"
  echo "    sudo stellar-relay prereq syslog        the steps, with this host checked against each one"
  echo "    sudo stellar-relay add syslog           once syslog-ng is installed and running"
  echo "    sudo stellar-relay setup syslog --sensor-ip <sensor> --debug-log"
  echo "  The console's Settings page says the same thing and checks the host for you."
fi
