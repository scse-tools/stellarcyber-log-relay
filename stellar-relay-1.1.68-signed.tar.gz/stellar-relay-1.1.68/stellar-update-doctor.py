#!/usr/bin/env python3
"""stellar-update-doctor - why is this update still saying "Installing..."?

Run this on the host whose console is stuck. It READS by default and changes nothing; --fix is the
one option that writes, and it only ever does the two things a person would do by hand.

    sudo python3 stellar-update-doctor.py              look, say what is wrong, say what to do
    sudo python3 stellar-update-doctor.py --fix        do it: clear a dead run, finish a half-done dpkg
    sudo python3 stellar-update-doctor.py --log        print the whole update log as well

WHAT MAKES AN UPDATE LOOK STUCK

Up to and including 1.1.3, the installer ran inside the console's own systemd control group. Installing
the console restarts the console, and systemd stops a unit by signalling that whole group - so the
runner was killed in the act. The INSTALLER is a child of it and gets orphaned rather than killed, so
it carries on and writes its whole log, "Done." and all, while the thing that was supposed to record
the result is already gone. The state file is left saying {"running": true} with nobody alive to
correct it, and the page polls that for ever. A complete log is therefore not evidence that the run
finished properly, which is the single most confusing part of this.

So the question this answers is not "what does the log say" but "is anything still running, and did
the version actually change". 1.1.4 and later start the run in a transient unit of its own and decide
the status from the process, so they do not get stuck this way; this script is for the hosts that are
not there yet, and for confirming that one is not.

Standard library only, so it runs on any Ubuntu with python3. Nothing here contacts Stellar Cyber.
"""
import argparse
import glob
import json
import os
import re
import subprocess
import sys
import time

# The same environment names the root helpers use, and for the same reason: so this can be driven
# against a temporary tree in a test. Nothing a person types chooses a path here.
def _p(var, default):
    return os.environ.get(var) or default


RELAY = {
    "name": "Log Relay Manager",
    "dir": _p("UPDATE_DIR", "/var/lib/stellar-relay/update"),
    "service": "relay-monitor",
    "package": "stellar-relay-monitor",
    "env": _p("RELAY_MONITOR_ENV", "/etc/stellar-lab/relay-monitor.env"),
    "port": 8444,
    "upgrader": _p("STELLAR_RELAY_CMD", "/usr/sbin/stellar-relay"),
    "cache": _p("PKG_CACHE", "/var/lib/stellar-relay/packages"),
}
STUDIO = {
    "name": "Ingest Studio",
    "dir": _p("STUDIO_UPDATE_DIR", "/var/lib/stellar-lab/studio-update"),
    "service": "ingest-studio",
    "package": None,                       # a tarball install: no dpkg package
    "env": "/etc/stellar-lab/ingest-studio.env",
    "port": 8443,
    "upgrader": None,
    "cache": None,
}
LAB_VERSION = _p("LAB_ROOT_VERSION", "/opt/stellar-lab/VERSION")

BOLD, RED, AMBER, GREEN, OFF = "\033[1m", "\033[31m", "\033[33m", "\033[32m", "\033[0m"
if not sys.stdout.isatty():
    BOLD = RED = AMBER = GREEN = OFF = ""

FINDINGS = []           # (level, sentence, what to do)


def say(s=""):
    print(s)


def head(s):
    say("")
    say(BOLD + s + OFF)


def note(level, sentence, todo=""):
    FINDINGS.append((level, sentence, todo))
    mark = {"bad": RED + "  !! " + OFF, "warn": AMBER + "  ** " + OFF, "ok": GREEN + "  ok " + OFF}[level]
    say(mark + sentence)
    if todo:
        say("       -> " + todo)


def run(cmd, timeout=20):
    """(rc, output). Never raises: a missing program is an answer, not a crash."""
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except (OSError, subprocess.SubprocessError) as e:
        return 127, str(e)


def read_json(path):
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def read_text(path, tail=0):
    try:
        with open(path, errors="replace") as f:
            t = f.read()
        return t[-tail:] if tail else t
    except OSError:
        return ""


def ago(ts):
    if not ts:
        return "unknown"
    d = max(0, int(time.time() - ts))
    if d < 90:
        return "%d seconds ago" % d
    if d < 5400:
        return "%d minutes ago" % round(d / 60)
    if d < 48 * 3600:
        return "%.1f hours ago" % (d / 3600)
    return "%.1f days ago" % (d / 86400)


def pid_alive(pid):
    try:
        os.kill(int(pid), 0)
        return True
    except (OSError, ValueError, TypeError):
        return False


def unit_alive(unit):
    """1.1.4 and later start the run in a transient systemd unit and record its name; systemd's own answer about
    that unit does not depend on anything the run wrote. Inactive, unknown, or no systemd = not alive."""
    if not unit or not os.path.isdir("/run/systemd/system"):
        return False
    rc, out = run(["systemctl", "show", "-p", "ActiveState", "--", unit])
    return rc == 0 and "ActiveState=active" in out


def installed_version():
    """What this host is running, from the file the console itself reads."""
    t = read_text(LAB_VERSION).strip().splitlines()
    build = t[1].strip() if len(t) > 1 else ""
    return (t[0].strip() if t else ""), (build[6:].strip() if build.startswith("build ") else build)


def dpkg_version(pkg):
    if not pkg:
        return ""
    rc, out = run(["dpkg-query", "-W", "-f=${Version}", pkg])
    return out.strip() if rc == 0 else ""


def installer_processes():
    """Anything that looks like one of our installs, whoever started it. This is the question that
    matters on a host older than 1.1.4, where no pid was ever recorded."""
    rc, out = run(["ps", "-eo", "pid,etimes,args"])
    if rc != 0:
        return []
    want = re.compile(r"(stellar-relay upgrade|stellar-(relay|studio)-update|"
                      r"stellar-(relay|ingest-studio)-[0-9.]+/install\.sh|apt-get install .*stellar-relay)")
    found = []
    for line in out.splitlines()[1:]:
        parts = line.strip().split(None, 2)
        if len(parts) < 3 or str(os.getpid()) == parts[0] or "update-doctor" in parts[2]:
            continue
        if want.search(parts[2]):
            found.append((parts[0], int(parts[1]), parts[2][:120]))
    return found


def apt_busy():
    """dpkg's lock held by anything - unattended-upgrades is the usual one, and it blocks an upgrade
    silently for as long as it runs."""
    holders = []
    for lock in ("/var/lib/dpkg/lock-frontend", "/var/lib/dpkg/lock", "/var/lib/apt/lists/lock"):
        rc, out = run(["fuser", lock])
        if rc == 0 and out.strip():
            holders.append(lock)
    return holders


def check_product(p, args):
    """Everything about one product on this host. Returns True when it is installed here at all."""
    state_path = os.path.join(p["dir"], "state.json")
    if not os.path.isdir(p["dir"]) and not os.path.exists(p["env"]):
        return False

    head("%s" % p["name"])
    ver, build = installed_version() if p is RELAY or os.path.exists(LAB_VERSION) else ("", "")
    dver = dpkg_version(p["package"])
    say("  version on disk   : %s%s" % (ver or "unknown", (" (build %s)" % build) if build else ""))
    if p["package"]:
        say("  dpkg says         : %s" % (dver or "not installed as a package"))
        if ver and dver and ver != dver:
            note("warn",
                 "the files say %s and dpkg says %s." % (ver, dver),
                 "Usually means someone ran the kit installer over a package install. Not itself a "
                 "fault, but an upgrade compares against the dpkg version.")

    rc, out = run(["systemctl", "show", p["service"], "-p", "ActiveState", "-p", "SubState", "-p", "MainPID"])
    st = dict(l.split("=", 1) for l in out.splitlines() if "=" in l) if rc == 0 else {}
    say("  service           : %s %s (pid %s)" % (st.get("ActiveState", "?"), st.get("SubState", ""),
                                                  st.get("MainPID", "?")))
    if st.get("ActiveState") not in (None, "active"):
        note("bad", "%s is not running, so its console cannot answer at all." % p["service"],
             "sudo systemctl status %s   and   sudo journalctl -u %s -n 50" % (p["service"], p["service"]))

    state = read_json(state_path)
    if state is None:
        note("ok", "no update has been started here (no %s)." % state_path)
        return True

    started, action = state.get("started"), state.get("action") or "update"
    if not state.get("running"):
        res = "finished" if state.get("ok") else "did not finish"
        extra = " (cleared by hand, not completed)" if state.get("cleared") else ""
        note("ok", "the last %s %s%s, %s. Nothing is pending." % (action, res, extra, ago(state.get("ended"))))
        return True

    # --- it says it is running. Is it?
    say("  update state      : says RUNNING since %s" % ago(started))
    pidf = os.path.join(p["dir"], "run.pid")
    recorded = (read_text(pidf).strip() or state.get("pid") or "")
    if recorded and not str(recorded).isdigit():
        # 1.1.4 - 1.1.7 started the run with systemd-run, which halved the "$$" in its command line to "$", so the
        # pid file held a literal "$" and the helper wrote every run off as gone within a second (2 Oct 2026)
        note("warn", "the run's pid file holds %r, which is not a pid: a 1.1.4-1.1.7 helper under systemd." % recorded,
             "Nothing to fix by hand; 1.1.8 asks systemd about the unit instead. This script does the same below.")
    procs = installer_processes()
    unit_up = unit_alive(state.get("unit"))
    alive = bool(recorded and pid_alive(recorded)) or bool(procs) or unit_up

    if alive:
        who = ("process %s" % recorded) if recorded and pid_alive(recorded) else \
              ("systemd unit %s" % state.get("unit")) if unit_up and not procs else \
              (", ".join("pid %s (%s minutes)" % (q[0], round(q[1] / 60)) for q in procs))
        note("warn", "an install really IS still running: %s." % who,
             "Leave it. Watch it with: sudo tail -f %s" % os.path.join(p["dir"], "update.log"))
        locks = apt_busy()
        if locks:
            note("warn", "apt's lock is held (%s), which is usually unattended-upgrades." %
                 ", ".join(os.path.basename(l) for l in locks),
                 "It waits up to 15 minutes. Check with: ps -ef | grep -E 'apt|dpkg|unattended'")
        return True

    # --- nothing is running, so the run ended without recording how
    note("bad", "nothing is installing: the run ended without recording a result, and the page will "
                "say \"Installing...\" until that is cleared.",
         "This is the 1.1.3-and-earlier fault. --fix clears it; 1.1.4 and later decide from the "
         "process and never get stuck this way.")

    log = read_text(os.path.join(p["dir"], "update.log"))
    target = state.get("target") or ""
    if not target:                       # older state files did not record it; the bundle's name will do
        meta = read_json(os.path.join(p["dir"], "bundle.json")) or {}
        m = re.search(r"(\d+\.\d+\.\d+)", meta.get("name", ""))
        target = m.group(1) if m else ""
    if target:
        got = (dver or ver) == target
        note("ok" if got else "warn",
             "it was installing %s and this host is on %s." % (target, dver or ver or "an unknown version"),
             "" if got else "So it did not get there. The log below says how far it reached.")

    tail = "\n".join(log.splitlines()[-12:])
    if tail:
        say("")
        say("  last lines of %s:" % os.path.join(p["dir"], "update.log"))
        for l in tail.splitlines():
            say("    " + l)
    if args.log and log:
        say("")
        say("  --- the whole log ---")
        say(log)
    return True


def check_dpkg():
    head("Debian packages")
    rc, out = run(["dpkg", "--audit"])
    if rc == 127 or "No such file" in out:
        say("  there is no dpkg on this host, so there are no packages to check.")
        return False
    if rc != 0:
        note("warn", "dpkg --audit could not be run (exit %d)." % rc, out.strip().splitlines()[:1] and
             out.strip().splitlines()[0] or "")
        return False
    if out.strip():
        note("bad", "dpkg has a package it did not finish configuring.", "sudo dpkg --configure -a")
        for l in out.strip().splitlines()[:8]:
            say("      " + l)
        return True
    note("ok", "no package is left half-done (dpkg --audit is clean).")
    return False


def check_can_upgrade():
    """The other reason an upgrade stops dead on 1.1.3 and earlier: an empty package cache plus a
    cmd_upgrade whose `ls` ends the script under `set -euo pipefail`, silently, after "Backup first"."""
    if not os.path.exists(RELAY["upgrader"]):
        return
    head("Can this host run its own upgrade?")
    ver = dpkg_version(RELAY["package"]) or installed_version()[0]
    cached = glob.glob(os.path.join(RELAY["cache"] or "", "%s_%s_all.deb" % (RELAY["package"], ver)))
    src = read_text(RELAY["upgrader"])
    guarded = "head -1 || true)" in src if "PKG_CACHE" in src else True
    if cached:
        note("ok", "a copy of %s is cached, so an upgrade can put it back if one fails." % ver)
    elif guarded:
        note("warn", "no copy of %s is cached here." % ver,
             "Not fatal on this version: an upgrade runs, it just has no automatic way back.")
    else:
        note("bad", "no copy of %s is cached AND the stellar-relay installed here stops silently in "
                    "that case, just after \"Backup first\" - an upgrade would appear to hang." % ver,
             "Put the running version's .deb files in %s, or take the fixed script out of the new "
             "bundle: tar xzf BUNDLE && dpkg-deb --fsys-tarfile stellar-relay-monitor_*_all.deb | "
             "tar -xO ./usr/sbin/stellar-relay | sudo tee %s >/dev/null"
             % (RELAY["cache"], RELAY["upgrader"]))


def do_fix(products, dpkg_needs_configure):
    head("Fixing")
    did = []
    for p in products:
        state_path = os.path.join(p["dir"], "state.json")
        state = read_json(state_path)
        if not state or not state.get("running"):
            continue
        if installer_processes() or pid_alive(read_text(os.path.join(p["dir"], "run.pid")).strip()) or unit_alive(state.get("unit")):
            note("warn", "%s: an install is still running, so nothing was cleared." % p["name"],
                 "Wait for it, then run this again.")
            continue
        state.update({"running": False, "cleared": True, "ended": state.get("ended") or time.time()})
        try:
            tmp = state_path + ".tmp"
            with open(tmp, "w") as f:
                json.dump(state, f)
            os.chmod(tmp, 0o600)
            os.replace(tmp, state_path)
        except OSError as e:
            note("bad", "%s: could not write %s (%s)." % (p["name"], state_path, e), "Run this with sudo.")
            continue
        try:
            os.remove(os.path.join(p["dir"], "run.pid"))
        except OSError:
            pass
        did.append(p["name"])
        note("ok", "%s: cleared the stuck update state. Reload the page." % p["name"])

    if dpkg_needs_configure:
        say("  running: dpkg --configure -a")
        rc, out = run(["dpkg", "--configure", "-a"], timeout=600)
        for l in (out or "").strip().splitlines()[:20]:
            say("    " + l)
        note("ok" if rc == 0 else "bad",
             "dpkg --configure -a %s." % ("finished" if rc == 0 else "failed (rc %d)" % rc),
             "" if rc == 0 else "Send the lines above to Stellar Cyber.")
        did.append("dpkg")
    if not did:
        note("ok", "there was nothing to fix.")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--fix", action="store_true",
                    help="clear an update that is no longer running, and finish a half-done dpkg. "
                         "Never kills anything and never installs anything.")
    ap.add_argument("--log", action="store_true", help="print the whole update log, not just the end")
    args = ap.parse_args()

    say(BOLD + "Stellar Cyber update doctor" + OFF)
    say("  host: %s   %s" % (os.uname().nodename, time.strftime("%Y-%m-%d %H:%M:%S %Z")))
    if os.geteuid() != 0:
        say(AMBER + "  (not root: some files cannot be read, and --fix cannot write. Use sudo.)" + OFF)

    here = [p for p in (RELAY, STUDIO) if check_product(p, args)]
    if not here:
        say("")
        say("  Neither the Log Relay Manager nor Ingest Studio is installed on this host.")
        return 0
    needs_configure = check_dpkg()
    check_can_upgrade()

    if args.fix:
        do_fix(here, needs_configure)
        say("")
        say("Run it again with no options to confirm.")
        return 0

    head("What to do")
    bad = [f for f in FINDINGS if f[0] == "bad"]
    warn = [f for f in FINDINGS if f[0] == "warn"]
    if not bad and not warn:
        say("  Nothing is wrong here. No update is stuck and no package is half-done.")
        return 0
    n = 0
    for level, sentence, todo in bad + warn:
        if not todo:
            continue
        n += 1
        say("  %d. %s" % (n, sentence))
        say("     %s" % todo)
    if any("clears it" in f[2] or "half-done" in f[1] for f in bad):
        say("")
        say("  Most of the above is done for you by:")
        say("     sudo python3 %s --fix" % os.path.basename(sys.argv[0]))
    say("")
    # the log and the service of what is ON THIS HOST: naming the relay's on a sender with no relay
    # sends the reader to a file that does not exist, which is where they stop
    say("  If it still will not update, send Stellar Cyber the output of this script and:")
    for p in here:
        say("     sudo tail -200 %s" % os.path.join(p["dir"], "update.log"))
        say("     sudo journalctl -u %s -n 100 --no-pager" % p["service"])
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
