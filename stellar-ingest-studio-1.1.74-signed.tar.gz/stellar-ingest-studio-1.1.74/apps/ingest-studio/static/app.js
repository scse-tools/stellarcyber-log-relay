(() => {
  const { $, $$, esc, api, toast, fmt, pill, modal } = Lab;
  const S = { sources: [], paths: {}, vendors: {}, presets: {}, mixes: [], kinds: [], settings: {}, picked: new Set(), preset: "smoke", run: null, timer: null, relayOk: null };
  const PATH_SHORT = { syslogng: "syslog-ng", nginx: "nginx", raw: "direct to a sensor" };
  // ---- editions. The standard Studio defines log sources and sends their logs to the syslog-ng relay's
  // listeners, like a real device, and has NO management connection to the relay: nothing is read back, no
  // packet capture. The advanced Studio READS the relay (status, its map, what it forwarded) and may ask it
  // for a packet capture around a run. Neither edition writes the relay's configuration (Paul, 24 Sep 2026):
  // the tenant a device lands in and the sensor port it is forwarded to are the relay's own log-source row.
  const ED = { edition: "standard", advanced: false, known: false };
  const ADV = () => ED.advanced;
  function applyEdition() {
    document.querySelectorAll("[data-edition]").forEach(el => {
      const want = el.dataset.edition;
      el.classList.toggle("hidden", ED.known && (want === "advanced" ? !ED.advanced : ED.advanced));
    });
    // A column whose heading this edition does not have must lose its cells too, or every row below it
    // shifts one to the left. The heading's index is the column's index.
    document.querySelectorAll("table").forEach(t => {
      const hs = [...t.querySelectorAll("thead th")];
      hs.forEach((h, i) => {
        if (!h.dataset.edition) return;
        const hide = ED.known && (h.dataset.edition === "advanced" ? !ED.advanced : ED.advanced);
        h.classList.toggle("hidden", hide);
        // Only when the row still HAS that cell: a renderer that already leaves it out makes the row
        // shorter, and hiding by index would then hide the wrong column.
        t.querySelectorAll("tbody tr").forEach(tr => {
          if (tr.children.length !== hs.length) return;
          const c = tr.children[i]; if (c && !c.hasAttribute("colspan")) c.classList.toggle("hidden", hide);
        });
      });
    });
  }
  const TRANSPORT_LABEL = { udp514: "UDP 514", tcp514: "TCP 514", tcp601: "TCP 601 (RFC 6587)", tls6514: "TLS 6514", http80: "HTTP 80", https443: "HTTPS 443",
                            tls: "TLS (parser port)", tcp: "TCP (parser port)", udp: "UDP (parser port)" };
  const NO_RELAY = (p) => p === "raw";              // never touches the relay: nothing to look up there, nothing to confirm
  const OWN_TENANT = "sensor's own tenant";
  const identityLabel = (s) => s.identity && s.identity.field ? `${s.identity.field}=${s.identity.value == null ? "(varies)" : s.identity.value}` : "";
  const vendorTag = (v, f) => `<span class="tag vendor-${esc(v)}">${esc(S.vendors[v] || v)}${f && f !== "syslog" ? " · " + esc(f.toUpperCase()) : ""}</span>`;
  const pathLabel = (s) => `${PATH_SHORT[s.path] || s.path} · ${TRANSPORT_LABEL[s.transport] || s.transport}`;
  const LIVE = (st) => st === "running" || st === "confirming";
  // a run a person ends is STOPPED, which is what the button says (Paul, 4 Oct 2026: "instead of cancel when sending
  // logs, make it a stop button"); the API keeps its `cancelled` value, this is the word on the page
  const STATUS_WORD = (st) => st === "cancelled" ? "stopped" : st;
  // a server note is written to be read inside another sentence; on its own it starts with a capital and ends with a period
  const sentence = (t) => { t = String(t || "").trim(); return t ? t[0].toUpperCase() + t.slice(1) + (/[.!?]$/.test(t) ? "" : ".") : ""; };
  // a length of time the way a clock reads it - 0:42, 12:05, 1:02:09 - for a run that has no percentage
  const clock = (s) => { s = Math.max(0, Math.round(s || 0)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
    return h ? `${h}:${String(m).padStart(2, "0")}:${String(x).padStart(2, "0")}` : `${m}:${String(x).padStart(2, "0")}`; };
  const statusPill = (st) => pill({ running: "info", confirming: "info", done: "ok", cancelled: "warn", failed: "bad" }[st] || "idle", STATUS_WORD(st));
  const tenantColor = (hex) => `hsl(${parseInt((hex || "0").slice(0, 4), 16) % 360} 60% 55%)`;
  const tenantDot = (hex) => `<span class="tenantdot" style="background:${tenantColor(hex)}"></span>`;
  // What the RELAY says about a source, read from its map (advanced) - never something this Studio wrote.
  // {known:false} = could not be asked; {mapped:false} = not on the relay, lands in the catch-all;
  // {mapped:true, tenant, tenant_label, port} = the relay's own row for this device.
  const rel = (s) => s.relay || {};
  // A direct source is sent as-is (it lands in the sensor's own tenant) or wrapped with a tenant set here.
  const WRAPPED = (s) => NO_RELAY(s.path) && s.delivery === "tenant" && !!(s.tenant_id || s.tenant);
  const directTenant = (s) => s.tenant_id || s.tenant || "";
  const sensorOf = (s) => (S.sensors || []).find(x => String(x.n) === String(s.sensor || "1"));
  const sensorWords = (s) => { const x = sensorOf(s); return `sensor ${s.sensor || "1"}${x && x.address ? " " + x.address : x ? " (no address yet)" : " (not on Settings → Sensors)"}`; };
  const relayTenant = (s) => { if (NO_RELAY(s.path)) return WRAPPED(s) ? fmt.short(directTenant(s)) : OWN_TENANT;
    const r = rel(s); return r.mapped ? (r.tenant_label || (r.tenant || "").slice(0, 12) + "…") : r.mapped === false ? "catch-all tenant" : "decided by the relay"; };
  // where a direct source's logs land: its sensor, and as-is or under the tenant it carries
  const directCell = (s) => `${esc(sensorWords(s))}<div class="small faint">${WRAPPED(s)
      ? `${tenantDot(directTenant(s))}wrapped, tenant <span class="mono">${esc(fmt.short(directTenant(s)))}</span>${(s.wrapper_notes || []).length ? ` · <span class="warn" title="${esc(s.wrapper_notes.join(" "))}">not documented for this port</span>` : ""}`
      : "as-is: the sensor's own tenant"}</div>`;
  // the "Where its logs land" cell, in every table that has one: the relay's row for a relay-path source, the
  // sensor and the tenant (or none) for a direct one
  function onRelayCell(s) {
    if (NO_RELAY(s.path)) return directCell(s);
    if (!ADV()) return `<span class="faint">created there, by a person</span>`;
    const r = rel(s);
    if (!r.known) return `${pill("idle", "not read")}<div class="small faint">${esc((r.error || "the relay could not be asked").slice(0, 90))}</div>`;
    if (!r.mapped) return `${pill("warn", "not on the relay")}<div class="small faint">its logs land in the relay's catch-all tenant until it is added there</div>`;
    return `${tenantDot(r.tenant)}${esc(r.tenant_label || fmt.short(r.tenant))} <span class="faint mono small">:${esc(r.port || "")}</span><div class="small faint">the relay's row, by ${esc(r.by || "address")}${r.selector && r.by !== "address" ? ` ${esc(r.selector)}` : ""}</div>`;
  }
  // Build the diagram data from what Studio knows. ids: which sources to draw (null = all enabled). run: live snapshot or null.
  function topoData(ids, run, relayStatus) {
    const st = S.settings || {}, r = relayStatus || S.relayStatus || {};
    const svc = Object.fromEntries((r.services || []).map(x => [x.name, x]));
    const per = (run && run.per_source) || {};
    const pick = S.sources.filter(x => ids ? ids.has(x.id) : x.enabled);
    // The boxes on the right. A direct source lands on ITS sensor (Settings -> Sensors); a relay-path source on the
    // sensor the relay chose. When the relay was read and something goes through it, the boxes are the relay's own
    // sensors and a direct source is found among them by address (or drawn as a box of its own); otherwise they are
    // this Studio's sensors. Nothing drawn going through the relay = no relay box at all.
    const viaRelay = pick.some(x => !NO_RELAY(x.path));
    const mine = (S.sensors || st.sensors || []);
    const boxOf = (m) => ({ name: "Modular Sensor", ip: m.address || "address not set (Settings → Sensors)", tls: m.transport === "tls", num: m.n });
    let sensors, numFor;
    if (viaRelay && r.sensors && r.sensors.length) {
      sensors = r.sensors.map((x, i) => ({ name: "Modular Sensor", ip: x.ip, role: x.role, tls: (mine[0] || {}).transport !== "tcp", num: x.n || i + 1 }));
      numFor = (x) => {
        if (!NO_RELAY(x.path)) return rel(x).sensor || "1";
        const me = sensorOf(x);
        const hit = me && sensors.find(b => b.ip === me.address);
        if (hit) return String(hit.num);
        const k = "d" + (x.sensor || "1");
        if (me && !sensors.some(b => String(b.num) === k)) sensors.push(Object.assign(boxOf(me), { num: k, title: `Sensor ${me.n} (this Studio's)` }));
        return k;
      };
    } else if (viaRelay && !pick.some(x => NO_RELAY(x.path))) {
      // through the relay only, and the relay not read: which sensor is the relay's choice
      sensors = [{ name: "Modular Sensor", ip: (mine[0] || {}).address || "(known to the relay)", tls: (mine[0] || {}).transport !== "tcp", num: 1 }];
      numFor = () => "1";
    } else {
      sensors = (mine.length ? mine : [{ n: 1, address: "", transport: "tls" }]).map(boxOf);
      numFor = (x) => NO_RELAY(x.path) ? String(x.sensor || "1") : (rel(x).sensor || "1");
    }
    const sources = pick.map(x => {
        const live = per[String(x.id)];
        const confirmed = run && run.relay ? confirmedFor(x, run.relay) : 0;
        // The nginx path posts a webhook JSON document, not this vendor's syslog: the diagram must say
        // what is on the wire, or a search for the vendor finds nothing and reads as a tenant failure.
        const httpJson = x.path === "nginx";
        const rr = rel(x);
        return { name: x.name, vendor: httpJson ? "JSON document" : (x.origin?.vendor || x.vendor), product: httpJson ? "not " + (x.origin?.vendor || x.vendor) + " syslog" : (x.origin?.product || ""),
                 format: httpJson ? "" : (x.format || "syslog"), ip: x.bind_ip, transport: (TRANSPORT_LABEL[x.transport] || x.transport) + (x.client_cert ? " · client cert" : ""), identity: httpJson ? "" : identityLabel(x),
                 lane: x.path === "nginx" ? "nginx" : x.path === "raw" ? "raw" : "syslog", tenant: relayTenant(x),
                 tenantHex: WRAPPED(x) ? directTenant(x) : rr.mapped ? rr.tenant : "", wrapped: WRAPPED(x),
                 port: x.sensor_port, enabled: !!x.enabled, sensor: numFor(x),
                 live: live ? { sent: live.sent, failed: live.failed, confirmed } : null };
    });
    // The relay's sensors and this Studio's are numbered separately: when both are in one picture, each box says whose it is.
    if (sensors.some(b => String(b.num).startsWith("d"))) sensors.forEach(b => { if (!b.title) b.title = `Sensor ${b.num} (the relay's)`; });
    return {
      sender: { name: "Sender · " + ($("#hostname").textContent || "this host"), sub: "LOG SOURCES (SIMULATED FIREWALLS)", ip: (S.settings.host_ips || []).filter(h => h.iface !== "lo").map(h => h.ip).slice(0, 3).join("  ") },
      relay: { name: r.host ? "Relay · " + r.host : "Log relay", ip: st.relay_ip || "relay address not set", syslogOk: r.ok ? !!svc["syslog-ng"]?.active : undefined, nginxOk: r.ok ? !!svc.nginx?.active : undefined,
               syslogInstalled: r.methods ? !!r.methods.syslog?.installed : undefined, nginxInstalled: r.methods ? !!r.methods.nginx?.installed : undefined,
               nginxPort: st.nginx_port || 80, nginxHidden: !ADV(), syslogPorts: `udp/tcp ${r.settings?.listen_port || 514} · tcp 601 · tls 6514`, debugLog: r.ok ? r.settings?.debug_log === "yes" : undefined,
               hidden: pick.length > 0 && !viaRelay },
      sensors, sources,
    };
  }
  // what the relay reported forwarding FROM this source's address: the relay's activity entries carry the
  // source address of every batch, which is the one thing a device and its relay row have in common
  const confirmedFor = (src, relay) => (relay && relay.entries || []).filter(e => e.srcip && e.srcip === src.bind_ip).reduce((a, e) => a + (e.count || 0), 0);

  // ---------------------------------------------------------------- loaders
  async function loadCore() {
    const [src, pre] = await Promise.all([api("GET", "/api/sources"), api("GET", "/api/presets")]);
    S.sources = src.sources; S.paths = src.paths; S.vendors = src.vendors; S.formats = src.formats || {};
    S.parserPort = src.parser_port || {}; S.cefPort = src.cef_port || 5143; S.rawVendors = src.raw_vendors || []; S.deviceFields = src.device_fields || {};
    S.devType = src.dev_type || {};
    S.webhookSources = src.webhook_sources || {};
    // the direct path: this Studio's sensors, the two ways to send, and what is not documented per vendor/format
    S.sensors = src.sensors || []; S.deliveries = src.deliveries || {}; S.wrapperNotes = src.wrapper_notes || {};
    ED.edition = src.edition || "standard"; ED.advanced = !!src.advanced; ED.known = true;
    S.managerNote = src.manager_note || ""; S.onRelayNote = src.on_relay_note || ""; S.relayError = src.relay_error || "";
    S.presets = pre.presets; S.mixes = pre.mixes; S.kinds = pre.kinds;
    applyEdition();
  }
  async function loadSettings() { S.settings = await api("GET", "/api/settings"); if (S.settings.sensors) S.sensors = S.settings.sensors; }

  // ---------------------------------------------------------------- dashboard
  async function pageDashboard() {
    await Promise.all([loadCore(), loadSettings()]);
    $("#d-sources").textContent = S.sources.length;
    const byPath = {}; S.sources.forEach(s => byPath[PATH_SHORT[s.path]] = (byPath[PATH_SHORT[s.path]] || 0) + 1);
    $("#d-sources-d").textContent = Object.entries(byPath).map(([k, v]) => `${v} via ${k}`).join(", ") || "none defined";
    const relaySrcs = S.sources.filter(s => !NO_RELAY(s.path));
    const known = relaySrcs.filter(s => rel(s).known), mapped = known.filter(s => rel(s).mapped);
    $("#d-mapped").textContent = known.length ? `${mapped.length} / ${relaySrcs.length}` : "…";
    $("#d-mapped-d").textContent = !relaySrcs.length ? "no relay-path log sources yet" : !known.length ? (S.relayError ? "the relay could not be asked" : "reading the relay's map")
      : mapped.length === relaySrcs.length ? "every device has a row on the relay" : `${relaySrcs.length - mapped.length} land in the catch-all until added there`;

    const runs = await api("GET", "/api/runs?limit=8");
    const day = Date.now() / 1000 - 86400;
    const recent = runs.runs.filter(r => r.started > day);
    $("#d-runs").textContent = recent.length;
    $("#d-runs-d").textContent = recent.length ? `${fmt.n(recent.reduce((a, r) => a + (r.sent || 0), 0))} events sent` : "nothing sent today";
    $("#d-runs-tbl").innerHTML = runs.runs.length ? runs.runs.map(r => runRow(r, true)).join("") : `<tr><td colspan="7" class="empty">No runs yet</td></tr>`;
    $$("#d-runs-tbl tr.clickable").forEach(tr => tr.onclick = () => openRun(+tr.dataset.id));

    // topology: what this host knows (sources, sensor); relay lanes updated below once status arrives
    const st = S.settings;
    const last = runs.runs.find(r => r.status !== "running" && r.status !== "confirming");
    const lastRun = last && last.started > Date.now() / 1000 - 300 ? { per_source: last.results || {}, relay: last.relay } : null;
    const drawTopology = (relayStatus) => $("#topology").innerHTML = Lab.topology(topoData(null, lastRun, relayStatus));
    drawTopology();
    const unmapped = known.filter(s => !rel(s).mapped);
    // the steps follow what the log sources need: the relay only when one goes through it, a sensor address only
    // when one goes straight to a sensor
    const direct = S.sources.filter(s => NO_RELAY(s.path));
    const noAddr = direct.filter(s => { const x = sensorOf(s); return !x || !x.address; });
    const steps = [
      ...(relaySrcs.length || !S.sources.length ? [{ ok: !!st.relay_ip, t: "Point at the relay", p: "The log relay's IP or host name, in Settings.", href: "#/settings" }] : []),
      ...(direct.length ? [{ ok: !noAddr.length, t: "Give each sensor its address", p: noAddr.length ? `Not sendable yet, no sensor address: ${noAddr.map(s => s.name).join(", ")}.` : "Every direct log source's sensor has an address. Each one has a Test the connection button.", href: "#/settings?view=sensors" }] : []),
      ...(ADV() && relaySrcs.length ? [{ ok: !!st.relay_monitor_url && st.relay_token, t: "Connect the log relay manager", p: "URL and API token, so this Studio can read the relay's map and what it forwarded, and capture packets around a run. It never changes the relay.", href: "#/settings" }] : []),
      { ok: S.sources.length > 0, t: "Create log sources", p: "One per firewall, configured as the real device would be: through the relay, or straight to a sensor.", href: "#/sources" },
      ...(!relaySrcs.length ? [] : ADV()
        ? [{ ok: known.length === relaySrcs.length && !unmapped.length, t: "Every log source exists on the relay", p: !known.length ? "The relay's map could not be read." : unmapped.length ? `Not on the relay yet: ${unmapped.map(s => s.name).join(", ")}. Add them there, in the Log Relay Manager's Log sources & tenants.` : "The relay has a row for every device that goes through it.", href: "#/sources" }]
        : [{ ok: true, t: "Create the same log sources on the relay", p: "In the Log Relay Manager, by a person: that row decides the tenant and the sensor port. This Studio cannot see or change it.", href: "#/sources" }]),
      { ok: S.sources.every(s => s.ip_present), t: "Source IPs present on this host", p: S.sources.filter(s => !s.ip_present).map(s => `${s.name} (${s.bind_ip})`).join(", ") || "All bind IPs are configured.", href: "#/sources" },
    ];
    // the number and the title are the links; the sentence under them is text a person can select and copy
    // (a whole step as one link turned every drag into dragging the link - Paul, 9 Oct 2026)
    $("#checklist").innerHTML = steps.map((s, i) => `<div class="step ${s.ok ? "done" : "todo"}"><a class="num" href="${s.href}">${s.ok ? "✓" : i + 1}</a><div><a class="step-t" href="${s.href}"><b>${esc(s.t)}</b></a><p>${esc(s.p)}</p></div></div>`).join("");

    // relay
    if (!ADV() || !st.relay_monitor_url) {
      if ($("#d-relay")) { $("#d-relay").textContent = "not set"; $("#d-relay-d").textContent = "configure in Settings"; }
      $("#d-relay-pill").className = "pill idle"; $("#d-relay-pill").textContent = "not configured";
      $("#relaybox").innerHTML = `<div class="empty">${ADV() ? "Log Relay Manager not configured" : "This Studio has no management connection to the relay. Open the Log Relay Manager on the relay itself."}</div>`;
      return;
    }
    const r = await api("GET", "/api/relay/status");
    if (!r.ok) {
      $("#d-relay").textContent = "offline"; $("#d-relay-d").textContent = r.error.slice(0, 60);
      $("#d-relay-pill").className = "pill bad"; $("#d-relay-pill").textContent = "unreachable";
      $("#relaybox").innerHTML = `<div class="empty">${esc(r.error)}</div>`; return;
    }
    const svc = Object.fromEntries((r.services || []).map(s => [s.name, s]));
    S.relayStatus = r; drawTopology(r);
    const mstate = (k, name) => r.methods && r.methods[k] && !r.methods[k].installed ? `${name} not installed` : `${name} ${svc[name]?.state || "?"}`;
    $("#d-relay").textContent = r.host || "ok"; $("#d-relay-d").textContent = `${mstate("syslog", "syslog-ng")}, ${mstate("nginx", "nginx")}`;
    $("#d-relay-pill").className = "pill ok"; $("#d-relay-pill").textContent = "connected · read only";
    const conns = r.sensor_connections || [];
    // a destination the relay cannot reach accepts records and delivers none: worth saying here, because
    // from this host the send looks perfect (the relay buffers them until the port opens).
    const stuck = (r.syslogng?.destinations || []).filter(d => d.problem);
    $("#relaybox").innerHTML = [
      ["syslog-ng", svc["syslog-ng"]?.state || "?"], ["nginx", svc.nginx?.state || "?"],
      ["sensor connections", conns.length], ["forwarded (syslog-ng)", fmt.n(r.totals?.syslog || 0)],
      ["proxied (nginx)", fmt.n(r.totals?.http || 0)], ["http errors", fmt.n(r.totals?.http_errors || 0)],
      ...(stuck.length ? [["not reaching the sensor", stuck.map(d => ":" + d.port).join(", ")]] : []),
    ].map(([l, v]) => `<div class="b"><div class="l">${esc(l)}</div><div class="v">${esc(v)}</div></div>`).join("");
    const feed = await api("GET", "/api/relay/feed?n=8");
    $("#d-feed").innerHTML = (feed.entries || []).length ? feed.entries.slice().reverse().map(feedRow).join("") : `<div class="empty">No activity yet</div>`;
  }

  function feedRow(e) {
    const ok = e.ok !== false;
    return `<div class="ev ${ok ? "" : "bad"}"><span class="t">${fmt.time(e.ts)}</span><span>${fmt.n(e.count)} × ${esc(e.label || e.kind)} from <code>${esc(e.srcip)}</code> → ${tenantDot(e.tenant)}${esc(e.tenant_label || e.tenant || "?")}${e.kind === "http" ? ` <span class="faint">(${e.status}/${esc(e.up_status)})</span>` : ` <span class="faint">:${e.port}</span>`}</span><span class="faint small">${fmt.bytes(e.bytes)}</span></div>`;
  }

  function runRow(r, compact) {
    const srcs = (r.params?.sources || []);
    const relayN = (r.relay?.summary || []).reduce((a, s) => a + s.count, 0);
    const needsRelay = srcs.some(s => !NO_RELAY(s.path));
    const relayCell = !needsRelay ? `<span class="faint">n/a (direct)</span>` : LIVE(r.status) ? `<span class="faint">…</span>` : relayN ? pill(relayN >= r.sent ? "ok" : "warn", `${fmt.n(relayN)} forwarded`) : pill("bad", "none seen");
    const srcCell = srcs.map(s => `<span class="chip">${esc(s.name)}${s.identity ? ` <span class="faint">${esc(s.identity)}</span>` : ""}</span>`).join("");
    if (compact) return `<tr class="clickable" data-id="${r.id}"><td>#${r.id} <span class="faint small">${fmt.ago(r.started)}</span></td><td>${srcCell}</td><td class="small">${[...new Set(srcs.map(s => PATH_SHORT[s.path]))].join(", ")}</td><td class="num">${fmt.n(r.sent)}</td><td class="num">${r.failed ? `<span style="color:var(--bad)">${fmt.n(r.failed)}</span>` : 0}</td>${ADV() ? `<td>${relayCell}</td>` : ""}<td>${statusPill(r.status)}</td></tr>`;
    return `<tr class="clickable runrow" data-id="${r.id}"><td>#${r.id}<br><span class="sp">${fmt.dt(r.started)}</span></td><td>${esc(r.user || "")}</td><td>${srcCell}</td><td class="small">${esc(r.params?.mix || "")}${r.params?.kind ? ` / ${esc(r.params.kind)}` : ""}<br><span class="sp">${fmt.n(r.params?.count)} each${r.params?.rate ? ` @ ${r.params.rate}/s` : ""}${r.params?.size ? `, ${fmt.bytes(r.params.size)}` : ""}</span></td><td class="num">${fmt.n(r.sent)}</td><td class="num">${r.failed ? `<span style="color:var(--bad)">${fmt.n(r.failed)}</span>` : 0}</td>${ADV() ? `<td>${relayCell}</td>` : ""}<td>${statusPill(r.status)}</td><td class="small muted">${esc(r.note || "")}</td></tr>`;
  }

  // ---------------------------------------------------------------- send
  async function pageSend() {
    await Promise.all([loadCore(), loadSettings()]);
    // presets
    $("#presets").innerHTML = Object.entries(S.presets).map(([k, p]) => `<button class="preset ${k === S.preset ? "active" : ""}" data-k="${k}"><b>${esc(p.label)}</b><span>${esc(p.desc)}</span></button>`).join("");
    $$("#presets .preset").forEach(b => b.onclick = () => applyPreset(b.dataset.k));
    if (!$("#f-mix").options.length) {
      $("#f-mix").innerHTML = S.mixes.map(m => `<option value="${m}">${m}</option>`).join("");
      $("#f-kind").innerHTML += S.kinds.map(k => `<option value="${k}">${k}</option>`).join("");
      applyPreset(S.preset);
    }
    // sources
    if (!S.sources.length) { $("#srclist").innerHTML = `<div class="empty">No log sources yet. <a href="#/sources">Create one</a>.</div>`; }
    else {
      // every enabled firewall is ticked on the FIRST visit only: "none" empties the set and redraws the page, and
      // re-ticking everything whenever the set is empty undid "none" before anyone could see it
      if (!S.pickedInit) { S.pickedInit = true; if (!S.picked.size) S.sources.filter(s => s.enabled).forEach(s => S.picked.add(s.id)); }
      // the right-hand side of each row is what the RELAY says about the device (its row's tenant and port,
      // or that it has none), because that is where its logs will land - nothing about it is set here
      const onRelay = (s) => {
        if (NO_RELAY(s.path)) return `<span class="faint">→ sensor ${esc(s.sensor || "1")} :${esc(s.sensor_port)} ${WRAPPED(s) ? `wrapped, tenant ${esc(fmt.short(directTenant(s)))}` : "as-is"}</span>`;
        const r = rel(s);
        if (!ADV()) return `<span class="faint">→ the relay decides</span>`;
        if (!r.known) return `<span class="faint">→ relay not read</span>`;
        if (!r.mapped) return `${pill("warn", "not on the relay")}`;
        return `${tenantDot(r.tenant)}${esc(r.tenant_label || fmt.short(r.tenant))} <span class="faint mono small">:${esc(r.port)}</span>`;
      };
      $("#srclist").innerHTML = S.sources.map(s => `<label class="srcpick ${S.picked.has(s.id) ? "on" : ""} ${s.enabled ? "" : "off"}" data-id="${s.id}"><input type="checkbox" ${S.picked.has(s.id) ? "checked" : ""}><span class="n"><b>${esc(s.name)} ${vendorTag(s.vendor, s.format)}</b><small>${esc(pathLabel(s))} · from ${esc(s.bind_ip || "default IP")}${identityLabel(s) ? ` · ${esc(identityLabel(s))}` : ""}</small></span><span>${onRelay(s)} <button class="btn sm" data-edit="${s.id}" title="Change this firewall's path or transport without leaving this page">Edit</button></span></label>`).join("");
      // The row is a <label>, so a click anywhere in it toggles the checkbox: the Edit button has to
      // stop that before it opens the dialog, or ticking and editing fight each other.
      $$("#srclist [data-edit]").forEach(b => b.onclick = (e) => {
        e.preventDefault(); e.stopPropagation();
        const src = S.sources.find(x => x.id === +b.dataset.edit);
        if (src) sourceModal(src);
      });
      $$("#srclist .srcpick input").forEach(cb => cb.onchange = () => { const id = +cb.closest(".srcpick").dataset.id; cb.checked ? S.picked.add(id) : S.picked.delete(id); cb.closest(".srcpick").classList.toggle("on", cb.checked); hint(); drawSendTopo(); });
    }
    hint(); drawSendTopo();
    if (ADV() && !S.relayStatus && S.settings.relay_monitor_url) { try { S.relayStatus = await api("GET", "/api/relay/status"); drawSendTopo(); } catch (e) { /* offline */ } }
    // resume a running run if any
    const rr = await api("GET", "/api/runs?limit=1");
    if (rr.active.length && !S.run) watchRun(rr.active[0].id);
  }
  function drawSendTopo(run) {
    if (!$("#topology-send")) return;
    $("#topology-send").innerHTML = Lab.topology(topoData(S.picked.size ? S.picked : new Set(), run || S.lastRun || null));
    $("#topo-send-note").textContent = run ? `run #${run.id}: ${run.status}` : "ticked firewalls are drawn; lanes animate while a run is sending";
  }
  function applyPreset(k) {
    S.preset = k; const p = S.presets[k]; if (!p) return;
    $$("#presets .preset").forEach(b => b.classList.toggle("active", b.dataset.k === k));
    $("#f-count").value = p.count; $("#f-rate").value = p.rate; $("#f-mix").value = p.mix; $("#f-size").value = p.size; $("#f-kind").value = "";
    const hm = $("#f-howmuch"); if (hm) { hm.value = p.loop ? "loop" : "count"; howMuchBoxes(); }
    hint();
  }
  // How much to send: a number of events, a length of time, or until Stop. A duration with a rate has a
  // knowable total and is sent as that count; at full speed, or "until I press Stop", the run is open-ended
  // and the sender stops it on the clock, on Stop, or on its own safety cap.
  const howMuch = () => ($("#f-howmuch") || {}).value || "count";
  // seconds, minutes or hours, capped at a day (the sender's own cap): the number box's maximum follows the unit
  const DAY = 86400;
  const durationSecs = () => Math.min(DAY, Math.max(1, +($("#f-for") || {}).value || 0) * (+($("#f-for-unit") || {}).value || 1));
  const forText = () => { const s = durationSecs(); return s % 3600 === 0 ? `${s / 3600} h` : s % 60 === 0 ? `${s / 60} min` : `${s} s`; };
  function howMuchBoxes() {
    const m = howMuch();
    if ($("#f-count-wrap")) $("#f-count-wrap").classList.toggle("hidden", m !== "count");
    if ($("#f-for-wrap")) $("#f-for-wrap").classList.toggle("hidden", m !== "time");
    const unit = +($("#f-for-unit") || {}).value || 1, box = $("#f-for");
    if (box) { box.max = String(Math.floor(DAY / unit)); if (+box.value > +box.max) box.value = box.max; }
    const note = $("#f-howmuch-note");
    if (note) note.textContent = m === "count" ? ""
      : m === "time" ? "Seconds, minutes or hours, up to 24 hours. At a rate, that is a known number of events; at 0 (full speed) it sends as many as it can for that long."
      : "Keeps sending until you press Stop on the run. There is a safety cap of 2,000,000 events per firewall.";
    hint();
  }
  function hint() {
    const n = S.picked.size, c = +$("#f-count").value || 0, rate = +$("#f-rate").value || 0, m = howMuch();
    let text;
    if (!n) text = "pick at least one firewall";
    else if (m === "loop") text = `${n} firewall${n > 1 ? "s" : ""} sending until you press Stop${rate ? `, ${rate}/s each` : ", as fast as they can"}`;
    else if (m === "time") {
      const secs = durationSecs();
      text = rate ? `${fmt.n(n * Math.round(rate * secs))} events across ${n} firewall${n > 1 ? "s" : ""} over ${forText()}`
                  : `${n} firewall${n > 1 ? "s" : ""} sending as fast as they can for ${forText()}`;
    } else {
      const secs = rate ? Math.ceil(c / rate) : 0;
      text = `${fmt.n(n * c)} events across ${n} firewall${n > 1 ? "s" : ""}${secs ? `, about ${secs}s` : ""}`;
    }
    $("#startHint").textContent = text;
    const udp = [...S.picked].some(id => ["udp514", "udp"].includes(S.sources.find(s => s.id === id)?.transport));
    if (udp && +$("#f-size").value > 8000) $("#startHint").textContent += " · size too big for UDP sources";
  }
  ["f-count", "f-rate", "f-size", "f-for"].forEach(id => { const el = $("#" + id); if (el) el.oninput = hint; });
  ["f-howmuch", "f-for-unit"].forEach(id => { const el = $("#" + id); if (el) el.onchange = howMuchBoxes; });
  howMuchBoxes();
  $$("[data-size]").forEach(x => x.onclick = (e) => { e.preventDefault(); $("#f-size").value = x.dataset.size; hint(); });
  $("#pickAll").onclick = (e) => { e.preventDefault(); S.sources.forEach(s => S.picked.add(s.id)); pageSend(); };
  $("#pickNone").onclick = (e) => { e.preventDefault(); S.picked.clear(); pageSend(); };
  // Add or change a firewall without leaving the Send page: switching pages to try another path is the
  // main thing that made comparing them tedious.
  $("#sendAddSource").onclick = (e) => { e.preventDefault(); sourceModal(); };

  $("#startBtn").onclick = async () => {
    const m = howMuch();
    const body = { sources: [...S.picked], count: +$("#f-count").value, rate: +$("#f-rate").value, mix: $("#f-mix").value, kind: $("#f-kind").value, size: +$("#f-size").value, seed: $("#f-seed").value, note: $("#f-note").value, capture: $("#f-capture").checked,
                   duration: m === "time" ? durationSecs() : 0, loop: m === "loop" };
    $("#startBtn").disabled = true;
    try { const r = await api("POST", "/api/runs", body); toast(`Run #${r.id} started`, "ok"); watchRun(r.id); }
    catch (e) { toast(e.message, "bad"); }
    finally { $("#startBtn").disabled = false; }
  };
  // Stop answers at once (Paul, 4 Oct 2026: "I hit stop ... but it's not clear it is stopped"): the button goes to
  // "Stopping…" and stays disabled, the pill reads "stopping" through the run's last steps - the senders finish the
  // event in hand, then the run waits 3 s for the relay to flush and asks it what it forwarded - and only the poll
  // that sees the final status puts "stopped" on the pill and the toast.
  const stopBtn = (b, stopping) => { b.disabled = stopping; b.textContent = stopping ? "Stopping…" : "Stop"; };
  $("#cancelBtn").onclick = async () => {
    if (!S.run || S.stopping === S.run) return;
    S.stopping = S.run; stopBtn($("#cancelBtn"), true); if (S.lastRun) renderRun(S.lastRun);
    try { await api("POST", `/api/runs/${S.run}/cancel`); toast("Stopping: the senders finish the event in hand, then the run asks the relay what it forwarded", "ok"); }
    catch (e) { toast(e.message, "bad"); S.stopping = null; stopBtn($("#cancelBtn"), false); if (S.lastRun) renderRun(S.lastRun); }
  };

  function watchRun(id) {
    S.run = id; clearInterval(S.timer);
    $("#runcard").classList.remove("hidden"); $("#run-log").innerHTML = ""; $("#run-relay").innerHTML = "";
    $("#runcard").scrollIntoView({ behavior: "smooth", block: "start" });
    const tick = async () => {
      let r; try { r = await api("GET", `/api/runs/${id}`); } catch (e) { Lab.pollFailed(e); return; }
      renderRun(r);
      if (!LIVE(r.status)) { clearInterval(S.timer); S.run = null; S.stopping = null; $("#cancelBtn").classList.add("hidden"); stopBtn($("#cancelBtn"), false); toast(`Run #${id} ${STATUS_WORD(r.status)}: ${fmt.n(r.sent)} sent, ${fmt.n(r.failed)} failed`, r.failed ? "bad" : "ok"); }
      else { $("#cancelBtn").classList.remove("hidden"); stopBtn($("#cancelBtn"), S.stopping === id); }
    };
    tick(); S.timer = setInterval(tick, 1000);
  }
  if ($("#find-run-log")) Lab.frame.search("run-log", $("#find-run-log"), { placeholder: "Find in the log" });
  window.RENDER_RUN = (r) => renderRun(r);      // ui-smoke renders a running run it cannot otherwise start
  function renderRun(r) {
    S.lastRun = r;
    $("#run-title").textContent = `Run #${r.id}`;
    const stopping = S.stopping === r.id && LIVE(r.status);
    $("#run-status").className = "pill " + (stopping ? "warn" : ({ running: "info", confirming: "info", done: "ok", cancelled: "warn", failed: "bad" }[r.status] || "idle"));
    $("#run-status").textContent = stopping ? (r.status === "confirming" ? "stopping · asking the relay" : "stopping") : r.status === "confirming" ? "asking the relay" : STATUS_WORD(r.status);
    // A run with no known total ("until I press Stop", or a duration at full speed) has no percentage to claim
    // (it used to show a full bar and "100%" from the first second): it shows how long it has been sending, a
    // moving stripe, and for a duration how long it goes on for - which IS known, so that bar fills by time.
    const open = r.open_ended || r.pct == null, bar = $("#run-bar"), pctEl = $("#run-pct");
    bar.parentElement.classList.toggle("open", open);
    bar.parentElement.classList.toggle("stopped", open && !LIVE(r.status));
    if (open) {
      const el = r.elapsed_s || 0, dur = r.duration || (r.params || {}).duration || 0, timed = dur && !(r.loop || (r.params || {}).loop);
      bar.style.width = timed && LIVE(r.status) ? Math.min(100, 100 * el / dur) + "%" : "100%";
      pctEl.textContent = !LIVE(r.status) ? `ran ${clock(el)}` : timed ? `${clock(el)} of ${clock(dur)}` : `${clock(el)} · until stopped`;
      pctEl.title = timed ? "sending as fast as it can until the time is up: the bar is the time, not a number of events"
                          : "sending until you press Stop: there is no total, so there is no percentage";
    } else {
      bar.style.width = r.pct + "%"; pctEl.textContent = `${r.pct}%`; pctEl.title = "";
    }
    // what the relay reported forwarding from this source's address (the run's own relay read)
    const conf = (s) => confirmedFor({ bind_ip: s.bind_ip }, r.relay);
    // what the relay's map said about the device when the run started: kept with the run, so history reads right
    const landed = (s) => {
      if (s.path === "raw") return `sensor ${esc(s.sensor || "1")} <span class="faint mono">:${esc(s.port || "?")}</span><br><span class="faint">${WRAPPED(s) ? `wrapped, tenant ${esc(fmt.short(directTenant(s)))}` : esc(OWN_TENANT)}</span>`;
      const rr = s.relay || {};
      if (!ADV()) return `<span class="faint">decided by the relay</span>`;
      if (!rr.known) return `<span class="faint">relay not read</span>`;
      if (!rr.mapped) return `${pill("warn", "not on the relay")} <span class="faint small">catch-all</span>`;
      return `${tenantDot(rr.tenant)}${esc(rr.tenant_label || fmt.short(rr.tenant))} <span class="faint mono">:${esc(rr.port || s.port)}</span>`;
    };
    // events per second and the average size, per firewall and in total, the way the relay's Delivery tab reads
    // (Paul, 4 Oct 2026: "the same kind of format, with the events per second ... show the events per second
    // being sent and the total being sent to a sensor ... the average packet size as well")
    const live = LIVE(r.status);
    const rateCell = (now, avg) => live
      ? `${now == null ? `<span class="small muted">measuring…</span>` : `${fmt.n(Math.round(now))} <span class="small muted">now</span>`}<br><span class="small muted">${fmt.n(Math.round((now != null ? now : avg) * 60))}/min · ${fmt.n(Math.round(avg || 0))} avg</span>`
      : `${fmt.n(Math.round(avg || 0))} <span class="small muted">avg · ${fmt.n(Math.round((avg || 0) * 60))}/min</span>`;
    const rows = Object.values(r.per_source || {}), n = rows.length;
    const liveLine = $("#run-live");
    if (liveLine) {
      if (live && !r.sent) liveLine.textContent = "Starting…";
      else if (live) liveLine.innerHTML = `<b>${r.rate_now == null ? "measuring…" : fmt.n(Math.round(r.rate_now)) + " events/s"}</b> across ${n} firewall${n === 1 ? "" : "s"} right now${r.rate_now != null && n > 1 ? ` (${fmt.n(Math.round(r.rate_now / n))}/s each)` : ""} · <b>${fmt.n(r.sent)}</b> sent in ${fmt.dur(r.elapsed_s || 0)}, ${fmt.n(Math.round(r.rate_avg || 0))} events/s on average · average event <b>${fmt.bytes(r.avg_bytes || 0)}</b>${r.bytes_per_s_now != null ? ` · ${fmt.bytes(r.bytes_per_s_now)}/s` : ""}`;
      else liveLine.innerHTML = `Sent <b>${fmt.n(r.sent)}</b> events in ${fmt.dur(r.elapsed_s || 0)}: <b>${fmt.n(Math.round(r.rate_avg || 0))} events/s</b> on average across ${n} firewall${n === 1 ? "" : "s"}, average event <b>${fmt.bytes(r.avg_bytes || 0)}</b>, ${fmt.bytes(r.bytes || 0)} in all.`;
    }
    const cols = ADV() ? 10 : 9;
    $("#run-sources").innerHTML = rows.map(s => { const c = conf(s); return `<tr><td><b>${esc(s.name)}</b> ${vendorTag(s.vendor, s.format)}</td><td class="small">${esc(PATH_SHORT[s.path])} · ${esc(TRANSPORT_LABEL[s.transport] || s.transport)}</td><td class="mono small">${esc(s.bind_ip || "default IP")}</td>
      <td class="num"><b>${fmt.n(s.sent)}</b><span class="small"> ${s.open_ended || !s.count ? "so far" : "/ " + fmt.n(s.count)}</span></td><td class="num nobr">${rateCell(s.rate_now, s.rate_avg)}</td><td class="num nobr">${s.sent ? fmt.bytes(s.avg_bytes || 0) : "—"}</td><td class="num">${s.failed ? `<span style="color:var(--bad)">${fmt.n(s.failed)}</span>` : 0}${s.reconnects ? `<br><span class="small muted nobr" title="the connection to the relay broke after records had been delivered on it, and the sender dialed again as a device would; what was in flight at the break is counted as failed">reconnected ${s.reconnects}×</span>` : ""}</td><td class="num">${fmt.bytes(s.bytes)}</td>
      ${ADV() ? `<td>${live ? '<span class="faint">…</span>' : NO_RELAY(s.path) ? '<span class="faint">n/a (direct)</span>' : c ? pill(c >= s.sent ? "ok" : "warn", `${fmt.n(c)} forwarded`) : pill("bad", "none seen")}</td>` : ""}
      <td class="small">${landed(s)}${s.identity ? `<br><span class="faint mono">${esc(s.identity)}</span>` : ""}</td></tr>${s.last_error ? `<tr><td colspan="${cols}" class="small" style="color:var(--bad)">${esc(s.last_error)}</td></tr>` : s.note ? `<tr><td colspan="${cols}" class="small muted">${esc(s.note)}</td></tr>` : ""}`; }).join("")
      + (n > 1 ? `<tr class="run-total"><td colspan="3"><b>All ${n} firewalls</b> <span class="small">· what the sensor side receives in all</span></td><td class="num"><b>${fmt.n(r.sent)}</b></td><td class="num nobr">${rateCell(r.rate_now, r.rate_avg)}</td><td class="num nobr">${r.sent ? fmt.bytes(r.avg_bytes || 0) : "—"}</td><td class="num">${r.failed ? `<span style="color:var(--bad)">${fmt.n(r.failed)}</span>` : 0}</td><td class="num">${fmt.bytes(r.bytes || 0)}</td>${ADV() ? "<td></td>" : ""}<td></td></tr>` : "");
    const sum = r.relay?.summary;
    if (sum && sum.length) $("#run-relay").innerHTML = `<div class="callout ok"><b>The relay reported</b> ${sum.map(s => `${fmt.n(s.count)} × ${esc(s.label)} → ${esc(s.tenant_label || s.tenant)} via :${s.port}${s.errors ? ` <span style="color:var(--bad)">(${s.errors} errors)</span>` : ""}`).join("; ")}</div>`;
    else if (!LIVE(r.status) && r.relay && Object.keys(r.relay).length) $("#run-relay").innerHTML = `<div class="callout"><b>The relay saw nothing for this run.</b> Check that each device is a log source on the relay, that the listener is up, and that the relay's copy of forwarded records is on.</div>`;
    else $("#run-relay").innerHTML = "";
    // a frame: an unchanged log is left alone, a growing one follows the bottom only while the reader
    // is there, and the find box (mounted once, below) keeps its query across ticks
    Lab.frame.set("run-log", $("#run-log"), r.log || [], { follow: true, text: (l) => l.line || "",
      render: (l, i, { hl, cls }) => `<div class="${esc(l.kind)}${cls}">${l.ts ? `<span class="dim">${fmt.time(l.ts)}</span> ` : ""}${hl(l.line)}</div>` });
    drawSendTopo(r);
  }

  // ---------------------------------------------------------------- throughput
  // How many logs a second this path carries, and what breaks first. The numbers come from three places
  // and the page never blurs them: what THIS host sent, what the RELAY's own counters say it did with
  // them, and what the PLATFORM ended up holding. A hop that was not read says so rather than showing a
  // zero, because a zero reads as "nothing arrived" when it means "nobody asked".
  const TP = { cfg: null, plan: "ramp", id: null, timer: null, last: null, sizingTimer: null };
  const VERDICT = { clean: ["ok", "nothing lost"], sent: ["info", "sent, not confirmed"], backlog: ["warn", "a backlog built up"],
                    sender: ["warn", "this host was the limit"], lost: ["bad", "records were lost"] };
  const num = (v, d = 0) => v == null ? '<span class="faint">—</span>' : fmt.n(Math.round(v * 10 ** d) / 10 ** d);
  // a relay cell: a real zero is a fact, a hop nobody could read is not
  const relayCell = (r, key, bad) => !r || !r.read ? '<span class="faint" title="the relay could not be read">—</span>'
    : r[key] == null ? '<span class="faint" title="syslog-ng did not report this counter">—</span>'
    : bad && r[key] ? `<span style="color:var(--bad)"><b>${fmt.n(r[key])}</b></span>` : fmt.n(r[key]);

  async function pageThroughput() {
    if (!TP.cfg) TP.cfg = await api("GET", "/api/bench/plans");
    const c = TP.cfg;
    $("#tpCap").innerHTML = `<b>This is real traffic.</b> ${esc(c.cap_note)}`;
    $("#tp-nolimit-hint").textContent = c.cap_note;
    if (!$("#tpPlans").children.length) {
      $("#tpPlans").innerHTML = Object.entries(c.plans).map(([k, p]) =>
        `<button class="preset ${k === TP.plan ? "active" : ""}" data-k="${k}"><b>${esc(p.label)}</b><span>${esc(p.desc)}</span></button>`).join("");
      $$("#tpPlans .preset").forEach(b => b.onclick = () => pickPlan(b.dataset.k));
      $("#tp-size").innerHTML = c.sizes.map(s => `<option value="${s.key}">${esc(s.label)}</option>`).join("");
      $("#tp-size").value = "native";
      ["tp-size", "tp-devices", "tp-rate", "tp-eps", "tp-seconds", "tp-source"].forEach(id => { const el = $("#" + id); el.oninput = el.onchange = tpHint; });
      $("#tp-nolimit").onchange = tpHint;
      Lab.infoButtons($("#tpPlans").closest("section"));
    }
    $("#tp-source").innerHTML = c.sources.length
      ? c.sources.map(s => `<option value="${s.id}">${esc(s.name)} — ${esc(S.vendors[s.vendor] || s.vendor)}, ${esc(TRANSPORT_LABEL[s.transport] || s.transport)}</option>`).join("")
      : `<option value="">no syslog log source yet</option>`;
    $("#tp-srchint").innerHTML = c.sources.length
      ? `A throughput test measures one path. The simulated devices all send as this one, from ${esc(c.sources.find(s => String(s.id) === $("#tp-source").value)?.bind_ip || "this host's default address")}.`
      : `There is no syslog log source yet. <a href="#/sources">Create one</a> that sends to the syslog-ng relay.`;
    pickPlan(TP.plan);
    await loadBenchHistory();
    const r = await api("GET", "/api/bench");
    // coming back to the page shows the last result rather than an empty card: the numbers are the point
    // of the page, and re-running the test to see them again is not a reasonable way to read them
    if (r.active) watchBench(r.active);
    else if (TP.last) renderBench(TP.last);
    else if (r.runs?.length) renderBench(await api("GET", `/api/bench/${r.runs[0].id}`));
  }

  function pickPlan(k) {
    TP.plan = k;
    $$("#tpPlans .preset").forEach(b => b.classList.toggle("active", b.dataset.k === k));
    $("#tpPlanQ").textContent = TP.cfg.plans[k].question;
    // each plan asks for different things, so only what it uses is on screen
    $("#tp-epsfield").classList.toggle("hidden", k !== "devices");
    $("#tp-ratefield").classList.toggle("hidden", k === "devices");
    $("#tp-devlabel").textContent = k === "devices" ? "Up to this many devices" : "Simulated devices";
    $("#tp-rate").parentElement.querySelector("label").textContent =
      k === "ramp" ? "Highest rate to try (0 = the built-in ladder)" : "Records/s to offer (0 = as fast as allowed)";
    if (k === "devices" && +$("#tp-devices").value < 10) $("#tp-devices").value = 250;
    tpHint();
  }

  function tpHint() {
    const c = TP.cfg, k = TP.plan;
    const size = c.sizes.find(s => s.key === $("#tp-size").value) || c.sizes[0];
    const src = c.sources.find(s => String(s.id) === $("#tp-source").value);
    const proto = { udp514: "udp", tcp514: "tcp", tcp601: "tcp", tls6514: "tls" }[src?.transport] || "tls";
    $("#tp-wire").textContent = size.note;
    const secs = +$("#tp-seconds").value || 20, devices = +$("#tp-devices").value || 1, rate = +$("#tp-rate").value || 0;
    const capped = !$("#tp-nolimit").checked, cap = capped ? c.caps.rate : Infinity;
    // the same trimming plan_steps() does on the server, so the hint is what will actually run
    let steps = 1, offered = Math.min(rate || cap, cap);
    if (k === "ramp") { const rs = c.ramp_rates.filter(r => (!rate || r <= rate * 8) && r <= cap); steps = rs.length || 1; offered = rs[rs.length - 1] || c.ramp_rates[0]; }
    else if (k === "sizes") steps = c.sweep_sizes.length;
    else if (k === "devices") { const eps = +$("#tp-eps").value || 10; const ns = c.device_counts.filter(n => n <= devices && eps * n <= cap); steps = ns.length || 1; offered = eps * (ns[ns.length - 1] || 1); }
    $("#tpHint").innerHTML = src
      ? `${steps} step${steps > 1 ? "s" : ""} of ${secs}s each, about <b>${Math.ceil(steps * (secs + c.settle + 2) / 60)} minute(s)</b> in all, over ${proto.toUpperCase()}.
         Up to <b>${fmt.n(Math.round(offered))}</b> records/s${capped && offered >= c.caps.rate ? " — the cap. Tick “no limit” to go past it." : "."}
         ${c.managed ? "" : `<br><b>This Studio has no management connection to the relay</b>, so it can measure only what this host sent. Open the Log Relay Manager beside it for the relay's side.`}`
      : `Pick a log source first.`;
  }

  $("#tpStart").onclick = async () => {
    const body = { plan: TP.plan, source: +$("#tp-source").value, size: $("#tp-size").value,
                   seconds: +$("#tp-seconds").value, devices: +$("#tp-devices").value, rate: +$("#tp-rate").value,
                   eps: +$("#tp-eps").value, stop_on_loss: $("#tp-stop").checked,
                   distinct_devices: $("#tp-distinct").checked, no_limit: $("#tp-nolimit").checked };
    if (body.no_limit && !confirm("No limit means this sends as fast as the path allows, for as long as you asked, into the real sensor and the real platform.\n\nRun it?")) return;
    $("#tpStart").disabled = true;
    try { const r = await api("POST", "/api/bench", body); toast(`Throughput run #${r.id} started`, "ok"); watchBench(r.id); }
    catch (e) { toast(e.message, "bad"); }
    finally { $("#tpStart").disabled = false; }
  };
  $("#tpCancel").onclick = async () => {
    if (!TP.id || TP.stopping === TP.id) return;
    TP.stopping = TP.id; stopBtn($("#tpCancel"), true); if (TP.last) renderBench(TP.last);
    try { await api("POST", `/api/bench/${TP.id}/cancel`); toast("Stopping: the step in hand ends, then the run settles and reads the relay once more", "ok"); }
    catch (e) { toast(e.message, "bad"); TP.stopping = null; stopBtn($("#tpCancel"), false); if (TP.last) renderBench(TP.last); }
  };
  $("#tpRecount").onclick = async () => {
    if (!TP.id) return;
    $("#tpRecount").disabled = true;
    try { const r = await api("POST", `/api/bench/${TP.id}/recount`); TP.last.platform = r; renderPlatform(TP.last); toast(`${fmt.n(r.count)} in the platform`, "ok"); }
    catch (e) { toast(e.message, "bad"); }
    finally { $("#tpRecount").disabled = false; }
  };
  $("#tp-sizing-eps").oninput = () => { clearTimeout(TP.sizingTimer); TP.sizingTimer = setTimeout(renderSizing, 300); };
  if ($("#find-tp-log")) Lab.frame.search("tp-log", $("#find-tp-log"), { placeholder: "Find in the log" });

  function watchBench(id) {
    TP.id = id; clearInterval(TP.timer);
    $("#tpRunCard").classList.remove("hidden");
    const tick = async () => {
      let r; try { r = await api("GET", `/api/bench/${id}`); } catch (e) { Lab.pollFailed(e); return; }
      renderBench(r);
      if (["running", "settling"].includes(r.status)) { $("#tpCancel").classList.remove("hidden"); stopBtn($("#tpCancel"), TP.stopping === id); }
      else {
        clearInterval(TP.timer); TP.stopping = null; $("#tpCancel").classList.add("hidden"); stopBtn($("#tpCancel"), false);
        const cl = (r.summary || {}).ceiling_records_s;
        toast(`Throughput run #${id} ${STATUS_WORD(r.status)}` + (cl ? `: ${fmt.n(Math.round(cl))} records/s with nothing lost` : ""), r.status === "done" ? "ok" : "warn");
        loadBenchHistory();
      }
    };
    tick(); TP.timer = setInterval(tick, 1000);
  }

  function renderBench(r) {
    TP.last = r; TP.id = r.id;
    $("#tpRunCard").classList.remove("hidden");
    $("#tpRunTitle").textContent = `Run #${r.id} · ${TP.cfg.plans[r.params.plan]?.label || r.params.plan} · ${esc(r.source?.name || "")}`;
    const st = r.status;
    const stopping = TP.stopping === r.id && ["running", "settling"].includes(st);
    $("#tpRunStatus").className = "pill " + (stopping ? "warn" : ({ running: "info", settling: "info", done: "ok", cancelled: "warn", failed: "bad" }[st] || "idle"));
    $("#tpRunStatus").textContent = stopping ? (st === "settling" ? "stopping · finishing up" : "stopping") : st === "settling" ? "finishing up" : STATUS_WORD(st);
    $("#tpCsv").style.display = r.steps?.length ? "" : "none";
    $("#tpCsv").href = `/api/bench/${r.id}/csv`;
    const cal = r.calibration || {};
    $("#tpCal").innerHTML = cal.build_records_s
      ? `<b>What this host can do</b> — builds <b>${fmt.n(Math.round(cal.build_records_s))}</b> of these events a second on one core
         (${fmt.n(Math.round(cal.avg_bytes))} B each)${cal.write_records_s ? `, writes <b>${fmt.n(Math.round(cal.write_records_s))}</b>/s into a socket that discards them` : ""},
         on ${cal.cpus} core(s). <span class="faint">${esc(cal.note)}</span>`
      : "";
    // the step running now
    const cur = r.current;
    $("#tpLive").innerHTML = cur ? `<div class="callout info"><b>Step ${cur.n}</b> — ${esc(cur.size_label)}, ${cur.devices} device(s),
        ${cur.offered ? fmt.n(Math.round(cur.offered)) + "/s" : "as fast as possible"}, ${cur.state}.
        <b>${fmt.n(cur.sent)}</b> sent${cur.errors ? ` · <span style="color:var(--bad)">${fmt.n(cur.errors)} failed</span>` : ""}
        ${cur.connected != null ? ` · ${cur.connected} connection(s) open` : ""}
        <div class="small faint" style="margin-top:4px">${esc(cur.wire || "")}</div>
        ${cur.series?.length ? `<div style="margin-top:6px">${Lab.spark(cur.series)}<span class="faint small"> records/s, second by second</span></div>` : ""}</div>` : "";
    // the steps done
    const rows = (r.steps || []).map(s => {
      const [cls, label] = VERDICT[s.verdict] || ["idle", s.verdict];
      const rr = s.relay || {};
      return `<tr data-step="${s.n}"><td>${s.n}</td><td style="white-space:nowrap">${esc(s.size_label)}${s.size_bytes > 0 ? "" : `<div class="faint small">${fmt.n(Math.round(s.avg_bytes || 0))} B each</div>`}</td>
        <td class="num">${fmt.n(s.devices)}${s.connect_failed ? `<div class="small" style="color:var(--bad)">${s.connect_failed} would not connect</div>` : ""}</td>
        <td class="num">${s.offered ? fmt.n(Math.round(s.offered)) : "max"}</td><td class="num">${fmt.n(s.sent)}${s.errors ? `<div class="small" style="color:var(--bad)">${fmt.n(s.errors)} failed</div>` : ""}</td>
        <td class="num"><b>${num(s.achieved)}</b></td><td class="num">${num(s.mbit_s, 1)}</td>
        ${ADV() ? `<td class="num">${relayCell(rr, "accepted")}</td><td class="num">${relayCell(rr, "written")}</td><td class="num">${relayCell(rr, "queued")}</td>
        <td class="num">${relayCell(rr, "dropped", true)}</td><td class="num">${relayCell(rr, "udp_dropped", true)}</td>
        <td class="num">${rr.read && rr.syslogng_cores != null ? (rr.syslogng_cores).toFixed(2) : '<span class="faint">—</span>'}</td>` : ""}
        <td>${pill(cls, label)}</td></tr>`;
    }).join("");
    $("#tpStepRows").innerHTML = rows || `<tr><td colspan="${ADV() ? 14 : 8}" class="empty">no step finished yet</td></tr>`;
    $("#tpNotes").innerHTML = (r.steps || []).filter(s => s.notes?.length).map(s => {
      const [cls] = VERDICT[s.verdict] || ["idle"];
      return `<div class="callout ${cls === "ok" ? "ok" : cls === "bad" ? "bad" : ""} small" style="margin-top:8px"><b>Step ${s.n} — ${esc(s.size_label)}, ${s.devices} device(s):</b> ${s.notes.map(esc).join(" ")}<div class="faint" style="margin-top:4px">${esc(s.wire || "")}</div></div>`;
    }).join("");
    Lab.frame.set("tp-log", $("#tpLog"), r.log || [], { follow: true, text: (l) => l.line || "",
      render: (l, i, { hl, cls }) => `<div class="${esc(l.kind)}${cls}">${l.ts ? `<span class="dim">${fmt.time(l.ts)}</span> ` : ""}${hl(l.line)}</div>` });
    renderSummary(r); renderPlatform(r);
    applyEdition();
  }

  function renderSummary(r) {
    const s = r.summary || {};
    const show = !!(r.steps || []).length && !["running"].includes(r.status);
    $("#tpSummaryCard").classList.toggle("hidden", !show);
    $("#tpSizingCard").classList.toggle("hidden", !show || !s.ceiling_records_s);
    if (!show) return;
    const parts = [];
    if (s.ceiling_records_s) {
      parts.push(`<p style="font-size:26px;margin:0 0 2px"><b>${fmt.n(Math.round(s.ceiling_records_s))}</b> <span class="faint" style="font-size:15px">records/s</span></p>
        <p class="small" style="margin:0 0 10px">${s.confirmed ? "the highest rate with nothing lost" : "the highest rate <b>this host</b> sent without an error of its own"} — ${esc(s.ceiling_size)}, ${s.ceiling_devices} device(s), ${(s.ceiling_mbit_s || 0).toFixed(1)} Mbit/s.
        ${s.topped_out ? "<b>Nothing broke at the highest rate tried</b>, so this is a floor, not a ceiling: raise the rate, or tick “no limit”." : ""}</p>`);
    } else {
      parts.push(`<p class="small" style="margin:0 0 10px"><b>No step finished without losing records.</b> The ceiling is below the lowest rate tried.</p>`);
    }
    parts.push(`<p class="small faint" style="margin:0 0 10px"><b>On what basis:</b> ${esc(s.basis || "")}</p>`);
    // Not confirmed is not a dead end: the relay holds the other half of the answer, and this says which
    // window to read it over (Paul, 2 Oct 2026, after a run that reported no loss while the relay dropped
    // 15.8% of that port's records).
    if (s.relay_check) {
      const rc = s.relay_check;
      parts.push(`<div class="callout warn small"><b>This run measured the sending side only.</b> Whether the relay
        kept these records is recorded on the relay itself, and this page cannot read it. Look there for the window
        <b>${esc(fmt.dt(rc.from))}</b> to <b>${esc(fmt.dt(rc.to))}</b>, in ${esc(rc.where)}: Accepted, Written,
        <b>Waiting</b> and <b>Dropped</b> for this log source's sensor port. ${esc(rc.how)}
        ${rc.tag ? `<div class="faint" style="margin-top:4px">Every record in this run carries the marker <code>STELLAR-PERF-${esc(rc.tag)}</code>, so the platform can be searched for it too.</div>` : ""}</div>`);
    }
    if (s.first_failure) parts.push(`<div class="callout bad small"><b>First step that did not hold — step ${s.first_failure.n}</b>, offering ${fmt.n(Math.round(s.first_failure.offered))}/s: ${s.first_failure.notes.map(esc).join(" ")}</div>`);
    if (s.sender_limited) parts.push(`<div class="callout warn small"><b>This host was working at its own limit</b> at the best step, so the number above is Ingest Studio's ceiling as much as the lab's. A bigger sender, or more of them, would push further.</div>`);
    if (s.max_connections) parts.push(`<p class="small" style="margin:10px 0 0">The relay accepts <b>${fmt.n(s.max_connections)}</b> TCP/TLS sessions at once (<code>max-connections</code> in its configuration) — a hard limit on how many devices can hold a session, whatever the rate.</p>`);
    parts.push(`<p class="small faint" style="margin:10px 0 0">${fmt.n(s.total_sent)} records, ${fmt.bytes(s.total_bytes)} in all.</p>`);
    $("#tpSummary").innerHTML = parts.join("");
    renderSizing();
  }

  async function renderSizing() {
    const s = TP.last?.summary || {};
    if (!s.ceiling_records_s) return;
    const eps = +$("#tp-sizing-eps").value || 10;
    let r;
    try {
      r = await api("GET", `/api/bench/sizing?records_s=${s.ceiling_records_s}&eps=${eps}` +
        (s.max_connections ? `&max_connections=${s.max_connections}` : "") + `&proto=${encodeURIComponent(s.proto || "tls")}`);
    } catch (e) { $("#tpSizing").innerHTML = `<p class="small">${esc(e.message)}</p>`; return; }
    const table = (s.sizing || []).map(x => `<tr><td class="num">${fmt.n(x.eps_per_device)}</td><td class="num"><b>${fmt.n(x.devices)}</b></td><td class="small faint">${esc(x.limited_by)}</td></tr>`).join("");
    $("#tpSizing").innerHTML = `
      <p style="font-size:26px;margin:0 0 2px"><b>${fmt.n(r.devices)}</b> <span class="faint" style="font-size:15px">log sources</span></p>
      <p class="small" style="margin:0 0 10px">${esc(r.note)}</p>
      ${r.by_connections ? `<p class="small faint" style="margin:0 0 10px">The rate alone would allow ${fmt.n(r.by_rate)}; the relay's session limit allows ${fmt.n(r.by_connections)}.</p>` : ""}
      <table style="margin-top:6px"><thead><tr><th class="num">Logs/s each</th><th class="num">Log sources</th><th>Limited by</th></tr></thead><tbody>${table}</tbody></table>
      <p class="small faint" style="margin:10px 0 0">Arithmetic on the measured ceiling, not a separate measurement. The <b>How many log sources?</b> plan measures it directly, by opening that many connections.</p>`;
  }

  function renderPlatform(r) {
    const p = r.platform;
    $("#tpPlatformCard").classList.toggle("hidden", !p || !ADV());
    if (!p) return;
    const tag = r.tag || r.params?.tag || "";
    if (p.error || p.asked === false) {
      $("#tpPlatform").innerHTML = `<p class="small">${esc(p.note || p.error || "")}</p>
        <p class="small faint">Search <code>STELLAR-PERF-${esc(tag)}</code> in Stellar Cyber to count this run by hand.</p>`;
      return;
    }
    const pct = p.pct == null ? null : Math.round(p.pct);
    $("#tpPlatform").innerHTML = `
      <p style="font-size:26px;margin:0 0 2px"><b>${fmt.n(p.count)}</b> <span class="faint" style="font-size:15px">of ${fmt.n(p.sent)} sent${pct != null ? ` · ${pct}%` : ""}</span></p>
      <p class="small" style="margin:0 0 8px">records carrying <code>STELLAR-PERF-${esc(tag)}</code>, counted ${esc(fmt.ago(p.at))} by the relay asking the platform.</p>
      <p class="small faint">${esc(p.note || "")} Query: <code>${esc(p.query || "")}</code></p>`;
  }

  async function loadBenchHistory() {
    const r = await api("GET", "/api/bench");
    const rows = (r.runs || []).map(b => {
      const s = b.summary || {};
      // the worst thing that happened in the run, which is what a history row is for
      const worst = (b.steps || []).some(x => x.verdict === "lost") ? "lost"
        : (b.steps || []).some(x => x.verdict === "backlog") ? "backlog" : null;
      return `<tr class="clickable" data-bench="${b.id}"><td>#${b.id} <span class="faint small">${esc(fmt.ago(b.started))}</span></td>
        <td>${esc(TP.cfg.plans[b.params?.plan]?.label || b.params?.plan || "")}</td><td class="small">${esc(b.params?.steps?.length ? (b.summary?.ceiling_size || "") : "")}</td>
        <td class="num">${fmt.n((b.steps || []).length)}</td><td class="num">${s.ceiling_records_s ? fmt.n(Math.round(s.ceiling_records_s)) + "/s" : "—"}</td>
        <td>${worst ? pill(...VERDICT[worst]) : (b.steps || []).length ? pill("ok", "nothing lost") : ""}</td><td>${pill({ done: "ok", running: "info", settling: "info", cancelled: "warn", failed: "bad" }[b.status] || "idle", STATUS_WORD(b.status))}</td></tr>`;
    }).join("");
    $("#tpHistory").innerHTML = rows || `<tr><td colspan="7" class="empty">No throughput run yet</td></tr>`;
    $$("#tpHistory [data-bench]").forEach(tr => tr.onclick = async () => {
      const b = await api("GET", `/api/bench/${tr.dataset.bench}`);
      renderBench(b); $("#tpRunCard").scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }

  // ---------------------------------------------------------------- sources
  let RF_SEL = null;
  async function loadRelayFiles() {
    // Reading the relay's own files is a management connection, which the standard edition does not have:
    // the card is not on the page and the route is not there either. A read: there is no "mark as reviewed"
    // here any more, because that bookmark is the relay's, and this Studio changes nothing on the relay.
    if (!ADV()) return;
    if (!$("#relayfile-tabs")) return;
    const d = await api("GET", "/api/relay/config-files");
    $("#relayfile-tabs").classList.toggle("hidden", !d.ok);
    if (!d.ok) { $("#relayfile-tabs").innerHTML = ""; $("#relayfile-view").innerHTML = `<div class="empty">${esc(d.error || "log relay manager not configured")}</div>`; return; }
    const files = d.files.filter(f => ["syslog-map", "syslog-conf", "nginx-map", "nginx-conf"].includes(f.id));
    if (!RF_SEL) RF_SEL = (files.find(f => f.changed) || files[0] || {}).id;
    const short = { "syslog-map": "tenant map", "syslog-conf": "config", "nginx-map": "tenant map", "nginx-conf": "config" };
    const tab = (f) => `<button class="${f.id === RF_SEL ? "active" : ""}" data-rf="${f.id}">${esc(short[f.id] || f.title)}${f.changed ? `<span class="badge">+${f.added_count}</span>` : ""}</button>`;
    $("#relayfile-tabs").innerHTML = `<span class="group">SYSLOG-NG</span>${files.filter(f => f.relay === "syslog-ng").map(tab).join("")}<span class="group">NGINX</span>${files.filter(f => f.relay === "nginx").map(tab).join("")}`;
    $$("[data-rf]").forEach(b => b.onclick = () => { RF_SEL = b.dataset.rf; loadRelayFiles(); });
    const f = await api("GET", `/api/relay/config-files/${RF_SEL}`); const added = new Set(f.added);
    // the same file again (a refresh): carry the reader's scroll position over to the new frame
    const prev = $("#rf-frame"), restore = prev && prev.dataset.id === RF_SEL ? { top: prev.scrollTop, left: prev.scrollLeft } : null;
    $("#relayfile-view").innerHTML = `<div class="row" style="margin-bottom:8px;align-items:center"><span id="rf-find"></span><div><code class="small">${esc(f.path)}</code> <span class="faint small">on the relay · ${esc(f.what)} · read only</span></div><div>${f.changed ? pill("warn nodot", `${f.added.length} added · ${f.removed.length} removed since reviewed on the relay`) : f.never_reviewed ? pill("idle nodot", "not reviewed on the relay yet") : pill("ok nodot", "unchanged since reviewed on the relay")}</div></div>
      ${f.exists ? `<div class="cfg-text" id="rf-frame" data-id="${esc(RF_SEL)}"></div>` : `<div class="empty">${esc(f.error)}</div>`}
      ${f.removed.length ? `<div class="cfg-removed">removed since review:\n${esc(f.removed.join("\n"))}</div>` : ""}`;
    if (f.exists) {
      Lab.frame.set("rf-file", $("#rf-frame"), f.lines, { restore, empty: '<div class="ln"><span></span><span class="faint">(empty file)</span></div>',
        render: (l, i, { hl, cls }) => `<div class="ln${added.has(i) ? " add" : ""}${cls}"><span>${i + 1}</span><span>${hl(l) || " "}</span></div>` });
      Lab.frame.search("rf-file", $("#rf-find"), { placeholder: "Find in this file" });
      if (!restore && f.added.length) Lab.frame.reveal("rf-file", f.added[0]);   // scrolls the frame, not the page
    }
  }
  async function pageSources() {
    await Promise.all([loadCore(), loadSettings()]);
    loadRelayFiles().catch(() => {});
    if (ADV() && !S.relayStatus && S.settings.relay_monitor_url) { try { S.relayStatus = await api("GET", "/api/relay/status"); } catch (e) { /* offline */ } }
    // The device type's own parser port on the sensor. Used ONLY when the source goes straight to the sensor;
    // through a relay the relay's row names the port, and the cell says so instead of pretending this host decides.
    const portCell = (s) => {
      if (s.path === "nginx") return `<code>:5200</code><br><span class="faint small">HTTP JSON; the relay adds the tenant</span>`;
      if (s.path === "raw") return `<code>:${esc(s.parser_port)}</code><br><span class="faint small">used: straight to this port on sensor ${esc(s.sensor || "1")}</span>`;
      const r = rel(s);
      const relayPort = r.mapped && r.port && String(r.port) !== String(s.parser_port) ? `<br><span class="small" style="color:var(--warn)">the relay's row sends it to :${esc(r.port)}</span>` : "";
      return `<code class="faint">:${esc(s.parser_port)}</code><br><span class="faint small">not used here: the relay's row decides</span>${relayPort}`;
    };
    $("#srcTbl").innerHTML = S.sources.length ? S.sources.map(s => `<tr data-id="${s.id}"><td><b>${esc(s.name)}</b>${s.enabled ? "" : ` ${pill("idle", "disabled")}`}</td><td>${vendorTag(s.vendor, s.format)}</td><td class="small">${esc(pathLabel(s))}</td><td><code>${esc(s.bind_ip || "default")}</code>${s.ip_present ? "" : `<br>${pill("bad", "not on host")}`}</td><td class="small">${portCell(s)}</td><td class="small"><code>${esc(identityLabel(s))}</code>${s.identity?.explicit ? "" : `<br><span class="faint">default value</span>`}</td><td class="small">${onRelayCell(s)}</td><td style="white-space:nowrap"><button class="btn sm" data-act="edit">Edit</button> <button class="btn sm danger" data-act="del">Delete</button></td></tr>`).join("") : `<tr><td colspan="8" class="empty">No log sources yet</td></tr>`;
    Lab.infoButtons($("#ipnote"));
    $$("#srcTbl button").forEach(b => b.onclick = async () => {
      const id = +b.closest("tr").dataset.id, s = S.sources.find(x => x.id === id);
      if (b.dataset.act === "edit") return sourceModal(s);
      if (b.dataset.act === "del") { if (!confirm(`Delete log source "${s.name}" from this Studio? The relay's own log source for it is not touched.`)) return; try { const r = await api("DELETE", `/api/sources/${id}`); toast(r.relay_manual ? `Deleted here. ${r.relay_manual}` : "Deleted"); S.picked.delete(id); pageSources(); } catch (e) { toast(e.message, "bad"); } }
    });
  }
  function reportSaved(r) {
    const bits = [];
    if (r.ip?.added) bits.push(`IP added to ${r.ip.iface}`); else if (r.ip?.error) bits.push(`IP: ${r.ip.error}`);
    const rr = r.relay || {};
    if (rr.mapped) bits.push(`saved here; the relay already has a row for it (tenant ${rr.tenant_label || fmt.short(rr.tenant)}, port :${rr.port})`);
    else if (rr.mapped === false) bits.push("saved here. The relay has no log source for this device yet: create it there, in the Log Relay Manager, or its logs land in the relay's catch-all tenant");
    else if (rr.mapped === null) bits.push("saved: it goes straight to its sensor, so nothing on the relay is involved");
    else bits.push("saved here. Create the same log source on the relay, in the Log Relay Manager: that row decides the tenant and the sensor port");
    // a tenant sent to a port not documented to read the wrapper: said, never refused
    (r.warnings || []).forEach(w => bits.push(w));
    toast(bits.join(" · "), r.ip?.error ? "bad" : (rr.mapped === false || (r.warnings || []).length) ? "warn" : "ok");
  }
  function suggestIp() {
    const used = new Set(S.sources.map(s => s.bind_ip).concat(S.settings.host_ips?.map(h => h.ip) || []));
    const base = (S.settings.host_ips || []).find(h => h.iface !== "lo")?.ip; if (!base) return "";
    const p = base.split("."); for (let i = 200; i < 250; i++) { const c = `${p[0]}.${p[1]}.${p[2]}.${i}`; if (!used.has(c)) return c; }
    return "";
  }
  function sourceModal(s) {
    const pathKeys0 = Object.keys(S.paths || {});
    s = s || { name: "", vendor: "fortigate", path: pathKeys0[0] || "syslogng", transport: pathKeys0[0] === "raw" ? "tls" : "tls6514", bind_ip: suggestIp(), enabled: 1, format: "syslog", id_field: "", device_id: "", webhook_source: "generic", ingest_path: "", delivery: "asis", tenant_id: "" };
    // A log source is configured the way the real device is: what it is, how it sends, from where, and how it
    // identifies itself. Through a relay there is no tenant and no delivery method here - those are the relay's own
    // row for the device. Straight to a sensor (8 Oct 2026) it is sent as-is, or wrapped with a tenant set here. The
    // parser port is shown because a real device is told one, and it is used only on the direct path.
    const m = modal(`<h2>${s.id ? "Edit" : "New"} log source</h2>
      <p class="small muted" style="margin:0 0 12px" id="m-note"></p>
      <div class="row"><div class="field"><label>Name</label><input id="m-name" value="${esc(s.name)}" placeholder="e.g. Branch FortiGate"></div>
        <div class="field"><label>Log source (vendor / product)</label><select id="m-vendor"></select></div></div>
      <div class="row" style="margin-top:12px"><div class="field"><label>Path</label><select id="m-path">${Object.entries(S.paths).map(([k, p]) => { const mk = k === "syslogng" ? "syslog" : k === "nginx" ? "nginx" : ""; const off = mk && S.relayStatus && S.relayStatus.methods && S.relayStatus.methods[mk] && !S.relayStatus.methods[mk].installed; return `<option value="${k}" ${k === s.path ? "selected" : ""} ${off ? "disabled" : ""}>${esc(p.label)}${off ? " (not installed on the relay)" : ""}</option>`; }).join("")}</select><div class="hint" id="m-pathmethodhint"></div></div>
        <div class="field"><label>Transport</label><select id="m-transport"></select><div class="hint" id="m-transporthint"></div></div></div>
      <div class="row" style="margin-top:12px" id="m-directrow"><div class="field" id="m-sensorfield"><label>Sensor it sends to</label><select id="m-sensor"></select><div class="hint" id="m-sensorhint"></div></div>
        <div class="field" id="m-deliveryfield"><label>What it sends</label><select id="m-delivery"></select><div class="hint" id="m-deliveryhint"></div></div></div>
      <div class="field" style="margin-top:12px" id="m-tenantfield"><label>Tenant ID it sends</label>
        <input id="m-tenant" value="${esc(s.tenant_id || "")}" placeholder="32 hexadecimal characters: the tenant's ID in Stellar Cyber" autocomplete="off" spellcheck="false" class="mono">
        <div class="hint" id="m-tenanthint"></div><div class="small warn" id="m-wrapnote" style="margin-top:4px"></div></div>
      <div class="row" style="margin-top:12px"><div class="field"><label>Log format</label><select id="m-format"></select><div class="hint" id="m-fmthint"></div></div>
        <div class="field"><label>Sensor parser port</label><div class="mono" id="m-port" style="padding:9px 0;font-size:15px"></div><div class="hint" id="m-porthint"></div></div></div>
      <div class="field" style="margin-top:12px"><label>Source IP on this host</label><input id="m-ip" value="${esc(s.bind_ip)}"><div class="hint" id="m-iphint"></div></div>
      <div class="field" style="margin-top:12px" id="m-webhookfield"><label>What this log source posts</label>
        <select id="m-webhook_source"></select><div class="hint" id="m-webhookhint"></div></div>
      <div class="field" style="margin-top:12px" id="m-pathfield"><label>URL path it posts to on the relay</label>
        <input id="m-ingest_path" value="${esc(s.ingest_path || "")}" placeholder="e.g. acme"><div class="hint" id="m-pathhint"></div></div>
      <div class="field" style="margin-top:12px" id="m-idfield"><label>How this device identifies itself in its logs</label>
        <div class="row"><div class="field" style="flex:0 1 200px"><select id="m-id_field"></select></div><div class="field"><input id="m-device_id" value="${esc(s.device_id || "")}"></div></div><div class="hint" id="m-idhint"></div></div>
      <div class="field" style="margin-top:12px" id="m-trustfield"><label>How this device trusts the relay's certificate</label>
        <select id="m-tls_verify">
          <option value="any">Accept any certificate (default)</option>
          <option value="ca">Validate it against a CA</option>
          <option value="pin">Pin this exact certificate</option>
        </select>
        <div class="hint" id="m-trusthint"></div>
        <div id="m-cawrap" style="margin-top:6px;display:none">
          <div class="row"><label class="btn sm" style="cursor:pointer;flex:0 0 auto">Choose the CA file<input type="file" id="m-cafile" accept=".pem,.crt,.cer,.key,.txt" style="display:none"></label><span class="small" id="m-caname"></span></div>
          <div class="hint">The CA that signed the relay's 6514 certificate. Leave it empty to use the relay CA set in Settings. Dialled by host name the name is checked too; by address only the chain can be.</div>
        </div>
        <div id="m-pinwrap" style="margin-top:6px;display:none">
          <div class="row"><input id="m-tls_pin" placeholder="SHA-256 of the relay's certificate" value="${esc(s.tls_pin || "")}" autocomplete="off"><button class="btn sm" id="m-pinfetch" style="flex:0 0 auto">Fetch it from the relay</button></div>
          <div class="hint" id="m-pinhint">Pinning needs no CA, so it works with the relay's own self-signed certificate. Nothing is sent if the relay ever presents a different one.</div>
        </div></div>
      <div class="field" style="margin-top:12px" id="m-certfield"><label>Client certificate for TLS 6514 (optional)</label>
        <div class="small" id="m-certnow"></div>
        <div class="row" style="margin-top:6px"><label class="check" style="flex:0 0 auto"><input type="radio" name="m-certmode" value="one" checked> One file (certificate + key)</label><label class="check" style="flex:0 0 auto"><input type="radio" name="m-certmode" value="two"> Separate certificate and key files</label></div>
        <div class="row" style="margin-top:6px" id="m-certone"><label class="btn sm" style="cursor:pointer;flex:0 0 auto">Choose a PEM (certificate + key)<input type="file" id="m-certfile" accept=".pem,.crt,.cer,.key,.txt" style="display:none"></label><button class="btn sm" id="m-certclear" style="flex:0 0 auto">Remove</button></div>
        <div class="row" style="margin-top:6px;display:none" id="m-certtwo"><label class="btn sm" style="cursor:pointer;flex:0 0 auto">Certificate file<input type="file" id="m-certfile2" accept=".pem,.crt,.cer,.txt" style="display:none"></label><label class="btn sm" style="cursor:pointer;flex:0 0 auto">Key file<input type="file" id="m-keyfile2" accept=".key,.pem,.txt" style="display:none"></label><button class="btn sm" id="m-certclear2" style="flex:0 0 auto">Remove</button></div>
        <div class="hint">Only needed when the relay accepts devices by certificate (Log Relay Manager → Log relay services → Security → "Which devices may connect over TLS"). The certificate (with its chain, if any) and its private key, no passphrase; the key stays in this Studio's credential store and is never shown again.</div></div>
      <div class="flow" id="m-flow" style="margin:10px 0 14px"></div>
      <div class="field"><label><input type="checkbox" id="m-enabled" ${s.enabled ? "checked" : ""}> Enabled (shown on the Send page)</label></div>
      <div class="row"><button class="btn primary" id="m-save" style="flex:0 0 auto">Save</button><button class="btn" id="m-cancel" style="flex:0 0 auto">Cancel</button></div>`);
    const pathKeys = Object.keys(S.paths || {});
    const path = () => { const v = $("#m-path", m).value; return S.paths[v] ? v : (pathKeys[0] || "syslogng"); };
    const vendor = () => $("#m-vendor", m).value;
    const fillVendors = () => {
      // as-is needs a dedicated parser port; the other sources are recognised only inside the wrapper
      const raw = path() === "raw", cur = $("#m-vendor", m).value || s.vendor;
      const okv = (k) => !raw || S.rawVendors.includes(k);
      $("#m-vendor", m).innerHTML = Object.entries(S.vendors).map(([k, v]) => `<option value="${k}" ${okv(k) ? "" : "disabled"}>${esc(v)}${okv(k) ? "" : " (not as-is: no dedicated parser port)"}</option>`).join("");
      $("#m-vendor", m).value = okv(cur) ? cur : S.rawVendors[0];
      fillFormats();
    };
    const fillFormats = () => {
      const v = vendor(), opts = path() === "raw" ? ["syslog"] : (S.formats[v] || ["syslog"]);
      $("#m-format", m).innerHTML = opts.map(f => `<option value="${f}" ${f === s.format ? "selected" : ""}>${f === "cef" ? "CEF (ArcSight)" : "native syslog"}</option>`).join("");
      $("#m-format", m).disabled = opts.length < 2; fillIdFields();
    };
    const fillIdFields = () => {
      const fields = S.deviceFields[vendor()] || [], cur = $("#m-id_field", m).value || s.id_field;
      $("#m-id_field", m).innerHTML = fields.map((f, i) => `<option value="${f.field}">${esc(f.field)} · ${esc(f.label)}${i === 0 && fields.length > 1 ? " (recommended)" : ""}</option>`).join("");
      if (fields.some(f => f.field === cur)) $("#m-id_field", m).value = cur;
      $("#m-idfield", m).style.display = fields.length ? "" : "none";
      refresh();
    };
    const fillWebhook = () => {
      const p = path(), http = p === "nginx";
      const cur = $("#m-webhook_source", m).value || s.webhook_source || "generic";
      $("#m-webhook_source", m).innerHTML = Object.entries(S.webhookSources || { generic: "Generic JSON log source" })
        .map(([k, label]) => `<option value="${k}">${esc(label)}</option>`).join("");
      $("#m-webhook_source", m).value = cur;
      $("#m-webhookfield", m).style.display = http ? "" : "none";
      $("#m-pathfield", m).style.display = http ? "" : "none";
    };
    // the client certificate: undefined = leave what is stored, "" = remove it, text = a new PEM
    let clientPem;
    const certNow = () => {
      const box = $("#m-certnow", m); if (!box) return;
      const f = clientPem === undefined ? s.client_cert : null;
      box.innerHTML = clientPem ? `<span class="ok">new certificate chosen - saved with the log source</span>`
        : clientPem === "" ? `<span class="muted">none (removed on Save)</span>`
        : f ? `${esc(f.cn || f.subject || "certificate")} <span class="faint">· issued by ${esc(f.issuer || "?")}${f.days_left != null ? ` · ${f.days_left < 0 ? "expired" : "expires in " + f.days_left + " days"}` : ""}</span>`
        : `<span class="faint">none: this device presents no certificate</span>`;
    };
    const fillCert = () => {
      const on = path() === "syslogng" && $("#m-transport", m).value === "tls6514";
      $("#m-certfield", m).style.display = on ? "" : "none";
      $("#m-trustfield", m).style.display = on ? "" : "none";
      fillTrust();
      partsNow();
    };
    // the certificate may be given as ONE file (certificate + key) or as separate files - the same thing once
    // joined, so the two pickers are collected here and sent as two fields the relay joins (Paul, 2 Oct 2026)
    let certPart, keyPart;
    const certMode = () => (($$("input[name=m-certmode]", m).find(r => r.checked) || {}).value || "one");
    const partsNow = () => {
      const box = $("#m-certnow", m); if (!box) return;
      if (certMode() === "two" && (certPart || keyPart)) {
        box.innerHTML = `<span class="ok">${certPart ? "certificate" : "no certificate yet"} + ${keyPart ? "key" : "no key yet"} chosen</span>`
          + (certPart && keyPart ? "" : ` <span class="faint">- both files are needed</span>`);
        return;
      }
      certNow();
    };
    $("#m-certfile", m).onchange = async () => { const f = $("#m-certfile", m).files[0]; if (!f) return; clientPem = await f.text(); certPart = keyPart = undefined; partsNow(); };
    $("#m-certclear", m).onclick = (e) => { e.preventDefault(); clientPem = ""; certPart = keyPart = undefined; partsNow(); };
    $("#m-certfile2", m).onchange = async () => { const f = $("#m-certfile2", m).files[0]; if (!f) return; certPart = await f.text(); partsNow(); };
    $("#m-keyfile2", m).onchange = async () => { const f = $("#m-keyfile2", m).files[0]; if (!f) return; keyPart = await f.text(); partsNow(); };
    $("#m-certclear2", m).onclick = (e) => { e.preventDefault(); certPart = keyPart = ""; clientPem = undefined; partsNow(); };
    $$("input[name=m-certmode]", m).forEach(r => r.onchange = () => {
      const two = certMode() === "two";
      $("#m-certone", m).style.display = two ? "none" : "";
      $("#m-certtwo", m).style.display = two ? "" : "none";
      partsNow();
    });
    // how this device trusts the RELAY's certificate: accept any, a CA, or a pin
    let caPem;
    const fillTrust = () => {
      const v = $("#m-tls_verify", m).value;
      $("#m-cawrap", m).style.display = v === "ca" ? "" : "none";
      $("#m-pinwrap", m).style.display = v === "pin" ? "" : "none";
      $("#m-trusthint", m).textContent =
        v === "ca" ? "The relay's certificate must chain to the CA. This is what a production device does, and it needs a CA that signed it."
        : v === "pin" ? "The relay's certificate must be exactly the one pinned here, whoever signed it."
        : "Whatever the relay presents is accepted. This is what the Stellar Cyber documentation asks of senders while the relay is self-signed.";
    };
    $("#m-tls_verify", m).value = s.tls_verify || "any";
    $("#m-tls_verify", m).onchange = fillTrust;
    $("#m-cafile", m).onchange = async () => { const f = $("#m-cafile", m).files[0]; if (!f) return; caPem = await f.text(); $("#m-caname", m).innerHTML = `<span class="ok">${esc(f.name)}</span>`; };
    $("#m-pinfetch", m).onclick = async (e) => {
      e.preventDefault();
      const b = $("#m-pinfetch", m), hint = $("#m-pinhint", m);
      b.disabled = true; hint.textContent = "reading the certificate the relay is presenting\u2026";
      try {
        const r = await api("GET", "/api/relay-cert");
        $("#m-tls_pin", m).value = r.sha256;
        hint.innerHTML = `Pinned what ${esc(r.host)}:6514 is presenting now: <b>${esc(r.cn || r.subject || "certificate")}</b>`
          + (r.not_after ? ` <span class="faint">\u00b7 expires ${esc(r.not_after)}</span>` : "");
      } catch (err) { hint.innerHTML = `<span class="bad">${esc(errText ? errText(err) : err.message)}</span>`; }
      b.disabled = false;
    };
    // The direct path: which of this Studio's sensors it sends to (Settings -> Sensors), and whether its log goes
    // as-is or wrapped with a tenant. Through a relay neither applies: the relay's row decides both.
    const fillSensors = () => {
      const raw = path() === "raw", list = S.sensors || [];
      $("#m-directrow", m).style.display = raw ? "" : "none";
      const cur = $("#m-sensor", m).value || String(s.sensor || "1");
      $("#m-sensor", m).innerHTML = (list.length ? list : [{ n: 1, address: "", transport: "tls" }])
        .map(x => `<option value="${x.n}">Sensor ${x.n} · ${esc(x.address || "no address yet")} · ${esc((x.transport || "tls").toUpperCase())}</option>`).join("");
      if (list.some(x => String(x.n) === cur)) $("#m-sensor", m).value = cur;
      fillDelivery();
    };
    const fillDelivery = () => {
      const raw = path() === "raw";
      const cur = $("#m-delivery", m).value || (s.delivery === "tenant" ? "tenant" : "asis");
      $("#m-delivery", m).innerHTML = Object.entries(Object.keys(S.deliveries || {}).length ? S.deliveries : { asis: "As-is", tenant: "With a tenant" })
        .map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join("");
      $("#m-delivery", m).value = cur;
      $("#m-tenantfield", m).style.display = raw && cur === "tenant" ? "" : "none";
    };
    // a new direct source, or one moved to the direct path, starts with its sensor's own transport
    const sensorDefault = () => { const x = (S.sensors || []).find(y => String(y.n) === $("#m-sensor", m).value); if (x && x.transport) $("#m-transport", m).value = x.transport; };
    const fillTransports = () => { const p = path(); $("#m-transport", m).innerHTML = ((S.paths[p] || {}).transports || []).map(t => `<option value="${t}" ${t === s.transport ? "selected" : ""}>${TRANSPORT_LABEL[t]}</option>`).join(""); fillSensors(); fillWebhook(); fillVendors();
      if (p === "raw" && !(s.id && s.path === "raw")) sensorDefault(); refresh(); };
    const refresh = () => {
      fillCert();
      const p = path(), t = $("#m-transport", m).value, vk = vendor(), v = S.vendors[vk], raw = p === "raw";
      const relay = S.settings.relay_ip || "relay";
      const f = $("#m-format", m).value;
      const fields = S.deviceFields[vk] || [], fld = fields.find(x => x.field === $("#m-id_field", m).value) || fields[0];
      const idVal = $("#m-device_id", m).value.trim() || (fld ? (fld.default == null ? "(varies per event)" : fld.default) : "");
      const idText = fld ? `${fld.field}=${idVal}` : "";
      const sn = $("#m-sensor", m).value || "1", sen = (S.sensors || []).find(x => String(x.n) === sn);
      const sensorIp = raw ? ((sen && sen.address) || "address not set (Settings → Sensors)") : "";
      const wrapped = raw && $("#m-delivery", m).value === "tenant";
      const tid = $("#m-tenant", m).value.trim().toLowerCase(), tidOk = /^[0-9a-f]{32}$/.test(tid);
      const ip = $("#m-ip", m).value;
      // the line at the top says which world this source is in: the relay's row decides, or nothing on the relay is involved
      $("#m-note", m).textContent = raw
        ? "Sent straight to a Modular Sensor's parser port, as the firewall itself would send to it: no relay is involved, and nothing on the relay needs to exist for it."
        : sentence(S.onRelayNote || "Each log source defined here must also exist on the relay, as a log source in the Log Relay Manager.");
      // the device type's own parser port on the sensor; CEF has one shared port whatever the vendor
      const own = f === "cef" ? S.cefPort : (S.parserPort[vk] || "?");
      // what the relay's row says today, for the source being edited (a read; not something set here)
      const rr = s.id ? rel(S.sources.find(x => x.id === s.id) || {}) : {};
      const onRelay = !ADV() ? "the relay's own log-source row for this device" : rr.mapped ? `on the relay: tenant ${rr.tenant_label || (rr.tenant || "").slice(0, 8)}, port :${rr.port}` : rr.known ? "NOT on the relay yet: catch-all tenant" : "the relay's own row (not read)";
      const wh = $("#m-webhook_source", m).value || "generic";
      const whLabel = (S.webhookSources || {})[wh] || "Generic JSON log source";
      const nodes = p === "syslogng" ? [`${v} (${ip || "?"})`, `${TRANSPORT_LABEL[t]}`, `syslog-ng @ ${relay} looks the device up in its own map`, `wraps + TLS → sensor (${onRelay})`]
        : p === "nginx" ? [`${whLabel} JSON`, `POST ${$("#m-ingest_path", m).value.trim() ? "/ingest/" + $("#m-ingest_path", m).value.trim().replace(/^\/+|\/+$/g, "") + "/httpjson" : "/httpjson"}`,
                           `nginx @ ${relay} adds Stellar-TenantID from its map (by ${$("#m-ingest_path", m).value.trim() ? "URL path" : "address"})`, "HTTPS → sensor :5200"]
          : [`${v} (${ip || "host IP"}) · ${idText}`,
             wrapped ? `${TRANSPORT_LABEL[t].split(" ")[0]}: the log inside the Stellar JSON wrapper (tenant ${tidOk ? tid.slice(0, 8) + "…" : "?"}, msg_origin)` : `${TRANSPORT_LABEL[t].split(" ")[0]} as-is, no wrapper, no tenant`,
             `sensor ${sn} ${sensorIp}:${own} · ${wrapped ? "tenant " + (tidOk ? tid.slice(0, 8) + "…" : "?") : OWN_TENANT}`];
      $("#m-flow", m).innerHTML = nodes.map((n, i) => `${i ? '<span class="arr">→</span>' : ""}<span class="node">${esc(n)}</span>`).join("");
      $("#m-port", m).textContent = p === "nginx" ? ":5200" : `:${own}`;
      $("#m-port", m).style.opacity = raw ? "1" : ".55";
      $("#m-porthint", m).textContent = raw ? `Used: this source sends straight to this port on sensor ${sn} (${v}'s parser${f === "cef" ? ", the shared CEF port" : ""}).`
        : p === "nginx" ? "The sensor's HTTP JSON listener. The relay's map adds the tenant; the listener picks the parser."
          : `NOT used on this path. The relay's own log-source row names the sensor port it forwards to (normally this one, ${v}'s parser${f === "cef" ? ", the shared CEF port" : ""}); shown so the device is configured as the real one would be.`;
      // On the nginx path the parser is chosen by the sensor's :5200 listener, not by a port of this
      // source's own, so naming a parser port here would be wrong.
      $("#m-fmthint", m).textContent = raw ? (wrapped ? "Sent inside the wrapper to this format's parser port on the sensor." : "Sent as-is to this format's parser port on the sensor.")
        : p === "nginx" ? `NOT USED on this path. The nginx path is for devices that natively POST webhook JSON (PAN-OS HTTP profiles, Meraki webhooks, FortiGate automation stitches, CrowdStrike, Okta, AWS, Azure), so this path posts a generic JSON document - not ${v} syslog, and no device id. Search the marker, not the vendor. For ${v}'s own log use the syslog-ng path.`
          : f === "cef" ? "CEF is parsed on the sensor's shared CEF port, whatever the vendor." : `${v}'s own syslog, as the device writes it.`;
      $("#m-iphint", m).textContent = raw ? (wrapped ? "Optional: it is the wrapper's msg_origin.srcip when set; left empty, this host's own address to the sensor is used." : "Optional: nothing on this path looks the device up by address. Set one only to imitate a particular firewall's IP.")
        : `Required. The relay recognizes this device by the address it sees, unless its row on the relay names a field in the log. The app adds it to the interface here; remember to add it as a secondary private IP on the instance's ENI in AWS.`;
      if (fld) {
        $("#m-device_id", m).placeholder = fld.default == null ? "leave blank: varies per event" : `default ${fld.default}`;
        $("#m-idhint", m).textContent = `Written into every log as ${idText}. `
          + (raw ? (wrapped ? "The tenant comes from the wrapper here, so this is only the device's name in its own log." : "Put this exact value in the sensor's tenant mapping to land these logs in a tenant; blank sends the default shown.")
            : p === "syslogng" ? "A relay row can recognize the device by this value instead of its address (devid=… on the relay), which is what lets several devices send from one address."
              : `NOT WRITTEN on this path. The body is a JSON document, which has no ${fld ? fld.field : "devid"} field at all, so this value appears nowhere and cannot be filtered on. Use the syslog-ng path to send a log that carries it.`);
      }
      $("#m-webhookhint", m).textContent = p === "nginx"
        ? `The BODY of each POST is this product's own webhook JSON. The nginx path carries the tenant in a header the relay adds, so the body is whatever the product sends - pick the one your log source really is, or Generic for a plain JSON feed.`
        : "";
      const label = $("#m-ingest_path", m).value.trim().replace(/^\/+|\/+$/g, "");
      $("#m-pathhint", m).innerHTML = p !== "nginx" ? ""
        : label
          ? `This source posts to <code>${esc(t === "https443" ? "https" : "http")}://${esc(relay)}/ingest/${esc(label)}/httpjson</code>. The relay's path map says which tenant that label means (set there, in the Log Relay Manager). <b>Recommended</b>, and the only thing that works for a cloud log source: it posts from whatever address its provider uses.`
          : `Leave empty to post to <code>/httpjson</code> and be recognized by <b>address</b> on the relay — fine for an on-premises source with a fixed IP, useless for a cloud service. Give it the label the relay's path map uses to get a URL of its own.`;
      // which sensor, and whether this source's transport is the one the sensor is set to take
      $("#m-sensorhint", m).innerHTML = !sen ? `<span class="bad">There is no such sensor on Settings → Sensors.</span>`
        : !sen.address ? `<span class="bad">Sensor ${esc(sn)} has no address yet:</span> give it one on <a href="#/settings?view=sensors">Settings → Sensors</a> before a run.`
        : raw && sen.transport && sen.transport !== t ? `<span class="warn">Sensor ${esc(sn)} is set to ${esc(sen.transport.toUpperCase())}; this source sends ${esc(String(t).toUpperCase())}.</span> The sensor's Syslog TLS toggle decides which one it takes.`
        : `Its address and how this Studio trusts it are on <a href="#/settings?view=sensors">Settings → Sensors</a>.`;
      $("#m-deliveryhint", m).textContent = wrapped
        ? "The device's log, inside the record the relay would have written for it: the tenant and the full msg_origin (vendor, product, format, srcip), which the sensor needs to honor the tenant."
        : "The device's own syslog, exactly as it writes it. No tenant travels with it, so it lands in the sensor's own tenant unless a mapping on the sensor assigns one.";
      $("#m-tenanthint", m).innerHTML = !tid ? "The tenant's ID in Stellar Cyber: 32 characters, 0-9 and a-f."
        : tidOk ? `<span class="ok">A valid tenant ID.</span>`
        : `<span class="bad">Not a tenant ID yet: it is 32 characters of 0-9 and a-f (${tid.length} so far${/[^0-9a-f]/.test(tid) ? ", and it holds characters that are not hexadecimal" : ""}). The sensor silently ignores anything else and uses its own tenant.</span>`;
      $("#m-wrapnote", m).textContent = wrapped ? (((S.wrapperNotes || {})[vk] || {})[f] || []).join(" ") : "";
      // The relay only listens on 443 when it was installed with --front-tls. Offering the transport and
      // letting the run time out teaches nobody; say it here, with the command that fixes it.
      const relayPorts = ((S.relayStatus && S.relayStatus.listeners) || []).map(l => String(l.port));
      const mk = p === "syslogng" ? "syslog" : p === "nginx" ? "nginx" : "", mm = mk && S.relayStatus && S.relayStatus.methods && S.relayStatus.methods[mk];
      $("#m-pathmethodhint", m).innerHTML = mm && !mm.installed
        ? `<span class="bad">The relay does not have this method installed.</span> On the relay: <code>${esc(mm.add_cmd || "sudo stellar-relay add " + mk)}</code> (methods can be added or removed at any time; nothing else changes). This source cannot be saved on this path until then.`
        : mm && !mm.configured ? `<span class="bad">This method is installed on the relay but not set up yet.</span> On the relay: <code>${esc(mm.setup_cmd || "")}</code>` : "";
      $("#m-transporthint", m).innerHTML = (p === "nginx" && t === "https443" && relayPorts.length && !relayPorts.includes("443"))
        ? `<span class="bad">This relay is not listening on 443, so a run will time out.</span> It needs the nginx relay reinstalled with <code>--front-tls</code>, which adds a 443 listener with a self-signed certificate.`
        : "";
      $("#m-transport", m).closest(".field").querySelector("label").textContent = p === "syslogng" && t === "udp514" && vk === "meraki" ? "Transport (Meraki is UDP-only on real devices)" : "Transport";
    };
    $("#m-path", m).onchange = fillTransports; $("#m-vendor", m).onchange = fillFormats; $("#m-id_field", m).onchange = refresh;
    ["m-transport", "m-format", "m-webhook_source"].forEach(id => $("#" + id, m).onchange = refresh);
    $("#m-sensor", m).onchange = () => { sensorDefault(); refresh(); };
    $("#m-delivery", m).onchange = () => { fillDelivery(); refresh(); if ($("#m-delivery", m).value === "tenant") $("#m-tenant", m).focus(); };
    $("#m-ip", m).oninput = refresh; $("#m-device_id", m).oninput = refresh; $("#m-ingest_path", m).oninput = refresh; $("#m-tenant", m).oninput = refresh;
    fillTransports();
    $("#m-cancel", m).onclick = () => m.remove();
    $("#m-save", m).onclick = async () => {
      const body = { name: $("#m-name", m).value, vendor: vendor(), format: $("#m-format", m).value, path: path(), transport: $("#m-transport", m).value, bind_ip: $("#m-ip", m).value, enabled: $("#m-enabled", m).checked,
                     id_field: $("#m-id_field", m).value, device_id: $("#m-device_id", m).value.trim() };
      if (path() === "raw") {
        body.sensor = $("#m-sensor", m).value;
        body.delivery = $("#m-delivery", m).value || "asis";
        if (body.delivery === "tenant") body.tenant_id = $("#m-tenant", m).value.trim().toLowerCase();
      }
      // a chosen or removed certificate travels with the save; untouched, the stored one stays
      const tlsOff = $("#m-certfield", m).style.display === "none";
      if (certMode() === "two" && (certPart !== undefined || keyPart !== undefined)) {
        body.client_cert_pem = tlsOff ? "" : (certPart || "");
        body.client_key_pem = tlsOff ? "" : (keyPart || "");
      } else if (clientPem !== undefined) {
        body.client_pem = tlsOff ? "" : clientPem;
      }
      body.tls_verify = tlsOff ? "any" : $("#m-tls_verify", m).value;
      if (body.tls_verify === "ca" && caPem !== undefined) body.tls_ca = caPem;
      if (body.tls_verify === "pin") body.tls_pin = $("#m-tls_pin", m).value.trim();
      body.webhook_source = $("#m-webhook_source", m).value;
      body.ingest_path = $("#m-ingest_path", m).value.trim();
      $("#m-save", m).disabled = true;
      try { const r = await (s.id ? api("PUT", `/api/sources/${s.id}`, body) : api("POST", "/api/sources", body)); reportSaved(r); m.remove(); if (!s.id) S.picked.add(r.id); await loadCore(); (location.hash.startsWith("#/send") ? pageSend : pageSources)(); }
      catch (e) { toast(e.message, "bad"); $("#m-save", m).disabled = false; }
    };
  }
  $("#addSource").onclick = () => sourceModal();

  // ---------------------------------------------------------------- history
  async function pageHistory() {
    const r = await api("GET", "/api/runs?limit=200");
    $("#histTbl").innerHTML = r.runs.length ? r.runs.map(x => runRow(x, false)).join("") : `<tr><td colspan="9" class="empty">No runs yet</td></tr>`;
    $$("#histTbl tr.clickable").forEach(tr => tr.onclick = () => openRun(+tr.dataset.id));
  }
  async function openRun(id) {
    const r = await api("GET", `/api/runs/${id}`);
    const p = r.params || {};
    const landed = (s) => s.path === "raw" ? `sensor ${s.sensor || "1"} :${s.port || "?"} · ${WRAPPED(s) ? "wrapped, tenant " + fmt.short(directTenant(s)) : OWN_TENANT}`
      : (s.relay && s.relay.mapped) ? `${s.relay.tenant_label || fmt.short(s.relay.tenant)} :${s.relay.port || s.port}` : (s.relay && s.relay.known) ? "not on the relay (catch-all)" : "decided by the relay";
    const m = modal(`<div class="head"><h2>Run #${r.id} ${statusPill(r.status)}</h2><div class="actions"><button class="btn sm primary" id="m-rerun">Re-run with same settings</button><button class="btn sm" id="m-close">Close</button></div></div>
      <dl class="kv"><dt>Started</dt><dd>${fmt.dt(r.started)}${r.finished ? ` · ${Math.round(r.finished - r.started)}s` : ""}</dd><dt>By</dt><dd>${esc(r.user || "")}</dd>
      <dt>Settings</dt><dd>${p.loop ? "until stopped" : p.duration && !p.rate ? `as many as it could for ${clock(p.duration)}` : `${fmt.n(p.duration && p.rate ? Math.round(p.rate * p.duration) : p.count)} events`} per firewall, mix <b>${esc(p.mix)}</b>${p.kind ? ` / ${esc(p.kind)}` : ""}${p.rate ? `, ${p.rate}/s` : ", max rate"}${p.size ? `, padded to ${fmt.bytes(p.size)}` : ""}${p.seed != null ? `, seed ${p.seed}` : ""}</dd>
      ${r.note ? `<dt>Note</dt><dd>${esc(r.note)}</dd>` : ""}</dl>
      <h3 style="margin-top:14px">Per firewall</h3>
      <table><thead><tr><th>Source</th><th>Path</th><th>Where it lands</th><th class="num">Sent</th><th class="num">Failed</th><th class="num">Bytes</th></tr></thead><tbody>
      ${Object.values(r.per_source || {}).map(s => `<tr><td>${esc(s.name)} ${vendorTag(s.vendor)}</td><td class="small">${esc(PATH_SHORT[s.path])} · ${esc(TRANSPORT_LABEL[s.transport] || s.transport)}</td><td class="small">${esc(landed(s))}${s.identity ? ` <span class="faint mono small">${esc(s.identity)}</span>` : ""}</td><td class="num">${fmt.n(s.sent)}</td><td class="num">${fmt.n(s.failed)}${s.reconnects ? `<br><span class="small muted nobr" title="the connection to the relay broke after records had been delivered on it, and the sender dialed again as a device would; what was in flight at the break is counted as failed">reconnected ${s.reconnects}×</span>` : ""}</td><td class="num">${fmt.bytes(s.bytes)}</td></tr>${s.last_error ? `<tr><td colspan="6" class="small" style="color:var(--bad)">${esc(s.last_error)}</td></tr>` : s.note ? `<tr><td colspan="6" class="small muted">${esc(s.note)}</td></tr>` : ""}`).join("")}</tbody></table>
      ${!ADV() ? `<h3 style="margin-top:14px">Where to confirm this</h3><p class="small muted">This Studio has no management connection to the relay, so it does not ask what the relay forwarded. Search this run's marker in Stellar Cyber, and open the Log Relay Manager's Activity page on the relay.</p>` : `
      <h3 style="margin-top:14px">What the relay reported</h3>
      ${(r.relay?.summary || []).length ? `<table><thead><tr><th>Records</th><th>Parser</th><th>Tenant</th><th>Port</th><th>Errors</th></tr></thead><tbody>${r.relay.summary.map(s => `<tr><td class="num">${fmt.n(s.count)}</td><td>${esc(s.label)}</td><td>${esc(s.tenant_label || s.tenant)}</td><td>:${s.port}</td><td>${s.errors || 0}</td></tr>`).join("")}</tbody></table>` : `<p class="faint small">Nothing recorded from the relay (direct-to-sensor run, log relay manager not configured, or nothing was forwarded).</p>`}
`}
      <h3 style="margin-top:14px">Log</h3><div class="log">${(r.log || []).map(l => `<div class="${esc(l.kind)}">${l.ts ? `<span class="dim">${fmt.time(l.ts)}</span> ` : ""}${esc(l.line)}</div>`).join("")}</div>`);
    $("#m-close", m).onclick = () => m.remove();
    $("#m-rerun", m).onclick = () => {
      S.picked = new Set((p.sources || []).map(s => s.id)); S.preset = "";
      m.remove(); location.hash = "#/send";
      setTimeout(() => { $("#f-count").value = p.count; $("#f-rate").value = p.rate || 0;
        // how much it sent, as it was asked: a count, a length of time, or until Stop
        $("#f-howmuch").value = p.loop ? "loop" : p.duration ? "time" : "count";
        if (p.duration) { const u = p.duration % 3600 === 0 ? 3600 : p.duration % 60 === 0 ? 60 : 1; $("#f-for-unit").value = String(u); $("#f-for").value = p.duration / u; }
        howMuchBoxes(); $("#f-mix").value = p.mix; $("#f-kind").value = p.kind || ""; $("#f-size").value = p.size || 0; $("#f-seed").value = p.seed ?? ""; $("#f-capture").checked = !!p.capture; $("#f-note").value = r.note || ""; $$("#presets .preset").forEach(b => b.classList.remove("active")); hint(); toast("Settings restored; press Start sending"); }, 300);
    };
  }
  $("#showAudit").onclick = async () => {
    const r = await api("GET", "/api/audit");
    const m = modal(`<div class="head"><h2>Audit log</h2><button class="btn sm" id="m-close">Close</button></div><table><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Detail</th></tr></thead><tbody>${r.items.map(a => `<tr><td class="small">${fmt.dt(a.ts)}</td><td>${esc(a.user)}</td><td><code>${esc(a.action)}</code></td><td class="small muted">${esc(a.detail)}</td></tr>`).join("") || `<tr><td colspan="4" class="empty">Nothing yet</td></tr>`}</tbody></table>`);
    $("#m-close", m).onclick = () => m.remove();
  };

  // ---------------------------------------------------------------- services
  async function pageServices() {
    const r = await api("GET", "/api/services");
    // The pill holds one word. A state that carries a reason ("unknown (…)") is split: the word in the pill,
    // the reason on its own wrapped line, so nothing can run out of the card.
    const row = (s, where, actions) => {
      const st = String(s.state || "unknown"), i = st.indexOf(" ("), word = i > 0 ? st.slice(0, i) : st, why = i > 0 ? st.slice(i + 2).replace(/\)$/, "") : "";
      // the buttons sit under the name, on the left, where every other page puts what it exists for
      return `<div class="svc"><div><b>${esc(s.name)} ${pill(s.active ? "ok" : "bad", word)}</b><small>${esc(s.since || "mock Modular Sensor on this host")}</small>${why ? `<div class="why">${esc(why)}</div>` : ""}<div class="svc-acts">${actions.map(a => `<button class="btn sm ${a === "stop" ? "danger" : ""}" data-w="${where}" data-n="${esc(s.name)}" data-a="${a}">${a[0].toUpperCase() + a.slice(1)}</button>`).join("")}</div></div></div>`;
    };
    // the page's own subtitle already says the relay's services are the relay's: the card does not say it again
    $("#svc-local").innerHTML = r.services.filter(s => s.where !== "relay").map(s => row(s, "local", ["start", "stop", "restart"])).join("");
    $$("#svc-local button").forEach(b => b.onclick = async () => {
      if (b.dataset.a === "stop" || b.dataset.a === "restart") { if (!confirm(`${b.dataset.a} ${b.dataset.n}?`)) return; }
      b.disabled = true;
      try { await api("POST", `/api/services/${b.dataset.w}/${b.dataset.n}/${b.dataset.a}`); toast(`${b.dataset.n}: ${b.dataset.a} ok`, "ok"); setTimeout(pageServices, 1500); }
      catch (e) { toast(e.message, "bad"); b.disabled = false; }
    });
  }

  // ---------------------------------------------------------------- settings
  // this host's own addresses, or a sentence saying they could not be read (a host with no `ip` command)
  const hostIpsHtml = () => (S.settings.host_ips || []).map(h => `${esc(h.iface)} ${esc(h.ip)}`).join("<br>")
    || `<span class="faint">could not be read on this host</span>`;
  // The sensors and the sensor's time zone are saved from their own tab (Save sensors), not with these.
  const SKEYS_ALL = ["console_name", "relay_ip", "nginx_port", "relay_monitor_url", "relay_token", "iface", "relay_ca"];
  // The standard edition has no management connection and no nginx path, so those boxes are not on the page:
  // reading or sending them would either throw on a missing element or be refused by the relay-facing rule.
  const SKEYS = () => SKEYS_ALL.filter(k => ADV() || !["nginx_port", "relay_monitor_url", "relay_token"].includes(k));
  // Updating this app from a bundle Stellar Cyber signed. The same card as the Log Relay Manager's,
  // from the shared framework, so the two cannot drift apart. No impact table here: nothing flows
  // through Ingest Studio, so the only cost is that a test run in progress stops.
  let UPDATE_CARD = null;
  const updateCardOpts = () => ({
    what: "Ingest Studio",
    bundle: "stellar-ingest-studio-<version>-signed.tar.gz",
    steps: 10,     // the bundle's install.sh, the test tools and the app's own installer; see updateCard
    // the same command as the relay's: it reports on whichever console is on this host, and the one
    // thing a stuck Ingest Studio needs is someone to say whether anything is still installing
    recover: { cmd: "sudo stellar-update-doctor",
               info: "Run this on the host over SSH, not from here. It reads and changes nothing: it says whether an install is still running and whether the version on disk changed, then prints what to do. Add --fix to clear a run that is no longer running. It never kills anything and never installs anything. If this Studio was updated from 1.1.3 or earlier, the command is not on the host yet; it is in the release bundle." },
    impact: () => `<div class="cfg-note"><div class="grow"><b>No logs flow through this host.</b> Ingest Studio only ever sends test
      traffic, so an update costs nothing but a run in progress. Your log sources, run history, settings and sign-in are kept.</div></div>`,
    confirm: { title: "Update Ingest Studio now?", mustType: "update", button: "Update now" },
    rollback: { title: "Roll back to the previous version?", mustType: "roll back", button: "Roll back",
                text: "The release that was installed before the last update is put back." },
  });

  // Settings in tabs, the way the Log Relay Manager's is (Paul, 1 Oct 2026): the relay and this host, the sensors a
  // direct log source sends to (8 Oct 2026), Security (the sign-in timeout and this Studio's HTTPS certificate,
  // 8 Oct 2026), and updating this app. The tab last opened is remembered per
  // browser; ?view= picks one.
  const SET_VIEWS = ["relay", "sensors", "security", "update"];
  let SET_VIEW = (() => { try { const v = localStorage.getItem("is-set-view"); return SET_VIEWS.includes(v) ? v : "relay"; } catch (e) { return "relay"; } })();
  function setSetView(v) {
    if (!SET_VIEWS.includes(v)) v = "relay";
    SET_VIEW = v; try { localStorage.setItem("is-set-view", v); } catch (e) {}
    SET_VIEWS.forEach(k => { const el = $("#set-view-" + k); if (el) el.classList.toggle("hidden", k !== v); });
    $$("#set-tabs button").forEach(b => b.classList.toggle("active", b.dataset.setview === v));
  }
  $$("#set-tabs button").forEach(b => b.onclick = () => setSetView(b.dataset.setview));
  setSetView(SET_VIEW);


  // Settings -> Security: the sign-in timeout and this Studio's own HTTPS certificate - the tab the Log Relay
  // Manager has, with the same certificate card (Lab.certCard), so reissuing or replacing a certificate is done
  // the same way in both (Paul, 8 Oct 2026). Built on first use, never at module load: a fault in a Settings card
  // must not take the whole page with it.
  let STUDIO_CERT_CARD = null;
  function studioCertSwapped() {
    const bg = Lab.modal(`<h2>This Studio now has its new certificate</h2>
      <p class="small muted">Reload this page so your browser can see it. A browser trusts a certificate one at a time, so until this page is reloaded, every button on it is refused by the browser, not by the Studio.</p>
      <p class="small muted">A self-signed certificate makes the browser warn once after the reload; accept it as you did the first time. A run in progress is not affected.</p>
      <div class="row" style="margin-top:14px;justify-content:flex-end"><button class="btn primary" id="scs-reload">Reload now</button></div>`);
    $("#scs-reload", bg).onclick = () => location.reload();
  }
  function studioCertCard() {
    if (STUDIO_CERT_CARD) return STUDIO_CERT_CARD;
    STUDIO_CERT_CARD = Lab.certCard({
      id: "cc", api: "/api/console-cert", body: "#cc-body", pill: "#cc-pill", who: "browsers",
      dl: { cert: "ingest-studio.crt", ca: "ingest-studio-ca.pem", csr: "ingest-studio.csr" },
      here: () => location.hostname, generatedWords: "self-signed, made at install", selfPill: "self-signed: browsers warn",
      cnHint: "The name or address people type in the browser to open this Studio. A host name your DNS resolves to this host is best; an address works too.",
      sansLabel: "Every name and address this Studio is opened by",
      sansHint: "Browsers check the address bar against this list, not against the common name. Prefilled with this host's addresses and the one you are using now; remove any that are not yours, add a DNS name if you have one.",
      installFor: `this Studio's HTTPS on port ${esc(location.port || "8443")}, the page browsers open. It has nothing to do with the logs this Studio sends: those use the log relay's or the sensor's certificate.`,
      selfCost: "Browsers will warn again.",
      selfWarning: "This certificate is <b>self-signed</b>, so every browser warns on the first visit. Downloads from these pages still work, because the Studio fetches them itself; <code>curl</code> and anything scripted need <code>-k</code> or the certificate trusted. Have a certificate authority sign a request made here to stop the warning for good.",
      helperMissing: "The root helper <code>stellar-studio-cert</code> is not installed on this host, so the certificate can be seen here but not changed. Run the Studio's installer again (<code>sudo bash install.sh</code>).",
      warnings: (c) => {
        const w = [];
        if (!c.tls) w.push("This Studio is serving plain HTTP right now (NO_TLS), so the certificate is not presented to anyone.");
        if (c.managed === false) w.push("The Studio's settings file points TLS_CERT at a different file than the one this page manages. Point it back at the default to manage the certificate here.");
        return w;
      },
      after: (what, r) => {
        const f = r.facts || {}, ch = r.chain || {};
        if (what === "install") return `Installed${r.reloaded ? " and presented from now on" : ""}: <b>${esc(f.subject || "")}</b>${ch.note ? ", " + esc(ch.note) : ""}. <b>Reload this page</b>: the browser opens a new connection and sees the new certificate.`;
        if (what === "restore") return `Previous certificate back in use: ${esc(f.subject || "")}. Reload this page so the browser opens a new connection and sees it.`;
        if (what === "reissue") return `Reissued, self-signed, for ${esc((r.names || []).join(", "))}. Reload this page so the browser opens a new connection and sees it.`;
        return "Back on a self-signed certificate. Reload this page and accept the browser's warning once.";
      },
      changed: (r, what) => { if (what === "reissue") studioCertSwapped(); },
    });
    window.STUDIO_CERT_CARD = STUDIO_CERT_CARD;    // ui-smoke drives render() with states the real helper is not in
    return STUDIO_CERT_CARD;
  }
  async function renderSessionPolicy() {
    const box = $("#session-policy"); if (!box) return;
    let p; try { p = await api("GET", "/api/session-policy"); } catch (e) { box.innerHTML = `<p class="small faint">${esc(Lab.errText(e))}</p>`; return; }
    box.innerHTML = `<p class="small muted" style="margin:0 0 8px">Everyone signed in to this Studio is signed out after this long without activity. Typing, clicking, scrolling and saving count; a page refreshing itself does not, so a tab left open still signs out. A change takes effect at each account's next activity. A run keeps sending whether anyone is signed in or not.</p>
      <div class="row"><div class="field" style="flex:0 1 420px"><label for="sess-idle">Sign out after (minutes)</label><input id="sess-idle" inputmode="numeric" value="${esc(String(p.idle_minutes))}"><div class="hint">${p.min} to ${p.max} (${p.max / 60} hours); the default is ${p.default}</div></div><button class="btn primary" id="sess-save">Save</button></div>`;
    $("#sess-save", box).onclick = async () => {
      const v = $("#sess-idle", box).value.trim();
      try { const r = await api("PUT", "/api/session-policy", { idle_minutes: v }); toast(`Sign-ins now end after ${r.idle_minutes} minutes without activity`, "ok"); }
      catch (e) { toast(Lab.errText(e), "bad"); }
      renderSessionPolicy();
    };
  }
  async function loadSecurity() {
    renderSessionPolicy().catch(() => {});
    const card = studioCertCard();
    try { const want = Lab.hashParams().get("cert"); if (want && !card.panel) card.panel = want; card.render(await api("GET", "/api/console-cert")); }
    catch (e) { const b = $("#cc-body"); if (b) b.innerHTML = `<p class="small faint">${esc(Lab.errText(e))}</p>`; }
  }

  async function pageSettings() {
    // ?cert= opens the certificate card's panel, so it lands on the tab that holds it
    setSetView(Lab.hashParams().get("view") || (Lab.hashParams().get("cert") ? "security" : SET_VIEW));
    loadSecurity();
    await loadSettings();
    Lab.infoButtons($("#set-view-relay"));
    Lab.infoButtons($("#set-view-sensors"));
    tzOptions();
    loadSensors().catch((e) => { const b = $("#sens-cards"); if (b) b.innerHTML = `<p class="small bad">${esc(Lab.errText(e))}</p>`; });
    SKEYS().forEach(k => { const el = $("#s-" + k); if (el) el.value = S.settings[k] ?? ""; });
    relayCaNow();
    $("#ifaceHint").textContent = `Detected default interface: ${S.settings.default_iface}`;
    $("#hostips").innerHTML = hostIpsHtml();
    // the relay console holds this at module scope, so ui-smoke can drive render() with a state the
    // real helper cannot easily be put into (an install in flight, a failed one). This page's is in a
    // closure, so it is published deliberately: the same card, reachable the same way, in both apps.
    if (!UPDATE_CARD) { UPDATE_CARD = Lab.updateCard(updateCardOpts()); window.UPDATE_CARD = UPDATE_CARD; }
    UPDATE_CARD.load().catch(() => {});
  }
  // The sensor's time zone (Paul, 7 Oct 2026: "I have the sensor set for our time with the time zone. Can the log
  // be sent with the right time"). Every zone this host knows, in one skinned list with its type-to-filter box;
  // the options are built once, and the sentence under it says what the devices' clocks read now.
  function tzOptions() {
    const sel = $("#s-device_tz"); if (!sel) return;
    const zones = S.settings.time_zones || [];
    if (sel.options.length !== zones.length + 1) {
      sel.innerHTML = `<option value="">Not set (UTC)</option>` + zones.map(z => `<option value="${esc(z)}">${esc(z.replace(/_/g, " "))}</option>`).join("");
    }
    const now = $("#s-device_tz-now"); if (now) now.textContent = S.settings.device_tz_now || "";
  }
  // The CA that signed the relay's 6514 certificate: with it, every TLS send verifies the relay (the chain; not
  // the name, since this host dials the relay by address). A file button fills the box; the box is what is saved.
  function relayCaNow() {
    const box = $("#s-relay_ca-now"); if (!box) return;
    const f = S.settings.relay_ca_facts;
    box.innerHTML = f && f.ok ? `verifying the relay against <b>${esc(f.cn || f.subject)}</b> <span class="faint">· ${f.days_left != null ? (f.days_left < 0 ? "expired" : "expires in " + f.days_left + " days") : ""}</span>`
      : `<span class="faint">none: any certificate the relay presents is accepted (what the Stellar Cyber documentation asks of senders)</span>`;
  }
  const caFile = $("#s-relay_ca-file");
  if (caFile) caFile.onchange = async () => { const f = caFile.files[0]; if (!f) return; $("#s-relay_ca").value = await f.text(); $("#dirty").classList.remove("hidden"); };
  const caClear = $("#s-relay_ca-clear");
  if (caClear) caClear.onclick = (e) => { e.preventDefault(); $("#s-relay_ca").value = ""; $("#dirty").classList.remove("hidden"); };
  async function saveSettings(quiet) {
    const body = {}; SKEYS().forEach(k => { const el = $("#s-" + k); if (el) body[k] = el.value; });
    await api("PUT", "/api/settings", body);
    $("#dirty").classList.add("hidden");
    if (!quiet) toast("Settings saved", "ok");
    await loadSettings(); $("#hostips").innerHTML = hostIpsHtml();
    $("#s-relay_token").value = S.settings.relay_token || "";
    relayCaNow();
  }

  // ---------------------------------------------------------------- settings: the sensors
  // One card per Modular Sensor a direct log source sends to (Paul, 8 Oct 2026: "a sensor configuration section
  // similar to log relay manager so it can send directly to a sensor"), each with the same parts as a sensor card
  // on the relay: its address, the transport a direct log source pointed at it starts with, how this Studio trusts
  // its certificate, which log sources send to it, and a test of the address IN THE BOX, saved or not. Numbers stay
  // what they are: a log source names its sensor by number, so nothing is renumbered when one is removed.
  const SENS = { cards: [], meta: { max: 8, trusts: {} }, results: {}, tz0: null };
  const TRUST_HINT = {
    any: "Whatever the sensor presents is accepted: what the Stellar Cyber documentation asks of senders while a sensor wears its self-signed default.",
    stellar: "Its certificate must chain to Stellar Cyber's own CA, which ships with this Studio. The name on it is not checked.",
    ca: "Its certificate must chain to the CA uploaded here. The name on it is not checked: a sensor usually names its internal address.",
    pin: "Its certificate must be exactly this one, whoever signed it. Nothing is sent if it ever presents another.",
  };
  const sensDirty = (on) => { const p = $("#sens-dirty"); if (p) p.classList.toggle("hidden", !on); };
  async function loadSensors() {
    const d = await api("GET", "/api/sensors");
    SENS.meta = d; SENS.cards = d.sensors.map(x => ({ ...x })); S.sensors = d.sensors;
    SENS.tz0 = S.settings.device_tz || "";
    drawSensorCards(); sensDirty(false);
  }
  function sensResultHtml(r) {
    if (!r) return "";
    if (r.error) return `<div class="callout small" style="margin:8px 0 0">${esc(r.error)}</div>`;
    const rows = (r.results || []).map(x => {
      const c = x.cert || {};
      const verdict = x.reachable === null ? pill("idle", "not checkable")
        : !x.reachable ? pill("bad", "not reachable") : x.handshake_ok === false ? pill("bad", "no TLS")
        : x.operational ? pill("ok", x.handshake_ok ? "answers, TLS " + (x.tls_version || "").replace("TLSv", "") : "answers") : pill("bad", "refused by its trust");
      const lines = [x.error && `<span class="bad">${esc(x.error)}</span>`,
        c.sha256 && `certificate <b>${esc(c.cn || c.subject || "?")}</b> <span class="faint">· issued by ${esc(c.issuer || "?")}${c.days_left != null ? ` · ${c.days_left < 0 ? "expired" : "expires in " + c.days_left + " days"}` : ""}${c.self_signed ? " · self-signed" : ""}</span>`,
        c.sha256 && `<span class="mono faint" title="SHA-256 of the certificate">SHA-256 ${esc(c.sha256)}</span>`,
        x.chain_ok === true && `<span class="ok">chains to the CA this sensor is set to trust</span>`,
        x.pin_ok === true && `<span class="ok">the pinned certificate</span>`,
        ...(x.notes || []).map(n => `<span class="muted">${esc(n)}</span>`)].filter(Boolean);
      return `<tr><td class="mono nobr">:${esc(x.port)}</td><td class="nobr">${verdict}${x.ms != null ? ` <span class="faint small">${x.ms} ms</span>` : ""}</td><td class="small">${lines.join("<br>")}</td></tr>`;
    }).join("");
    return `<div class="small" style="margin:10px 0 4px"><b>${esc(r.address)}</b> ${esc(r.summary)} <span class="faint">· tested ${esc(r.ports_from)}${r.saved ? "" : " · this address is not saved yet"}</span></div>
      <table class="sens-res"><thead><tr><th>Port</th><th>Answer</th><th>What came back</th></tr></thead><tbody>${rows}</tbody></table>`;
  }
  function sensorCardHtml(c) {
    const m = SENS.meta || {}, trusts = m.trusts || {}, srcs = c.sources || [];
    const r = SENS.results[c.n];
    const head = r && !r.error ? (r.operational === null ? pill("idle", "UDP: not checkable") : r.operational ? pill("ok", "answers") : pill("bad", "does not answer properly")) : "";
    const ca = c.ca_new ? `<span class="ok">${esc(c.ca_name || "a CA")} chosen: saved with the sensor</span>`
      : c.ca_facts && c.ca_facts.ok ? `${esc(c.ca_facts.subject || c.ca_facts.cn || "a CA")} <span class="faint">${c.ca_facts.days_left != null ? `· ${c.ca_facts.days_left < 0 ? "expired" : "expires in " + c.ca_facts.days_left + " days"}` : ""}</span>`
      : `<span class="faint">no CA uploaded for this sensor yet</span>`;
    const pinnedPorts = [...new Set(srcs.map(x => x.port))].join(", ");
    return `<div class="card sens-card" data-sens="${c.n}" style="margin-bottom:14px">
      <div class="head"><h3>Sensor ${c.n}</h3>${head}</div>
      <div class="row">
        <div class="field"><label>Address</label><input data-k="address" value="${esc(c.address || "")}" placeholder="10.0.1.5${c.n} or sensor${c.n}.example.com" autocomplete="off" spellcheck="false">
          <div class="hint">An IPv4 address, or a host name this host can resolve.${(c.resolved || []).length ? ` Resolves to ${esc(c.resolved.join(", "))} now.` : ""}</div></div>
        <div class="field" style="max-width:220px"><label>Transport</label><select data-k="transport">${["tls", "tcp", "udp"].map(t => `<option value="${t}" ${c.transport === t ? "selected" : ""}>${t === "tls" ? "TLS (default)" : t.toUpperCase()}</option>`).join("")}</select>
          <div class="hint">What a direct log source pointed here starts with. It must match the sensor profile's Log Forwarder &rarr; TLS toggle.</div></div>
        <div class="field" style="max-width:320px"><label>How this Studio trusts its certificate</label><select data-k="trust">${Object.entries(trusts).map(([k, v]) => `<option value="${k}" ${c.trust === k ? "selected" : ""} ${k === "stellar" && !m.builtin_ca ? "disabled" : ""}>${esc(v)}${k === "stellar" && !m.builtin_ca ? " (not on this host)" : ""}</option>`).join("")}</select>
          <div class="hint">${esc(TRUST_HINT[c.trust] || TRUST_HINT.any)}</div></div>
      </div>
      <div class="row" data-show="ca" style="margin-top:4px;${c.trust === "ca" ? "" : "display:none"}">
        <label class="btn sm" style="cursor:pointer;flex:0 0 auto">Choose the CA file (PEM)<input type="file" data-k="cafile" accept=".pem,.crt,.cer,.txt" style="display:none"></label>
        <span class="small" style="align-self:center">${ca}</span></div>
      <div class="row" data-show="pin" style="margin-top:4px;${c.trust === "pin" ? "" : "display:none"}">
        <div class="field"><label>SHA-256 of its certificate</label><input data-k="pin" value="${esc(c.pin || "")}" placeholder="64 hexadecimal characters" class="mono" autocomplete="off" spellcheck="false"></div>
        <button class="btn sm" data-act="readpin">Read it from the sensor</button></div>
      <div class="small" style="margin:10px 0 6px">${srcs.length
        ? `Log sources that send here: ${srcs.map(x => `<span class="chip">${esc(x.name)} <span class="faint">:${esc(x.port)} ${x.delivery === "tenant" ? "wrapped" : "as-is"}</span></span>`).join("")}`
        : `<span class="faint">No direct log source sends here yet.</span>`}</div>
      <div class="row">
        <div class="field" style="max-width:220px"><label>Port to test</label><input data-k="port" value="${esc(c.port || "")}" placeholder="${esc(pinnedPorts || "e.g. 5517")}" inputmode="numeric" autocomplete="off"></div>
        <button class="btn" data-act="test">Test the connection</button>
        ${c.n === 1 ? "" : `<button class="btn danger" data-act="remove">Remove sensor ${c.n}</button>`}
      </div>
      <div class="hint" style="margin-top:4px">${srcs.length ? `Leave the port empty to test ${pinnedPorts}, the ports its log sources use.` : "Type the parser port to test: no log source sends here yet."} Nothing is sent; the address in the box is tested, saved or not.</div>
      <div data-slot="result">${sensResultHtml(r)}</div>
    </div>`;
  }
  function drawSensorCards() {
    const box = $("#sens-cards"); if (!box) return;
    box.innerHTML = SENS.cards.map(sensorCardHtml).join("");
    const add = $("#sensAdd"); if (add) add.disabled = SENS.cards.length >= (SENS.meta.max || 8);
    $$(".sens-card", box).forEach(card => {
      const c = SENS.cards.find(x => String(x.n) === card.dataset.sens);
      const bind = (k, ev, fn) => { const el = card.querySelector(`[data-k="${k}"]`); if (el) el[ev] = fn; };
      bind("address", "oninput", (e) => { c.address = e.target.value.trim(); sensDirty(true); });
      bind("transport", "onchange", (e) => { c.transport = e.target.value; sensDirty(true); });
      bind("trust", "onchange", (e) => { c.trust = e.target.value; sensDirty(true); drawSensorCards(); });
      bind("pin", "oninput", (e) => { c.pin = e.target.value.trim(); sensDirty(true); });
      bind("port", "oninput", (e) => { c.port = e.target.value.trim(); });      // a test setting, not saved
      bind("cafile", "onchange", async (e) => { const f = e.target.files[0]; if (!f) return; c.ca_new = await f.text(); c.ca_name = f.name; sensDirty(true); drawSensorCards(); });
      const act = (a, fn) => { const b = card.querySelector(`[data-act="${a}"]`); if (b) b.onclick = (e) => { e.preventDefault(); fn(b); }; };
      act("test", (b) => testSensor(c, card, b));
      act("readpin", (b) => readPin(c, card, b));
      act("remove", () => removeSensor(c));
    });
  }
  // what the card holds, for a check of the address in the box (saved or not)
  const cardBody = (c) => ({ n: c.n, address: c.address, transport: c.transport, trust: c.trust, pin: c.pin || "",
                             ...(c.ca_new ? { ca: c.ca_new } : {}), port: c.port || "" });
  async function testSensor(c, card, b) {
    const slot = card.querySelector('[data-slot="result"]');
    b.disabled = true; slot.innerHTML = `<p class="small faint" style="margin:8px 0 0">Connecting to ${esc(c.address || "?")} from this host…</p>`;
    try { SENS.results[c.n] = await api("POST", "/api/sensors/check", cardBody(c)); }
    catch (e) { SENS.results[c.n] = { error: Lab.errText(e) }; }
    drawSensorCards();
  }
  async function readPin(c, card, b) {
    b.disabled = true;
    try {
      const r = await api("POST", "/api/sensors/check", { ...cardBody(c), transport: "tls", trust: "any" });
      const got = (r.results || []).map(x => (x.cert || {}).sha256).find(Boolean);
      if (!got) { toast((r.results || []).map(x => x.error).filter(Boolean)[0] || "No certificate came back from that address", "bad"); b.disabled = false; return; }
      c.pin = got; sensDirty(true); drawSensorCards();
      toast(`Pinned what ${r.address} is presenting now. Save sensors to keep it.`, "ok");
    } catch (e) { toast(Lab.errText(e), "bad"); b.disabled = false; }
  }
  async function removeSensor(c) {
    const srcs = c.sources || [];
    if (srcs.length) {
      toast(`Sensor ${c.n} is not removed: ${srcs.length} log source${srcs.length === 1 ? " sends" : "s send"} to it (${srcs.map(x => x.name).join(", ")}). Point ${srcs.length === 1 ? "it" : "them"} at another sensor first.`, "bad");
      return;
    }
    const yes = await Lab.confirm({ title: `Remove sensor ${c.n}?`, text: `Nothing changes until you press Save sensors. Sensor numbers are not reused for the others: every other sensor keeps its number.`, button: `Remove sensor ${c.n}`, danger: true });
    if (!yes) return;
    SENS.cards = SENS.cards.filter(x => x.n !== c.n); delete SENS.results[c.n];
    sensDirty(true); drawSensorCards();
  }
  const sensAddBtn = $("#sensAdd");
  if (sensAddBtn) sensAddBtn.onclick = () => {
    const empty = SENS.cards.find(c => !c.address);
    if (empty && empty.n !== 1) { const box = $(`.sens-card[data-sens="${empty.n}"] [data-k="address"]`); if (box) box.focus(); return toast(`Sensor ${empty.n} has no address yet: fill that one in first`, "warn"); }
    let n = 0; for (let i = 1; i <= (SENS.meta.max || 8); i++) if (!SENS.cards.some(c => c.n === i)) { n = i; break; }
    if (!n) return toast(`This Studio sends to at most ${SENS.meta.max || 8} sensors`, "warn");
    SENS.cards.push({ n, address: "", transport: (SENS.cards[0] || {}).transport || "tls", trust: "any", pin: "", sources: [] });
    SENS.cards.sort((a, b) => a.n - b.n);
    sensDirty(true); drawSensorCards();
    const box = $(`.sens-card[data-sens="${n}"] [data-k="address"]`); if (box) box.focus();
  };
  const sensSaveBtn = $("#sensSave");
  if (sensSaveBtn) sensSaveBtn.onclick = async () => {
    sensSaveBtn.disabled = true;
    try {
      const body = { sensors: SENS.cards.map(c => ({ n: c.n, address: c.address || "", transport: c.transport || "tls", trust: c.trust || "any",
                                                     pin: c.pin || "", ...(c.ca_new ? { ca: c.ca_new } : {}) })) };
      await api("PUT", "/api/sensors", body);
      const tz = ($("#s-device_tz") || {}).value || "";
      if (tz !== SENS.tz0) await api("PUT", "/api/settings", { device_tz: tz });
      await loadSettings(); tzOptions(); await loadSensors();
      toast("Sensors saved", "ok");
    } catch (e) { toast(Lab.errText(e), "bad"); }
    finally { sensSaveBtn.disabled = false; }
  };
  const tzSel = $("#s-device_tz"); if (tzSel) tzSel.addEventListener("change", () => sensDirty(true));
  SKEYS_ALL.forEach(k => { const el = $("#s-" + k); if (el) el.addEventListener("input", () => $("#dirty").classList.remove("hidden")); });
  $("#saveSettings").onclick = async () => { try { await saveSettings(false); } catch (e) { toast(e.message, "bad"); } };
  $("#testRelay").onclick = async () => {
    $("#testRelayOut").textContent = "saving, then testing…";
    try { await saveSettings(true); } catch (e) { $("#testRelayOut").innerHTML = `${pill("bad", "save failed")} ${esc(e.message)}`; return; }
    const r = await api("POST", "/api/settings/test-relay");
    const hint = !r.ok && /timed out|unreachable|refused/i.test(r.error || "") ? ` <span class="faint">(check the relay's security group allows TCP 8444 from this host's private IP)</span>` : "";
    $("#testRelayOut").innerHTML = r.ok ? `${pill("ok", "connected, read only")} ${esc(r.host)} · ${(r.services || []).map(s => `${s.name} ${s.state}`).join(", ")}` : `${pill("bad", "failed")} ${esc(r.error)}${hint}`;
  };
  $("#probeBtn").onclick = async () => {
    $("#probeOut").innerHTML = `<span class="faint">saving, then probing…</span>`;
    try { await saveSettings(true); } catch (e) { toast(e.message, "bad"); return; }
    const r = await api("GET", "/api/probe");
    $("#probeOut").innerHTML = r.results.length ? `<table><thead><tr><th>Target</th><th>TCP</th><th>TLS</th></tr></thead><tbody>${r.results.map(p => `<tr><td>${esc(p.label)} <code class="faint">${esc(p.host)}:${p.port}</code></td><td>${p.tcp ? pill("ok", "open") : pill("bad", "closed")}${p.error ? ` <span class="small faint">${esc(p.error)}</span>` : ""}</td><td>${p.tls === null ? "" : p.tls ? pill("ok", p.tls) + (p.cert_sha256 ? ` <span class="faint small mono" title="SHA-256 ${esc(p.cert_sha256)}">cert ${esc(p.cert_sha256.slice(0, 12))}…</span>` : "") : pill("warn", "no TLS")}</td></tr>`).join("")}</tbody></table>` : `<span class="faint">Set the log relay's address first.</span>`;
  };

  // ---------------------------------------------------------------- boot
  // Every page ends by drawing tables, and a column this edition does not have has to lose its cells: run
  // the edition pass after the page, not only after the data.
  const withEdition = (fn) => async (...a) => { const r = await fn(...a); applyEdition(); return r; };
  const go = Lab.router(Object.fromEntries(Object.entries({ dashboard: pageDashboard, send: pageSend, throughput: pageThroughput, sources: pageSources, history: pageHistory, services: pageServices, settings: pageSettings }).map(([k, fn]) => [k, withEdition(fn)])));
  async function boot() {
    try {
      const me = await api("GET", "/api/me");
      try { const st = await api("GET", "/api/settings"); ED.edition = st.edition || "standard"; ED.advanced = !!st.advanced; ED.known = true; S.settings = st; } catch (e) { /* the page still loads */ }
      applyEdition();
      // showApp() first, then write into the shell: after a sign-out or an expiry the shell has been
      // emptied, and writing to a missing #who threw here, which this catch turned straight back into
      // the sign-in form - a good sign-in that looked refused (AELDEV-76750). Lab.login() reloads
      // rather than resolving in that case, so boot() only reaches a shell that really exists.
      Lab.showApp();
      const w = $("#who"); if (w) w.textContent = me.user;
      const h = $("#hostname"); if (h) { h.textContent = me.console_name || me.host; h.title = me.console_name ? `host: ${me.host}` : ""; }
      const vv = $("#version"), V = me.version || {};
      if (vv) vv.textContent = V.version ? `v${V.version}${V.build ? " \u00b7 " + String(V.build).split(" ")[0] : ""}` : "";
      go();
    }
    catch (e) { Lab.showLogin(); }
  }
  $("#loginForm").onsubmit = async (e) => {
    e.preventDefault(); const f = e.target; $("#loginErr").textContent = "";
    try { await Lab.login(f.user.value, f.password.value); f.reset(); boot(); } catch (err) { $("#loginErr").textContent = err.message; }
  };
  $("#logout").onclick = (e) => { e.preventDefault(); Lab.logout(); };
  boot();
})();
