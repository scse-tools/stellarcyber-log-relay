"""
Run engine for Ingest Studio: sends realistic firewall events for one or more
defined log sources, in background threads, with live progress and cancel.

Reuses the event generators from tools/stellar-send.py so that the UI and the
CLI produce identical traffic.
"""
import errno
import hashlib
import http.client
import importlib.util
import json
import re
import tempfile
import subprocess
import shutil
import calendar
import os
import socket
import ssl
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))


def _load_stellar_send():
    candidates = [
        os.path.join(HERE, "stellar_send.py"),
        os.path.join(HERE, "..", "common", "stellar_send.py"),
        os.path.join(HERE, "..", "..", "tools", "stellar-send.py"),
        "/usr/local/bin/stellar-send",
    ]
    for c in candidates:
        if os.path.exists(c):
            spec = importlib.util.spec_from_file_location("stellar_send", c)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            return mod
    raise RuntimeError("stellar-send.py not found; install the kit's tools first")


SS = _load_stellar_send()

# path -> how to deliver.  transport values are what the UI offers per path.
# A log source is a DEVICE, so its paths are the ways a real device sends: syslog to the relay, a webhook
# POST to the relay, or its own syslog straight to the sensor. The old "sensor HTTP JSON :5200 with a
# tenant in the request" path went with the tenant (Paul, 24 Sep 2026): a device configuration carries no
# tenant, and that path was nothing but one.
PATHS = {
    "syslogng": {"label": "syslog-ng relay: the device sends syslog", "transports": ["udp514", "tcp514", "tcp601", "tls6514"]},
    "nginx":    {"label": "nginx relay: the device POSTs HTTP JSON or a webhook", "transports": ["http80", "https443"]},
    # Both editions (Paul, 8 Oct 2026: "so it can send directly to a sensor ... if ingest studio is also used to
    # send logs for testing directly to a sensor"). Sending to a parser port is what a device does, so it is
    # no management connection: the standard edition's rule - nothing to or from the relay's API - is untouched.
    "raw":      {"label": "Direct to a sensor: the device's own syslog, no relay", "transports": ["tls", "tcp", "udp"]},
}
# How a direct log source delivers: its own syslog as-is (no tenant: it lands in the sensor's own tenant), or
# that log inside the Stellar JSON wrapper with a tenant, to the parser's own port - the record the relay
# would have written for it. A relay-path source has neither: the relay decides.
DELIVERIES = {"asis": "As-is: the device's own syslog, no tenant (it lands in the sensor's own tenant)",
              "tenant": "With a tenant: the log inside the Stellar JSON wrapper, to the parser's own port"}
NO_RELAY = ("raw",)               # paths that never touch the relay: nothing to look up there, nothing to confirm
TRANSPORT_PORT = {"udp514": 514, "tcp514": 514, "tcp601": 601, "tls6514": 6514, "http80": 80, "https443": 443}
# test hook: shift the syslog ports (tests run an unprivileged fake relay on 10514/10601/16514)
_PORT_BASE = int(os.environ.get("IS_PORT_BASE", "0") or 0)
if _PORT_BASE:
    for _k in ("udp514", "tcp514", "tcp601", "tls6514"):
        TRANSPORT_PORT[_k] += _PORT_BASE
VENDORS = dict(SS.VENDOR_LABEL)          # ui key -> label (eight sources)
FORMATS = dict(SS.FORMATS_FOR)           # ui key -> ["syslog"] or ["syslog", "cef"]
PRESETS = {
    # the scenario Paul tests most (4 Oct 2026: "just events per second until I stop"): a steady rate per firewall
    # until Stop, with the rate and the total on the run card and the sensor's intake on the relay's Delivery tab
    "stream": {"label": "Steady stream", "count": 10, "rate": 500, "mix": "realistic", "size": 0, "loop": True,
               "desc": "500 events/s per firewall until you press Stop (set the rate below)"},
    "smoke": {"label": "Smoke test", "count": 10, "rate": 0, "mix": "realistic", "size": 0, "desc": "10 events, as fast as possible"},
    "demo": {"label": "Demo", "count": 200, "rate": 5, "mix": "alerts", "size": 0, "desc": "200 alert-heavy events at 5/s, about 40 s"},
    "soak": {"label": "Soak", "count": 5000, "rate": 50, "mix": "realistic", "size": 0, "desc": "5,000 realistic events at 50/s, about 100 s"},
    "bigpackets": {"label": "Big packets", "count": 20, "rate": 2, "mix": "traffic", "size": 100000, "desc": "20 events of 100 KB (TCP/TLS paths only)"},
}


def parser_port_of(source):
    """This log source's own parser port on the sensor: the port a real device of this type sends to when it
    goes straight to the sensor (CEF has one shared port, whatever the vendor). Through a relay the port is
    the RELAY's decision - its log-source row names it - and this is only what that row most likely says."""
    return SS.origin_for(source["vendor"], source.get("format") or "syslog")[3]


def sensor_port_of(source):
    """The sensor port this source's records reach, as far as this host can know it: the nginx path is always
    the HTTP JSON port; a relay row read from the relay (source['relay_port']) wins over the vendor's port."""
    if source["path"] == "nginx":
        return 5200
    return int(source.get("relay_port") or parser_port_of(source))


# ---------------------------------------------------------------- the Modular Sensors this Studio sends to
# Settings -> Sensors (Paul, 8 Oct 2026: "a sensor configuration section similar to log relay manager so it can
# send directly to a sensor"). One entry per sensor, numbered 1..8, kept as JSON in the settings table under
# "sensors". A direct log source names its sensor by NUMBER, so a number is never compacted: removing sensor 2
# leaves sensor 3 as sensor 3. A free number is only ever one no log source names (removal is refused while one
# does), so a new sensor may take it. Through a relay the relay decides the sensor, and none of this applies.
MAX_SENSORS = 8
SENSOR_TRANSPORTS = ("tls", "tcp", "udp")
# How this Studio trusts a sensor's TLS certificate, the same four choices a sensor card on the relay offers:
#   any      accept whatever it presents (what the Stellar Cyber documentation asks of senders while a sensor
#            wears its self-signed default) - the default
#   stellar  it must chain to Stellar Cyber's own CA (syslog-ng/stellar-sensor-ca.pem, shipped with the Studio)
#   ca       it must chain to a CA uploaded for this sensor
#   pin      it must be exactly the certificate whose SHA-256 is pinned, whoever signed it
# The NAME on the certificate is reported and never enforced: a Modular Sensor usually carries its internal
# address as its certificate name, so a name check would refuse a sensor reached by its public address
# (measured on the lab relay, 2 Oct 2026: that is exactly what stopped all delivery there).
SENSOR_TRUSTS = ("any", "stellar", "ca", "pin")
SENSOR_TRUST_LABEL = {"any": "Accept any certificate (default)", "stellar": "Stellar Cyber's CA (built in)",
                      "ca": "A CA I upload", "pin": "Pin its certificate"}


def _sensor_entry(n, address="", transport="tls", trust="any", ca="", pin=""):
    return {"n": int(n), "address": str(address or "").strip(), "transport": transport if transport in SENSOR_TRANSPORTS else "tls",
            "trust": trust if trust in SENSOR_TRUSTS else "any", "ca": ca or "", "pin": normalise_pin(pin) if pin else ""}


def sensors_from_settings(settings):
    """The sensors, sorted by number, sensor 1 always first and always present (its address may be empty).

    A database from before this list existed carries sensor_ip, sensor_ip_2 and sensor_tls: they are read as
    sensors 1 and 2, with the TLS toggle as their transport, so an existing Studio keeps sending exactly where it
    did. Nothing is written by reading; the first save of the Sensors tab writes the list."""
    raw = (settings or {}).get("sensors")
    lst = None
    if raw:
        try:
            lst = json.loads(raw) if isinstance(raw, str) else raw
        except ValueError:
            lst = None
    out = {}
    if isinstance(lst, list):
        for x in lst:
            try:
                n = int((x or {}).get("n"))
            except (TypeError, ValueError):
                continue
            if 1 <= n <= MAX_SENSORS and n not in out:
                out[n] = _sensor_entry(n, x.get("address"), x.get("transport"), x.get("trust"), x.get("ca"), x.get("pin"))
    else:
        tr = "tcp" if str((settings or {}).get("sensor_tls", "1")) == "0" else "tls"
        out[1] = _sensor_entry(1, (settings or {}).get("sensor_ip"), tr)
        if str((settings or {}).get("sensor_ip_2") or "").strip():
            out[2] = _sensor_entry(2, settings["sensor_ip_2"], tr)
    out.setdefault(1, _sensor_entry(1))
    return [out[k] for k in sorted(out)]


def sensor_for(settings, n):
    """The sensor a direct log source names (empty = sensor 1), or None when there is no such sensor."""
    want = str(n or "1").strip() or "1"
    return next((x for x in sensors_from_settings(settings) if str(x["n"]) == want), None)


def builtin_sensor_ca():
    """Stellar Cyber's own CA: beside the app on an installed host (install.sh copies it there), in the kit's
    syslog-ng/ directory in a checkout, or where the relay's package installs it. "" when this host has none."""
    for p in (os.environ.get("IS_SENSOR_CA_BUILTIN"), os.path.join(HERE, "stellar-sensor-ca.pem"),
              os.path.join(HERE, "..", "..", "syslog-ng", "stellar-sensor-ca.pem"),
              "/usr/lib/stellar-relay/stellar-sensor-ca.pem", "/usr/local/lib/stellar-relay/stellar-sensor-ca.pem"):
        if p and os.path.isfile(p):
            return os.path.abspath(p)
    return ""


def sensor_trust(sensor):
    """(mode for tls_context, CA PEM, pin) for one sensor. Raises RuntimeError in our words when the chosen CA
    is not there to check against."""
    t = (sensor or {}).get("trust") or "any"
    if t == "stellar":
        p = builtin_sensor_ca()
        if not p:
            raise RuntimeError("this sensor is set to check its certificate against Stellar Cyber's CA, and that CA is not on "
                               "this host (it ships beside the app). Re-run the Studio's installer, or choose another way to trust it")
        with open(p) as f:
            return "ca", f.read(), ""
    if t == "ca":
        if not sensor.get("ca"):
            raise RuntimeError("this sensor is set to check its certificate against an uploaded CA, and none is stored: "
                               "upload it on Settings → Sensors")
        return "ca", sensor["ca"], ""
    if t == "pin":
        return "pin", "", sensor.get("pin") or ""
    return "any", "", ""


# The parser ports documented to read the Stellar JSON wrapper on their OWN port: Appendix A of Stellar Cyber's
# "Multi-Tenant Log Ingestion Through a syslog-ng Log Relay" (the relay's DOCUMENTED_PARSERS, 45 ports), as
# (label, msg_origin vendor, msg_origin product). test_the_studios_wrapper_table_is_the_documented_one holds this
# equal to the relay's table and to windows-agent/reference/stellar-wrapper-ports.csv. A tenant sent anywhere
# else is a question for the sensor, not a fact: the record may be parsed with the tenant ignored, or not at all.
WRAPPER_PORTS = {
    5526: ("Accops", "accops", "accops"), 5602: ("Airgap Ransomware Kill Switch", "airgap", "ransomware_kill_switch"),
    5605: ("Android", "android", "android"), 5607: ("Avaya Switch", "avaya", "switch"),
    5621: ("BeyondTrust BeyondInsight", "beyondtrust", "beyondinsight"), 5161: ("Calyptix", "calyptix", "utm"),
    5165: ("Centrify", "centrify", "centrify_suite"), 5174: ("Check Point Appliance", "checkpoint", "appliance"),
    5618: ("Check Point EDR (Harmony)", "checkpoint", "harmony"), 5168: ("Cisco Firepower", "cisco", "firepower"),
    5176: ("Cisco IKE", "cisco", "ike"), 5163: ("Cisco IronPort", "cisco", "ironport"), 5157: ("Cisco ISE", "cisco", "ise"),
    5172: ("Cisco Meraki (legacy)", "cisco", "meraki"), 5603: ("Ericom ZTEdge", "ericom", "ztedge"),
    5612: ("Extreme AirDefense", "extreme", "air_defense"), 5614: ("Extreme Network Access Control", "extreme", "extremecontrol"),
    5162: ("F5 BIG-IP", "f5", "big-ip"), 5542: ("Fortinet FortiAnalyzer", "fortinet", "fortianalyzer"),
    5517: ("Fortinet FortiGate", "fortinet", "fortigate"), 5616: ("Fortinet FortiMail", "fortinet", "fortimail"),
    5177: ("Generic (BlackBerry Cylance)", "cylance", "cylanceoptics"), 5173: ("Juniper SRX", "juniper", "srx"),
    5516: ("Juniper SSG", "juniper", "ssg"), 5606: ("Lepide", "lepide", "data_security_platform"),
    5613: ("MonitorApp AI WAF", "monitorapp", "ai_waf"), 5608: ("NetApp", "netapp", "netapp"),
    5167: ("NetIQ Access Manager", "netiq", "access_manager"), 5622: ("Ordr Connected Device Security", "ordr", "connected_device_security"),
    5515: ("Palo Alto Networks Firewall", "palo_alto_networks", "firewall"), 5617: ("PIOLINK WEBFRONT-K", "piolink", "webfront-k"),
    5619: ("Radware DefensePro", "radware", "defensepro"), 5611: ("SECUI MFD", "secui", "mfd"),
    5623: ("SentinelOne Singularity Mobile", "sentinelone", "singularity_mobile"), 5609: ("ShareTech Firewall", "sharetech", "utm_firewall"),
    5590: ("Snare Agent", "snare", "snare_agent"), 5152: ("SonicWall Firewall", "sonicwall", "firewall"),
    5520: ("Sophos Firewall", "sophos", "firewall"), 5620: ("VMware UAG", "vmware", "unified_access_gateway"),
    5615: ("VMware vCenter", "vmware", "vcenter"), 5634: ("Wazuh", "wazuh", "wazuh_siem"),
    5599: ("Windows DNS Server", "windows", "dns_server"), 5601: ("Windows Event (NXLog)", "microsoft", "windows"),
    5610: ("Windows System Security", "microsoft", "system_security"), 5604: ("Zenarmor", "sunny_valley_networks", "zenarmor"),
}
# On the capture-port sheet (windows-agent/reference/stellar-wrapper-ports.csv) but not in the published appendix:
# the CEF parsers' shared ports. The sheet's "Multi tenant support" column says Stellar Capture for them; the
# 45 do not list them, so a tenant sent there is said to be the sheet's word, not the document's.
WRAPPER_SHEET_ONLY = {5143: "the CEF port 71 CEF parsers share", 5870: "the CEF port for octet-counted framing"}


def wrapper_notes(vendor, fmt="syslog"):
    """What to say about sending THIS log source wrapped with a tenant to its own parser port: [] when the port
    is one of the documented 45 and the record carries the documented vendor/product, else one sentence per
    thing that is not documented. Warned, never refused: whether a parser honours the tenant is the sensor's."""
    v, p, f, port = SS.origin_for(vendor, fmt)
    doc = WRAPPER_PORTS.get(port)
    if doc:
        label, dv, dp = doc
        if (v, p) != (dv, dp):
            return [f"Port {port} is documented to read the wrapper as {label}, whose wrapper carries "
                    f"msg_origin {dv}/{dp}; this Studio writes {v}/{p} for {VENDORS.get(vendor, vendor)}. "
                    f"Whether the sensor honors the tenant with that vendor/product is untested."]
        return []
    if port in WRAPPER_SHEET_ONLY:
        return [f"Port {port} ({WRAPPER_SHEET_ONLY[port]}) is listed as reading the wrapper on Stellar Cyber's capture-port "
                f"sheet, but not among the 45 parser ports its published document names. Check that the tenant is honored "
                f"before relying on it."]
    return [f"Port {port} is not one of the 45 parser ports documented to read the Stellar JSON wrapper on their own port. "
            f"The sensor may parse the log and ignore the tenant (it then lands in the sensor's own tenant), or not parse "
            f"it at all. Send a few and look before relying on it."]


# ---------------------------------------------------------------- TLS between a log source and the relay
# A real firewall sending TLS to the relay's 6514 may have to present a CERTIFICATE of its own (the relay's
# "Only accept devices with a certificate signed by" list), and may VERIFY the relay's certificate against a CA.
# Until 2 Oct 2026 this Studio did neither: it presented nothing and accepted anything, so the relay's device-CA
# gating could not be tested from here (Paul: "for each log source, can I add a certificate for sending syslog
# TLS logs to syslog ng"). A log source now carries an optional client certificate and key; Settings carries an
# optional CA for the relay. Python's ssl wants files, so the PEMs are written to a private temporary directory
# for the length of one connection and removed afterwards.
PEM_BLOCK = re.compile(r"-----BEGIN ([A-Z0-9 ]+?)-----.*?-----END \1-----", re.S)


def split_pem(text):
    """(certificates, private keys) found in a PEM text, each as its own block."""
    certs, keys = [], []
    for m in PEM_BLOCK.finditer(text or ""):
        kind = m.group(1)
        (keys if "PRIVATE KEY" in kind else certs if "CERTIFICATE" in kind else []).append(m.group(0).strip() + "\n")
    return certs, keys


def x509_facts(pem):
    """subject, cn, issuer, expiry, fingerprint of the first certificate in a PEM string, via openssl."""
    try:
        p = subprocess.run(["openssl", "x509", "-noout", "-subject", "-issuer", "-enddate", "-fingerprint", "-sha256"],
                           input=pem, capture_output=True, text=True, timeout=15)
    except (OSError, subprocess.TimeoutExpired) as e:
        return {"ok": False, "error": f"openssl: {e}"}
    if p.returncode != 0:
        return {"ok": False, "error": (p.stderr or p.stdout).strip()[-200:] or "not a certificate"}
    f = {"ok": True}
    for line in p.stdout.splitlines():
        k, _, v = line.partition("=")
        k = k.strip().lower()
        if k == "subject":
            f["subject"] = v.strip()
            m = re.search(r"CN\s*=\s*([^,/]+)", v)
            f["cn"] = m.group(1).strip() if m else ""
        elif k == "issuer":
            f["issuer"] = v.strip()
        elif k == "notafter":
            f["not_after"] = v.strip()
            try:
                f["expires"] = calendar.timegm(time.strptime(v.strip(), "%b %d %H:%M:%S %Y %Z"))
                f["days_left"] = int((f["expires"] - time.time()) // 86400)
            except ValueError:
                pass
        elif "fingerprint" in k:
            f["fingerprint"] = v.strip()
    f["self_signed"] = f.get("subject") == f.get("issuer")
    return f


class _TlsFiles:
    """The PEMs as files, for the length of one connection, in a directory only this process can read."""

    def __init__(self, ca_pem="", cert_pem="", key_pem=""):
        self.dir = tempfile.mkdtemp(prefix="studio-tls-")
        os.chmod(self.dir, 0o700)
        self.ca = self._put("ca.pem", ca_pem)
        self.cert = self._put("client.crt", cert_pem)
        self.key = self._put("client.key", key_pem)

    def _put(self, name, text):
        if not text:
            return ""
        path = os.path.join(self.dir, name)
        with open(path, "w") as f:
            f.write(text)
        os.chmod(path, 0o600)
        return path

    def close(self):
        shutil.rmtree(self.dir, ignore_errors=True)


# How a log source trusts the relay's certificate (Paul, 2 Oct 2026: "let me specify if I want to enable the
# ability to valid the cert or pin the cert"). Three modes, and they are genuinely different questions:
#   any  - accept whatever the relay presents. What the Stellar Cyber documentation asks of senders while the
#          relay is self-signed, and the default, so nothing changes for a source that says nothing.
#   ca   - the certificate must chain to a CA you give, and must be issued for the name you dial when the relay
#          is given by host name. This is what a production device does.
#   pin  - the certificate must be exactly the one you pinned, by SHA-256. Nothing else is checked, so it works
#          with a self-signed relay certificate that no CA will ever vouch for, which is the usual lab case.
TLS_VERIFY_MODES = ("any", "ca", "pin")


def cert_fingerprint(der):
    """A certificate's SHA-256 in lowercase hex: how a pinned certificate is named."""
    return hashlib.sha256(der).hexdigest()


def normalise_pin(text):
    """A fingerprint as a person pastes it - colons, spaces, 0x and case are all fine."""
    return re.sub(r"[^0-9a-f]", "", str(text or "").lower())


def pin_problem(sock, pin, who="relay", where="on this log source"):
    """"" when the certificate the relay (or a sensor: `who`) just presented is the pinned one, else our own
    sentence. Python has no pinning of its own, so the handshake is done without verification and the
    certificate is checked here - which is the whole point of a pin: it needs no CA and no name."""
    want = normalise_pin(pin)
    der = sock.getpeercert(binary_form=True)
    if not der:
        return f"the {who} presented no certificate, so the pinned one could not be checked"
    got = cert_fingerprint(der)
    if got == want:
        return ""
    return (f"the {who}'s certificate is not the pinned one, so nothing was sent. Pinned "
            f"{want[:16]}..., the {who} presented {got[:16]}... . If you replaced the {who}'s certificate on "
            f"purpose, pin the new one {where}; if you did not, do not send to it until you know why "
            "it changed.")


def peek_cert(host, port, timeout=8):
    """The certificate a TLS listener is presenting right now, as (der, pem). Nothing is verified and nothing
    is sent: it connects, reads the certificate and hangs up - which is how a pin is taken without anyone
    copying a 64-character fingerprint by hand."""
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    with socket.create_connection((host, int(port)), timeout=timeout) as raw:
        with ctx.wrap_socket(raw, server_hostname=host) as sock:
            der = sock.getpeercert(binary_form=True)
    if not der:
        raise OSError("it presented no certificate")
    return der, ssl.DER_cert_to_PEM_cert(der)


def tls_context(relay_ca_pem="", client_cert_pem="", client_key_pem="", server_name="", verify="", pin=""):
    """(context, note, files): what a log source sends TLS with. A CA for the relay turns verification on: the
    chain always, and the NAME too when the relay is dialed by a host name (Settings: "Log relay IP or host
    name") - a certificate names hosts, so dialed by address only the chain can be checked, and the note says
    which it was (Paul, 2 Oct 2026: "we need a hostname configured ... this should be explained"). A client
    certificate is presented when the relay asks for one. Without either, any certificate is accepted and none
    is presented - what the Stellar Cyber documentation asks of senders. Call files.close() once the socket is
    wrapped."""
    files = _TlsFiles(relay_ca_pem, client_cert_pem, client_key_pem)
    bits = []
    by_name = bool(server_name) and not re.match(r"^\d{1,3}(\.\d{1,3}){3}$", server_name)
    # An explicit mode wins; with none, a CA still means "verify against it", so every source saved before
    # this choice existed keeps behaving exactly as it did.
    mode = verify if verify in TLS_VERIFY_MODES else ("ca" if relay_ca_pem else "any")
    try:
        if mode == "pin":
            # pinning checks the certificate itself, after the handshake: no CA can vouch for a self-signed
            # relay, and the name on it does not matter when you have named the certificate exactly.
            ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
            bits.append(f"pinning the relay's certificate (SHA-256 {normalise_pin(pin)[:16]}...)")
        elif mode == "ca" and files.ca:
            ctx = ssl.create_default_context(cafile=files.ca)
            ctx.check_hostname = by_name
            ctx.verify_mode = ssl.CERT_REQUIRED
            # Python 3.13+ verifies in X.509 STRICT mode by default and refuses a CA made with a plain
            # `openssl req -x509` ("CA cert does not include key usage extension") - the shape of nearly every
            # lab CA, and not something syslog-ng or openssl itself refuses. This host checks the way they do.
            ctx.verify_flags &= ~getattr(ssl, "VERIFY_X509_STRICT", 0)
            f = x509_facts(relay_ca_pem)
            bits.append(f"verifying the relay's certificate against {f.get('subject') or 'the CA in Settings'}"
                        + (f", including that it is issued for {server_name}" if by_name
                           else " (the chain only: the relay is dialed by address, and a certificate names hosts - give the relay by its host name in Settings to check the name too)"))
        else:
            ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        if files.cert and files.key:
            ctx.load_cert_chain(files.cert, files.key)
            f = x509_facts(client_cert_pem)
            bits.append(f"presenting the client certificate {f.get('cn') or f.get('subject') or ''}".rstrip())
    except (ssl.SSLError, OSError) as e:
        files.close()
        raise RuntimeError(f"this log source's TLS material could not be loaded: {e}")
    return ctx, "; ".join(bits), files


def sensor_tls_context(sensor):
    """(context, note, files, mode, pin): how a DIRECT log source sends TLS to its sensor. The sensor's own trust
    choice (Settings -> Sensors) decides: accept any, a CA (Stellar Cyber's or one uploaded), or a pin. The name on
    the certificate is never enforced - a Modular Sensor usually carries its internal address as its certificate
    name - so a CA check is the chain only, and the note says so. No client certificate: a sensor asks for none.
    Call files.close() once the socket is wrapped."""
    mode, ca, pin = sensor_trust(sensor)
    files = _TlsFiles(ca, "", "")
    n = sensor.get("n", 1)
    try:
        if mode == "ca":
            ctx = ssl.create_default_context(cafile=files.ca)
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_REQUIRED
            ctx.verify_flags &= ~getattr(ssl, "VERIFY_X509_STRICT", 0)   # judge as openssl and syslog-ng do
            f = x509_facts(ca)
            note = (f"verifying sensor {n}'s certificate against {f.get('subject') or 'the chosen CA'} (the chain; the name "
                    f"on it is not checked, because a sensor usually names its internal address)")
        else:
            ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
            note = (f"pinning sensor {n}'s certificate (SHA-256 {normalise_pin(pin)[:16]}...)" if mode == "pin" else "")
    except (ssl.SSLError, OSError) as e:
        files.close()
        raise RuntimeError(f"sensor {n}'s CA could not be loaded: {getattr(e, 'reason', None) or e}")
    return ctx, note, files, mode, pin


def _connect_reason(e, timeout):
    """Why a connection to a sensor port failed, in our words (the OS's own reason is kept at the end)."""
    if isinstance(e, (socket.timeout, TimeoutError)):
        return (f"timed out: nothing answered on that port within {timeout:g} s. A firewall or security group "
                f"dropping it, or the wrong address")
    if isinstance(e, ConnectionRefusedError):
        return ("refused: the host answered, but nothing listens on that port. The parser port is not enabled "
                "on that sensor, or the address is not the sensor")
    if isinstance(e, socket.gaierror):
        return "the name does not resolve on this host"
    return f"could not connect ({getattr(e, 'strerror', None) or e})"


IPV4_SHAPE = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")


def sensor_check(address, port, transport="tls", sensor=None, timeout=4.0):
    """Is a sensor's parser port OPERATIONAL from this host: a TCP connection and, over TLS, a real handshake.
    Reports the certificate it presented (subject, issuer, expiry, SHA-256), whether it passes the sensor's
    trust choice (chain to the chosen CA, or the pin), and - reported, never enforced - whether it carries the
    address dialed. Nothing is sent. UDP has no connection, so it cannot be checked from here and says so."""
    res = {"port": int(port), "transport": transport, "reachable": None, "handshake_ok": None, "cert": None,
           "chain_ok": None, "pin_ok": None, "name_ok": None, "operational": None, "error": "", "notes": []}
    if transport == "udp":
        res["notes"].append("UDP has no connection: nothing answers a datagram, so a UDP port cannot be checked from here. "
                            "Send a short run and search its marker in Stellar Cyber")
        return res
    t0 = time.time()
    try:
        sock = socket.create_connection((address, int(port)), timeout=timeout)
    except OSError as e:
        res.update(reachable=False, operational=False, error=_connect_reason(e, timeout), ms=int((time.time() - t0) * 1000))
        return res
    res["reachable"] = True
    if transport != "tls":
        sock.close()
        res.update(operational=True, ms=int((time.time() - t0) * 1000))
        res["notes"].append("plain TCP: a connection was opened and closed; the sensor's TLS toggle must be off for this to deliver")
        return res
    try:
        mode, ca, pin = sensor_trust(sensor or {})
    except RuntimeError as e:
        sock.close()
        res.update(operational=False, error=str(e))
        return res
    der = None
    try:
        sock.settimeout(timeout)
        ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        tls = ctx.wrap_socket(sock, server_hostname=None if IPV4_SHAPE.match(address) else address)
        der = tls.getpeercert(binary_form=True)
        res["tls_version"] = tls.version()
        tls.close()
        res["handshake_ok"] = True
    except (ssl.SSLError, OSError) as e:
        try:
            sock.close()
        except OSError:
            pass
        res.update(handshake_ok=False, operational=False,
                   error=(f"the TLS handshake failed ({getattr(e, 'reason', None) or e}). Either the sensor's TLS toggle is "
                          f"off (then send TCP), or the port is not a TLS listener"))
        return res
    if der:
        facts = x509_facts(ssl.DER_cert_to_PEM_cert(der))
        res["cert"] = {k: facts.get(k) for k in ("subject", "cn", "issuer", "not_after", "days_left", "self_signed")}
        res["cert"]["sha256"] = cert_fingerprint(der)
    if mode == "pin":
        res["pin_ok"] = bool(der) and cert_fingerprint(der) == normalise_pin(pin)
        if not res["pin_ok"]:
            res["notes"].append(f"this is not the pinned certificate (pinned {normalise_pin(pin)[:16]}...): a send refuses it and sends nothing")
    if ca and der:
        files = _TlsFiles(ca, "", "")
        try:
            for check_name in (True, False):
                try:
                    vctx = ssl.create_default_context(cafile=files.ca)
                    vctx.verify_flags &= ~getattr(ssl, "VERIFY_X509_STRICT", 0)
                    vctx.check_hostname = check_name
                    with socket.create_connection((address, int(port)), timeout=timeout) as s2:
                        s2.settimeout(timeout)
                        with vctx.wrap_socket(s2, server_hostname=address) as v:
                            v.version()
                    res["chain_ok"], res["name_ok"] = True, check_name
                    break
                except ssl.SSLCertVerificationError as e:
                    why = (getattr(e, "verify_message", "") or str(e)).strip()
                    if check_name and any(w in why.lower() for w in ("hostname", "ip address mismatch", "not valid for", "doesn't match", "does not match")):
                        continue        # the chain may still be fine: try without the name
                    res["chain_ok"] = False
                    res["verify_error"] = why.split("(_ssl.c")[0].strip().rstrip(".")[:160]
                    break
                except (ssl.SSLError, OSError) as e:
                    res["verify_error"] = f"the second connection, to check the chain, failed ({getattr(e, 'reason', None) or e})"
                    break
        finally:
            files.close()
        if res["chain_ok"] is False:
            res["notes"].append("NOT signed by the CA this sensor is set to trust"
                                + (f" ({res['verify_error']})" if res.get("verify_error") else "")
                                + ": a send refuses it and sends nothing. Choose accept any, or the CA that signed it")
    if res["chain_ok"] and res["name_ok"] is False:
        cn = (res["cert"] or {}).get("cn") or "another name"
        res["notes"].append(f"the certificate names {cn}, not {address}: sensors usually carry their internal address as the "
                            f"certificate name. Reported, not enforced: a send checks the chain and not the name")
    res["operational"] = bool(res["handshake_ok"]) and res["chain_ok"] is not False and res["pin_ok"] is not False
    res["ms"] = int((time.time() - t0) * 1000)
    return res


def check_client_pair(cert_pem, key_pem):
    """Our own sentence when a client certificate and key cannot be used together, else ''."""
    files = _TlsFiles("", cert_pem, key_pem)
    try:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.load_cert_chain(files.cert, files.key)
    except ssl.SSLError as e:
        why = str(getattr(e, "reason", "") or e).lower()
        if "key values mismatch" in why or "mismatch" in why:
            return "the private key does not belong to that certificate"
        if "bad decrypt" in why or "password" in why or "passphrase" in why:
            return "the private key has a passphrase; this Studio needs one without"
        return f"the certificate and key could not be loaded: {getattr(e, 'reason', None) or e}"
    except OSError as e:
        return f"the certificate and key could not be loaded: {e}"
    finally:
        files.close()
    return ""


def tls_closed_early(e):
    """A TLS connection the relay ACCEPTED and then shut down, rather than refused in the handshake.

    Under TLS 1.3 the handshake finishes before the server has judged the client's certificate, so a relay
    whose 6514 listener requires one (syslog-ng peer-verify(required-trusted), which is on as soon as a
    device CA is listed) completes the handshake and sends its alert on the first record. What this host
    sees is a broken pipe or a reset on sendall, never an ssl.SSLError - which is why this has to be
    recognised here rather than left to the handshake's own except clause."""
    return isinstance(e, (BrokenPipeError, ConnectionResetError)) and not isinstance(e, ssl.SSLError)


def tls_failure_sentence(e, target, port, has_client_cert, has_relay_ca, to_relay=True, sent=None):
    """What a TLS failure means for this log source, in our words, never the exception's alone.

    to_relay says which hop this was: the syslog-ng relay's 6514 (where a device CA can demand a client
    certificate) or a Modular Sensor's parser port on the direct path (which never asks for one). sent is how
    many records this run had already written when the stream broke, when the caller knows."""
    reason = str(getattr(e, "verify_message", "") or getattr(e, "reason", "") or e)
    low = reason.lower()
    if tls_closed_early(e):
        who = "relay" if to_relay else "sensor"
        # A stream that breaks on the FIRST record is the TLS 1.3 shape of a refused client certificate; one
        # that breaks after thousands is the other end going away, and the records before it were delivered.
        early = sent is None or sent <= 1
        if early:
            what = (f"the {who} at {target}:{port} accepted the TLS connection and then closed it as this host started "
                    f"sending ({reason}), so nothing this run counted as sent reached it. ")
        else:
            what = (f"the {who} at {target}:{port} closed the TLS connection after {sent:,} records had been delivered "
                    f"({reason}); the ones counted before it closed did arrive, the rest were not sent. ")
        if not to_relay:
            return what + ("A Modular Sensor asks for no client certificate, so this is the sensor's TLS listener going "
                           "away: a sensor restart, its Syslog TLS toggle turned off, or the parser port stopped. "
                           "Check the sensor and send again.")
        if not early:
            return what + ("A relay that drops an established stream was restarted or stopped mid-run (the Log Relay "
                           "Manager's Log relay services page shows when); send the rest again.")
        why = ("Over TLS 1.3 the handshake finishes before the relay judges the certificate, which is why a refusal "
               "arrives on the first record rather than as a handshake error; a syslog-ng stopped or restarted "
               "mid-run looks the same from this host.")
        if has_client_cert:
            return what + ("This log source does present a certificate and the relay did not accept it: it must be signed by "
                           "one of the CAs listed on the Log Relay Manager under Log relay services \u2192 Security, and where "
                           f"that list is restricted by name, carry the name set there for this log source. {why}")
        return what + ("This log source presents none, and a device CA listed on the Log Relay Manager under Log relay "
                       "services \u2192 Security makes one compulsory for every device on 6514. Either remove it there, or "
                       f"give this log source a certificate (edit it and choose a PEM holding its certificate and key). {why}")
    if not to_relay:
        # a sensor's port: no client certificate is involved, and the name is never checked (sensor_tls_context)
        if "certificate verify failed" in low or "unable to get local issuer" in low or "self-signed" in low or "self signed" in low:
            return (f"the sensor's certificate at {target}:{port} does not chain to the CA chosen for it on Settings \u2192 Sensors "
                    f"({reason}), so nothing was sent. Choose the CA that signed it, pin its certificate, or accept any certificate.")
        return (f"the TLS handshake with the sensor at {target}:{port} failed ({reason}). Either the sensor's Syslog TLS toggle "
                f"is off (send TCP instead), or that port is not a TLS listener.")
    if "hostname mismatch" in low or "ip address mismatch" in low or "not valid for" in low:
        return (f"the relay's certificate is not issued for the name this host dials ({target}): {reason}. Dial the relay by a name "
                f"its certificate carries (Settings → Log relay IP or host name), or install on the relay a certificate for {target}.")
    if "certificate verify failed" in low or "unable to get local issuer" in low or "self-signed" in low:
        return (f"the relay's certificate at {target}:{port} does not chain to the CA in Settings ({reason}). Either install on the "
                f"relay a certificate issued by that CA (Log Relay Manager → Log relay services → Security), or remove the CA here to accept any.")
    if "alert" in low or "handshake failure" in low or "eof" in low or "reset" in low or "unknown ca" in low or "bad certificate" in low:
        if has_client_cert:
            return (f"the relay at {target}:{port} refused the TLS handshake ({reason}). If the relay only accepts devices with a certificate signed by a listed CA, "
                    f"this log source's certificate must be signed by one of them.")
        return (f"the relay at {target}:{port} refused the TLS handshake ({reason}). If the relay only accepts devices with a certificate "
                f"(Log Relay Manager → Log relay services → Security), give this log source one: edit it and choose a PEM holding its certificate and key.")
    return f"the TLS handshake with {target}:{port} failed: {reason}"


# Where a vendor's identity field is a POSITION rather than a key: the relay names a PAN-OS serial col3=..., because
# a PAN-OS log carries no key names and syslog-ng matches it by its place in the line. The generator calls the same
# thing "serial" (DEVICE_FIELDS), so a lookup on the relay must try both spellings.
CSV_POSITION = {("paloalto", "serial"): 3}

# The vendors whose logs cannot state their offset, so the SENSOR reads their times in its own zone. A run that
# sends one says which clock they were written on: a sensor set to Pacific filed UTC-written Palo Alto events
# seven hours ahead (7 Oct 2026), where no search ending "now" finds them.
ZONE_LESS_VENDORS = {"paloalto", "cisco_asa", "snare", "windows_dns", "nxlog"}


def clock_line(sources):
    """The run log's sentence about which clock the offset-free formats were written on, or '' when the run
    sends none of them."""
    names = sorted({s.get("name") or s.get("vendor") for s in sources
                    if s.get("vendor") in ZONE_LESS_VENDORS or s.get("webhook_source") == "paloalto_http"})
    if not names:
        return ""
    who = ", ".join(names[:4]) + (f" and {len(names) - 4} more" if len(names) > 4 else "")
    if SS.DEVICE_TZ_NAME:
        return (f"times: {who} write no time zone in their logs, so they are written on {SS.DEVICE_TZ_NAME} time "
                f"(Settings: the sensor's time zone), which is the zone the sensor reads them in")
    return (f"times: {who} write no time zone in their logs, so they are written in UTC. A sensor set to another "
            f"zone files them that many hours away from now: set Settings, Sensor's time zone, to the sensor's")


def csv_position(vendor, field):
    return CSV_POSITION.get((vendor, field), 0)


def delivery_of(source):
    """'tenant' for a direct log source that sends its log wrapped with a tenant, else 'asis'. A relay-path
    source is always 'asis' here: what the relay does with it is the relay's."""
    return "tenant" if source.get("path") == "raw" and source.get("delivery") == "tenant" and source.get("direct_tenant") else "asis"


def local_address_for(target, port):
    """The address this host would send from to reach target: what a sensor sees as the device's address, and so
    what the wrapper's msg_origin.srcip says when a direct log source has no source IP of its own. A UDP
    'connect' sends nothing; it only asks the routing table."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect((target, int(port)))
            return s.getsockname()[0]
    except OSError:
        return ""


def identity_of(source):
    """(field, value) this source writes into every log so a sensor-side tenant mapping or a field-keyed
    relay can find it; value None = varies per event. Empty device_id = the generator's default."""
    return SS.identity_for(source["vendor"], source.get("id_field") or None, source.get("device_id") or None)


def identity_label(source):
    f, v = identity_of(source)
    return f"{f}={v if v is not None else '(varies)'}" if f else ""


class RunState:
    """Live, in-memory state of one run. Persisted to the DB when it finishes."""

    def __init__(self, run_id, params):
        self.id = run_id
        self.params = params
        self.started = time.time()
        self.finished = None
        self.status = "running"
        self.cancel = threading.Event()
        self.lock = threading.Lock()
        self.per_source = {}          # source id -> {name, sent, failed, bytes, count, last_error}
        self.log = []
        self.relay = {}
        self.note = ""                # the run's note, as typed on the Send page; also the capture's description on the relay
        self._hist = []               # (ts, {source id: (sent, bytes)}) at each snapshot: what events/s is measured from
        self.user = ""

    def add_log(self, line, kind=""):
        with self.lock:
            self.log.append({"ts": time.time(), "kind": kind, "line": line})
            self.log = self.log[-400:]

    def snapshot(self, now=None):
        now = now or time.time()
        with self.lock:
            sent = sum(s["sent"] for s in self.per_source.values())
            failed = sum(s["failed"] for s in self.per_source.values())
            total = sum(s["count"] for s in self.per_source.values()) or 1
            # events per second and the average event size, from this run's own counts (Paul, 4 Oct 2026):
            # every snapshot is a sample, the live rate is over the last RATE_WINDOW seconds of them
            self._hist.append((now, {sid: (r["sent"], r["bytes"]) for sid, r in self.per_source.items()}))
            self._hist = [h for h in self._hist if now - h[0] <= RATE_WINDOW + 5]
            rates = run_rates(self._hist, self.per_source, self.started, self.finished, now)
            per_source = {sid: {**r, **rates["sources"].get(sid, {})} for sid, r in self.per_source.items()}
            # A run with no known total ("until I press Stop", or a duration at full speed) has no percentage: the
            # page showed a full bar and "100%" from the first second, because its total was 0 and became 1 above.
            # It gets the time it has been sending instead (and, for a duration, how long it will go on for).
            open_ended = any(r.get("open_ended") for r in self.per_source.values())
            return {"id": self.id, "status": self.status, "started": self.started, "finished": self.finished,
                    "sent": sent, "failed": failed, "total": None if open_ended else total, "open_ended": open_ended,
                    "pct": None if open_ended else min(100, int(100 * (sent + failed) / total)),
                    "duration": float(self.params.get("duration") or 0) or None, "loop": bool(self.params.get("loop")),
                    "bytes": rates["bytes"], "elapsed_s": rates["elapsed_s"], "rate_now": rates["rate_now"],
                    "rate_avg": rates["rate_avg"], "avg_bytes": rates["avg_bytes"], "bytes_per_s_now": rates["bytes_per_s_now"],
                    "per_source": per_source, "log": list(self.log[-120:]), "relay": self.relay, "params": self.params}


RATE_WINDOW = 10           # seconds of a run's own samples that "events/s now" is measured over


def run_rates(hist, per_source, started, finished, now):
    """Events per second and the average event size, from the run's own counts. Pure.

    `hist` is the samples the run took at each snapshot, oldest first: (ts, {source id: (sent, bytes)}).
    The live rate is the change over the oldest sample within RATE_WINDOW seconds (at least 2 s back, or it
    is noise), the average is over the whole run so far, and the size is bytes over events. One event is one
    log on the relay, so these read against the relay's Delivery tab (Paul, 4 Oct 2026: "show the events per
    second being sent and the total being sent to a sensor ... the average packet size as well")."""
    end = finished or now
    elapsed = max(0.0, end - started)
    base = None
    if len(hist) >= 2 and not finished:
        last = hist[-1]
        base = next((h for h in hist if last[0] - h[0] <= RATE_WINDOW), None)
        if base is not None and last[0] - base[0] < 2:
            base = None
    span = (hist[-1][0] - base[0]) if base is not None else 0
    out = {"sources": {}, "elapsed_s": round(elapsed, 1)}
    t_sent = t_bytes = 0
    t_now = 0.0
    for sid, rec in per_source.items():
        sent, nbytes = int(rec.get("sent") or 0), int(rec.get("bytes") or 0)
        t_sent += sent
        t_bytes += nbytes
        row = {"rate_avg": round(sent / elapsed, 1) if elapsed > 0 else 0.0,
               "avg_bytes": int(round(nbytes / sent)) if sent else 0, "rate_now": None}
        if base is not None:
            row["rate_now"] = round((sent - base[1].get(sid, (0, 0))[0]) / span, 1)
            t_now += row["rate_now"]
        out["sources"][sid] = row
    out.update(sent=t_sent, bytes=t_bytes,
               rate_avg=round(t_sent / elapsed, 1) if elapsed > 0 else 0.0,
               avg_bytes=int(round(t_bytes / t_sent)) if t_sent else 0,
               rate_now=round(t_now, 1) if base is not None else None,
               bytes_per_s_now=int(round((t_bytes - sum(v[1] for v in base[1].values())) / span)) if base is not None else None)
    return out


# A run with no count - "until stopped", or a duration at full speed - still stops somewhere: this many
# events per source, or the duration, whichever comes first. A forgotten run must not fill a disk.
LOOP_CAP = 2_000_000

class Worker(threading.Thread):
    """Sends `count` events for one source."""

    def __init__(self, state, source, params, settings, tls=None):
        super().__init__(daemon=True)
        self.st, self.src, self.p, self.settings = state, source, params, settings
        # the log source's own client certificate and key, read from the database for this run only: it is never on
        # the source dict (which is stored with the run's results) and never leaves this process
        self.tls = tls or {}
        self.seq_from = 1             # event numbering: markers 1..N
        self.count = int(params["count"])
        self.rate = float(params.get("rate") or 0)
        # How long to send for, instead of how many (Paul, 1 Oct 2026: "let me set the number of seconds or
        # minutes to send the logs ... or send in loop until stopped"). A duration with a rate has a known
        # total, so the count stays the thing the loop counts and the page can still predict it; a duration
        # at full speed, or "until stopped", runs until the clock or the Stop button says otherwise, with a
        # cap so a forgotten run cannot fill a disk.
        self.until = float(params.get("duration") or 0)          # seconds, 0 = none
        self.loop = bool(params.get("loop"))
        if self.until and self.rate > 0:
            self.count = max(1, int(round(self.rate * self.until)))
        self.cap = int(params.get("cap") or LOOP_CAP)
        # Is the total knowable before the run? A count is, and so is a duration at a set rate. "Until
        # stopped", and a duration at full speed, are not: the page must not show a total it invented.
        self.known = not self.loop and not (self.until and self.rate <= 0)
        secs = int(self.until)
        self.how_many = (f"{self.count} events" if self.known
                         else (f"events for {secs // 60} min {secs % 60} s" if secs >= 60 else f"events for {secs} s") if self.until
                         else "events until you press Stop")
        self.size = int(params.get("size") or 0)
        self.kind = params.get("kind") or None
        self.scene = SS.Scene(seed=params.get("seed"), mix=params.get("mix") or "realistic")
        self.target = None            # host this worker connects to, for the error text
        self.sensor = None            # the direct path: the sensor's entry from Settings -> Sensors (set in _send_raw)
        self.wrap = None              # the direct path with a tenant: (tenant ID, msg_origin.srcip)
        with state.lock:
            state.per_source[str(source["id"])] = {
                "name": source["name"], "vendor": source["vendor"], "bind_ip": source.get("bind_ip") or "",
                "path": source["path"], "transport": source["transport"], "format": source.get("format") or "syslog",
                "identity": identity_label(source),
                # where it lands, as far as this host knows: the port (the relay's row, else the vendor's own)
                # and what the relay's map said about this device when the run started, if it was asked
                "port": sensor_port_of(source), "relay": source.get("relay") or None,
                # the direct path only: which sensor, and whether the log went as-is or wrapped with a tenant
                **({"sensor": str(source.get("sensor") or "1"), "delivery": delivery_of(source),
                    "tenant": source.get("direct_tenant") or ""} if source["path"] == "raw" else {}),
                "sent": 0, "failed": 0, "bytes": 0, "count": self.count if self.known else 0,
                "open_ended": not self.known, "last_error": "",
                # a connection that broke mid-run and was dialed again, as a device would (7 Oct 2026): how many
                # times, and the latest word on it - kept apart from last_error, which marks the firewall as failed
                "reconnects": 0, "note": ""}

    def _rec(self, **kw):
        with self.st.lock:
            rec = self.st.per_source[str(self.src["id"])]
            for k, v in kw.items():
                if k in ("sent", "failed", "bytes", "reconnects"):
                    rec[k] += v
                else:
                    rec[k] = v

    def run(self):
        s = self.src
        try:
            if s["path"] == "syslogng":
                self._send_syslog()
            elif s["path"] == "raw":
                self._send_raw()
            else:
                https = s["transport"] == "https443"
                port = 443 if https else int(self.settings.get("nginx_port") or 80)
                # A tenant URL identifies the tenant by PATH on the relay, which is the only thing that works
                # for a cloud log source: it posts from whatever address its provider uses. The label is part
                # of the device's own configuration (the URL it is told to POST to); the relay's path map says
                # which tenant it means. Without one the relay falls back to this source's address.
                label = (s.get("ingest_path") or "").strip("/")
                where = f"/ingest/{label}/httpjson" if label else "/httpjson"
                self._send_http(f"{'https' if https else 'http'}://{self.settings['relay_ip']}:{port}{where}")
        except Exception as e:  # noqa: BLE001
            msg = str(e) or e.__class__.__name__
            # A TLS stream fails in two ways and only one of them is an SSLError: the handshake can be refused
            # (SSLError), or the relay can accept the connection and close it on the first record, which is how
            # TLS 1.3 reports a client certificate it will not take. The second arrived here as a bare
            # "BrokenPipeError: [Errno 32] Broken pipe" until 6 Oct 2026 - Python's sentence, not ours, and it
            # named neither the cause nor anything to do about it.
            ours = bool(getattr(self, "_tls_where", None)) and isinstance(e, (ssl.SSLError, BrokenPipeError, ConnectionResetError))
            if ours:
                with self.st.lock:
                    sent = self.st.per_source.get(str(s["id"]), {}).get("sent", 0)
                msg = tls_failure_sentence(e, *self._tls_where, sent=sent)
            # a RuntimeError raised here is already our own sentence (a refused pin, a sensor with no address, a CA
            # that is not there): it is said as it is, never with Python's class name in front of it
            ours = ours or isinstance(e, RuntimeError)
            if isinstance(e, (TimeoutError, socket.timeout)) or "timed out" in msg:
                msg += (f" connecting to {self.target or self.settings.get('relay_ip') or 'the sensor'} from {s.get('bind_ip') or 'the default IP'}. "
                        "A timeout usually means the source IP is not assigned to this instance's network interface in AWS "
                        "(EC2 > Network interfaces > Manage IP addresses), or the target's security group does not allow this port from it.")
            self._rec(last_error=msg[:700])      # the whole sentence, advice included: 400 cut it off mid-word
            self.st.add_log(f"{s['name']}: {msg}" if ours else f"{s['name']}: {e.__class__.__name__}: {msg}", "bad")

    def _more(self, n, started):
        """Is there another event to send? The run ends on the Stop button, on the clock when a duration was
        given, on the count when one was, and always on the cap."""
        if self.st.cancel.is_set():
            return False
        if n >= self.cap:
            if n == self.cap:
                self.st.add_log(f"{self.src['name']}: stopped at the {self.cap:,} event safety cap", "warn")
            return False
        if self.until and self.rate <= 0:
            return time.monotonic() - started < self.until        # as fast as possible, for this long
        if self.loop:
            return True                                           # until stopped
        return n < self.count

    def _pace(self, started, i):
        if self.rate > 0:
            delay = started + i / self.rate - time.monotonic()
            if delay > 0:
                self.cancel_wait(delay)

    def cancel_wait(self, t):
        self.st.cancel.wait(t)

    # ---- syslog family
    def _send_syslog(self):
        """Through the syslog-ng relay: the relay looks the tenant up and wraps the log. Which tenant, and
        which sensor port, is the relay's own log-source row for this device - this host only sends."""
        s = self.src
        tr = s["transport"]
        proto = "udp" if tr == "udp514" else "tls" if tr == "tls6514" else "tcp"
        target, port = self.settings["relay_ip"], TRANSPORT_PORT[tr]
        span = (f"{SS.MARKER}-{self.seq_from} … -{self.seq_from + self.count - 1}" if self.known
                else f"{SS.MARKER}-{self.seq_from} onwards")
        rel = s.get("relay") or {}
        if rel.get("known") and rel.get("mapped"):
            where = (f"on the relay this device is mapped to tenant {rel.get('tenant_label') or rel.get('tenant', '')[:12]} "
                     f"and sensor port :{rel.get('port') or sensor_port_of(s)}")
        elif rel.get("known"):
            where = "on the relay this device is NOT mapped, so its logs land in the relay's catch-all tenant until someone adds it there"
        else:
            where = "which tenant and sensor port is the relay's own log-source row for this device, not a setting here"
        self._send_stream(target, port, proto, octet=tr in ("tcp601", "tls6514"),    # RFC 6587 framing (FortiGate reliable mode)
                          intro=f"{s['name']}: {VENDORS[s['vendor']]} → {tr} {target}:{port} from {s['bind_ip'] or 'default IP'}, "
                                f"{self.how_many} ({span}); the relay wraps each one and forwards it - {where}")

    def _send_raw(self):
        """Straight to a sensor's parser port: no relay. Two ways (Paul, 8 Oct 2026):
          as-is      what the firewall itself would send - no wrapper, no tenant. The log lands in the sensor's own
                     tenant unless a sensor-side mapping reads the device identity out of it, which is why that
                     identity is in the run log.
          a tenant   the same log inside the Stellar JSON wrapper, with the FULL msg_origin (without it the sensor
                     ignores the tenant: measured 17 Sep 2026), to the parser's own port - the record the relay
                     would have written for this device."""
        s = self.src
        n = str(s.get("sensor") or "1")
        self.sensor = sensor_for(self.settings, n)
        if not self.sensor:
            raise RuntimeError(f"there is no sensor {n} on Settings → Sensors any more: point this log source at a sensor that is there")
        target = self.sensor["address"]
        if not target:
            raise RuntimeError(f"sensor {n} has no address yet (Settings → Sensors)")
        port = SS.direct_port(s["vendor"], s.get("format") or "syslog") + _PORT_BASE
        proto = s["transport"]
        want = self.sensor.get("transport") or "tls"
        if proto != want and "udp" not in (proto, want):
            self.st.add_log(f"{s['name']}: sensor {n} is set to {want.upper()} on Settings → Sensors, but this log source sends "
                            f"{proto.upper()}; the sensor's Syslog TLS toggle decides which one it takes, so change one of them if "
                            f"the connection is refused", "warn")
        self.wrap = None
        if delivery_of(s) == "tenant":
            tid = s.get("direct_tenant") or ""
            srcip = s.get("bind_ip") or local_address_for(target, port) or "0.0.0.0"
            self.wrap = (tid, srcip)
            v, p, f, _ = SS.origin_for(s["vendor"], s.get("format") or "syslog")
            for note in wrapper_notes(s["vendor"], s.get("format") or "syslog"):
                self.st.add_log(f"{s['name']}: {note}", "warn")
            how = (f"each log inside the Stellar JSON wrapper: tenant {tid[:8]}..., msg_origin {v}/{p}/{f} srcip {srcip}, "
                   f"to the parser's own port")
        else:
            how = f"as-is, no tenant wrapper (it lands in the sensor's own tenant); every log carries {identity_label(s)}"
        self._send_stream(target, port, proto, octet=False,
                          intro=f"{s['name']}: {VENDORS[s['vendor']]} → {proto} sensor {n} {target}:{port} from {s['bind_ip'] or 'default IP'}, "
                                f"{self.how_many}, {how}")

    # When the stream to the relay breaks after records were delivered on it, the relay went away - a restart, a
    # reload that closed its listener, a reset under load (Ingest Studio run #275, 7 Oct 2026: three TLS firewalls
    # at 1,000/s, "Connection reset by peer" on each, and every one gave up with "Failed 1"). A real device does
    # not give up: FortiOS keeps a 16 MB syslog cache per server and reconnects, PAN-OS queues and reconnects; both
    # carry on from the next record once the relay answers again. So does this now: close, wait (1 s, then
    # doubling to 10 s), dial again with the same TLS, carry on from the next event - until the run ends, Stop is
    # pressed, or the relay has not come back for RECONNECT_GIVE_UP_S, which a device would not do but a test run
    # must. A stream that breaks BEFORE any record was delivered on it is not an outage: it is the TLS 1.3 shape
    # of a refused client certificate, and run() says so and stops.
    RECONNECT_GIVE_UP_S = 120
    RECONNECT_MAX_DELAY_S = 10.0

    def _open_stream(self, target, port, proto, bind):
        """One connection to the target: a UDP socket, a TCP connection, or a TLS session with this source's
        certificate and its view of the relay's. Raises RuntimeError in our words when TLS refuses."""
        s = self.src
        if proto == "udp":
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            if bind:
                try:
                    sock.bind(bind)
                except OSError as e:
                    sock.close()
                    if getattr(e, "errno", None) == errno.EADDRNOTAVAIL:
                        raise RuntimeError(f"this host does not have the source IP {bind[0]} on any interface, so nothing can be sent "
                                           f"from it: save the log source again (that adds it), or clear its source IP")
                    raise
        else:
            try:
                sock = socket.create_connection((target, port), timeout=10, source_address=bind)
            except OSError as e:
                # our sentence, not the OS's errno: refused and timed out mean different things to fix
                if bind and getattr(e, "errno", None) == errno.EADDRNOTAVAIL:
                    raise RuntimeError(f"this host does not have the source IP {bind[0]} on any interface, so nothing can be sent "
                                       f"from it: save the log source again (that adds it), or clear its source IP")
                who = "the relay" if s.get("path") == "syslogng" else f"sensor {(self.sensor or {}).get('n', '')}".strip()
                raise RuntimeError(f"could not reach {who} at {target}:{port}: {_connect_reason(e, 10)}")
            if proto == "tls":
                # the relay path: the CA in Settings (verify the relay) and this source's own certificate (be
                # verified by it). The direct path to a sensor presents no certificate (a sensor asks for none) and
                # trusts the sensor's certificate the way its card on Settings -> Sensors says.
                to_relay = s.get("path") == "syslogng"
                if to_relay:
                    # the source's own CA if it has one, else the Settings-wide one; the mode and pin are the source's
                    mode = self.tls.get("verify") or ""
                    ca = self.tls.get("ca") or self.settings.get("relay_ca") or ""
                    pin = self.tls.get("pin") or ""
                    if self.tls.get("key_error"):
                        self.st.add_log(f"{s['name']}: its client certificate's key could not be read from the host's credential store ({self.tls['key_error']}); sending without a certificate", "warn")
                    ctx, note, files = tls_context(ca, self.tls.get("client_cert", ""), self.tls.get("client_key", ""),
                                                   server_name=target, verify=mode, pin=pin)
                    who, where = "relay", "on this log source"
                else:
                    ctx, note, files, mode, pin = sensor_tls_context(self.sensor or {})
                    ca = mode == "ca"
                    who, where = "sensor", f"on sensor {(self.sensor or {}).get('n', 1)}'s card (Settings → Sensors)"
                has_cert = bool(self.tls.get("client_cert")) and to_relay
                self._tls_where = (target, port, has_cert, bool(ca), to_relay)
                try:
                    if note:
                        self.st.add_log(f"{s['name']}: {note}", "dim")
                    sock = ctx.wrap_socket(sock, server_hostname=target)
                    if mode == "pin":
                        why = pin_problem(sock, pin, who=who, where=where)
                        if why:
                            sock.close()
                            raise RuntimeError(why)
                except ssl.SSLError as e:
                    sock.close()
                    raise RuntimeError(tls_failure_sentence(e, target, port, has_cert, bool(ca), to_relay=to_relay))
                finally:
                    files.close()
        return sock

    def _reconnect(self, sock, target, port, proto, bind, err, delivered, lost_event):
        """The stream broke after `delivered` records on it: dial again as a device would. Returns the new socket
        and how long the outage lasted, None when Stop was pressed meanwhile; raises when the relay stays away."""
        s = self.src
        t0 = time.monotonic()
        try:
            sock.close()
        except OSError:
            pass
        how = "reset by the other side" if isinstance(err, ConnectionResetError) else "closed" if isinstance(err, BrokenPipeError) else f"lost ({err})"
        self.st.add_log(f"{s['name']}: the connection to {target}:{port} was {how} after {delivered} events on it; event {lost_event} was in "
                        f"flight and is gone. Reconnecting as a device would (a FortiGate keeps a 16 MB cache and reconnects; a PAN-OS "
                        f"queues and reconnects): what the relay had already taken is in its buffer, and the run carries on from "
                        f"event {lost_event + 1}.", "warn")
        self._rec(reconnects=1, note=f"connection {how} after {delivered} events; reconnecting")
        attempt, delay = 0, 1.0
        while True:
            attempt += 1
            self.cancel_wait(delay)
            if self.st.cancel.is_set():
                return None, time.monotonic() - t0
            try:
                new = self._open_stream(target, port, proto, bind)
            except (OSError, RuntimeError) as e2:
                waited = time.monotonic() - t0
                if waited > self.RECONNECT_GIVE_UP_S:
                    raise RuntimeError(f"the relay at {target}:{port} did not take a connection again within {self.RECONNECT_GIVE_UP_S // 60} minutes "
                                       f"({attempt} attempts; the last answer: {str(e2)[:160]}). A real device would keep trying and drop the oldest "
                                       f"records from its cache; this run gives up here.")
                delay = min(self.RECONNECT_MAX_DELAY_S, delay * 2)
                continue
            waited = time.monotonic() - t0
            self.st.add_log(f"{s['name']}: reconnected to {target}:{port} after {waited:.0f} s (attempt {attempt}); carrying on from event {lost_event + 1}", "dim")
            self._rec(note=f"reconnected after {waited:.0f} s (attempt {attempt})")
            return new, waited

    def _send_stream(self, target, port, proto, octet, intro):
        s = self.src
        self.target = target
        self._tls_where = None          # set in _open_stream only for TLS, so a plain socket's failure is never read as one
        bind = (s["bind_ip"], 0) if s.get("bind_ip") else None
        sock = self._open_stream(target, port, proto, bind)
        self.st.add_log(intro, "dim")
        if self.size:
            # what that size means on the wire, so the relay's Packets page can be read against it
            if proto == "udp":
                wire = ("fits one 1500-byte Ethernet frame" if self.size <= 1472
                        else f"is larger than one frame, so this host's IP layer sends it as {-(-(self.size + 8) // 1480)} fragments")
            else:
                segs = -(-(self.size + 1) // 1448)
                wire = (f"leaves this host in about {segs} TCP segment(s) of up to 1448 B" + (" inside TLS records" if proto == "tls" else "")
                        + "; the relay re-segments it on its own TLS connection to the sensor")
            self.st.add_log(f"{s['name']}: each log is padded to exactly {self.size} bytes and {wire}", "dim")
        started = time.monotonic()
        field, value = identity_of(s)
        identity = {field: value} if field and value is not None else None
        conn_sent = 0       # records delivered on the CURRENT connection: none (or one) at a break is a refusal, not an outage
        shift = 0.0         # outage time, so the pace resumes from the reconnect instead of bursting to catch up
        try:
            n = -1
            while True:
                n += 1
                if not self._more(n, started):
                    break
                i = self.seq_from + n
                payload = SS.build_syslog(s["vendor"], i, self.size, kind=self.kind, scene=self.scene,
                                          fmt=s.get("format") or "syslog", identity=identity)
                if self.wrap:
                    # the direct path with a tenant: the same log, inside the record the relay would have written
                    tid, srcip = self.wrap
                    payload = SS.wrap_record(s["vendor"], s.get("format") or "syslog", tid, srcip,
                                             payload.decode("utf-8", "replace")).encode()
                if proto == "udp" and len(payload) > SS.UDP_MAX_PAYLOAD:
                    self._rec(failed=1, last_error=f"event {i}: {len(payload)} B exceeds UDP maximum; use TCP/TLS")
                    continue
                try:
                    if proto == "udp":
                        sock.sendto(payload, (target, port))
                    else:
                        frame = (f"{len(payload)} ".encode() + payload) if octet else payload + b"\n"
                        sock.sendall(frame)
                    self._rec(sent=1, bytes=len(payload))
                    conn_sent += 1
                except OSError as e:
                    self._rec(failed=1)
                    if proto == "udp":
                        self._rec(last_error=str(e))
                        continue
                    if conn_sent <= 1:
                        # nothing - or one record, which under TLS 1.3 is what a refused client certificate lets
                        # through before the alert lands - was taken on this connection: refused, said by run().
                        # (An outage after exactly one record reads the same way; a reconnect would meet the
                        # same refusal, so the first break on a fresh connection is never dialed again.)
                        self._rec(last_error=str(e))
                        raise
                    sock, outage = self._reconnect(sock, target, port, proto, bind, e, conn_sent, i)
                    if sock is None:
                        break                      # Stop was pressed while waiting
                    conn_sent = 0
                    shift += outage
                    continue
                self._pace(started + shift, n + 1)
        finally:
            try:
                if proto == "tls":
                    sock.unwrap()
                elif proto != "udp":
                    sock.shutdown(socket.SHUT_WR)
            except OSError:
                pass
            sock.close()

    # ---- HTTP family
    def _send_http(self, url):
        """A webhook POST to the nginx relay. The body is the product's own webhook JSON; the tenant is added by
        the relay from the URL path or the client address, so nothing about a tenant is sent from here."""
        s = self.src
        shape = (s.get("webhook_source") or "generic")
        from urllib.parse import urlsplit
        u = urlsplit(url)
        bind = (s["bind_ip"], 0) if s.get("bind_ip") else None
        if u.scheme == "https":
            ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
            conn = http.client.HTTPSConnection(u.hostname, u.port or 443, timeout=30, context=ctx, source_address=bind)
        else:
            conn = http.client.HTTPConnection(u.hostname, u.port or 80, timeout=30, source_address=bind)
        self.st.add_log(f"{s['name']}: POST {url} from {s['bind_ip'] or 'default IP'}, {self.how_many}; "
                        f"the relay adds the Stellar-TenantID header from its own map (by URL path, else by this address)", "dim")
        # Say what is actually on the wire. Method 5 carries the tenant in the header, so the body is
        # the product's own webhook JSON - not a firewall syslog line. Searching the platform for the
        # vendor's syslog fields finds nothing, which reads as a tenant failure and is not one.
        shape_label = (SS.WEBHOOK_SOURCES.get(shape) or SS.WEBHOOK_SOURCES["generic"])["label"]
        self.st.add_log(f"{s['name']}: the body is a {shape_label} JSON payload, markers {SS.MARKER}-{self.seq_from} … "
                        f"-{self.seq_from + self.count - 1}. Search the marker in Stellar Cyber.", "dim")
        started = time.monotonic()
        statuses = {}
        try:
            n = -1
            while True:
                n += 1
                if not self._more(n, started):
                    break
                i = self.seq_from + n
                body = SS.build_webhook(shape, i, self.size, identity_of(s)[0] and {identity_of(s)[0]: s.get("device_id") or None})
                headers = {"Content-Type": "application/json", "User-Agent": "ingest-studio/1.0"}
                try:
                    conn.request("POST", u.path or "/httpjson", body=body, headers=headers)
                    resp = conn.getresponse(); resp.read()
                    statuses[resp.status] = statuses.get(resp.status, 0) + 1
                    if 200 <= resp.status < 300:
                        self._rec(sent=1, bytes=len(body))
                    else:
                        self._rec(failed=1, last_error=f"HTTP {resp.status}")
                except (OSError, http.client.HTTPException) as e:
                    self._rec(failed=1, last_error=str(e)[:120])
                    conn.close()
                    conn = conn.__class__(u.hostname, u.port or (443 if u.scheme == "https" else 80), timeout=30,
                                          **({"context": ctx} if u.scheme == "https" else {}), source_address=bind)
                self._pace(started, n + 1)
        finally:
            conn.close()
        if statuses:
            self.st.add_log(f"{s['name']}: HTTP responses {statuses}", "ok" if set(statuses) == {200} else "warn")


class RunManager:
    """Owns live runs; one run at a time per source, many sources per run.

    What a run may ask of the relay (Paul, 24 Sep 2026: "the only item we should do is enable the capture at
    the start of a test"): a packet capture around the run, and READS - which sensor ports the relay can
    reach, and what it forwarded afterwards. It never changes anything on the relay: the tenant and the sensor
    port for each device are the relay's own log-source row, so a run sends what a real device would send
    and reports what the relay did with it."""

    def _tls_of(self, src):
        """A source's client certificate and key for one run: the certificate from the database, the key from the
        credential store. A key that cannot be read is said in the run log and the source sends without one."""
        t = self.db.source_tls(src["id"])
        # how this source trusts the RELAY's certificate travels with it: accept any, verify against a CA, or
        # pin the exact certificate (Paul, 2 Oct 2026)
        out = {"client_cert": t.get("client_cert", ""), "client_key": "",
               "verify": t.get("tls_verify", "") or "", "ca": t.get("tls_ca", "") or "", "pin": t.get("tls_pin", "") or ""}
        if t.get("key_stored") and out["client_cert"]:
            try:
                out["client_key"] = (self.key_reader(src["id"]) if self.key_reader else "") or ""
            except Exception as e:  # noqa: BLE001
                out["key_error"] = str(e)
            if not out["client_key"]:
                out["client_cert"] = ""
        return out

    def __init__(self, db, relay_client, managed=None, key_reader=None):
        # key_reader(sid) -> the PEM private key of that log source's client certificate, read from the host's
        # credential store for this run only (app.py wires the root helper in); None where there is none
        self.key_reader = key_reader
        # managed() = does this Studio have a management connection to the relay? The standard edition does
        # not, so the port check, the packet capture and the relay-side confirmation are not attempted at
        # all: each would otherwise be logged as something that went wrong, when nothing did.
        self.managed = managed or (lambda: True)
        self.db, self.relay = db, relay_client
        self.live = {}
        self.lock = threading.Lock()

    def start(self, user, params, sources, settings, note=""):
        run_id = self.db.create_run(user, params, note)
        st = RunState(run_id, params)
        st.note, st.user = (note or "").strip(), user or ""
        with self.lock:
            self.live[run_id] = st
        threading.Thread(target=self._drive, args=(st, sources, settings), daemon=True).start()
        return st

    @staticmethod
    def capture_description(st, sources):
        """What the relay's Packet capture page shows at the top for this run's capture: the note typed on
        the Send page, or, without one, which sources sent how many events. Paul (18 Sep 2026): "when I
        enter a note for the test session, I want to sync that note to the packet capture"."""
        if st.note:
            return st.note[:300]
        names = ", ".join(s["name"] for s in sources[:4]) + ("…" if len(sources) > 4 else "")
        return f"{names}: {st.params.get('count')} events each"[:300]

    @staticmethod
    def relay_ports(sources):
        """The sensor ports the RELAY will forward these sources to, as far as this host knows: the port the
        relay's own row names when it was read, else the vendor's parser port. Only syslog-ng sources: every
        other path connects from this host, where a failure is visible."""
        return {sensor_port_of(s) for s in sources if s["path"] == "syslogng"}

    def _check_ports(self, st, sources):
        """Ask the relay which sensor ports it can actually reach, before a single event is sent.

        This is the one failure that is invisible from the sender: syslog-ng accepts the records,
        counts them and holds them in its disk buffer for ever, so the run reports a clean send and
        nothing ever appears on the sensor. Only the relay can answer it, so the relay is asked. A read:
        nothing is changed, and an unreachable port is reported and still sent to - those records are the
        source's only delivery, and they flush when the port opens.
        """
        wanted = self.relay_ports(sources)
        if not wanted:
            return
        if not self.managed():
            st.add_log("the sensor ports are checked from the relay, which only the relay's own console can do. "
                       "If nothing arrives in the platform, open Sensors on the Log Relay Manager and run its check there.", "dim")
            return
        try:
            checks = self.relay.sensor_ports(sorted(wanted))
        except Exception as e:  # noqa: BLE001
            st.add_log(f"could not check the sensor ports from the relay ({e}); sending anyway", "dim")
            return
        for c in checks:
            if not c.get("reachable"):
                st.add_log(f"the relay cannot reach the sensor {c['sensor']} on :{c['port']} — {c['error']}. The records are sent "
                           f"anyway: the relay keeps them in its disk buffer and delivers them when the port opens", "bad")

    def _drive(self, st, sources, settings):
        relay_start = time.time()
        if self.managed():
            try:
                marker = self.relay.activity_cursor()
                relay_start = marker if marker else relay_start
            except Exception as e:  # noqa: BLE001
                st.add_log(f"log relay manager not reachable ({e}); run will not be confirmed on the relay side", "warn")
        self._check_ports(st, sources)
        line = clock_line(sources)
        if line:
            st.add_log(line, "dim")
        # Capture on the relay around the whole run: started 1 s before the first event so the relay has time
        # to begin, stopped 1 s after the last so the sensor-side TLS segments are in the file too. The
        # relay's Packets page then shows exactly this run's packets, in and out.
        capture = bool(st.params.get("capture")) and any(s["path"] not in NO_RELAY for s in sources) and self.managed()
        if st.params.get("capture") and not capture:
            st.add_log("packet capture skipped: none of these sources goes through the relay", "dim")
        if capture:
            try:
                desc = self.capture_description(st, sources)
                info = self.relay.capture_start(60, description=desc, source=f"Ingest Studio run #{st.id}" + (f" by {st.user}" if st.user else "")).get("capture", {})
                st.add_log(f"relay: packet capture started on {info.get('interface') or 'the relay'} (up to 60 s, stopped 1 s after the run), "
                           f"described on the relay as \u201c{desc}\u201d; sending begins in 1 s", "dim")
                time.sleep(1)
            except Exception as e:  # noqa: BLE001
                st.add_log(f"relay: could not start a packet capture ({e}); sending anyway", "warn")
                capture = False
        try:
            workers = [Worker(st, s, st.params, settings, tls=self._tls_of(s)) for s in sources]
            for w in workers:
                w.start()
            for w in workers:
                w.join()
        except Exception as e:  # noqa: BLE001
            st.add_log(f"run stopped: {e}", "bad")
        if capture:
            time.sleep(1)
            step = "stop"
            try:
                self.relay.capture_stop()
                step = "read"
                pk = self.relay.packets()
                flows = pk.get("flows") or []
                inn = [f for f in flows if f["dir"] == "in"]; out = [f for f in flows if f["dir"] == "out"]
                seg = lambda fs: sum(len(f["segments"]) for f in fs)
                st.add_log(f"relay: capture stopped, {len(pk.get('packets') or [])} packet(s). Into the relay: {sum(f['packets'] for f in inn)} packet(s), "
                           f"{sum(f['payload_bytes'] for f in inn)} B of payload in {seg(inn)} segment(s)/datagram(s). Out to the sensor: "
                           f"{sum(f['packets'] for f in out)} packet(s), {sum(f['tls_records'] for f in out)} TLS record(s), "
                           f"{sum(f['tls_bytes'] for f in out)} B of ciphertext in {seg(out)} segment(s). "
                           f"Bytes and hex: {self.relay.packets_url()}", "ok")
            except Exception as e:  # noqa: BLE001
                st.add_log(f"relay: could not {step} the capture ({e}). The relay keeps whatever it captured: see its Packets page", "warn")
        final = "cancelled" if st.cancel.is_set() else "done"
        snap = st.snapshot()
        aborted = any(s.get("last_error") for s in snap["per_source"].values())
        if not snap["sent"] and (snap["failed"] or aborted):
            final = "failed"                      # nothing left this host: a connect timeout, refused port, bad bind IP
        st.status = "confirming"      # still live: waiting for the relay's view of this run
        direct = [s for s in sources if s["path"] == "raw"]
        if direct:
            span = f"{SS.MARKER}-1 … -{st.params['count']}" if not snap.get("open_ended") else f"{SS.MARKER}-1 onwards"
            asis = [s["name"] for s in direct if delivery_of(s) == "asis"]
            wrapped = [s for s in direct if delivery_of(s) == "tenant"]
            if asis:
                st.add_log(f"{', '.join(asis)} went straight to the sensor as-is, so there is nothing to confirm on the relay. In Stellar "
                           f"Cyber, search for the marker {span} under the sensor's own tenant (or the tenant a mapping on the sensor "
                           "assigns from the device identity); generated FortiGate traffic events land in the Traffic index, not Syslog.", "dim")
            for s in wrapped:
                st.add_log(f"{s['name']} went straight to the sensor wrapped with tenant {s.get('direct_tenant', '')[:8]}...: in Stellar Cyber, "
                           f"search for the marker {span} under that tenant. If they are under the sensor's own tenant instead, that "
                           f"parser port did not honor the wrapper.", "dim")
        # give the relay a moment to flush, then ask what it forwarded
        needs_relay = any(s["path"] not in NO_RELAY for s in sources)
        if needs_relay and not self.managed():
            st.add_log(f"this Studio does not ask the relay what it forwarded - it has no management connection to it. "
                       f"The events left this host; to see them arrive, search {SS.MARKER}-1 … -{st.params['count']} in "
                       f"Stellar Cyber, and open the Log Relay Manager's own Activity page on the relay.", "dim")
        if needs_relay and self.managed():
            st.add_log("waiting 3 s for the relay to flush, then asking it what it forwarded…", "dim")
            time.sleep(3)
            try:
                st.relay = self.relay.activity_since(relay_start)
                for row in st.relay.get("summary", []):
                    st.add_log(f"relay: {row['count']} {row['label']} records → tenant {row['tenant_label']} via :{row['port']}"
                               + (f" ({row['errors']} with errors)" if row.get("errors") else ""), "ok" if not row.get("errors") else "warn")
                    if row.get("problem"):
                        st.add_log(f"relay: {row['problem']}", "warn")
                if not st.relay.get("summary"):
                    st.add_log("relay reported nothing forwarded for this run (check that each device is a log source on the relay, "
                               "the listeners, that the relay's copy of forwarded records is on, and Log Relay Manager > Overview for a feed error)", "warn")
            except Exception as e:  # noqa: BLE001
                st.add_log(f"relay confirmation failed: {e}", "warn")
        st.finished = time.time()
        st.status = final
        snap = st.snapshot()
        self.db.update_run(st.id, finished=st.finished, status=st.status, results=snap["per_source"],
                           relay=st.relay, sent=snap["sent"], failed=snap["failed"],
                           log="\n".join(f"{time.strftime('%H:%M:%S', time.localtime(l['ts']))} {l['line']}" for l in st.log))

    def get(self, run_id):
        with self.lock:
            return self.live.get(run_id)

    def cancel(self, run_id):
        st = self.get(run_id)
        if st and st.status == "running":
            st.cancel.set()
            st.add_log("cancel requested", "warn")
            return True
        return False

    def active(self):
        with self.lock:
            return [s.snapshot() for s in self.live.values() if s.status == "running"]

    def forget_finished(self, keep=20):
        with self.lock:
            done = [k for k, v in self.live.items() if v.status != "running"]
            for k in done[:-keep]:
                del self.live[k]
