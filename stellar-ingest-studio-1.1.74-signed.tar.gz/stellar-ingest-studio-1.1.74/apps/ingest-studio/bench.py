"""Throughput test for Ingest Studio: how many logs a second this lab really carries, and where they stop.

A Send run answers "does this path work". This answers "how much of it works, and what breaks first".

WHAT IT MEASURES, hop by hop. Each one is counted by the only thing that can see it:

    this host  ->  what the generator can build, and what this host can write to a socket. Measured
                   before anything is sent (calibrate()) and again as CPU while each step runs, because
                   a test that is really measuring its own sender must say so rather than report the
                   number as the system's.
    the wire   ->  for UDP, what the relay's KERNEL threw away before syslog-ng saw it: a full receive
                   buffer. The sender cannot see this - sendto() succeeded - and neither can syslog-ng.
                   The relay's /api/perf-counters reads it from /proc. For TCP and TLS nothing is lost
                   here by construction: the stream either arrives or the connection breaks, and a relay
                   that cannot keep up shows as this host's writes blocking.
    the relay  ->  syslog-ng's own counters: accepted off the socket, written to the sensor, still
                   queued, dropped. Only `dropped` means gone; `queued` means delayed.
    the sensor ->  it never says. What can be said is that the relay wrote the records to it and that
                   the queue did not grow - a sensor that stops reading shows up as written stalling
                   while queued climbs.
    the platform-> one query. Every record of a run carries STELLAR-PERF-<tag>, so the count is exact.
                   The event markers cannot be counted: a throughput run sends the same ones many times.

A SIZE IS EXACT, WHICH SOMETIMES MEANS CUTTING. The generators pad a record up to the size asked for,
but a firewall's own traffic log is already 500-900 B, so asking for 100 B used to give 800 B records and
a size sweep that measured the same thing six times. A record shorter than the vendor writes is therefore
CUT to length. syslog-ng does not parse what it forwards (flags(no-parse)), so every relay number holds;
the sensor's parser is a different matter, and a cut record also loses its run tag, so steps that cut are
reported as such and left out of the platform count.

WHY THE RECORDS ARE PRE-BUILT. Building one realistic firewall event costs this host about 15-60k
records a second on ONE core. If every record were built inside the send loop, a throughput test would
measure Python and report it as the relay's ceiling. So each step builds a POOL of real events from the
same generators the Send page uses - identical bytes - and replays it, rebuilding it every second so the
timestamps inside the logs stay current. Within a second a record may go out more than once; that is why
the run tag, not the marker, is what the platform counts.
"""
import json
import os
import random
import resource
import socket
import ssl
import threading
import time

import sender as snd                       # the paths, ports and generators a Send run uses

SS = snd.SS

# ---- how the sending is done, and why these numbers
SLICE = 0.02                # pacing granularity: a paced step is corrected 50 times a second
POOL_SIZE = 256             # distinct events replayed per connection; enough that no two adjacent records match
POOL_TTL = 1.0              # rebuilt this often, so a log's own timestamp is never more than a second old
WRITE_BATCH = 64            # records per sendall at most; the kernel coalesces anyway, this only saves syscalls
MAX_WORKERS = 32            # threads; each owns a slice of the connections and serves them round-robin
SETTLE = 4.0                # seconds to wait after a step before reading the relay again, so what it had
                            # queued has a chance to be written: reading immediately understates delivery

# ---- the cap. Paul, 25 Sep 2026: capped, with an explicit override. A throughput test points real traffic
# at a real sensor and a real platform; a mistyped rate should not be able to flood either.
CAPS = {"rate": 20000, "seconds": 120, "devices": 1000, "steps": 24, "records": 5_000_000}
CAP_NOTE = (f"a throughput run is capped at {CAPS['rate']:,} records/s offered, {CAPS['seconds']}s per step, "
            f"{CAPS['devices']} simulated devices, {CAPS['steps']} steps and {CAPS['records']:,} records in total. "
            "Tick “no limit” to send more than that - it is real traffic into a real platform.")

# ---- sizes, and what a size means on the wire.
# Paul's question, and it is the right one: a log is not a packet. Over UDP one log is exactly one
# datagram (and one Ethernet frame, until it is too big to be). Over TCP and TLS there are no log
# boundaries on the wire at all - the stream is packed, so several small logs ride in one segment and a
# big one spans several. That is why this test counts RECORDS everywhere and reports packets only where
# packets are a real thing.
SIZES = [
    {"key": "native", "bytes": 0, "label": "as the device writes it", "note": "about 500-900 B for a firewall traffic log; no padding"},
    {"key": "100", "bytes": 100, "label": "100 B", "note": "about 14 of them fit one 1500 B frame over TCP. Shorter than any "
     "firewall's own log, so each record is cut to length - see what that costs, below"},
    {"key": "512", "bytes": 512, "label": "512 B", "note": "about 2-3 to a frame over TCP; one datagram over UDP. Around or "
     "below a firewall's natural log size, so records may be cut to length"},
    {"key": "1000", "bytes": 1000, "label": "1000 B", "note": "one per frame over TCP, with room to spare"},
    {"key": "1472", "bytes": 1472, "label": "1472 B", "note": "the largest UDP payload that still fits ONE Ethernet frame"},
    {"key": "1500", "bytes": 1500, "label": "1500 B", "note": "over UDP this is already two IP fragments: 1500 > 1472"},
    {"key": "4000", "bytes": 4000, "label": "4000 B", "note": "a long web-filter or IPS log; 3 TCP segments, or 3 UDP fragments"},
    {"key": "16000", "bytes": 16000, "label": "16 KB", "note": "an outlier: 12 segments, and larger than one TLS record"},
    {"key": "mix", "bytes": -1, "label": "a realistic mix", "note": "100 B to 4 KB in the proportions a firewall estate really sends"},
]
SIZE_BY_KEY = {s["key"]: s for s in SIZES}
# what a mixed step sends: (bytes, share). Short session logs dominate a real estate; the long ones are
# the web-filter, IPS and application records.
MIX = [(120, 0.30), (400, 0.35), (800, 0.20), (1500, 0.10), (4000, 0.05)]

MTU_PAYLOAD_UDP = 1472      # 1500 - 20 (IP) - 8 (UDP)
MSS = 1448                  # 1500 - 20 (IP) - 20 (TCP) - 12 (timestamps)


def wire_note(size, proto):
    """What one log of this size is on the wire, for this transport. Never a guess: arithmetic."""
    if size <= 0:
        return "unpadded: a firewall traffic log is about 500-900 B, so one log per frame over UDP and a few per segment over TCP"
    if proto == "udp":
        if size <= MTU_PAYLOAD_UDP:
            return f"one datagram in one Ethernet frame ({size} B ≤ {MTU_PAYLOAD_UDP} B of payload)"
        frags = -(-(size + 8) // 1480)
        return (f"one datagram sent as {frags} IP fragments ({size} B > {MTU_PAYLOAD_UDP} B). Every fragment has to "
                f"arrive or the whole log is lost, and the kernel counts that as one lost datagram, not {frags}")
    if size < MSS:
        per = MSS // size
        return (f"smaller than one TCP segment, so the stream packs about {per} logs into each {MSS} B segment: "
                f"packets and logs are not the same thing here")
    segs = -(-size // MSS)
    return f"about {segs} TCP segment(s) per log" + (", inside TLS records of up to 16 KB" if proto == "tls" else "")


# ---- the built-in plans. Each expands to a list of steps; a step is one measurement.
PLANS = {
    "ramp": {
        "label": "Find the ceiling",
        "desc": "one size, the rate stepped up until something is lost or the sender runs out of road",
        "question": "How many logs a second does this path carry before anything is lost?",
    },
    "sizes": {
        "label": "Size sweep",
        "desc": "the same rate at 100 B, 512 B, 1000 B, 1500 B, 4000 B and a realistic mix",
        "question": "How much does the size of a log cost, and where does the path stop being about records and start being about bytes?",
    },
    "devices": {
        "label": "How many log sources?",
        "desc": "a fixed rate per device, with more and more devices sending at once",
        "question": "How many firewalls at N logs a second can this relay carry - and does the device COUNT cost anything beyond the total rate?",
    },
    "soak": {
        "label": "Soak",
        "desc": "one size and one rate, held for several minutes",
        "question": "Does it still hold after minutes, or does a queue build up slowly?",
    },
    "custom": {"label": "Custom", "desc": "the steps you write", "question": ""},
}

RAMP_RATES = [100, 500, 1000, 2500, 5000, 10000, 20000, 40000, 80000]
SWEEP_SIZES = ["100", "512", "1000", "1500", "4000", "mix"]
DEVICE_COUNTS = [1, 10, 50, 100, 250, 500, 1000]


def plan_steps(plan, opts, no_limit=False):
    """Expand a plan into steps. Every plan ends up as the same thing: a list of measurements.

    The cap is applied HERE as well as checked afterwards, because the built-in ramp climbs past it: a
    ladder trimmed to the cap runs and says where it stopped, while one that is merely refused leaves
    the button doing nothing but showing an error.
    """
    secs = int(opts.get("seconds") or 20)
    size = opts.get("size") or "native"
    devices = int(opts.get("devices") or 1)
    rate = float(opts.get("rate") or 0)
    ceiling = None if no_limit else CAPS["rate"]
    if plan == "ramp":
        rates = [r for r in RAMP_RATES if (not rate or r <= rate * 8) and (ceiling is None or r <= ceiling)]
        if rate and ceiling is not None:
            rates = [r for r in rates if r <= max(rate, RAMP_RATES[0])]
        return [{"size": size, "devices": devices, "rate": r, "seconds": secs} for r in rates or [RAMP_RATES[0]]]
    if plan == "sizes":
        return [{"size": s, "devices": devices, "rate": rate, "seconds": secs} for s in SWEEP_SIZES]
    if plan == "devices":
        eps = float(opts.get("eps") or 10)
        counts = [n for n in DEVICE_COUNTS if n <= max(devices, 1)] or [1]
        if ceiling is not None:
            counts = [n for n in counts if eps * n <= ceiling] or counts[:1]
        return [{"size": size, "devices": n, "rate": eps * n, "seconds": secs, "eps": eps} for n in counts]
    if plan == "soak":
        return [{"size": size, "devices": devices, "rate": rate, "seconds": max(secs, 60)}]
    return list(opts.get("steps") or [])


def check_caps(steps, no_limit):
    """Refuse a plan that would send more than the cap allows, naming the number that is over."""
    if no_limit:
        return
    if len(steps) > CAPS["steps"]:
        raise ValueError(f"{len(steps)} steps is more than the {CAPS['steps']} a capped run allows")
    total = 0
    for i, s in enumerate(steps, 1):
        if s["rate"] > CAPS["rate"]:
            raise ValueError(f"step {i} offers {s['rate']:,.0f} records/s, over the cap of {CAPS['rate']:,}")
        if s["seconds"] > CAPS["seconds"]:
            raise ValueError(f"step {i} runs {s['seconds']}s, over the cap of {CAPS['seconds']}s")
        if s["devices"] > CAPS["devices"]:
            raise ValueError(f"step {i} uses {s['devices']} devices, over the cap of {CAPS['devices']}")
        total += (s["rate"] or CAPS["rate"]) * s["seconds"]
    if total > CAPS["records"]:
        raise ValueError(f"the whole run would send about {total:,.0f} records, over the cap of {CAPS['records']:,}")


# --------------------------------------------------------------------------- the payload pool
class Pool:
    """Framed records, ready to write, rebuilt so the timestamps inside them stay current.

    Built from the same generators a Send run uses, so the bytes on the wire are the bytes a Send run
    puts there. Each connection gets its own pool with its own seed, so two devices never send the same
    stream in lockstep.
    """

    def __init__(self, vendor, fmt, size, octet, proto, identity, tag, seed, seq_from=1):
        self.vendor, self.fmt, self.size, self.octet, self.proto = vendor, fmt, size, octet, proto
        self.identity, self.tag = identity, tag
        self.scene = SS.Scene(seed=seed, mix="realistic")
        self.rnd = random.Random(seed)
        self.seq = seq_from
        self.frames, self.built_at, self.bytes = [], 0.0, 0
        self.truncated = 0          # records this pool had to CUT to reach the asked-for size
        self.build()

    def _size_for(self, i):
        if self.size >= 0:
            return self.size
        r, acc = self.rnd.random(), 0.0                 # the realistic mix
        for b, share in MIX:
            acc += share
            if r <= acc:
                return b
        return MIX[-1][0]

    def build(self):
        frames, total, cut = [], 0, 0
        for i in range(POOL_SIZE):
            want = self._size_for(i)
            payload = SS.build_syslog(self.vendor, self.seq, want, scene=self.scene,
                                      fmt=self.fmt, identity=self.identity, tag=self.tag)
            self.seq += 1
            # build_syslog pads to at least `want`. A firewall's own traffic log is 500-900 B, so every
            # size BELOW that came out the same length and a "100 B" step measured 800 B records - which
            # made the whole point of a size sweep vanish. To ask the question that was asked, a record
            # shorter than the vendor writes has to be CUT, and the step says it was: syslog-ng does not
            # parse (flags(no-parse)), so its numbers hold, but a cut log loses the run tag and may not
            # parse on the sensor, which is why a cut step is left out of the platform count.
            if want > 0 and len(payload) > want:
                payload = payload[:want]
                cut += 1
            total += len(payload)
            if self.proto == "udp":
                frames.append(payload)
            elif self.octet:
                frames.append(f"{len(payload)} ".encode() + payload)
            else:
                frames.append(payload + b"\n")
        self.frames, self.built_at, self.bytes, self.truncated = frames, time.monotonic(), total, cut
        return self

    def fresh(self, now):
        if now - self.built_at >= POOL_TTL:
            self.build()
        return self.frames


def build_rate(vendor, fmt, size, n=2000):
    """How fast this host can BUILD these events, on one core. The first number any throughput test owes
    the reader: everything below it is the system's, everything at it is this host's own limit."""
    sc = SS.Scene(seed=1, mix="realistic")
    sz = 0 if size < 0 else size
    t0 = time.monotonic()
    total = 0
    for i in range(1, n + 1):
        total += len(SS.build_syslog(vendor, i, sz, scene=sc, fmt=fmt))
    dt = max(1e-6, time.monotonic() - t0)
    return {"records_s": n / dt, "avg_bytes": total / n}


def write_rate(frame, seconds=0.6):
    """How fast this host can frame and write these bytes to a socket that throws them away.

    Plain TCP over loopback, so it is the ceiling with no network and no TLS in the way. A real step over
    TLS costs more than this; what the number is for is telling "the relay is the limit" from "this
    sender is the limit", together with the sender's own CPU while the step runs.
    """
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", 0))
    srv.listen(1)
    port = srv.getsockname()[1]
    stop = threading.Event()

    def sink():
        try:
            c, _ = srv.accept()
        except OSError:
            return
        with c:
            while not stop.is_set():
                try:
                    if not c.recv(1 << 16):
                        return
                except OSError:
                    return

    th = threading.Thread(target=sink, daemon=True)
    th.start()
    try:
        s = socket.create_connection(("127.0.0.1", port), timeout=5)
    except OSError:
        stop.set(); srv.close()
        return None
    batch = frame * WRITE_BATCH
    n = 0
    t0 = time.monotonic()
    try:
        while time.monotonic() - t0 < seconds:
            s.sendall(batch)
            n += WRITE_BATCH
    except OSError:
        pass
    dt = max(1e-6, time.monotonic() - t0)
    stop.set(); s.close(); srv.close()
    return {"records_s": n / dt, "bytes_s": n * len(frame) / dt}


# --------------------------------------------------------------------------- one simulated device
class Conn:
    """One simulated device: one socket and one pool of its own.

    A device is a CONNECTION, which is what makes "how many log sources" a measurable question rather
    than an arithmetic one: 500 firewalls at 20 logs a second is not the same work as 10 firewalls at
    1000, even though both offer 10,000 records a second. Over TCP and TLS each one holds a session that
    syslog-ng's max-connections() has to have room for, and each TLS session has its own state.
    """

    def __init__(self, source, settings, params, index, tag):
        self.src, self.settings, self.p, self.index = source, settings, params, index
        self.proto, self.target, self.port, self.octet = snd_target(source, settings)
        self.bind = (source.get("bind_ip"), 0) if source.get("bind_ip") else None
        field, value = snd.identity_of(source)
        if value is not None and params.get("distinct_devices") and index:
            value = f"{value}-{index:04d}"          # a device of its own, for testing the map at scale
        self.identity = {field: value} if field and value is not None else None
        self.pool = Pool(source["vendor"], source.get("format") or "syslog", params["size_bytes"], self.octet,
                         self.proto, self.identity, tag, seed=1000 + index, seq_from=1 + index * POOL_SIZE)
        self.sock, self.dead, self.idx, self.error = None, False, 0, ""

    def connect(self):
        try:
            if self.proto == "udp":
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                if self.bind:
                    s.bind(self.bind)
                s.connect((self.target, self.port))   # connected UDP: an ICMP refusal is reported on a later send
            else:
                s = socket.create_connection((self.target, self.port), timeout=15, source_address=self.bind)
                s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                if self.proto == "tls":
                    ctx = ssl.create_default_context()
                    ctx.check_hostname = False
                    ctx.verify_mode = ssl.CERT_NONE
                    s = ctx.wrap_socket(s, server_hostname=self.target)
            self.sock = s
            return True
        except (OSError, ssl.SSLError) as e:
            self.dead, self.error = True, f"{e.__class__.__name__}: {e}"
            return False

    def close(self):
        if not self.sock:
            return
        try:
            if self.proto == "tls":
                self.sock.unwrap()
            elif self.proto != "udp":
                self.sock.shutdown(socket.SHUT_WR)
        except OSError:
            pass
        try:
            self.sock.close()
        except OSError:
            pass
        self.sock = None


def snd_target(source, settings):
    """(proto, host, port, octet-framed) this source sends to. The same decision a Send run makes."""
    if source["path"] == "raw":
        n = str(source.get("sensor") or "1")
        sen = snd.sensor_for(settings, n)
        host = (sen or {}).get("address") or ""
        if not host:
            raise ValueError(f"sensor {n} has no address (Settings → Sensors)")
        return source["transport"], host, SS.direct_port(source["vendor"], source.get("format") or "syslog") + snd._PORT_BASE, False
    if source["path"] != "syslogng":
        raise ValueError("a throughput test sends syslog: it measures the syslog-ng relay and the sensor's parser "
                         "ports. An nginx log source posts one HTTP request per record, which measures nginx and "
                         "this host's HTTP client, not the log path - use Send for those.")
    tr = source["transport"]
    host = settings.get("relay_ip") or ""
    if not host:
        raise ValueError("the log relay's address is not set (Settings)")
    proto = "udp" if tr == "udp514" else "tls" if tr == "tls6514" else "tcp"
    return proto, host, snd.TRANSPORT_PORT[tr], tr in ("tcp601", "tls6514")


class Worker(threading.Thread):
    """Owns a slice of the connections and serves them round-robin.

    One thread per connection would mean a thread per simulated device, and 1000 Python threads spend
    their time on the GIL rather than on the wire. A worker paces each of its connections against the
    clock instead. A write that blocks holds up that worker's other connections - which is the truth we
    want: if the relay stops reading, this host stops sending, and the time spent blocked is the measure.
    """

    def __init__(self, conns, eps_each, seconds, cancel, start_at, budget=None):
        super().__init__(daemon=True)
        self.conns, self.eps, self.seconds, self.cancel, self.start_at = conns, eps_each, seconds, cancel, start_at
        # the cap, in records, this worker may send. A rate the run asks for is bounded by the pacing;
        # an UNPACED step is bounded by nothing at all, so the cap has to be enforced here or "as fast as
        # possible" means whatever the link allows - millions of records into a real platform.
        self.budget = budget
        self.capped = False
        self.sent = self.bytes = self.errors = 0
        self.blocked = 0.0
        self.last_error = ""
        # when this worker actually stopped sending. The step's rate is measured against THIS, not
        # against when the driver noticed: a watcher waiting a second between samples would otherwise
        # add its own wait to the window and report every paced step as slower than it ran.
        self.ended = None

    def _push(self, c, n, now):
        frames = c.pool.fresh(now)
        t0 = time.monotonic()
        try:
            if c.proto == "udp":
                for k in range(n):
                    f = frames[(c.idx + k) % POOL_SIZE]
                    c.sock.send(f)
                    self.sent += 1
                    self.bytes += len(f)
            else:
                buf = b"".join(frames[(c.idx + k) % POOL_SIZE] for k in range(n))
                c.sock.sendall(buf)
                self.sent += n
                self.bytes += len(buf)
        except (OSError, ssl.SSLError) as e:
            self.errors += n
            self.last_error = f"{e.__class__.__name__}: {e}"
            c.dead, c.error = True, self.last_error
            c.close()
        self.blocked += time.monotonic() - t0
        c.idx += n
        return n

    def run(self):
        try:
            self._send()
        finally:
            self.ended = time.monotonic()

    def _send(self):
        owed = [0] * len(self.conns)
        deadline = self.start_at + self.seconds
        while not self.cancel.is_set():
            now = time.monotonic()
            if now >= deadline:
                return
            if self.budget is not None and self.sent + self.errors >= self.budget:
                self.capped = True
                return
            live = 0
            if self.eps <= 0:                       # as fast as this host can
                for c in self.conns:
                    if c.dead:
                        continue
                    live += 1
                    self._push(c, 8 if c.proto == "udp" else WRITE_BATCH, now)
                if not live:
                    return
                continue
            elapsed = now - self.start_at
            idle = True
            for i, c in enumerate(self.conns):
                if c.dead:
                    continue
                live += 1
                due = int(elapsed * self.eps) - owed[i]
                if due <= 0:
                    continue
                n = min(due, WRITE_BATCH)
                owed[i] += n
                self._push(c, n, now)
                idle = False
            if not live:
                return
            if idle:
                self.cancel.wait(SLICE)


# --------------------------------------------------------------------------- what the relay did
def probe_delta(a, b):
    """What the relay's counters say happened between two readings.

    One thing has to be said plainly about `accepted`: it is syslog-ng's count of records read off its
    sockets from EVERY device on that relay, not only this test. So it can only be read one way round -
    if it is LOWER than what this host sent, records were certainly lost; if it is higher or equal,
    nothing of ours is missing (something else was also sending). The kernel's per-socket UDP drop
    counter has no such problem: it is that listener's socket, and it is the precise answer for UDP.
    """
    if not a or not b:
        return {"read": False, "error": "the relay's counters could not be read"}
    dt = max(1e-6, (b.get("monotonic") or 0) - (a.get("monotonic") or 0))
    sa, sb = a.get("syslogng") or {}, b.get("syslogng") or {}
    acc_a, acc_b = sa.get("accepted"), sb.get("accepted")
    accepted = (acc_b - acc_a) if isinstance(acc_a, int) and isinstance(acc_b, int) else None
    before = {d["port"]: d for d in (sa.get("destinations") or [])}
    ports, written, dropped, queued, processed = [], 0, 0, 0, 0
    for d in sb.get("destinations") or []:
        p = before.get(d["port"]) or {}
        row = {"port": d["port"], "target": d.get("target"),
               "written": d["written"] - (p.get("written") or 0),
               "dropped": d["dropped"] - (p.get("dropped") or 0),
               "processed": d["processed"] - (p.get("processed") or 0),
               "queued": d["queued"]}                 # a level, not a delta: what is still waiting
        ports.append(row)
        written += max(0, row["written"]); dropped += max(0, row["dropped"])
        processed += max(0, row["processed"]); queued += row["queued"]
    ka, kb = a.get("kernel") or {}, b.get("kernel") or {}

    def kd(key):
        x, y = ka.get(key), kb.get(key)
        return (y - x) if isinstance(x, int) and isinstance(y, int) else None

    socks_a = {s["port"]: s for s in (ka.get("sockets") or [])}
    socks = []
    for s in kb.get("sockets") or []:
        was = socks_a.get(s["port"]) or {}
        socks.append({"port": s["port"], "dropped": s["drops"] - (was.get("drops") or 0), "rx_queue": s["rx_queue"]})
    udp_dropped = sum(s["dropped"] for s in socks) if socks else kd("udp_rcvbuf_errors")
    pa, pb = sa.get("process") or {}, sb.get("process") or {}
    ticks = b.get("clock_ticks") or 100
    cores = ((pb.get("ticks") - pa.get("ticks")) / ticks / dt) if pa.get("ticks") is not None and pb.get("ticks") is not None else None
    ca, cb = a.get("cpu"), b.get("cpu")
    host_cpu = None
    if ca and cb and (cb[1] - ca[1]):
        host_cpu = 100.0 * (cb[0] - ca[0]) / (cb[1] - ca[1])
    return {
        "read": True, "error": "", "seconds": dt,
        "accepted": accepted, "written": written, "dropped": dropped, "queued": queued, "processed": processed,
        "per_port": ports, "udp_dropped": udp_dropped, "udp_sockets": socks,
        "tcp_listen_overflows": kd("tcp_listen_overflows"),
        "syslogng_cores": cores, "host_cpu_pct": host_cpu,
        "memory": (b.get("memory") or {}).get("available"),
        "buffer_bytes": (b.get("buffers") or {}).get("bytes"),
        "max_connections": b.get("max_connections"),
    }


def _cpu_self():
    r = resource.getrusage(resource.RUSAGE_SELF)
    return r.ru_utime + r.ru_stime


# --------------------------------------------------------------------------- the verdict on one step
LOSS_TOLERANCE = 0.001          # a thousandth: below this a difference is counter timing, not loss


def judge(step):
    """One word for what happened, and the sentences behind it. The order matters: a step that lost
    records is reported as losing them even if the sender was also at its limit."""
    notes, verdict = [], "clean"
    r = step.get("relay") or {}
    if step.get("cut"):
        notes.append(f"a {step['size_label']} log is shorter than a {step.get('vendor_label') or 'firewall'} writes, so each "
                     f"record was CUT to that length. The relay does not parse what it forwards, so its numbers hold - but a "
                     f"cut log loses the run tag and may not parse on the sensor, so this step is left out of the platform count.")
    if step.get("capped_rate"):
        notes.append(f"\u201cas fast as possible\u201d was paced at the cap of {CAPS['rate']:,} records/s. If it reached "
                     f"that cleanly, this path carries at least that - tick \u201cno limit\u201d to find where it stops.")
    elif step.get("capped"):
        notes.append(f"this step stopped early at the cap of {CAPS['rate']:,} records/s, so its rate is measured over "
                     f"a short window and is not reliable. Tick \u201cno limit\u201d, or ask for a rate.")
    sent, offered = step["sent"], step["offered"]
    if step["errors"]:
        verdict = "lost"
        notes.append(f"{step['errors']:,} record(s) could not be written by this host: {step['last_error']}")
    if r.get("read"):
        if r.get("udp_dropped"):
            verdict = "lost"
            notes.append(f"the relay's KERNEL threw away {r['udp_dropped']:,} datagram(s) before syslog-ng saw them: "
                         f"its UDP receive buffer was full. These are gone, and nothing at the sender could see it.")
        if r.get("dropped"):
            verdict = "lost"
            notes.append(f"syslog-ng DROPPED {r['dropped']:,} record(s): its disk buffer filled, or it could not wrap "
                         f"and forward as fast as they arrived. Gone, not delayed.")
        acc = r.get("accepted")
        if isinstance(acc, int) and sent and acc < sent * (1 - LOSS_TOLERANCE):
            verdict = "lost"
            notes.append(f"syslog-ng read {acc:,} records while this host sent {sent:,}: at least {sent - acc:,} never "
                         f"reached it. (That count includes every other device sending to this relay, so the real "
                         f"shortfall is at least this big.)")
        if verdict != "lost" and r.get("queued", 0) > max(1000, 1.0 * (step["achieved"] or 0)):
            verdict = "backlog"
            notes.append(f"{r['queued']:,} record(s) were still queued for the sensor {SETTLE:.0f}s after the step ended - "
                         f"more than a second's worth. Nothing is lost yet, but the sensor is not keeping up with this rate.")
        if r.get("tcp_listen_overflows"):
            notes.append(f"the relay's TCP listen queue overflowed {r['tcp_listen_overflows']} time(s): a device trying to "
                         f"connect was refused and had to retry. More devices than it accepts at once.")
    if verdict == "clean" and not r.get("read"):
        verdict = "sent"
        notes.append("this host sent every record without an error. The relay's own counters were not read, so what "
                     "syslog-ng did with them - accepted, forwarded, queued or dropped - is not known here, and nothing "
                     "on this page should be read as 'nothing was lost'. The relay knows: its Sensors page, "
                     "Delivery tab, has accepted / written / waiting / dropped per sensor port.")
    if verdict in ("clean", "sent") and offered and step["achieved"] < offered * 0.95:
        short = (f"this host sent {step['achieved']:,.0f} records/s of the {offered:,.0f} asked for")
        if r.get("read"):
            verdict = "sender"
            notes.append(f"{short}. Nothing was lost - the SENDER is the limit here, not the relay.")
        else:
            # the verdict stays "sent": what this host managed is known, what became of it is not
            notes.append(f"{short}, so this host did not keep up with what was asked. That says nothing about "
                         f"loss: every record it DID send left here without an error, and whether the relay kept "
                         f"them is still not known here.")
    if step.get("sender_limited") and verdict in ("clean", "sender"):
        notes.append(f"Ingest Studio used {step['sender_cpu_cores']:.1f} of this host's {step['cpus']} core(s) doing it: "
                     f"at or near its own ceiling, so a higher number needs a bigger sender, not a bigger relay.")
    if verdict == "clean":
        notes.append("nothing lost anywhere this test can see: syslog-ng read everything this host sent, wrote it to "
                     "the sensor, and was not holding a backlog afterwards.")
    return verdict, notes


# --------------------------------------------------------------------------- how many log sources
def sizing(records_s, eps_per_device, max_connections=None, proto="tls"):
    """How many devices a measured ceiling carries at N logs a second each, and what stops it first.

    Two limits, and they are different in kind. The rate limit is what this test measured. The
    connection limit is a number in the relay's own configuration - max-connections() - and it refuses
    the device after it however quiet the traffic is. UDP has no connection, so only the rate applies.
    """
    if not records_s or not eps_per_device:
        return None
    by_rate = int(records_s // eps_per_device)
    by_conn = int(max_connections) if (max_connections and proto != "udp") else None
    devices = min(x for x in (by_rate, by_conn) if x) if (by_rate or by_conn) else 0
    limited = "the measured rate" if devices == by_rate else "syslog-ng's max-connections()"
    note = (f"{devices:,} device(s) at {eps_per_device:g} logs a second each = {devices * eps_per_device:,.0f} records/s, "
            f"against a measured ceiling of {records_s:,.0f}/s.")
    if by_conn and devices == by_conn:
        note += (f" The rate would allow {by_rate:,}, but this relay accepts only {by_conn:,} sessions at once over "
                 f"{proto.upper()}; raise max-connections() in the relay configuration, or put those devices on UDP, "
                 f"which holds no session.")
    return {"devices": devices, "by_rate": by_rate, "by_connections": by_conn, "limited_by": limited,
            "eps_per_device": eps_per_device, "records_s": records_s, "note": note}


# --------------------------------------------------------------------------- one throughput run
class BenchState:
    """Live state of one throughput run: the steps done, the step running, and the log."""

    def __init__(self, bench_id, params, source):
        self.id = bench_id
        self.params = params
        self.source = source
        self.tag = params["tag"]
        self.started = time.time()
        self.finished = None
        self.status = "running"
        self.cancel = threading.Event()
        self.lock = threading.Lock()
        self.steps = []               # finished step results
        self.current = None           # the step running now, with live counters
        self.log = []
        self.calibration = {}
        self.summary = {}
        self.platform = None          # what the platform says arrived, when it can be asked
        self.user = ""

    def add_log(self, line, kind=""):
        with self.lock:
            self.log.append({"ts": time.time(), "kind": kind, "line": line})
            self.log = self.log[-400:]

    def snapshot(self):
        with self.lock:
            return {"id": self.id, "status": self.status, "started": self.started, "finished": self.finished,
                    "params": self.params, "source": self.source, "tag": self.tag,
                    "calibration": self.calibration, "steps": list(self.steps), "current": dict(self.current) if self.current else None,
                    "summary": self.summary, "platform": self.platform, "log": list(self.log[-160:])}


class BenchManager:
    """Owns live throughput runs. One at a time: two at once would measure each other."""

    def __init__(self, db, relay_client, managed=None):
        self.db, self.relay = db, relay_client
        self.managed = managed or (lambda: True)
        self.live = {}
        self.lock = threading.Lock()

    def running(self):
        with self.lock:
            return next((s for s in self.live.values() if s.status in ("running", "settling")), None)

    def get(self, bid):
        with self.lock:
            return self.live.get(bid)

    def cancel(self, bid):
        st = self.get(bid)
        if st and st.status in ("running", "settling"):
            st.cancel.set()
            st.add_log("cancel requested", "warn")
            return True
        return False

    def start(self, user, params, source, settings):
        bid = self.db.create_bench(user, params)
        st = BenchState(bid, params, {k: source.get(k) for k in ("id", "name", "vendor", "format", "path", "transport", "bind_ip")})
        st.user = user or ""
        with self.lock:
            self.live[bid] = st
        threading.Thread(target=self._drive, args=(st, source, settings), daemon=True).start()
        return st

    # ---- the relay's counters, read only when this Studio has a management connection
    def _counters(self):
        if not self.managed():
            return None
        try:
            return self.relay.perf_counters()
        except Exception as e:  # noqa: BLE001
            return {"_error": str(e)}

    def _drive(self, st, source, settings):
        p = st.params
        try:
            self._calibrate(st, source)
            base = self._counters()
            if base and base.get("_error"):
                # a relay that predates this feature answers 404, which is worth naming rather than
                # leaving as a number: the fix is an upgrade there, not anything on this host
                extra = (" \u2014 that relay is older than this feature: upgrade the Log Relay Manager on it "
                         "(sudo stellar-relay upgrade ...) to see its side of a throughput run"
                         if "404" in str(base["_error"]) else "")
                st.add_log(f"the relay's counters could not be read ({base['_error']}){extra}. This run measures the "
                           f"sending side only and cannot say what arrived", "warn")
                base = None
            elif base is None:
                st.add_log("this Studio has no management connection to the relay, so nothing can be read back from it: "
                           "this run measures what THIS HOST sent. Open the Log Relay Manager beside it to see what "
                           "syslog-ng accepted and forwarded.", "dim")
            elif base.get("syslogng", {}).get("ok") is False:
                st.add_log(f"syslog-ng's counters are not readable on the relay ({base['syslogng'].get('error')}), so the "
                           f"relay's side of every step will be blank", "warn")
            if base and base.get("max_connections"):
                st.add_log(f"the relay accepts at most {base['max_connections']:,} TCP/TLS sessions at once "
                           f"(max-connections in its configuration)", "dim")
            for n, step in enumerate(p["steps"], 1):
                if st.cancel.is_set():
                    break
                self._run_step(st, source, settings, n, step)
            st.status = "settling"
            self._summarise(st)
            self._count_in_platform(st, wait=True)
        except Exception as e:  # noqa: BLE001
            st.add_log(f"run stopped: {e.__class__.__name__}: {e}", "bad")
            st.status = "failed"
        finally:
            st.finished = time.time()
            if st.status not in ("failed",):
                st.status = "cancelled" if st.cancel.is_set() else "done"
            snap = st.snapshot()
            self.db.update_bench(st.id, finished=st.finished, status=st.status, steps=snap["steps"],
                                 summary=snap["summary"], calibration=snap["calibration"], platform=snap["platform"],
                                 log="\n".join(f"{time.strftime('%H:%M:%S', time.localtime(l['ts']))} {l['line']}" for l in st.log))

    # ---- what this host itself can do, before any of it is blamed on the relay
    def _calibrate(self, st, source):
        p = st.params
        size = SIZE_BY_KEY.get(p["steps"][0]["size"], SIZE_BY_KEY["native"])["bytes"] if p["steps"] else 0
        br = build_rate(source["vendor"], source.get("format") or "syslog", size)
        sample = SS.build_syslog(source["vendor"], 1, max(0, size), fmt=source.get("format") or "syslog")
        wr = write_rate(sample + b"\n")
        st.calibration = {"build_records_s": br["records_s"], "avg_bytes": br["avg_bytes"],
                          "write_records_s": (wr or {}).get("records_s"), "cpus": os.cpu_count(),
                          "note": "Two ceilings of this host, not of the lab. BUILD is how many of these events it can "
                                  "generate a second on one core - a step that asks for more than this is only possible "
                                  "because the records are pre-built and replayed. WRITE is how fast it can push the same "
                                  "bytes into a socket that throws them away (plain TCP over loopback, no network, no TLS): "
                                  "if it is far above every step's rate, this host's sockets are not what limited them. "
                                  "What the sender can really do end to end is whatever an unpaced step reaches, with its "
                                  "CPU beside it."}
        st.add_log(f"this host builds {br['records_s']:,.0f} of these events a second on one core "
                   f"(average {br['avg_bytes']:,.0f} B each)" +
                   (f", and can write {wr['records_s']:,.0f} a second to a socket that discards them" if wr else ""), "dim")
        st.add_log(f"every record of this run carries {SS.PERF_MARKER}-{st.tag}, so one query counts exactly this run "
                   f"in Stellar Cyber", "dim")

    def _run_step(self, st, source, settings, n, step):
        spec = SIZE_BY_KEY.get(step["size"], SIZE_BY_KEY["native"])
        params = dict(st.params, size_bytes=spec["bytes"])
        devices = max(1, int(step["devices"]))
        offered = float(step.get("rate") or 0)
        # "as fast as possible" under the cap is PACED at the cap, not sent flat out and stopped part way:
        # a burst that ends after 30 ms gives a rate measured over 30 ms, which is noise dressed as a number.
        capped_rate = not offered and not st.params.get("no_limit")
        if capped_rate:
            offered = float(CAPS["rate"])
        eps_each = (offered / devices) if offered else 0.0
        seconds = float(step["seconds"])
        proto = snd_target(source, settings)[0]
        live = {"n": n, "size": spec["key"], "size_label": spec["label"], "size_bytes": spec["bytes"],
                "vendor_label": snd.VENDORS.get(source["vendor"], source["vendor"]),
                "devices": devices, "offered": offered, "eps_each": eps_each, "seconds": seconds,
                "capped_rate": capped_rate,
                "proto": proto, "wire": wire_note(spec["bytes"], proto), "sent": 0, "bytes": 0, "errors": 0,
                "connected": 0, "state": "connecting", "series": []}
        st.current = live
        st.add_log(f"step {n}/{len(st.params['steps'])}: {spec['label']}, {devices} device(s), "
                   f"{'as fast as possible' if not offered else f'{offered:,.0f} records/s'}"
                   f"{' (the cap; tick no limit to go faster)' if capped_rate else ''} for {seconds:.0f}s "
                   f"— {live['wire']}", "")

        conns = [Conn(source, settings, params, i, st.tag) for i in range(devices)]
        t_connect = time.monotonic()
        self._connect_all(conns)
        connect_s = time.monotonic() - t_connect
        alive = [c for c in conns if not c.dead]
        live.update(connected=len(alive), connect_failed=len(conns) - len(alive), connect_seconds=connect_s, state="sending")
        if not alive:
            first = next((c.error for c in conns if c.error), "no connection could be opened")
            st.add_log(f"step {n}: not one of the {devices} connection(s) opened: {first}", "bad")
            with st.lock:
                st.steps.append(dict(live, state="failed", achieved=0, sent=0, mbit_s=0, verdict="lost",
                                     notes=[first], last_error=first, relay={"read": False}))
            st.current = None
            return
        if len(alive) < devices:
            why = next((c.error for c in conns if c.error), "")
            st.add_log(f"step {n}: {devices - len(alive)} of {devices} connection(s) could not be opened "
                       f"({why}); measuring the {len(alive)} that did. If this is where the relay stops "
                       f"accepting sessions, that is the answer to how many devices it carries", "warn")
        if devices > 1:
            st.add_log(f"step {n}: {len(alive)} connection(s) opened in {connect_s:.1f}s", "dim")

        before = self._counters()
        cpu0 = _cpu_self()
        start_at = time.monotonic()
        per = max(1, -(-len(alive) // MAX_WORKERS))
        groups = [alive[i:i + per] for i in range(0, len(alive), per)]
        budget = None if st.params.get("no_limit") else max(1, int(CAPS["rate"] * seconds / len(groups)))
        workers = [Worker(g, eps_each, seconds, st.cancel, start_at, budget) for g in groups]
        for w in workers:
            w.start()
        self._watch(st, live, workers, start_at, seconds)
        for w in workers:
            w.join()
        cpu_used = _cpu_self() - cpu0
        elapsed = max(1e-6, max((w.ended or start_at) for w in workers) - start_at)

        sent = sum(w.sent for w in workers)
        nbytes = sum(w.bytes for w in workers)
        errors = sum(w.errors for w in workers)
        blocked = sum(w.blocked for w in workers)
        last_error = next((w.last_error for w in workers if w.last_error), "")
        live.update(state="settling", sent=sent, bytes=nbytes, errors=errors)
        st.add_log(f"step {n}: {sent:,} records sent in {elapsed:.1f}s; waiting {SETTLE:.0f}s for the relay to write "
                   f"what it is holding before reading its counters", "dim")
        st.cancel.wait(SETTLE)
        after = self._counters()
        for c in conns:
            c.close()

        cpus = os.cpu_count() or 1
        cores = cpu_used / elapsed
        delta = probe_delta(before if before and not before.get("_error") else None,
                            after if after and not after.get("_error") else None)
        res = dict(live)
        res.update({
            "state": "done", "seconds_actual": elapsed, "sent": sent, "bytes": nbytes, "errors": errors,
            "achieved": sent / elapsed, "bytes_s": nbytes / elapsed, "mbit_s": nbytes * 8 / elapsed / 1e6,
            "blocked_pct": 100.0 * blocked / (elapsed * max(1, len(workers))),
            "sender_cpu_cores": cores, "cpus": cpus, "sender_limited": cores >= 0.85 * min(cpus, len(workers)),
            "last_error": last_error, "relay": delta,
            "avg_bytes": (nbytes / sent) if sent else 0,
            "capped": any(w.capped for w in workers),
            # a record shorter than this vendor writes had to be cut to reach the asked-for size
            "cut": any(c.pool.truncated for c in alive),
        })
        res["verdict"], res["notes"] = judge(res)
        with st.lock:
            st.steps.append(res)
        st.current = None
        kind = {"clean": "ok", "lost": "bad", "backlog": "warn", "sender": "warn"}.get(res["verdict"], "")
        st.add_log(f"step {n}: {res['achieved']:,.0f} records/s ({res['mbit_s']:.1f} Mbit/s) — {res['verdict']}. "
                   + " ".join(res["notes"]), kind)
        if res["verdict"] == "lost" and st.params.get("stop_on_loss"):
            st.add_log("stopping here: the plan says to stop at the first step that loses records", "warn")
            st.cancel.set()

    @staticmethod
    def _connect_all(conns):
        """Open every connection, in parallel enough that a thousand TLS handshakes do not take minutes."""
        if len(conns) == 1:
            conns[0].connect()
            return
        lock = threading.Lock()
        queue = list(conns)

        def work():
            while True:
                with lock:
                    if not queue:
                        return
                    c = queue.pop()
                c.connect()

        threads = [threading.Thread(target=work, daemon=True) for _ in range(min(32, len(conns)))]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

    @staticmethod
    def _watch(st, live, workers, start_at, seconds):
        """A records-per-second reading while the step runs, for the live chart."""
        last, last_t = 0, start_at
        while any(w.is_alive() for w in workers):
            # short waits so the loop leaves as soon as the workers do, a sample only once a second
            for _ in range(4):
                if not any(w.is_alive() for w in workers):
                    break
                st.cancel.wait(0.25)
            now = time.monotonic()
            sent = sum(w.sent for w in workers)
            dt = max(1e-6, now - last_t)
            live["sent"] = sent
            live["bytes"] = sum(w.bytes for w in workers)
            live["errors"] = sum(w.errors for w in workers)
            live["series"] = (live["series"] + [round((sent - last) / dt)])[-180:]
            live["elapsed"] = now - start_at
            last, last_t = sent, now

    # ---- what the whole run says
    EPS_TABLE = (5, 10, 25, 50, 100, 250)

    def _summarise(self, st):
        steps = [s for s in st.steps if s.get("state") == "done"]
        if not steps:
            st.summary = {"note": "no step completed, so there is nothing to conclude"}
            return
        clean = [s for s in steps if s["verdict"] in ("clean", "sent")]
        confirmed = any(s["verdict"] == "clean" for s in steps)
        best = max(clean, key=lambda s: s["achieved"], default=None)
        first_bad = next((s for s in steps if s["verdict"] in ("lost", "backlog")), None)
        maxconn = next((s["relay"].get("max_connections") for s in reversed(steps) if s.get("relay", {}).get("max_connections")), None)
        proto = steps[-1]["proto"]
        ceiling = best["achieved"] if best else None
        # A ceiling nothing broke at is not a ceiling: say which it is, or the number gets quoted as a limit.
        topped_out = bool(best and steps and best is steps[-1] and not first_bad)
        st.summary = {
            "ceiling_records_s": ceiling,
            "ceiling_step": best["n"] if best else None,
            "ceiling_mbit_s": best["mbit_s"] if best else None,
            "ceiling_size": best["size_label"] if best else None,
            "ceiling_devices": best["devices"] if best else None,
            "topped_out": topped_out,
            "first_failure": ({"n": first_bad["n"], "verdict": first_bad["verdict"], "offered": first_bad["offered"],
                               "achieved": first_bad["achieved"], "notes": first_bad["notes"]} if first_bad else None),
            "sender_limited": bool(best and best.get("sender_limited")),
            "confirmed": confirmed,
            # what a person has to do by hand when this Studio cannot read the relay: the window to look at
            # and where to look. Without it "not confirmed" is a dead end rather than one more step.
            "relay_check": None if confirmed else {
                "from": st.started, "to": time.time(), "tag": st.tag,
                "where": "the Log Relay Manager, Sensors page, Delivery tab",
                "how": ("Press Reset on the port counters there BEFORE a run, then read Accepted, Written, "
                        "Waiting and Dropped for the sensor port this log source uses when it ends: those four "
                        "numbers are the only place the relay's side of this run is recorded."),
            },
            "basis": ("confirmed against the relay's own counters: what it accepted, wrote and dropped"
                      if confirmed else
                      "the sending side only - the relay's counters were not read, so nothing here says what "
                      "syslog-ng did with these records"),
            "proto": proto, "max_connections": maxconn,
            "total_sent": sum(s["sent"] for s in steps),
            "total_bytes": sum(s["bytes"] for s in steps),
            "sizing": [sizing(ceiling, eps, maxconn, proto) for eps in self.EPS_TABLE] if ceiling else [],
        }
        if ceiling:
            # "nothing lost" is only true when the relay's counters were read. Without them the honest claim
            # is about THIS HOST and nothing else, or the line reads as an all-clear over a relay that may
            # have been dropping the whole time (Paul, 2 Oct 2026).
            head = ("highest rate with nothing lost: " if confirmed
                    else "highest rate this host sent without an error of its own: ")
            st.add_log(head + f"{ceiling:,.0f} records/s ({best['mbit_s']:.1f} Mbit/s) at "
                       f"{best['size_label']} from {best['devices']} device(s)"
                       + (". Nothing broke at the highest rate tried, so this is a floor, not a ceiling"
                          if topped_out else "")
                       + ("" if confirmed else ". The relay's counters were not read, so this says nothing about "
                                               "what reached the sensor - read the relay's Delivery tab for the "
                                               "same window"), "ok" if confirmed else "warn")
        else:
            st.add_log("no step completed without losing records: the first step already lost some, so the ceiling is "
                       "below the lowest rate tried", "warn")

    def _count_in_platform(self, st, wait=False):
        """Ask the relay to count this run's tag in Stellar Cyber - the one hop nothing else can see."""
        if not self.managed():
            st.platform = {"asked": False, "note": "this Studio has no management connection to the relay, so it cannot "
                                                   "ask the platform. Search " + f"{SS.PERF_MARKER}-{st.tag}" + " in Stellar Cyber."}
            return
        if wait:
            st.cancel.wait(20)               # the platform indexes a record a moment after it arrives
        try:
            res = self.relay.platform_count(st.tag)
        except Exception as e:  # noqa: BLE001
            st.platform = {"asked": True, "error": str(e),
                           "note": f"search {SS.PERF_MARKER}-{st.tag} in Stellar Cyber to count this run by hand"}
            st.add_log(f"the platform could not be counted ({e}); search {SS.PERF_MARKER}-{st.tag} there instead", "dim")
            return
        # only the steps whose records were left whole: a cut record has no run tag to find
        whole = [s for s in st.steps if s.get("state") == "done" and not s.get("cut")]
        sent = sum(s["sent"] for s in whole)
        res["sent"] = sent
        res["cut_steps"] = len([s for s in st.steps if s.get("state") == "done" and s.get("cut")])
        res["pct"] = (100.0 * res["count"] / sent) if sent else None
        st.platform = res
        st.add_log(f"Stellar Cyber holds {res['count']:,} record(s) carrying {SS.PERF_MARKER}-{st.tag}, against "
                   f"{sent:,} sent from here"
                   + (f" (the {res['cut_steps']} step(s) whose records were cut to size carry no tag and are not counted)"
                      if res["cut_steps"] else "")
                   + (f" ({res['pct']:.0f}%)" if res.get("pct") is not None else "")
                   + ". Indexing lags, so ask again in a minute before calling any of them missing.",
                   "ok" if sent and res["count"] >= sent * 0.95 else "warn")

    def recount(self, bid):
        """Ask the platform again: a count taken straight after a run is a floor, not a verdict."""
        st = self.get(bid)
        if st:
            self._count_in_platform(st)
            self.db.update_bench(st.id, platform=st.platform)
            return st.platform
        row = self.db.bench(bid)
        if not row:
            return None
        res = self.relay.platform_count(row["params"].get("tag", ""))
        sent = sum(s.get("sent", 0) for s in row.get("steps") or [])
        res.update(sent=sent, pct=(100.0 * res["count"] / sent) if sent else None)
        self.db.update_bench(bid, platform=res)
        return res

    def forget_finished(self, keep=10):
        with self.lock:
            done = [k for k, v in self.live.items() if v.status in ("done", "cancelled", "failed")]
            for k in done[:-keep]:
                del self.live[k]


def report_csv(row):
    """The step table as a CSV, for putting the numbers in front of someone who was not here."""
    cols = ["step", "size", "bytes_per_log", "devices", "offered_per_s", "seconds", "sent", "achieved_per_s",
            "mbit_s", "send_errors", "relay_accepted", "relay_written", "relay_dropped", "relay_queued",
            "kernel_udp_dropped", "syslogng_cores", "verdict", "notes"]
    out = [",".join(cols)]
    for s in row.get("steps") or []:
        r = s.get("relay") or {}
        vals = [s.get("n"), s.get("size_label"), s.get("avg_bytes") and round(s["avg_bytes"]), s.get("devices"),
                round(s.get("offered") or 0), round(s.get("seconds_actual") or s.get("seconds") or 0, 1),
                s.get("sent"), round(s.get("achieved") or 0), round(s.get("mbit_s") or 0, 2), s.get("errors"),
                r.get("accepted"), r.get("written"), r.get("dropped"), r.get("queued"), r.get("udp_dropped"),
                r.get("syslogng_cores") and round(r["syslogng_cores"], 2), s.get("verdict"),
                " ".join(s.get("notes") or [])]
        out.append(",".join('"' + str("" if v is None else v).replace('"', '""') + '"' for v in vals))
    return "\n".join(out) + "\n"
