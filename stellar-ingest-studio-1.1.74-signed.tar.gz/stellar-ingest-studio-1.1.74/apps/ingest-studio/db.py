"""SQLite storage for Ingest Studio: log sources, runs, settings. Standard library only."""
import json
import os
import sqlite3
import threading
import time

# The sources table in one place: the schema of a new database, and the rebuild an older database goes
# through when a constraint changes (SQLite cannot ALTER a NOT NULL away).
#
# A log source is a DEVICE configuration, as a real firewall has one (Paul, 24 Sep 2026): what it is, how it
# reaches the relay or the sensor, the address it sends from and how it identifies itself in its logs. The
# tenant it lands in, and the sensor port the relay forwards it to, are decided on the relay by its own
# log-source row, so they are not here. Columns from before that decision - tenant_id, wrapper_ports,
# relay_synced, relay_error, and the tenants table itself - stay in the schema so an older database opens
# unchanged, but nothing reads or writes them any more.
SOURCES_DDL = """(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, vendor TEXT NOT NULL, tenant_id INTEGER,
  path TEXT NOT NULL, transport TEXT NOT NULL, bind_ip TEXT NOT NULL, format TEXT DEFAULT 'syslog',
  sensor TEXT DEFAULT '', device_id TEXT DEFAULT '', id_field TEXT DEFAULT '',
  wrapper_ports TEXT DEFAULT 'parser', webhook_source TEXT DEFAULT '', ingest_path TEXT DEFAULT '',
  enabled INTEGER DEFAULT 1,
  relay_synced INTEGER DEFAULT 0, relay_error TEXT DEFAULT '',
  created REAL NOT NULL, FOREIGN KEY(tenant_id) REFERENCES tenants(id))"""
SOURCE_COLS = ("id", "name", "vendor", "tenant_id", "path", "transport", "bind_ip", "format", "sensor", "device_id",
               "id_field", "wrapper_ports", "webhook_source", "ingest_path", "enabled", "relay_synced",
               "relay_error", "created")
# columns added after the first release, with the value existing rows get. 'parser' is the delivery
# method every source used before the capture port became a choice.
ADDED_COLS = {"sensor": "''", "device_id": "''", "id_field": "''", "wrapper_ports": "'parser'",
              # Method 5: which product's webhook shape this source posts, and the tenant URL label
              # the relay routes it by. Empty = the generic JSON document, keyed by source address.
              "webhook_source": "''", "ingest_path": "''",
              # TLS to the relay's 6514: this source's own certificate (PEM, public) and, for the key, only the
              # MARKER "stored" - the key itself lives in the host's root-only credential store, through
              # stellar-studio-secret, and is read back over a pipe for a run. SOURCE_OUT carries neither column.
              "client_cert": "''", "client_key": "''",
              # how this source trusts the RELAY's certificate: '' or 'any' = accept any (the default, and what
              # every source saved before this choice existed keeps doing), 'ca' = it must chain to tls_ca,
              # 'pin' = it must be exactly the certificate whose SHA-256 is tls_pin.
              "tls_verify": "''", "tls_ca": "''", "tls_pin": "''",
              # The direct path only (8 Oct 2026): '' = as-is (the device's own syslog, no tenant), 'tenant' = the
              # log inside the Stellar JSON wrapper with direct_tenant (32 lowercase hex), to the parser's own port.
              # Not the old tenant_id column, which is an INTEGER pointing at the retired tenants table.
              "delivery": "''", "direct_tenant": "''"}

SCHEMA = """
CREATE TABLE IF NOT EXISTS tenants (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, tenant_id TEXT NOT NULL UNIQUE,
  note TEXT DEFAULT '', created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS sources __SOURCES_DDL__;
CREATE TABLE IF NOT EXISTS runs (
  id INTEGER PRIMARY KEY, started REAL NOT NULL, finished REAL, user TEXT, status TEXT NOT NULL,
  params TEXT NOT NULL, results TEXT DEFAULT '{}', relay TEXT DEFAULT '{}', log TEXT DEFAULT '',
  sent INTEGER DEFAULT 0, failed INTEGER DEFAULT 0, note TEXT DEFAULT '');
-- A throughput run is not a Send run: it has no per-source tally and no relay confirmation, it has a
-- list of measured STEPS, what this host itself could do (calibration) and what the platform counted.
CREATE TABLE IF NOT EXISTS bench_runs (
  id INTEGER PRIMARY KEY, started REAL NOT NULL, finished REAL, user TEXT, status TEXT NOT NULL,
  params TEXT NOT NULL, steps TEXT DEFAULT '[]', summary TEXT DEFAULT '{}', calibration TEXT DEFAULT '{}',
  platform TEXT DEFAULT '{}', log TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY, ts REAL, user TEXT, action TEXT, detail TEXT);
""".replace("__SOURCES_DDL__", SOURCES_DDL)

DEFAULT_SETTINGS = {
    "relay_ip": "",              # the log relay's address: an IP or a host name, private or public
    "relay_monitor_url": "",     # https://<relay>:8444
    "relay_token": "",
    # sensor_ip / sensor_ip_2 / sensor_tls are the two-sensor settings from before Settings -> Sensors (8 Oct 2026).
    # The list now lives under "sensors" (JSON); these three are read as sensors 1 and 2 until it exists, and are
    # kept in step with it on every save so a roll back to an older release still finds its sensors.
    "sensor_ip": "",
    "sensor_tls": "1",
    "iface": "",                 # interface for secondary IPs (auto-detected when empty)
    "nginx_port": "80",
    "sensor_ip_2": "",           # second Modular Sensor, when the relay forwards to two
    "relay_ca": "",              # PEM of the CA that signed the relay's 6514 certificate; empty = accept any
}


class DB:
    def __init__(self, path):
        self.path = path
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        self.lock = threading.Lock()
        with self.conn() as c:
            c.executescript(SCHEMA)
            # migrations for databases created by an earlier version
            info = list(c.execute("PRAGMA table_info(sources)"))
            have = {r["name"] for r in info}
            for col, default in ADDED_COLS.items():
                if col not in have:
                    c.execute(f"ALTER TABLE sources ADD COLUMN {col} TEXT DEFAULT {default}")
            if any(r["name"] == "tenant_id" and r["notnull"] for r in info):
                self._make_tenant_optional(c)
        for k, v in DEFAULT_SETTINGS.items():
            if self.get_setting(k) is None:
                self.set_setting(k, v)

    @staticmethod
    def _make_tenant_optional(c):
        """Databases from before the as-is path required a tenant on every source. SQLite cannot drop a NOT NULL,
        so the table is rebuilt: same columns, same rows, tenant_id nullable.

        The new table is built from SOURCES_DDL, which is the ORIGINAL shape, so every column added since by
        ALTER has to be put back on it before the rows are copied - otherwise this rebuild silently drops them
        and their data. It did exactly that to client_cert until 2 Oct 2026; nothing noticed because no query
        asked for the column, which is the quiet kind of data loss."""
        extra = [k for k in ADDED_COLS if k not in SOURCE_COLS]
        cols = ", ".join(list(SOURCE_COLS) + extra)
        c.execute(f"CREATE TABLE sources_new {SOURCES_DDL}")
        for col in extra:
            c.execute(f"ALTER TABLE sources_new ADD COLUMN {col} TEXT DEFAULT {ADDED_COLS[col]}")
        c.execute(f"INSERT INTO sources_new ({cols}) SELECT {cols} FROM sources")
        c.execute("DROP TABLE sources")
        c.execute("ALTER TABLE sources_new RENAME TO sources")

    def conn(self):
        c = sqlite3.connect(self.path, timeout=10, check_same_thread=False)
        c.row_factory = sqlite3.Row
        return c

    # ---- settings
    def get_setting(self, key, default=None):
        with self.conn() as c:
            r = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return r["value"] if r else default

    def set_setting(self, key, value):
        with self.conn() as c:
            c.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))

    def settings(self):
        with self.conn() as c:
            return {r["key"]: r["value"] for r in c.execute("SELECT key,value FROM settings")}

    # ---- sources
    # what a row carries out of the database: the device columns only
    SOURCE_OUT = ("id", "name", "vendor", "path", "transport", "bind_ip", "format", "sensor", "device_id",
                  "id_field", "webhook_source", "ingest_path", "enabled", "created", "tls_verify", "tls_pin",
                  "delivery", "direct_tenant")

    def sources(self):
        with self.conn() as c:
            rows = c.execute(f"SELECT {', '.join(self.SOURCE_OUT)} FROM sources ORDER BY name").fetchall()
        return [dict(r) for r in rows]

    def source(self, sid):
        with self.conn() as c:
            r = c.execute(f"SELECT {', '.join(self.SOURCE_OUT)} FROM sources WHERE id=?", (sid,)).fetchone()
        return dict(r) if r else None

    def upsert_source(self, d, sid=None):
        cols = ("name", "vendor", "path", "transport", "bind_ip", "format", "sensor", "device_id",
                "id_field", "webhook_source", "ingest_path", "enabled", "delivery", "direct_tenant")
        vals = [d.get(k, "") if k in ("sensor", "device_id", "id_field", "webhook_source", "ingest_path", "delivery", "direct_tenant") else d[k] for k in cols]
        with self.conn() as c:
            if sid:
                # tenant_id is cleared on every edit: an older database may still carry one from before the
                # tenant left the log source, and nothing must read it back as if it meant something
                c.execute(f"UPDATE sources SET {', '.join(k + '=?' for k in cols)}, tenant_id=NULL WHERE id=?", vals + [sid])
                return sid
            cur = c.execute(f"INSERT INTO sources({','.join(cols)},created) VALUES({','.join('?' * len(cols))},?)", vals + [time.time()])
            return cur.lastrowid

    def source_tls(self, sid):
        """The client certificate one source sends TLS with, and whether a key is stored for it (the key itself is
        in the host's credential store, under the name key_name(sid)) - for the sender, never for a page."""
        with self.conn() as c:
            r = c.execute("SELECT client_cert, client_key, tls_verify, tls_ca, tls_pin FROM sources WHERE id=?", (sid,)).fetchone()
        return {"client_cert": (r["client_cert"] or "") if r else "", "key_stored": bool(r and r["client_key"] == "stored"),
                "tls_verify": (r["tls_verify"] or "") if r else "", "tls_ca": (r["tls_ca"] or "") if r else "",
                "tls_pin": (r["tls_pin"] or "") if r else ""}

    @staticmethod
    def key_name(sid):
        return f"studio-source-{int(sid)}-key"

    def set_source_trust(self, sid, verify, ca_pem, pin):
        """How this source trusts the RELAY's certificate. Kept apart from upsert_source, which writes a fixed
        column list, so a caller that says nothing about trust leaves what is stored alone."""
        with self.conn() as c:
            c.execute("UPDATE sources SET tls_verify=?, tls_ca=?, tls_pin=? WHERE id=?",
                      (verify or "", ca_pem or "", pin or "", sid))

    def set_source_tls(self, sid, cert_pem, key_stored):
        with self.conn() as c:
            c.execute("UPDATE sources SET client_cert=?, client_key=? WHERE id=?", (cert_pem or "", "stored" if key_stored else "", sid))

    def delete_source(self, sid):
        with self.conn() as c:
            c.execute("DELETE FROM sources WHERE id=?", (sid,))

    # ---- runs
    def create_run(self, user, params, note=""):
        with self.conn() as c:
            cur = c.execute("INSERT INTO runs(started,user,status,params,note) VALUES(?,?,?,?,?)",
                            (time.time(), user, "running", json.dumps(params), note))
            return cur.lastrowid

    def update_run(self, rid, **fields):
        if not fields:
            return
        for k in ("results", "relay"):
            if k in fields and not isinstance(fields[k], str):
                fields[k] = json.dumps(fields[k])
        with self.conn() as c:
            c.execute(f"UPDATE runs SET {', '.join(k + '=?' for k in fields)} WHERE id=?", list(fields.values()) + [rid])

    def run(self, rid):
        with self.conn() as c:
            r = c.execute("SELECT * FROM runs WHERE id=?", (rid,)).fetchone()
        return self._run_row(r) if r else None

    def runs(self, limit=100):
        with self.conn() as c:
            rows = c.execute("SELECT * FROM runs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [self._run_row(r) for r in rows]

    @staticmethod
    def _run_row(r):
        d = dict(r)
        for k in ("params", "results", "relay"):
            try:
                d[k] = json.loads(d[k] or "{}")
            except ValueError:
                d[k] = {}
        return d

    # ---- throughput runs
    BENCH_JSON = ("params", "steps", "summary", "calibration", "platform")

    def create_bench(self, user, params):
        with self.conn() as c:
            cur = c.execute("INSERT INTO bench_runs(started,user,status,params) VALUES(?,?,?,?)",
                            (time.time(), user, "running", json.dumps(params)))
            return cur.lastrowid

    def update_bench(self, bid, **fields):
        if not fields:
            return
        for k in self.BENCH_JSON:
            if k in fields and not isinstance(fields[k], str):
                fields[k] = json.dumps(fields[k])
        with self.conn() as c:
            c.execute(f"UPDATE bench_runs SET {', '.join(k + '=?' for k in fields)} WHERE id=?", list(fields.values()) + [bid])

    def bench(self, bid):
        with self.conn() as c:
            r = c.execute("SELECT * FROM bench_runs WHERE id=?", (bid,)).fetchone()
        return self._bench_row(r) if r else None

    def benches(self, limit=50):
        with self.conn() as c:
            rows = c.execute("SELECT * FROM bench_runs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [self._bench_row(r) for r in rows]

    @classmethod
    def _bench_row(cls, r):
        d = dict(r)
        for k in cls.BENCH_JSON:
            try:
                d[k] = json.loads(d[k] or ("[]" if k == "steps" else "{}"))
            except ValueError:
                d[k] = [] if k == "steps" else {}
        return d

    # ---- audit
    def audit(self, user, action, detail=""):
        with self.conn() as c:
            c.execute("INSERT INTO audit(ts,user,action,detail) VALUES(?,?,?,?)", (time.time(), user, action, detail[:1000]))

    def audits(self, limit=200):
        with self.conn() as c:
            return [dict(r) for r in c.execute("SELECT * FROM audit ORDER BY id DESC LIMIT ?", (limit,))]
