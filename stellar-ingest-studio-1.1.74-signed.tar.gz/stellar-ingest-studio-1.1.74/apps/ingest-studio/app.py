#!/usr/bin/env python3
"""
Ingest Studio - runs on the sender host.

Define simulated firewalls (log sources) the way a real device is configured, send realistic events
through the syslog-ng relay, the nginx relay, or straight to a Modular Sensor (Settings -> Sensors: as-is,
or wrapped with a tenant), keep a history of every run with what the relay reported forwarding, and
restart the local mock sensor.

What this program may do TO the relay (Paul, 24 Sep 2026): start and stop a packet capture around a
test run. Nothing else. It reads the relay - its status, its map, what it forwarded, which sensor ports
it can reach - and never writes the relay's configuration: the tenant a device lands in and the sensor
port it is forwarded to are the relay's own log-source row, made there, by a person, so there is no
way for this program to conflict with the Log Relay Manager's configuration.

Standard library only. Configuration in /etc/stellar-lab/ingest-studio.env.
"""
import hashlib
import json
import os
import re
import socket
import threading
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "common"))
sys.path.insert(0, HERE)
import microweb as mw  # noqa: E402
from db import DB  # noqa: E402
import sender  # noqa: E402
import bench  # noqa: E402  the throughput test: how many logs a second this path carries
import certplan  # noqa: E402  planning a certificate reissue, shared with the Log Relay Manager

ENV_PATH = os.environ.get("INGEST_STUDIO_ENV", "/etc/stellar-lab/ingest-studio.env")
CFG = mw.load_env(ENV_PATH)
CFG.update({k[len("IS_"):]: v for k, v in os.environ.items() if k.startswith("IS_")})

def cfg(key, default=None):
    return CFG.get(key, default)

SUDO = [] if cfg("NO_SUDO") == "1" else ["sudo", "-n"]
DB_PATH = cfg("DB_PATH", "/var/lib/stellar-lab/ingest-studio/studio.db")
IP_HELPER = cfg("IP_HELPER", "/usr/local/sbin/stellar-lab-ip")
UPDATE_HELPER = cfg("UPDATE_HELPER", "/usr/local/sbin/stellar-studio-update")   # update THIS app from a signed bundle
# the ONE path the browser's upload lands on; the helper reads only it and copies it somewhere the
# service user cannot write, so nothing the browser sends ever names a file on this host
UPDATE_INCOMING = cfg("UPDATE_INCOMING", os.path.join(os.path.dirname(DB_PATH), "update-incoming.tar.gz"))
UPDATE_MAX_BYTES = int(cfg("UPDATE_MAX_BYTES", str(512 * 1024 * 1024)))


def app_version():
    """The release and build of the Ingest Studio running here: /opt/stellar-lab/VERSION on an installed
    host, packaging/VERSION in a checkout. Same shape as the relay console's."""
    for cand in (os.path.join(HERE, "..", "VERSION"), os.path.join(HERE, "..", "..", "packaging", "VERSION")):
        try:
            with open(cand) as f:
                lines = [l.strip() for l in f.read().splitlines() if l.strip()]
        except OSError:
            continue
        if not lines:
            continue
        out = {"version": lines[0], "build": "", "source": "installed" if "packaging" not in cand else "checkout"}
        for l in lines[1:]:
            if l.startswith("build "):
                out["build"] = l[6:].strip()
        return out
    return {"version": "unknown", "build": "", "source": "unknown"}
HEX32 = re.compile(r"^[0-9a-f]{32}$")
IPV4 = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")
# a plain host name, as the relay's own helpers accept it: the value goes into a socket connect, never a shell
HOSTNAME = re.compile(r"^(?=.{1,253}$)[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$")

db = DB(DB_PATH)


# ----------------------------------------------------------------------------- editions
# Two editions, the same split as the Log Relay Manager's (Paul, 24 Sep 2026): "I want a standard mode of
# ingest studio that is just used to create log sources. I want to treat the log sources like they are real
# and there should be no automated connections in standard mode to or from ingestion studio... it will only
# know about the syslog ng, but it will not push configs or have the option to troubleshoot with packet
# capture. That is advanced only."
#
# So in the STANDARD edition this program has NO management connection to the relay at all. It defines log
# sources and sends traffic to the syslog-ng relay's listeners - the same thing a real firewall does, which
# is the point of treating the sources as real - and nothing else. It never reads the relay's settings,
# never asks it to capture packets and never asks it what arrived. There is no token and no manager URL to
# set, so there is nothing for a customer to point at production by accident, and the relay refuses the
# token anyway (its own standard edition turns every token request down).
#
# The ADVANCED edition has the connection and uses it to READ the relay (status, map, what it forwarded,
# which sensor ports it can reach) and to start and stop a packet capture around a run. Neither edition
# writes the relay's configuration: since 24 Sep 2026 there is no code path that does (RelayClient has no
# method for it, and a test reads this file to keep it that way).
#
# The guard is in RelayClient._call, which is the only door to the relay: one refusal covers every caller,
# present and future. Hiding a button would not.
EDITIONS = ("standard", "advanced")
EDITION_FILE = os.path.join(os.path.dirname(DB_PATH) or ".", "edition.json")


def edition():
    forced = cfg("EDITION")                      # tests and the smoke pin it
    if forced in EDITIONS:
        return forced
    try:
        with open(EDITION_FILE) as f:
            d = json.load(f)
        return d.get("edition") if d.get("edition") in EDITIONS else "standard"
    except (OSError, ValueError):
        return "standard"


def advanced():
    return edition() == "advanced"


def set_edition(ed):
    if ed not in EDITIONS:
        raise mw.HttpError(400, "edition is standard or advanced")
    os.makedirs(os.path.dirname(EDITION_FILE) or ".", exist_ok=True)
    tmp = EDITION_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump({"edition": ed, "at": time.time()}, f)
    os.replace(tmp, EDITION_FILE)
    return ed


# What the standard edition offers: the syslog-ng relay, and straight to a Modular Sensor. nginx is not a
# standard path and is not named anywhere a standard console can reach. The direct path joined the standard
# edition on 8 Oct 2026 (Paul: "a sensor configuration section ... so it can send directly to a sensor ... if
# ingest studio is also used to send logs for testing directly to a sensor"): sending to a parser port is
# what a device does, not a management connection, so the rule above - nothing to or from the relay's API in
# the standard edition - is untouched.
STANDARD_PATHS = ("syslogng", "raw")


def paths_here():
    return dict(sender.PATHS) if advanced() else {k: v for k, v in sender.PATHS.items() if k in STANDARD_PATHS}


NO_MANAGER_NOTE = ("this Ingest Studio is the standard edition: it has no management connection to the log "
                   "relay. Log sources are defined here and traffic is sent to the relay's listeners, or "
                   "straight to a sensor's parser port, exactly as a real firewall would; the relay's own "
                   "configuration is changed on the relay, by a person, in its console")
# What every edition says about the relay's configuration: it is made on the relay. This program never writes it.
ON_RELAY_NOTE = ("each log source defined here must also exist on the relay, as a log source in the Log Relay "
                 "Manager: that row decides the tenant its logs land in and the sensor port they are forwarded "
                 "to. Until it exists, the device's logs land in the relay's catch-all tenant. This Studio never "
                 "writes the relay's configuration")


# ----------------------------------------------------------------------------- log relay manager client
class RelayClient:
    def __init__(self, db):
        self.db = db

    def _call(self, method, path, body=None, timeout=15, retry=None):
        """One request to the Log Relay Manager. A call that is safe to repeat (every GET, and the stop of a
        capture) is retried once after a connection-level failure: a run's stop-capture call was once
        answered by the relay and then reset on the wire, and the relay had in fact done the work, so a
        second read would have shown the packets. Cause of that reset not established; the retry is what
        keeps one dropped connection from reading as a failed capture."""
        if not advanced():
            # The ONE guard for every relay call there is or will be. A standard Studio talks to the relay
            # only by sending it logs on 514/601/6514, like a firewall.
            raise RuntimeError(NO_MANAGER_NOTE)
        s = self.db.settings()
        base = s.get("relay_monitor_url", "").rstrip("/")
        if not base:
            raise RuntimeError("log relay manager URL not set (Settings)")
        if retry is None:
            retry = method == "GET"
        ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        attempts = 2 if retry else 1
        for attempt in range(1, attempts + 1):
            req = urllib.request.Request(base + path, method=method,
                                         data=json.dumps(body).encode() if body is not None else None,
                                         headers={"X-Api-Token": s.get("relay_token", ""), "Content-Type": "application/json"})
            try:
                with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
                    return json.loads(r.read().decode() or "{}")
            except urllib.error.HTTPError as e:
                try:
                    detail = json.loads(e.read().decode())
                except Exception:  # noqa: BLE001
                    detail = {}
                raise RuntimeError(f"log relay manager {e.code}: {detail.get('error', e.reason)}" + (f" ({detail['detail']})" if detail.get("detail") else ""))
            except (urllib.error.URLError, OSError) as e:
                if attempt < attempts:
                    time.sleep(0.5)
                    continue
                raise RuntimeError(f"log relay manager unreachable: {getattr(e, 'reason', e)}" + (" (tried twice)" if attempts > 1 else ""))

    def status(self):
        return self._call("GET", "/api/status")

    def activity_cursor(self):
        return self._call("GET", "/api/activity?since=9999999999").get("now")

    # A run can be bracketed by a packet capture on the relay: start 1 s before sending, stop 1 s after.
    def capture_start(self, seconds=60, description="", source=""):
        """description = the run's note, shown at the top of the relay's Packet capture page and editable there."""
        return self._call("POST", "/api/packets/capture", {"seconds": int(seconds), "description": description[:300], "source": source[:120]}, timeout=20)

    def capture_stop(self):
        return self._call("POST", "/api/packets/stop", {}, timeout=30, retry=True)   # stopping twice is harmless

    def packets(self):
        return self._call("GET", "/api/packets", timeout=30)

    def packets_url(self):
        return self.db.settings().get("relay_monitor_url", "").rstrip("/") + "/#/packets"

    def activity_since(self, ts):
        return self._call("GET", f"/api/activity?since={ts}")

    def feed(self, n=40):
        return self._call("GET", f"/api/feed?n={n}")

    def errors(self):
        return self._call("GET", "/api/errors?minutes=15")

    def sensor_ports(self, ports):
        """Which of these sensor ports the RELAY can reach. Asked before a run, because syslog-ng
        buffers a port nothing answers on and the send looks perfect from this host."""
        q = ",".join(str(p) for p in sorted(set(ports)))
        return self._call("GET", f"/api/sensor-ports?ports={q}", timeout=30).get("sensor_ports", [])

    def tenant_map(self):
        """The relay's map as it is right now, read so this host can say whether each device it simulates
        exists there. Read only: the map is written on the relay, by a person."""
        return self._call("GET", "/api/tenant-map", timeout=30)

    def perf_counters(self):
        """One instant of the relay's counters, for a throughput test: what the kernel dropped before
        syslog-ng, what syslog-ng accepted, wrote, queued and dropped, and what it cost in CPU. A read,
        so it works whatever the relay's remote-sync setting says."""
        return self._call("GET", "/api/perf-counters", timeout=20)

    def platform_count(self, tag):
        """How many of a throughput run's records Stellar Cyber holds. The relay asks the platform - this
        host has no connection to it - and only an advanced console with the platform connected can."""
        return self._call("GET", f"/api/stellar/count?tag={urllib.parse.quote(tag)}", timeout=40)

    # That is the whole client. There is deliberately no method that changes the relay's configuration
    # (no map row, no tenant name, no service restart): the capture start/stop above is the only thing a
    # run asks the relay to do, and test_the_only_thing_the_studio_asks_the_relay_to_do_is_capture reads
    # this file to keep it that way.


relay = RelayClient(db)
# the client key of a log source, read from the host's credential store for one run, over a pipe
SECRET_HELPER = cfg("SECRET_HELPER", "/usr/local/sbin/stellar-studio-secret")


def _secret(*args, stdin=None):
    return mw.run_cmd(SUDO + [SECRET_HELPER, *args], timeout=30, stdin=stdin)


# ---- this Studio's own HTTPS certificate and its sign-in timeout: Settings -> Security (8 Oct 2026, Paul:
# "make it easy to re-issue the TLS certificate and HTTPS certificate. Do the same on ingest studio. It should have
# the same security tab"). The card is Lab.certCard, the one the Log Relay Manager uses; the root helper is the
# relay's own certificate code pointed at this Studio's files (stellar-studio-cert).
CERT_HELPER = cfg("CERT_HELPER", "/usr/local/sbin/stellar-studio-cert")
HTTPD = None                  # main() sets it, so a new certificate is swapped in place: no restart, no closed listener
_TLS_LOCK = threading.Lock()
SESSION_IDLE_DEFAULT = 720    # minutes: a sign-in lasted 12 hours before this was a setting, and still does by default


def cert_helper(*args, stdin=None):
    """The certificate helper's one JSON answer, or our own sentence when it cannot be run."""
    if not os.path.exists(CERT_HELPER):
        return {"ok": False, "helper_missing": True,
                "error": "the certificate helper (stellar-studio-cert) is not installed on this host: run the Studio's installer again"}
    rc, out, err = mw.run_cmd(SUDO + [CERT_HELPER, *args], timeout=180, stdin=stdin)
    for line in reversed((out or "").strip().splitlines()):
        try:
            return json.loads(line)
        except ValueError:
            continue
    said = (err or out or "").strip()
    return {"ok": False, "error": "the certificate helper did not answer" + (": " + said[-300:] if said else "")}


def studio_tls_reload():
    """Present the certificate on disk from the next connection on. Nothing to do when this Studio serves plain HTTP."""
    if HTTPD is None or getattr(HTTPD, "ssl_context", None) is None:
        return {"ok": True, "reloaded": False}
    try:
        with _TLS_LOCK:
            mw.reload_tls(HTTPD, cfg("TLS_CERT", "/etc/stellar-lab/ingest-studio.crt"), cfg("TLS_KEY", "/etc/stellar-lab/ingest-studio.key"))
        return {"ok": True, "reloaded": True}
    except Exception as e:  # noqa: BLE001  said, and undone by the caller
        return {"ok": False, "error": f"{e.__class__.__name__}: {e}"}


def session_idle_minutes():
    try:
        v = int(db.get_setting("session_idle_minutes") or SESSION_IDLE_DEFAULT)
    except (TypeError, ValueError):
        v = SESSION_IDLE_DEFAULT
    return max(5, min(720, v))


def _read_key(sid):
    rc, out, err = _secret("get", db.key_name(sid))
    if rc != 0:
        raise RuntimeError((err or "the credential helper could not read it").strip()[-160:])
    return out


runs = sender.RunManager(db, relay, managed=advanced, key_reader=_read_key)
benches = bench.BenchManager(db, relay, managed=advanced)


# ----------------------------------------------------------------------------- host helpers
def _bench_tag():
    """A short tag for one throughput run: 6 lowercase hex characters, enough that two runs on the same
    platform never collide, short enough to read out and type into a search box."""
    return os.urandom(3).hex()


def default_iface():
    rc, out, _ = mw.run_cmd(["ip", "-o", "-4", "route", "show", "to", "default"])
    parts = out.split()
    return parts[parts.index("dev") + 1] if "dev" in parts else "eth0"


def host_ips():
    rc, out, _ = mw.run_cmd(["ip", "-o", "-4", "addr", "show"])
    ips = []
    for line in out.splitlines():
        cols = line.split()
        if len(cols) >= 4 and cols[2] == "inet":
            ips.append({"iface": cols[1], "ip": cols[3].split("/")[0]})
    return ips


def ensure_bind_ip(ip):
    """Add a secondary IP to the interface if it is not already present."""
    if any(h["ip"] == ip for h in host_ips()):
        return {"added": False}
    iface = db.get_setting("iface") or default_iface()
    rc, out, err = mw.run_cmd(SUDO + [IP_HELPER, "add", ip, iface], timeout=20)
    if rc != 0:
        raise RuntimeError(f"could not add {ip} to {iface}: {(err or out).strip()[-300:]}")
    return {"added": True, "iface": iface}


def probe(host, port, timeout=5, try_tls=True):
    """TCP connect, plus a TLS handshake attempt where TLS is expected.
    The handshake is skipped on plain syslog ports: a ClientHello sent to tcp/514 would be
    forwarded to the sensor as a garbage message."""
    r = {"host": host, "port": port, "tcp": False, "tls": None, "error": ""}
    try:
        with socket.create_connection((host, port), timeout=timeout) as s:
            r["tcp"] = True
    except OSError as e:
        r["error"] = str(e)
        return r
    if not try_tls:
        return r
    try:
        ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        with socket.create_connection((host, port), timeout=timeout) as raw:
            with ctx.wrap_socket(raw, server_hostname=host) as tls:
                r["tls"] = tls.version()
                # which certificate the sensor presents: compare with the one uploaded to it
                r["cert_sha256"] = hashlib.sha256(tls.getpeercert(True)).hexdigest()
    except (ssl.SSLError, OSError) as e:
        r["tls"] = False
        r["tls_error"] = str(e)[:80]
    return r


# ----------------------------------------------------------------------------- the sensors (Settings -> Sensors)
# One card per Modular Sensor a DIRECT log source can send to, numbered 1..8, the way the Log Relay Manager's
# Sensors page has one per sensor it forwards to. The list is sender.sensors_from_settings(), which also reads a
# database from before the list existed (sensor_ip / sensor_ip_2 / sensor_tls) as sensors 1 and 2.
def sensors_list():
    return sender.sensors_from_settings(db.settings())


def sensor_address_problem(addr):
    """'' when addr is an IPv4 address or a plain host name that resolves on this host, else our sentence. The value
    only ever goes into a socket connect, but a name that does not resolve would fail every run, so it is refused
    when it is typed rather than when it is sent to."""
    addr = str(addr or "").strip()
    if not addr:
        return ""
    if IPV4.match(addr):
        return "" if all(int(p) <= 255 for p in addr.split(".")) else f"'{addr}' is not an IPv4 address (each part is 0 to 255)"
    if not HOSTNAME.match(addr):
        return f"'{addr[:60]}' is not an IPv4 address or a host name (letters, digits, dots and hyphens)"
    try:
        socket.getaddrinfo(addr, None, socket.AF_INET, socket.SOCK_STREAM)
    except (OSError, UnicodeError):
        return f"the name {addr} does not resolve on this host. Give the sensor's address, or a name this host's DNS knows"
    return ""


def resolve_ipv4(addr):
    try:
        return sorted({a[4][0] for a in socket.getaddrinfo(addr, None, socket.AF_INET, socket.SOCK_STREAM)}) if addr else []
    except (OSError, UnicodeError):
        return []


def pinned_sources(n, sources=None):
    """The direct log sources that send to sensor n (a source that names none sends to sensor 1)."""
    return [s for s in (sources if sources is not None else db.sources())
            if s["path"] == "raw" and str(s.get("sensor") or "1") == str(n)]


def save_sensors(lst):
    """Write the list, and keep the two settings that came before it in step, so an older release - after a roll
    back - still finds sensors 1 and 2 where it always looked."""
    db.set_setting("sensors", json.dumps([{k: x[k] for k in ("n", "address", "transport", "trust", "ca", "pin")} for x in lst]))
    one = next(x for x in lst if x["n"] == 1)
    two = next((x for x in lst if x["n"] == 2), None)
    db.set_setting("sensor_ip", one["address"])
    db.set_setting("sensor_ip_2", two["address"] if two else "")
    db.set_setting("sensor_tls", "0" if one["transport"] == "tcp" else "1")


def sensor_view(x, sources=None):
    """What a page may see of one sensor: everything but the CA itself, which is shown as facts."""
    pinned = pinned_sources(x["n"], sources)
    return {"n": x["n"], "address": x["address"], "transport": x["transport"], "trust": x["trust"], "pin": x["pin"],
            "has_ca": bool(x["ca"]), "ca_facts": sender.x509_facts(x["ca"]) if x["ca"] else None,
            "resolved": resolve_ipv4(x["address"]) if x["address"] and not IPV4.match(x["address"]) else [],
            "sources": [{"id": s["id"], "name": s["name"], "vendor": s["vendor"], "port": sender.parser_port_of(s),
                         "delivery": sender.delivery_of(s)} for s in pinned]}


_relay_cache = {"at": 0.0, "status": None, "map": None, "error": ""}
RELAY_TTL = float(os.environ.get("IS_KEYMODE_TTL", "15"))   # 0 in tests: read the relay every time


def _relay_read():
    """One status + map read of the relay, cached briefly (both are asked for on every page load and every
    source save). None for either when the relay cannot be asked; the error is kept so the page can say why."""
    if not advanced():
        return None, None, ""
    if RELAY_TTL and time.time() - _relay_cache["at"] < RELAY_TTL:
        return _relay_cache["status"], _relay_cache["map"], _relay_cache["error"]
    st = mp = None; err = ""
    try:
        st = relay.status()
        mp = relay.tenant_map()
    except Exception as e:  # noqa: BLE001
        err = str(e)
    _relay_cache.update(at=time.time(), status=st, map=mp, error=err)
    return st, mp, err


def relay_methods():
    """Which relay methods the relay has ({'syslog': {...}, 'nginx': {...}}), or None when the relay cannot be
    asked or is older than this field. None never blocks a save."""
    if not advanced():
        # A standard Studio knows the relay runs syslog-ng because that is what it sends to. It does not
        # ask, and it never claims to know whether the relay has anything else.
        return {"syslog": {"installed": True, "note": ""}}
    st, _, _ = _relay_read()
    return (st or {}).get("methods") or None


def relay_lookup(src):
    """What the RELAY's map says about one device defined here - read, never written.

    {known: False, error}                       the relay could not be asked (or this is the standard edition)
    {known: True, mapped: False, note}          the relay has no row for it: its logs land in the catch-all
    {known: True, mapped: True, selector, tenant, tenant_label, port, vendor, product, sensor}

    Matched the way the relay matches: a syslog-ng device by the address it sends from, or by its identity
    field and value (a row whose selector is `devid=FGT...`); an nginx device by its address, or by the URL
    label it posts to (the relay's path map). A relay keyed on a log field (KEY_MODE=field) has bare-serial
    selectors, so the device's identity value alone is tried too."""
    if src["path"] in sender.NO_RELAY:
        return {"known": True, "mapped": None,
                "note": f"goes straight to sensor {src.get('sensor') or '1'}: the relay is not involved, so there is nothing to look up there"}
    if not advanced():
        return {"known": False, "error": NO_MANAGER_NOTE}
    _, mp, err = _relay_read()
    if not mp:
        return {"known": False, "error": err or "the relay did not answer"}
    rows = {r["ip"]: r for r in mp.get("rows", []) if r.get("ip") != "default"}
    field, value = sender.identity_of(src)
    if src["path"] == "nginx":
        label = (src.get("ingest_path") or "").strip("/")
        # the relay lists its path map as rows ({label, tenantid}); an older relay answered a dict
        raw_paths = mp.get("nginx", {}).get("paths") or []
        paths = {r["label"]: r["tenantid"] for r in raw_paths} if isinstance(raw_paths, list) else dict(raw_paths)
        tenant = paths.get(label) if label else None
        by = "URL path" if tenant else ""
        if not tenant:
            r = rows.get(src.get("bind_ip") or "")
            tenant = (r or {}).get("nginx_tenant"); by = "address" if tenant else ""
        if not tenant:
            return {"known": True, "mapped": False, "note": "no row on the relay for this address or URL label: its POSTs land in the relay's catch-all tenant"}
        return {"known": True, "mapped": True, "by": by, "selector": label if by == "URL path" else src.get("bind_ip"),
                "tenant": tenant, "tenant_label": (mp.get("names") or {}).get(tenant, ""), "port": 5200}
    # syslog-ng: the row for this device, whichever selector shape the relay uses for it. A per-row field
    # selector (devid=X) works in any mode; a BARE serial as a selector only means anything when the whole
    # relay is keyed on that field (KEY_MODE=field) - in address mode such a row is matched by SOURCEIP and
    # can never fire, so it must not be reported as "mapped".
    candidates = [src.get("bind_ip") or ""]
    pos = sender.csv_position(src["vendor"], field) if field else 0
    if field and value:
        candidates.append(f"{field}={value}")
        if pos:
            candidates.append(f"col{pos}={value}")      # a PAN-OS serial is named by its position on the relay
        if mp.get("key_mode") == "field" and mp.get("key_field", field) == field:
            candidates.append(str(value))
    for sel in candidates:
        r = rows.get(sel)
        c = (r or {}).get("syslog")
        if c and c.get("tenantid"):
            by = "address" if sel == src.get("bind_ip") else (f"column {pos} ({field})" if sel.startswith("col") else field)
            return {"known": True, "mapped": True, "selector": sel, "by": by,
                    "tenant": c["tenantid"], "tenant_label": r.get("tenant_label") or (mp.get("names") or {}).get(c["tenantid"], ""),
                    "port": int(c.get("port") or 0) or sender.parser_port_of(src), "port2": int(c["port2"]) if c.get("port2") else None,
                    "vendor": c.get("vendor"), "product": c.get("product"), "sensor": r.get("sensor") or "1"}
    return {"known": True, "mapped": False, "note": "no log source on the relay for this device: its logs land in the relay's catch-all tenant"}


# ----------------------------------------------------------------------------- app + routes
# The zone the simulated devices' clocks are on (Settings, "Sensor's time zone"). One setting for every run, so
# the generator holds it process-wide: applied when the app starts and on every save. A zone this host no longer
# knows (its zone database changed under it) falls back to the UTC rule and says so in the journal, rather than
# keeping the app from starting.
def apply_device_tz():
    name = db.get_setting("device_tz", "") or ""
    try:
        return sender.SS.set_device_tz(name)
    except ValueError as e:
        print(f"sensor's time zone: {e}; writing UTC for the formats that cannot state an offset", flush=True)
        sender.SS.set_device_tz("")
        return ""


def device_tz_now():
    """One sentence for the Settings page: what the simulated devices' clocks read right now."""
    from datetime import datetime, timezone
    who = ", ".join(sender.SS.ZONE_LESS)
    tz = sender.SS.DEVICE_TZ
    if tz is None:
        return (f"Not set: {who} logs are written in UTC (now {datetime.now(timezone.utc):%H:%M} UTC). "
                f"Right only for a sensor set to UTC.")
    now = datetime.now(tz)
    off = now.strftime("%z")
    return (f"The simulated devices' clocks read {now:%H:%M} {now.tzname()} (UTC{off[:3]}:{off[3:]}): "
            f"{who} logs are written in this time, and FortiGate and Check Point state the offset.")


def build_app():
    app = mw.App("ingest-studio",
                 [os.path.join(HERE, "static"), os.path.join(HERE, "..", "common", "static")],
                 secret=cfg("SECRET_KEY", "dev-secret-change-me").encode(),
                 admin_user=cfg("ADMIN_USER", "admin"),
                 admin_hash=cfg("ADMIN_HASH", mw.hash_password("admin")))
    # X-App-Build on every answer, so an open page notices an update under it and offers a reload (the strip
    # at the top, lab.js noticeBuild). The relay console has sent it since 25 Sep 2026; the Studio never did,
    # so its strip had never once appeared - found 5 Oct 2026 by a smoke check that stubbed the header.
    _v = app_version()
    app.build_id = f"{_v['version']} {_v['build']}".strip()
    apply_device_tz()

    # ---- Settings -> Security: the sign-in timeout and this Studio's HTTPS certificate (8 Oct 2026)
    app.session_ttl = lambda: session_idle_minutes() * 60       # read live, as the relay console's is

    @app.route("GET", "/api/session-policy")
    def session_policy_get(req):
        return {"idle_minutes": session_idle_minutes(), "default": SESSION_IDLE_DEFAULT, "min": 5, "max": 720}

    @app.route("PUT", "/api/session-policy")
    def session_policy_put(req):
        try:
            v = int((req.json() or {}).get("idle_minutes"))
        except (TypeError, ValueError):
            raise mw.HttpError(400, "the timeout is a whole number of minutes")
        if not 5 <= v <= 720:
            raise mw.HttpError(400, "the timeout is between 5 minutes and 12 hours (720 minutes)")
        db.set_setting("session_idle_minutes", str(v))
        db.audit(req.user, "session.timeout", f"sign-in ends after {v} minutes without activity")
        return session_policy_get(req)

    def _cert_state(req=None):
        helper = os.path.exists(CERT_HELPER)
        info = cert_helper("info") if helper else {"in_use": None}
        here = (req.headers.get("Host", "") if req else "").rsplit(":", 1)[0].strip("[]")
        cname = db.get_setting("console_name", "") or ""
        names = []
        for n in [cname, here, socket.gethostname(), socket.getfqdn()] + [h["ip"] for h in host_ips()]:
            n = (n or "").strip()
            if n and n not in names and n not in ("localhost", "127.0.0.1") and not n.endswith((".in-addr.arpa", ".ip6.arpa", ".localdomain")):
                names.append(n)
        cert = cfg("TLS_CERT", "/etc/stellar-lab/ingest-studio.crt")
        st = dict(info, helper=helper, tls=bool(HTTPD is not None and getattr(HTTPD, "ssl_context", None) is not None),
                  url_hosts=names, console_name=cname, port=int(cfg("LISTEN_PORT", "8443")),
                  managed=os.path.abspath(info.get("cert_path") or cert) == os.path.abspath(cert))
        spec = certplan.reissue_spec(st.get("in_use"), names)
        # the Studio has no certificate authority of its own: a reissue is self-signed, for the same names
        st["reissue"] = {"possible": bool(st.get("in_use")) and bool(spec["cn"]) and helper, "via": "self", "authority_state": "none",
                         "cn": spec["cn"], "names": ([spec["cn"]] if spec["cn"] else []) + spec["sans"]}
        return st

    def _cert_live(res, what):
        """After the helper wrote a pair: present it; if the server cannot load it, put the previous pair back."""
        rl = studio_tls_reload()
        if not rl.get("ok"):
            back = cert_helper("restore") if res.get("previous_kept", True) else {}
            raise mw.HttpError(500, f"this Studio could not load the {what}, so the previous certificate was put back",
                               detail=rl.get("error", "") + ("" if back.get("ok", True) else " (and the previous pair could not be restored: " + back.get("error", "") + ")"))
        return rl

    def _cert_refused(res, words):
        raise mw.HttpError(400, res.get("error") or words)

    @app.route("GET", "/api/console-cert")
    def console_cert_get(req):
        return _cert_state(req)

    @app.route("GET", "/api/console-cert/download")
    def console_cert_download(req):
        """which=cert|ca|csr, through the helper. Never a key."""
        which = req.query.get("which") or "cert"
        names = {"cert": ("ingest-studio.crt", "application/x-pem-file"), "ca": ("ingest-studio-ca.pem", "application/x-pem-file"),
                 "csr": ("ingest-studio.csr", "application/pkcs10")}
        if which not in names:
            raise mw.HttpError(400, "which is cert, ca or csr")
        body = cert_helper("pems").get(which) or ""
        if not body:
            raise mw.HttpError(404, {"cert": "there is no certificate in use", "ca": "no CA was installed with the certificate in use",
                                     "csr": "there is no pending signing request"}[which])
        name, ctype = names[which]
        return mw.Response(200, body, content_type=ctype, headers=[("Content-Disposition", f'attachment; filename="{name}"')])

    @app.route("POST", "/api/console-cert/csr")
    def console_cert_csr(req):
        d = req.json() or {}
        spec = {k: d.get(k) for k in ("cn", "org", "ou", "country", "state", "locality", "key")}
        spec["sans"] = [str(x).strip() for x in (d.get("sans") or []) if str(x).strip()][:40]
        res = cert_helper("csr", stdin=json.dumps(spec))
        if not res.get("ok"):
            _cert_refused(res, "the request was not made")
        db.audit(req.user, "cert.csr", f"signing request for this Studio's HTTPS certificate: {(res.get('facts') or {}).get('subject', '')}")
        return dict(res, info=_cert_state(req))

    @app.route("DELETE", "/api/console-cert/csr")
    def console_cert_csr_rm(req):
        res = cert_helper("csr-rm")
        db.audit(req.user, "cert.csr-rm", "discarded the pending signing request and its key")
        return dict(res, info=_cert_state(req))

    @app.route("POST", "/api/console-cert")
    def console_cert_put(req):
        d = req.json() or {}
        pem, ca = str(d.get("pem") or ""), str(d.get("ca") or "")
        if not pem.strip():
            raise mw.HttpError(400, "choose the certificate file, or paste the certificate (PEM)")
        res = cert_helper("put", stdin=json.dumps({"pem": pem, "ca": ca}))
        if not res.get("ok"):
            _cert_refused(res, "the certificate was refused")
        rl = _cert_live(res, "certificate")
        f = res.get("facts") or {}
        db.audit(req.user, "cert.install", f"installed this Studio's HTTPS certificate: {f.get('subject', '')}, issued by {f.get('issuer', '')}")
        return dict(res, reloaded=rl.get("reloaded", False), info=_cert_state(req))

    @app.route("POST", "/api/console-cert/reissue")
    def console_cert_reissue(req):
        st = _cert_state(req)
        if not st["reissue"]["possible"]:
            raise mw.HttpError(409, "there is no certificate in use to reissue: install one or create one first")
        spec = certplan.reissue_spec(st.get("in_use"), st.get("url_hosts") or [])
        res = cert_helper("reissue", stdin=json.dumps(spec))
        if not res.get("ok"):
            _cert_refused(res, "the certificate could not be reissued")
        rl = _cert_live(res, "reissued certificate")
        res["reissued_via"], res["names"] = "self", st["reissue"]["names"]
        db.audit(req.user, "cert.reissue", f"reissued this Studio's HTTPS certificate, self-signed, for {', '.join(res['names'])} (the previous one is kept)")
        return dict(res, reloaded=rl.get("reloaded", False), info=_cert_state(req))

    @app.route("POST", "/api/console-cert/reset")
    def console_cert_reset(req):
        res = cert_helper("reset")
        if not res.get("ok"):
            _cert_refused(res, "not reset")
        rl = _cert_live(res, "self-signed certificate")
        db.audit(req.user, "cert.reset", "this Studio is back on a self-signed HTTPS certificate (the previous one is kept)")
        return dict(res, reloaded=rl.get("reloaded", False), info=_cert_state(req))

    @app.route("POST", "/api/console-cert/restore")
    def console_cert_restore(req):
        res = cert_helper("restore")
        if not res.get("ok"):
            _cert_refused(res, "not restored")
        rl = _cert_live(res, "previous certificate")
        db.audit(req.user, "cert.restore", f"put this Studio's previous HTTPS certificate back: {(res.get('facts') or {}).get('subject', '')}")
        return dict(res, reloaded=rl.get("reloaded", False), info=_cert_state(req))

    # ---- auth
    @app.route("POST", "/api/login", auth=None)
    def login(req):
        d = req.json()
        if not app.check_login(d.get("user", ""), d.get("password", ""), req.client_ip):
            raise mw.HttpError(401, "invalid username or password")
        db.audit(d["user"], "login", req.client_ip)
        return mw.Response.json({"ok": True, "user": d["user"]}, headers=[app.session_cookie(d["user"])])

    @app.route("POST", "/api/logout", role="any")
    def logout(req):
        return mw.Response.json({"ok": True}, headers=[app.clear_cookie()])

    @app.route("GET", "/api/me")
    def me(req):
        # the version rides here, as the relay console's does on /api/status: the sidebar says which
        # release is running, so "did my update land?" is answered without opening Settings
        return {"user": req.user, "app": "ingest-studio", "host": os.uname().nodename,
                "console_name": db.get_setting("console_name", ""),
                "version": app_version(), "edition": edition(), "advanced": advanced()}

    def manager_only():
        """404 for anything whose only purpose is to reach into the relay. 404 rather than 403: in this
        edition the feature does not exist, and a refusal that describes a feature is an advertisement
        for it - the same rule the Log Relay Manager's own advanced-only routes follow."""
        if not advanced():
            raise mw.HttpError(404, "not found")

    # ---- settings
    # The standard edition has no management connection, so the two settings that make one - the manager's
    # URL and its API token - are neither shown nor accepted. Whatever a database carries from an earlier
    # advanced install stays on disk untouched and unused; switching back to advanced brings it back.
    MANAGER_KEYS = ("relay_monitor_url", "relay_token")
    # nginx is not a standard path, so its port is not a standard setting either. The sensors are, in both
    # editions: they are where a direct log source sends (Settings -> Sensors).
    ADVANCED_KEYS = MANAGER_KEYS + ("nginx_port",)
    # the settings the sensor list replaced: never shown, still accepted from an older caller (PUT /api/settings)
    LEGACY_SENSOR_KEYS = ("sensor_ip", "sensor_ip_2", "sensor_tls")

    # ---- updating THIS app from a bundle Stellar Cyber signed. The same rules as the relay console's:
    # only a bundle bearing a valid signature from the release key installed on this host is unpacked,
    # verified again immediately before installing, and nothing here takes a path from the caller.
    def _update(*args, timeout=60):
        rc, out, err = mw.run_cmd(SUDO + [UPDATE_HELPER, *args], timeout=timeout)
        try:
            return json.loads(out.strip().splitlines()[-1]) if out.strip() else {}
        except ValueError:
            return {"ok": False, "error": (err or out or f"update helper exit {rc}").strip()[-400:]}

    @app.route("GET", "/api/update")
    def update_state(req):
        st = _update("status", timeout=20)
        st["running_version"] = app_version()
        return st

    @app.route("POST", "/api/update/upload")
    def update_upload(req):
        name = (req.query.get("name") or "bundle.tar.gz").strip()
        if "/" in name or "\\" in name or len(name) > 120:
            raise mw.HttpError(400, "that file name is not one this accepts")
        n, digest = req.save_body(UPDATE_INCOMING, UPDATE_MAX_BYTES)
        res = _update("stage", "--name", name, timeout=120)
        if res.get("error"):
            raise mw.HttpError(400, res["error"])
        res["uploaded"] = n
        res["sha256_uploaded"] = digest
        return res

    @app.route("POST", "/api/update/check")
    def update_check(req):
        return _update("check", timeout=300)

    @app.route("POST", "/api/update/apply")
    def update_apply(req):
        st = _update("staged", timeout=20)
        if not st or not st.get("sha256"):
            raise mw.HttpError(400, "no update is staged here; upload one first")
        if not st.get("signature_ok"):
            raise mw.HttpError(403, "that bundle is not signed by Stellar Cyber, so it is not installed: "
                                    + (st.get("signature") or ""))
        res = _update("apply", "--by", req.user or "", timeout=60)
        if not res.get("started"):
            raise mw.HttpError(500, res.get("error") or "the update did not start")
        return res

    @app.route("POST", "/api/update/rollback")
    def update_rollback(req):
        res = _update("rollback", "--by", req.user or "", timeout=60)
        if not res.get("started"):
            raise mw.HttpError(500, res.get("error") or "the rollback did not start")
        return res

    @app.route("POST", "/api/update/clear")
    def update_clear(req):
        """Stop waiting on a run that is no longer there. It does not stop an install: the helper
        refuses while the run is alive and names its pid, because a dpkg interrupted half-way is a
        worse place to be than a page that waits."""
        res = _update("clear", timeout=20)
        if not res.get("cleared"):
            raise mw.HttpError(409, res.get("error") or "that update is still running")
        return res

    @app.route("DELETE", "/api/update")
    def update_discard(req):
        return _update("discard", timeout=20)

    @app.route("GET", "/api/relay-cert")
    def relay_cert(req):
        """The certificate the relay is presenting on TLS 6514 right now, so a log source can PIN it without
        anyone copying a 64-character fingerprint by hand. Read-only: it connects, reads the certificate and
        hangs up, and it verifies nothing - the whole point of a pin is that it needs no CA."""
        host = (db.get_setting("relay_ip") or "").strip()
        if not host:
            raise mw.HttpError(400, "set the log relay's IP or host name in Settings first: there is nothing to read a certificate from")
        try:
            der, pem = sender.peek_cert(host, 6514)
        except (OSError, ssl.SSLError) as e:
            raise mw.HttpError(502, f"no certificate could be read from {host}:6514", detail=str(e))
        f = sender.x509_facts(pem) or {}
        return {"host": host, "port": 6514, "sha256": sender.cert_fingerprint(der),
                "subject": f.get("subject", ""), "cn": f.get("cn", ""), "not_after": f.get("not_after", ""),
                "days_left": f.get("days_left")}

    @app.route("GET", "/api/settings")
    def get_settings(req):
        s = db.settings()
        s["relay_token"] = "•" * 8 if s.get("relay_token") else ""
        s["edition"] = edition()
        s["advanced"] = advanced()
        if not advanced():
            for k in ADVANCED_KEYS:
                s.pop(k, None)
            s["manager_note"] = NO_MANAGER_NOTE
        srcs = db.sources()
        s["sensors"] = [sensor_view(x, srcs) for x in sender.sensors_from_settings(s)]
        for k in LEGACY_SENSOR_KEYS:
            s.pop(k, None)
        s["host_ips"] = host_ips()
        s["default_iface"] = default_iface()
        s["relay_ca_facts"] = sender.x509_facts(s["relay_ca"]) if s.get("relay_ca") else None
        s["device_tz"] = sender.SS.DEVICE_TZ_NAME
        s["device_tz_now"] = device_tz_now()
        s["time_zones"] = sender.SS.zone_names()
        return s

    @app.route("PUT", "/api/settings")
    def put_settings(req):
        d = req.json()
        if not advanced():
            named = [k for k in ADVANCED_KEYS if k in d and str(d[k]).strip()]
            if named:
                raise mw.HttpError(400, NO_MANAGER_NOTE + f" ({', '.join(named)} cannot be set here)")
        # The relay's address may be private or public, an IP or a host name (Paul, 24 Sep 2026): it is where
        # this host SENDS, so anything a socket can connect to is right. Only a shape that could never be an
        # address is refused - it goes into a connect, and nowhere else.
        v = str(d.get("relay_ip") or "").strip()
        if "relay_ip" in d and v and not (IPV4.match(v) or HOSTNAME.match(v)):
            raise mw.HttpError(400, f"relay ip must be an IP address or a host name, not '{v[:40]}'")
        # The two sensor settings from before Settings -> Sensors, from an older caller: they are sensors 1 and 2
        # of the list, checked by the same rule the Sensors tab uses, and nothing is written if either is wrong.
        legacy = {k: str(d[k]).strip() for k in LEGACY_SENSOR_KEYS if k in d}
        new_sensors = None
        if legacy:
            new_sensors = sensors_list()
            for k, n in (("sensor_ip", 1), ("sensor_ip_2", 2)):
                if k not in legacy:
                    continue
                why = sensor_address_problem(legacy[k])
                if why:
                    raise mw.HttpError(400, f"sensor {n}: {why}")
                cur = next((x for x in new_sensors if x["n"] == n), None)
                if cur:
                    cur["address"] = legacy[k]
                elif legacy[k]:
                    new_sensors.append(sender._sensor_entry(n, legacy[k], new_sensors[0]["transport"]))
            two = next((x for x in new_sensors if x["n"] == 2), None)
            if two and not two["address"] and not pinned_sources(2):
                new_sensors = [x for x in new_sensors if x["n"] != 2]       # cleared and nothing points at it: gone
            if "sensor_tls" in legacy:
                for x in new_sensors:
                    if x["n"] in (1, 2) and x["transport"] != "udp":
                        x["transport"] = "tcp" if legacy["sensor_tls"] == "0" else "tls"
            new_sensors.sort(key=lambda x: x["n"])
        # the name people reach THIS Studio by (Paul, 2 Oct 2026, "also the sender"). A label for the console's
        # identity, shown in the sidebar; it does not change the host's Linux name. A host name only, never an IP shape.
        cn = str(d.get("console_name") or "").strip()
        if "console_name" in d and cn and not HOSTNAME.match(cn):
            raise mw.HttpError(400, f"this Studio's name must be a host name, not '{cn[:40]}'")
        # the sensor's time zone: checked before anything is written, so a wrong name changes nothing
        tzname = str(d.get("device_tz") or "").strip()
        if "device_tz" in d:
            try:
                sender.SS.device_tz(tzname)
            except ValueError as e:
                raise mw.HttpError(400, f"Sensor's time zone: {e}")
        for k in ("relay_ip", "relay_monitor_url", "iface", "nginx_port", "console_name"):
            if k in d and (advanced() or k not in ADVANCED_KEYS):
                db.set_setting(k, str(d[k]).strip())
        if new_sensors is not None:
            save_sensors(new_sensors)
        # the CA that signed the relay's TLS certificate: verify the relay with it on every TLS send. Empty = accept any.
        if "relay_ca" in d:
            ca = str(d.get("relay_ca") or "").strip()
            if ca:
                certs, keys = sender.split_pem(ca)
                if keys:
                    raise mw.HttpError(400, "that PEM holds a private key: a CA is a certificate only, and a key must never be pasted here")
                if not certs or not sender.x509_facts(certs[0]).get("ok"):
                    raise mw.HttpError(400, "the relay CA must be a certificate in PEM form (-----BEGIN CERTIFICATE-----)")
                ca = "".join(certs)
            db.set_setting("relay_ca", ca)
        if "device_tz" in d:
            db.set_setting("device_tz", tzname)
            apply_device_tz()
        if advanced() and d.get("relay_token") and not set(d["relay_token"]) <= {"•"}:
            db.set_setting("relay_token", d["relay_token"].strip())
        db.audit(req.user, "settings", ", ".join(k for k in d if k != "relay_token"))
        _relay_cache["at"] = 0.0          # a new manager URL or token: read the relay afresh
        return get_settings(req)

    @app.route("POST", "/api/settings/test-relay")
    def test_relay(req):
        manager_only()
        try:
            st = relay.status()
            return {"ok": True, "host": st.get("host"), "services": st.get("services"), "settings": st.get("settings")}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e)}

    @app.route("GET", "/api/probe")
    def do_probe(req):
        """The relay's listener ports, from this host. The sensors are tested on their own cards (Settings ->
        Sensors), on the parser ports their direct log sources really use."""
        s = db.settings()
        targets = []   # (host, port, label, expect_tls)
        if s.get("relay_ip"):
            targets += [(s["relay_ip"], 514, "relay syslog tcp", False), (s["relay_ip"], 601, "relay syslog RFC 6587", False),
                        (s["relay_ip"], 6514, "relay syslog TLS", True)]
            if advanced():
                targets += [(s["relay_ip"], int(s.get("nginx_port") or 80), "relay nginx", False),
                            (s["relay_ip"], 443, "relay nginx TLS", True)]
        out = []
        for host, port, label, want_tls in targets:
            r = probe(host, port, 4, try_tls=want_tls); r["label"] = label; out.append(r)
        return {"results": out}

    # ---- the sensors a direct log source sends to (Settings -> Sensors)
    def _sensors_answer():
        srcs = db.sources()
        bi = sender.builtin_sensor_ca()
        facts = None
        if bi:
            with open(bi) as f:
                facts = sender.x509_facts(f.read())
        return {"sensors": [sensor_view(x, srcs) for x in sensors_list()], "max": sender.MAX_SENSORS,
                "transports": list(sender.SENSOR_TRANSPORTS), "trusts": dict(sender.SENSOR_TRUST_LABEL),
                "builtin_ca": facts}

    @app.route("GET", "/api/sensors")
    def get_sensors(req):
        return _sensors_answer()

    def _ca_from_body(n, text):
        certs, keys = sender.split_pem(text)
        if keys:
            raise mw.HttpError(400, f"sensor {n}: that file holds a private key. A CA is a certificate only, and a key must never be uploaded here")
        if not certs or not sender.x509_facts(certs[0]).get("ok"):
            raise mw.HttpError(400, f"sensor {n}: the CA must be a certificate in PEM form (-----BEGIN CERTIFICATE-----)")
        return "".join(certs)

    def _sensor_from_body(x, old):
        """One sensor as the page sent it, checked and completed from what is stored (a CA not re-sent is kept)."""
        try:
            n = int(x.get("n"))
        except (TypeError, ValueError):
            raise mw.HttpError(400, "each sensor needs its number")
        if not 1 <= n <= sender.MAX_SENSORS:
            raise mw.HttpError(400, f"sensors are numbered 1 to {sender.MAX_SENSORS}, not {n}")
        addr = str(x.get("address") or "").strip()
        why = sensor_address_problem(addr)
        if why:
            raise mw.HttpError(400, f"sensor {n}: {why}")
        if not addr and n != 1:
            raise mw.HttpError(400, f"sensor {n} has no address: give it one, or remove it")
        tr = str(x.get("transport") or "tls")
        if tr not in sender.SENSOR_TRANSPORTS:
            raise mw.HttpError(400, f"sensor {n}: the transport is TLS, TCP or UDP")
        trust = str(x.get("trust") or "any")
        if trust not in sender.SENSOR_TRUSTS:
            raise mw.HttpError(400, f"sensor {n}: how its certificate is trusted must be one of " + ", ".join(sender.SENSOR_TRUST_LABEL.values()))
        prev = old.get(n) or {}
        ca = prev.get("ca", "") if "ca" not in x else (str(x.get("ca") or "").strip())
        if ca and "ca" in x:
            ca = _ca_from_body(n, ca)
        pin = sender.normalise_pin(x.get("pin"))
        if trust == "stellar" and not sender.builtin_sensor_ca():
            raise mw.HttpError(400, f"sensor {n}: Stellar Cyber's CA is not on this host (it ships beside the app). Re-run the "
                                    f"Studio's installer, or choose another way to trust the sensor")
        if trust == "ca" and not ca:
            raise mw.HttpError(400, f"sensor {n}: checking its certificate against a CA needs the CA. Upload it on the card")
        if trust == "pin" and len(pin) != 64:
            raise mw.HttpError(400, f"sensor {n}: a pinned certificate is named by its SHA-256, 64 hex characters. Use "
                                    f"“Read it from the sensor” to take the one it presents now")
        return sender._sensor_entry(n, addr, tr, trust, ca, pin if trust == "pin" else "")

    @app.route("PUT", "/api/sensors")
    def put_sensors(req):
        """The whole list, as the Sensors tab holds it. A number missing from it is a sensor removed, which is
        refused while a log source still sends to it - by name, so nobody has to hunt for them. Numbers are kept as
        they are: nothing is renumbered, because a log source names its sensor by number."""
        d = req.json()
        given = d.get("sensors")
        if not isinstance(given, list) or not given:
            raise mw.HttpError(400, "send the list of sensors, sensor 1 included")
        old = {x["n"]: x for x in sensors_list()}
        new = [_sensor_from_body(x or {}, old) for x in given]
        nums = [x["n"] for x in new]
        if len(set(nums)) != len(nums):
            raise mw.HttpError(400, "two sensors share one number")
        if 1 not in nums:
            raise mw.HttpError(400, "sensor 1 stays: it is where a direct log source that names no sensor sends")
        seen = {}
        for x in new:
            if x["address"] and x["address"].lower() in seen:
                raise mw.HttpError(400, f"sensor {x['n']} has the same address as sensor {seen[x['address'].lower()]}")
            if x["address"]:
                seen[x["address"].lower()] = x["n"]
        srcs = db.sources()
        for n in sorted(set(old) - set(nums)):
            pinned = pinned_sources(n, srcs)
            if pinned:
                names = ", ".join(s["name"] for s in pinned[:6]) + (f" and {len(pinned) - 6} more" if len(pinned) > 6 else "")
                raise mw.HttpError(409, f"sensor {n} is not removed: {len(pinned)} log source{'s' if len(pinned) != 1 else ''} "
                                        f"send{'' if len(pinned) != 1 else 's'} to it ({names}). Point them at another sensor first, "
                                        f"or remove them")
        new.sort(key=lambda x: x["n"])
        save_sensors(new)
        gone = sorted(set(old) - set(nums))
        db.audit(req.user, "sensors.save", "; ".join(f"sensor {x['n']} {x['address'] or '(no address)'} {x['transport']} trust {x['trust']}" for x in new)
                 + (f"; removed sensor {', '.join(map(str, gone))}" if gone else ""))
        return _sensors_answer()

    @app.route("POST", "/api/sensors/check")
    def check_sensor(req):
        """Test one sensor from this host, as its card shows it - the address, transport and trust IN THE BOX, saved
        or not, so a person can test before saving. On the parser ports its direct log sources use, or one typed in.
        Nothing is written and nothing is sent: a connection, a TLS handshake, the certificate read and judged."""
        d = req.json()
        try:
            n = int(d.get("n") or 1)
        except (TypeError, ValueError):
            raise mw.HttpError(400, "which sensor is this")
        old = {x["n"]: x for x in sensors_list()}
        cur = dict(old.get(n) or sender._sensor_entry(n))
        addr = str(d.get("address", cur["address"]) or "").strip()
        if not addr:
            raise mw.HttpError(400, f"sensor {n} has no address to test: type it in first")
        why = sensor_address_problem(addr)
        if why:
            raise mw.HttpError(400, f"sensor {n}: {why}")
        tr = str(d.get("transport") or cur["transport"])
        trust = str(d.get("trust") or cur["trust"])
        if tr not in sender.SENSOR_TRANSPORTS or trust not in sender.SENSOR_TRUSTS:
            raise mw.HttpError(400, "the transport is TLS, TCP or UDP, and the trust one of the four on the card")
        ca = cur.get("ca", "")
        if str(d.get("ca") or "").strip():
            ca = _ca_from_body(n, str(d["ca"]))
        pin = sender.normalise_pin(d.get("pin") if "pin" in d else cur.get("pin"))
        sensor = sender._sensor_entry(n, addr, tr, trust, ca, pin)
        typed = str(d.get("port") or "").strip()
        pinned = pinned_sources(n)
        if typed:
            if not typed.isdigit() or not 1 <= int(typed) <= 65535:
                raise mw.HttpError(400, "a port is a number from 1 to 65535")
            ports = [int(typed)]
            why_ports = "the port typed in"
        elif pinned:
            ports = sorted({sender.SS.direct_port(s["vendor"], s.get("format") or "syslog") + sender._PORT_BASE for s in pinned})
            why_ports = "the parser ports its direct log sources use"
        else:
            raise mw.HttpError(400, f"no direct log source sends to sensor {n} yet, so there is no parser port to test: type one "
                                    f"(FortiGate's is 5517, Palo Alto's 5515)")
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=min(8, len(ports))) as pool:
            results = list(pool.map(lambda p: sender.sensor_check(addr, p, tr, sensor, timeout=float(cfg("SENSOR_CHECK_TIMEOUT", "4"))), ports))
        ok = [r for r in results if r.get("operational")]
        if tr == "udp":
            summary = "UDP cannot be checked from here: nothing answers a datagram"
        elif len(ok) == len(results):
            summary = f"answers on {', '.join(str(r['port']) for r in results)}" + (" with TLS" if tr == "tls" else "")
        else:
            bad = [r for r in results if not r.get("operational")]
            summary = f"does not answer properly on {', '.join(str(r['port']) for r in bad)}"
        return {"n": n, "address": addr, "resolved": resolve_ipv4(addr), "transport": tr, "trust": trust,
                "ports_from": why_ports, "results": results, "summary": summary,
                "operational": None if tr == "udp" else len(ok) == len(results), "saved": n in old and old[n]["address"] == addr}

    # ---- sources
    def _decorate(r, present, sensors=None):
        """What the page shows for one source beyond its stored columns: the parser port (a property of the device
        type, used only when it goes straight to the sensor), its identity, its POST path, and what the relay's map
        says about it - read from the relay, never written. A direct source also says which sensor it sends to, at
        what address, and whether its log goes as-is or wrapped with a tenant (with what is not documented about
        sending that port a tenant)."""
        r["ip_present"] = r["bind_ip"] in present or not r["bind_ip"]
        tenant = r.pop("direct_tenant", "") or ""
        delivery = r.pop("delivery", "") or ""
        if r["path"] == "raw":
            n = str(r.get("sensor") or "1")
            sen = next((x for x in (sensors if sensors is not None else sensors_list()) if str(x["n"]) == n), None)
            r["sensor"] = n
            r["sensor_address"] = (sen or {}).get("address", "")
            r["sensor_missing"] = sen is None
            r["delivery"] = "tenant" if delivery == "tenant" and tenant else "asis"
            if r["delivery"] == "tenant":
                r["tenant_id"] = tenant
                r["wrapper_notes"] = sender.wrapper_notes(r["vendor"], r.get("format") or "syslog")
        v, pr, fmt, port = sender.SS.origin_for(r["vendor"], r.get("format") or "syslog")
        r["origin"] = {"vendor": v, "product": pr, "format": fmt}
        # The device type's own parser port on the sensor. On the direct path this is where the logs go. Through
        # a relay it is NOT used by this host: the relay's own row names the port (usually this one).
        r["parser_port"] = port
        r["parser_port_used"] = r["path"] == "raw"
        r["relay"] = relay_lookup(r)
        rel = r["relay"]
        r["sensor_port"] = 5200 if r["path"] == "nginx" else (rel.get("port") if rel.get("mapped") else port)
        # what the device will say about itself in every log, shown before anything is sent
        if r["path"] == "nginx":
            f, val = sender.SS.webhook_identity(r.get("webhook_source") or "generic", r.get("device_id") or None)
        else:
            f, val = sender.identity_of(r)
        r["identity"] = {"field": f, "value": val, "explicit": bool(r.get("device_id"))}
        r["post_path"] = (f"/ingest/{r['ingest_path']}/httpjson" if r.get("ingest_path") else "/httpjson") \
            if r["path"] == "nginx" else None
        # the client certificate it presents on TLS 6514, as facts: the subject, the CA, when it expires. Never the key.
        tls = db.source_tls(r["id"]) if r.get("id") else {}
        r["client_cert"] = sender.x509_facts(tls["client_cert"]) if tls.get("client_cert") else None
        return r

    @app.route("GET", "/api/sources")
    def sources(req):
        present = {h["ip"] for h in host_ips()}
        sens = sensors_list()
        all_src = db.sources()
        rows = [_decorate(r, present, sens) for r in all_src]
        _, _, relay_error = _relay_read()
        return {"sources": rows, "paths": paths_here(), "vendors": sender.VENDORS, "formats": sender.FORMATS,
                # the direct path: the sensors to send to, the two ways to send, and - per vendor and format - what
                # is not documented about sending that parser port a tenant, so the dialog can say it as it is filled
                "sensors": [sensor_view(x, all_src) for x in sens], "deliveries": dict(sender.DELIVERIES),
                "wrapper_notes": {v: {f: sender.wrapper_notes(v, f) for f in fmts} for v, fmts in sender.FORMATS.items()},
                "edition": edition(), "advanced": advanced(), "managed": advanced(), "manager_note": "" if advanced() else NO_MANAGER_NOTE,
                "on_relay_note": ON_RELAY_NOTE, "relay_error": relay_error if advanced() else "",
                "parser_port": dict(sender.SS.PARSER_PORT), "cef_port": sender.SS.CEF_PORT, "raw_vendors": list(sender.SS.DIRECT_VENDORS),
                "dev_type": dict(sender.SS.DEV_TYPE),
                "webhook_sources": {k: v["label"] for k, v in sender.SS.WEBHOOK_SOURCES.items()},
                "device_fields": {v: [{"field": f, "label": l, "default": d} for f, l, d in fl] for v, fl in sender.SS.DEVICE_FIELDS.items()}}

    def _validate_source(d):
        out = {}
        out["name"] = d.get("name", "").strip()
        if not out["name"]:
            raise mw.HttpError(400, "name is required")
        out["vendor"] = d.get("vendor")
        if out["vendor"] not in sender.VENDORS:
            raise mw.HttpError(400, "vendor must be one of " + ", ".join(sender.VENDORS))
        out["path"] = d.get("path")
        if out["path"] not in paths_here():
            if out["path"] in sender.PATHS:
                raise mw.HttpError(400, "this Ingest Studio sends to the syslog-ng relay only; "
                                        f"'{out['path']}' is not one of its paths")
            raise mw.HttpError(400, "path must be one of " + ", ".join(paths_here()))
        out["transport"] = d.get("transport")
        if out["transport"] not in sender.PATHS[out["path"]]["transports"]:
            raise mw.HttpError(400, f"transport must be one of {sender.PATHS[out['path']]['transports']}")
        out["format"] = d.get("format") or "syslog"
        if out["format"] not in sender.FORMATS[out["vendor"]]:
            raise mw.HttpError(400, f"{sender.VENDORS[out['vendor']]} supports only {', '.join(sender.FORMATS[out['vendor']])}")
        if out["path"] == "raw":
            # as-is: the device's own syslog to its parser port, which only a vendor with one can do
            try:
                sender.SS.direct_port(out["vendor"], out["format"])
            except ValueError as e:
                raise mw.HttpError(400, str(e))
        # No tenant on a relay path (Paul, 24 Sep 2026): a device configuration carries none, and the tenant it lands
        # in is the relay's own log-source row. On the DIRECT path a log source may send one (8 Oct 2026): the log
        # inside the Stellar JSON wrapper, to the parser's own port - the record the relay would have written.
        tid = str(d.get("tenant_id") or "").strip().lower()
        delivery = str(d.get("delivery") or "").strip() or "asis"
        if out["path"] != "raw":
            if d.get("tenant_id") not in (None, "", 0):
                raise mw.HttpError(400, "a log source has no tenant here: the tenant is decided on the relay, by its own log-source row")
            if delivery != "asis":
                raise mw.HttpError(400, "a log source sends a tenant only straight to a sensor: through a relay, the relay's own "
                                        "log-source row decides the tenant")
            out["delivery"], out["direct_tenant"] = "", ""
        else:
            if delivery not in sender.DELIVERIES:
                raise mw.HttpError(400, "a direct log source sends as-is, or with a tenant")
            if delivery == "tenant":
                if not HEX32.match(tid):
                    raise mw.HttpError(400, "a tenant ID is 32 hexadecimal characters (0-9, a-f), as Stellar Cyber shows it under the "
                                            f"tenant's details; '{tid[:40]}' is not one, and the sensor would silently ignore it and "
                                            "use its own tenant")
                out["delivery"], out["direct_tenant"] = "tenant", tid
            else:
                if d.get("tenant_id") not in (None, "", 0):
                    raise mw.HttpError(400, "an as-is log carries no tenant: choose “With a tenant” to send one")
                out["delivery"], out["direct_tenant"] = "", ""
        out["bind_ip"] = d.get("bind_ip", "").strip()
        if out["bind_ip"] and not IPV4.match(out["bind_ip"]):
            raise mw.HttpError(400, "source IP must be an IPv4 address on this host")
        if out["path"] in ("syslogng", "nginx") and not out["bind_ip"]:
            raise mw.HttpError(400, "relay paths need a source IP: the relay recognizes a device by the address it sees, unless its row names a field in the log")
        out["device_id"] = str(d.get("device_id") or "").strip()
        if out["device_id"] and not re.match(r"^[A-Za-z0-9._:-]{1,128}$", out["device_id"]):
            raise mw.HttpError(400, "device ID may contain letters, digits, dot, underscore, colon and hyphen only")
        # which of the vendor's fields the device identifies itself by (empty = the recommended one)
        try:
            field, _ = sender.SS.identity_for(out["vendor"], str(d.get("id_field") or "").strip() or None, out["device_id"] or None)
        except ValueError as e:
            raise mw.HttpError(400, str(e))
        out["id_field"] = field or ""
        # The nginx path: which product's webhook shape this source posts, and the URL path it posts to
        # (the relay's path map says which tenant that label means). Both are meaningless on the syslog
        # paths, so they are cleared there.
        out["webhook_source"] = str(d.get("webhook_source") or "").strip()
        if out["webhook_source"] and out["webhook_source"] not in sender.SS.WEBHOOK_SOURCES:
            raise mw.HttpError(400, "webhook source must be one of " + ", ".join(sender.SS.WEBHOOK_SOURCES))
        out["ingest_path"] = str(d.get("ingest_path") or "").strip().strip("/")
        if out["ingest_path"] and not re.match(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,62}$", out["ingest_path"]):
            raise mw.HttpError(400, "the tenant URL label may contain letters, digits, dot, underscore and hyphen only")
        if out["path"] != "nginx":
            out["webhook_source"] = ""
            out["ingest_path"] = ""
        elif not out["webhook_source"]:
            out["webhook_source"] = "generic"
        out["sensor"] = str(d.get("sensor") or "").strip()
        if out["path"] != "raw":
            out["sensor"] = ""      # only the direct path picks a sensor here; through a relay the relay's row does
        else:
            # a sensor this Studio has (Settings -> Sensors), by its number; empty is sensor 1
            have = [str(x["n"]) for x in sensors_list()]
            if (out["sensor"] or "1") not in have:
                raise mw.HttpError(400, f"there is no sensor {out['sensor']} on Settings → Sensors; this Studio has "
                                        f"sensor{'s' if len(have) > 1 else ''} {', '.join(have)}. Add it there first")
        out["enabled"] = 1 if d.get("enabled", True) else 0
        # How this source trusts the RELAY's certificate (Paul, 2 Oct 2026: "let me specify if I want to enable
        # the ability to valid the cert or pin the cert"). Only meaningful on TLS to the syslog-ng relay.
        tls_on = out["path"] == "syslogng" and out["transport"] == "tls6514"
        if "tls_verify" in d:
            mode = str(d.get("tls_verify") or "").strip() or "any"
            if mode not in sender.TLS_VERIFY_MODES:
                raise mw.HttpError(400, "how to trust the relay's certificate must be accept any, validate against a CA, or pin it")
            if mode != "any" and not tls_on:
                raise mw.HttpError(400, "checking the relay's certificate applies only to TLS 6514 to the syslog-ng relay; this log source sends another way")
            t_verify = "" if mode == "any" else mode
            t_ca, t_pin = "", ""
            if mode == "ca":
                ca = str(d.get("tls_ca") or "").strip()
                if ca:
                    certs, keys = sender.split_pem(ca)
                    if keys:
                        raise mw.HttpError(400, "that file holds a private key: a CA is a certificate only, and a key must never be pasted here")
                    if not certs or not sender.x509_facts(certs[0]).get("ok"):
                        raise mw.HttpError(400, "the CA must be a certificate in PEM form (-----BEGIN CERTIFICATE-----)")
                    t_ca = "".join(certs)
                if not (t_ca or db.get_setting("relay_ca", "")):
                    raise mw.HttpError(400, "validating the relay's certificate needs a CA: give one here, or set the relay CA in Settings")
            if mode == "pin":
                pin = sender.normalise_pin(d.get("tls_pin"))
                if len(pin) != 64:
                    raise mw.HttpError(400, "a pinned certificate is named by its SHA-256: 64 hex characters. "
                                            "Use \u201cFetch it from the relay\u201d to read the one it is presenting now.")
                t_pin = pin
            out["_trust"] = (t_verify, t_ca, t_pin)
        # A client certificate for TLS to the relay (Paul, 2 Oct 2026). Given either as ONE file holding the
        # certificate and its key, or as separate certificate and key files - the same thing once joined.
        # client_pem absent = keep what is stored; "" = remove it.
        if "client_cert_pem" in d or "client_key_pem" in d:
            cert_part, key_part = str(d.get("client_cert_pem") or ""), str(d.get("client_key_pem") or "")
            if not cert_part.strip() and not key_part.strip():
                d["client_pem"] = ""
            elif not cert_part.strip() or not key_part.strip():
                raise mw.HttpError(400, "separate files need both: the certificate file and the private key file")
            else:
                d["client_pem"] = cert_part.rstrip() + "\n" + key_part.lstrip()
        if "client_pem" in d:
            text = str(d.get("client_pem") or "")
            if not text.strip():
                out["_client"] = ("", "")
            else:
                if not (out["path"] == "syslogng" and out["transport"] == "tls6514"):
                    raise mw.HttpError(400, "a client certificate is used only on TLS 6514 to the syslog-ng relay; this log source sends another way")
                certs, keys = sender.split_pem(text)
                if not certs or len(keys) != 1:
                    raise mw.HttpError(400, "the PEM must hold the certificate (with its chain, if any) and exactly one private key"
                                            + (f"; found {len(certs)} certificate(s) and {len(keys)} key(s)"))
                why = sender.check_client_pair("".join(certs), keys[0])
                if why:
                    raise mw.HttpError(400, why)
                facts = sender.x509_facts(certs[0])
                if facts.get("days_left") is not None and facts["days_left"] < 0:
                    raise mw.HttpError(400, f"that certificate expired ({facts.get('not_after')})")
                out["_client"] = ("".join(certs), keys[0])
        return out

    def _save_source(req, sid=None):
        d = _validate_source(req.json())
        # a relay path the relay does not have would send into nothing: say so now, with the command that adds it
        m = relay_methods() or {}
        want = {"syslogng": "syslog", "nginx": "nginx"}.get(d["path"])
        if want and m.get(want) and not m[want]["installed"]:
            raise mw.HttpError(400, f"the relay has no {sender.PATHS[d['path']]['label']}: " + m[want].get("note", "it is not installed"))
        client = d.pop("_client", None)
        trust = d.pop("_trust", None)
        new_id = db.upsert_source(d, sid)
        if trust is not None:
            db.set_source_trust(new_id, *trust)
        how = ""
        if client is not None:
            cert, key = client
            if key:
                # the key never enters the database: the root helper keeps it root-only, host-bound where it can
                rc, out, err = _secret("set", db.key_name(new_id), stdin=key)
                try:
                    res = json.loads(out.strip().splitlines()[-1]) if out.strip() else {}
                except ValueError:
                    res = {}
                if rc != 0 or not res.get("ok"):
                    if not sid:
                        db.delete_source(new_id)
                    raise mw.HttpError(500, "the private key could not be stored on this host: " + (res.get("error") or err or out or "the credential helper failed").strip()[-200:])
                how = res.get("method", "")
            else:
                _secret("delete", db.key_name(new_id))
            db.set_source_tls(new_id, cert, bool(key))
        src = _decorate(db.source(new_id), {h["ip"] for h in host_ips()})
        # Saved HERE only. Nothing is pushed to the relay: the relay's row for this device is made there, by a
        # person. What the relay currently says about the device is read back so the answer can say so. A direct
        # source with a tenant also gets back what is not documented about its port reading the wrapper: a warning,
        # never a refusal, because whether a parser honors the tenant is the sensor's to say.
        result = {"id": new_id, "ip": {}, "relay": src["relay"],
                  "on_relay_note": ON_RELAY_NOTE if src["path"] not in sender.NO_RELAY else "",
                  "warnings": src.get("wrapper_notes") or []}
        if d["bind_ip"]:
            try:
                result["ip"] = ensure_bind_ip(d["bind_ip"])
            except RuntimeError as e:
                result["ip"] = {"added": False, "error": str(e)}
        db.audit(req.user, "source.save", f"{d['name']} {d['vendor']} {d['path']}/{d['transport']} {d['bind_ip']}"
                 + (f" sensor {d['sensor'] or '1'} " + (f"with tenant {d['direct_tenant']}" if d["delivery"] == "tenant" else "as-is")
                    if d["path"] == "raw" else "")
                 + ("" if client is None else (f" client certificate set (key stored: {how or 'file'})" if client[0] else " client certificate removed")))
        return result

    @app.route("POST", "/api/sources")
    def add_source(req):
        return _save_source(req)

    @app.route("PUT", "/api/sources/{sid}")
    def edit_source(req):
        return _save_source(req, int(req.params["sid"]))

    @app.route("DELETE", "/api/sources/{sid}")
    def del_source(req):
        src = db.source(int(req.params["sid"]))
        if not src:
            raise mw.HttpError(404, "source not found")
        if db.source_tls(src["id"]).get("key_stored"):
            _secret("delete", db.key_name(src["id"]))
        db.delete_source(src["id"])
        db.audit(req.user, "source.delete", src["name"])
        # Nothing is removed from the relay's map from here: this program never wrote it. Said plainly, so
        # nobody assumes the relay stopped mapping a device it is still mapping.
        return {"ok": True, "relay_manual": ("the log source on the relay is unchanged: remove it there, in the "
                                             "Log Relay Manager, if the device is really going away")}

    # ---- runs
    @app.route("GET", "/api/presets")
    def presets(req):
        return {"presets": sender.PRESETS, "mixes": list(sender.SS.MIXES), "kinds": ["allow", "deny", "webfilter", "ips", "vpn", "admin"]}

    @app.route("POST", "/api/runs")
    def start_run(req):
        d = req.json()
        ids = [int(x) for x in d.get("sources", [])]
        if not ids:
            raise mw.HttpError(400, "pick at least one log source")
        srcs = [db.source(i) for i in ids]
        if any(s is None for s in srcs):
            raise mw.HttpError(404, "a selected source no longer exists")
        # How long to send for, as well as how many (Paul, 1 Oct 2026): a duration in seconds (the page
        # offers seconds or minutes), or "until stopped", which runs until Stop or the sender's safety cap.
        duration = max(0, min(int(d.get("duration") or 0), 24 * 3600))
        loop = bool(d.get("loop"))
        params = {"count": max(1, min(int(d.get("count") or 10), 1_000_000)), "rate": max(0.0, float(d.get("rate") or 0)),
                  "duration": duration, "loop": loop,
                  "mix": d.get("mix") or "realistic", "kind": d.get("kind") or None, "size": max(0, int(d.get("size") or 0)),
                  "seed": int(d["seed"]) if str(d.get("seed") or "").strip() else None,
                  # A packet capture happens ON THE RELAY, so it needs the management connection the
                  # standard edition does not have. Dropped here rather than attempted and logged as a
                  # failure; the page does not offer it either.
                  "capture": bool(d.get("capture")) and advanced(),
                  "sources": [{"id": s["id"], "name": s["name"], "vendor": s["vendor"], "format": s.get("format") or "syslog",
                               "identity": sender.identity_label(s), "path": s["path"], "transport": s["transport"],
                               "bind_ip": s.get("bind_ip") or "",
                               # the direct path: which sensor, and as-is or with which tenant, kept with the run's history
                               **({"sensor": str(s.get("sensor") or "1"), "delivery": sender.delivery_of(s),
                                   "tenant": s.get("direct_tenant") or ""} if s["path"] == "raw" else {})} for s in srcs]}
        if params["mix"] not in sender.SS.MIXES:
            raise mw.HttpError(400, "unknown mix")
        settings = db.settings()
        # What the relay's map says about each device, read once for the run: the run log names the tenant and
        # port the relay will use (or that the device is not on the relay yet), and the port check asks about
        # the port the relay's row names rather than a guess. A read; the relay is not changed.
        for s in srcs:
            s["relay"] = relay_lookup(s)
            if s["relay"].get("mapped") and s["relay"].get("port"):
                s["relay_port"] = s["relay"]["port"]
        for s in srcs:
            if s["path"] in ("syslogng", "nginx") and not settings.get("relay_ip"):
                raise mw.HttpError(400, "the log relay's address is not set (Settings)")
            if s["path"] == "raw":
                n = str(s.get("sensor") or "1")
                sen = sender.sensor_for(settings, n)
                if not sen:
                    raise mw.HttpError(400, f"{s['name']} sends to sensor {n}, and there is no sensor {n} on Settings → Sensors any more: "
                                            f"edit the log source and point it at one that is there")
                if not sen["address"]:
                    raise mw.HttpError(400, f"{s['name']} sends to sensor {n}, which has no address yet: give it one on Settings → Sensors")
        udp = any((s["path"] == "syslogng" and s["transport"] == "udp514") or (s["path"] == "raw" and s["transport"] == "udp") for s in srcs)
        if udp and params["size"] > sender.SS.UDP_MAX_PAYLOAD:
            raise mw.HttpError(400, f"size {params['size']} exceeds the UDP limit; use a TCP or TLS transport for big packets")
        active_ids = {ps for r in runs.active() for ps in r["per_source"]}
        if any(str(s["id"]) in active_ids for s in srcs):
            raise mw.HttpError(409, "one of these sources is already sending; wait or cancel that run")
        st = runs.start(req.user, params, srcs, settings, d.get("note", ""))
        db.audit(req.user, "run.start", f"run {st.id}: {params['count']} x {len(srcs)} sources")
        return {"id": st.id}

    @app.route("GET", "/api/runs")
    def list_runs(req):
        live = {r["id"]: r for r in runs.active()}
        rows = db.runs(int(req.query.get("limit", 100)))
        for r in rows:
            if r["id"] in live:
                r.update({k: live[r["id"]][k] for k in ("status", "sent", "failed", "pct")})
        return {"runs": rows, "active": list(live.values())}

    @app.route("GET", "/api/runs/{rid}")
    def get_run(req):
        rid = int(req.params["rid"])
        st = runs.get(rid)
        if st:
            return st.snapshot()
        r = db.run(rid)
        if not r:
            raise mw.HttpError(404, "run not found")
        r["per_source"] = r.pop("results", {})
        r["pct"] = 100
        r["log"] = [{"ts": None, "kind": "", "line": l} for l in (r.get("log") or "").splitlines()]
        return r

    @app.route("POST", "/api/runs/{rid}/cancel")
    def cancel_run(req):
        if not runs.cancel(int(req.params["rid"])):
            raise mw.HttpError(409, "run is not running")
        db.audit(req.user, "run.cancel", req.params["rid"])
        return {"ok": True}

    # ---- throughput test: how many logs a second this path really carries, and where they stop
    @app.route("GET", "/api/bench/plans")
    def bench_plans(req):
        """Everything the Throughput page needs to draw itself, so no number in it is hard-coded there."""
        return {"plans": bench.PLANS, "sizes": bench.SIZES, "caps": bench.CAPS, "cap_note": bench.CAP_NOTE,
                "ramp_rates": bench.RAMP_RATES, "device_counts": bench.DEVICE_COUNTS, "sweep_sizes": bench.SWEEP_SIZES,
                "eps_table": list(bench.BenchManager.EPS_TABLE), "settle": bench.SETTLE,
                "managed": advanced(),
                "sources": [{"id": s["id"], "name": s["name"], "vendor": s["vendor"], "transport": s["transport"],
                             "path": s["path"], "bind_ip": s.get("bind_ip") or ""}
                            for s in db.sources() if s["path"] == "syslogng"]}

    @app.route("POST", "/api/bench")
    def bench_start(req):
        d = req.json()
        src = db.source(int(d.get("source") or 0))
        if not src:
            raise mw.HttpError(400, "pick the log source to send as: a throughput test measures ONE path, "
                                    "fanned out over as many simulated devices as you ask for")
        if src["path"] != "syslogng":
            raise mw.HttpError(400, "a throughput test measures the syslog path to the relay. "
                                    f"{src['name']} sends by {src['path']}, which Send covers instead")
        if benches.running():
            raise mw.HttpError(409, "a throughput run is already going; two at once would measure each other")
        if runs.active():
            raise mw.HttpError(409, "a Send run is going; its traffic would be counted as this test's")
        plan = d.get("plan") or "ramp"
        if plan not in bench.PLANS:
            raise mw.HttpError(400, "unknown plan")
        opts = {"seconds": max(5, min(int(d.get("seconds") or 20), 3600)),
                "size": d.get("size") or "native", "devices": max(1, int(d.get("devices") or 1)),
                "rate": max(0.0, float(d.get("rate") or 0)), "eps": max(0.1, float(d.get("eps") or 10)),
                "steps": d.get("steps") or []}
        if opts["size"] not in bench.SIZE_BY_KEY:
            raise mw.HttpError(400, "unknown size")
        steps = bench.plan_steps(plan, opts, no_limit=bool(d.get("no_limit")))
        if not steps:
            raise mw.HttpError(400, "that plan produced no steps")
        # A custom plan's steps come straight off the wire, so every field is normalised to the type and
        # range the engine expects here rather than blowing up inside a sending thread, where the only
        # trace would be a failed run and a stack in the journal.
        try:
            for i, s in enumerate(steps, 1):
                s["size"] = s.get("size") or opts["size"]
                if s["size"] not in bench.SIZE_BY_KEY:
                    raise mw.HttpError(400, f"step {i}: unknown size {s['size']}")
                s["devices"] = max(1, min(int(s.get("devices") or opts["devices"]), 5000))
                s["rate"] = max(0.0, float(s.get("rate") or 0))
                s["seconds"] = max(1, min(int(s.get("seconds") or opts["seconds"]), 3600))
        except (TypeError, ValueError):
            raise mw.HttpError(400, "each step needs a size, a number of devices, a rate and a number of seconds")
        no_limit = bool(d.get("no_limit"))
        try:
            bench.check_caps(steps, no_limit)
        except ValueError as e:
            raise mw.HttpError(400, str(e) + ". " + bench.CAP_NOTE)
        udp = src["transport"] == "udp514"
        for s in steps:
            b = bench.SIZE_BY_KEY[s["size"]]["bytes"]
            if udp and b > sender.SS.UDP_MAX_PAYLOAD:
                raise mw.HttpError(400, f"{b} B is more than one UDP datagram can carry; use a TCP or TLS log source")
        params = {"plan": plan, "steps": steps, "note": (d.get("note") or "")[:300],
                  "stop_on_loss": bool(d.get("stop_on_loss", plan == "ramp")),
                  "distinct_devices": bool(d.get("distinct_devices")),
                  "no_limit": no_limit, "tag": _bench_tag(), "eps": opts["eps"]}
        st = benches.start(req.user, params, src, db.settings())
        db.audit(req.user, "bench.start", f"throughput #{st.id}: {plan}, {len(steps)} steps, source {src['name']}"
                                          + (", NO LIMIT" if no_limit else ""))
        return {"id": st.id}

    @app.route("GET", "/api/bench")
    def bench_list(req):
        live = benches.running()
        return {"runs": db.benches(int(req.query.get("limit", 25))), "active": live.id if live else None}

    @app.route("GET", "/api/bench/sizing")
    def bench_sizing(req):
        """How many log sources a measured ceiling carries at N logs a second each.

        Registered BEFORE /api/bench/{bid}, which would otherwise match "sizing" and fail trying to read
        it as a run number - the same trap /api/config-files/search fell into on the relay.
        """
        try:
            rate = float(req.query.get("records_s") or 0)
            eps = float(req.query.get("eps") or 0)
        except ValueError:
            raise mw.HttpError(400, "records_s and eps are numbers")
        if rate <= 0 or eps <= 0:
            raise mw.HttpError(400, "give the measured records/s and the logs a second one device sends")
        conns = req.query.get("max_connections")
        return bench.sizing(rate, eps, int(conns) if str(conns or "").isdigit() else None,
                            req.query.get("proto") or "tls") or {}

    @app.route("GET", "/api/bench/{bid}")
    def bench_get(req):
        bid = int(req.params["bid"])
        st = benches.get(bid)
        if st:
            return st.snapshot()
        row = db.bench(bid)
        if not row:
            raise mw.HttpError(404, "no such throughput run")
        row["log"] = [{"ts": None, "kind": "", "line": l} for l in (row.get("log") or "").splitlines()]
        row["current"] = None
        return row

    @app.route("POST", "/api/bench/{bid}/cancel")
    def bench_cancel(req):
        if not benches.cancel(int(req.params["bid"])):
            raise mw.HttpError(409, "that run is not going")
        db.audit(req.user, "bench.cancel", req.params["bid"])
        return {"ok": True}

    @app.route("POST", "/api/bench/{bid}/recount")
    def bench_recount(req):
        """Ask Stellar Cyber again. A count taken straight after a run is a floor: indexing lags."""
        manager_only()
        try:
            res = benches.recount(int(req.params["bid"]))
        except Exception as e:  # noqa: BLE001
            raise mw.HttpError(502, str(e))
        if res is None:
            raise mw.HttpError(404, "no such throughput run")
        return res

    @app.route("GET", "/api/bench/{bid}/csv")
    def bench_csv(req):
        bid = int(req.params["bid"])
        st = benches.get(bid)
        row = st.snapshot() if st else db.bench(bid)
        if not row:
            raise mw.HttpError(404, "no such throughput run")
        return mw.Response(200, bench.report_csv(row).encode(), "text/csv; charset=utf-8",
                           [("Content-Disposition", f'attachment; filename="throughput-run-{bid}.csv"')])

    # ---- relay passthrough (browser never holds the relay token)
    @app.route("GET", "/api/relay/status")
    def relay_status(req):
        manager_only()
        try:
            return {"ok": True, **relay.status()}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e)}

    @app.route("GET", "/api/relay/feed")
    def relay_feed(req):
        manager_only()
        try:
            return {"ok": True, **relay.feed(int(req.query.get("n", 30)))}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e), "entries": []}

    @app.route("GET", "/api/relay/errors")
    def relay_errors(req):
        manager_only()
        try:
            return {"ok": True, **relay.errors()}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e), "items": []}

    @app.route("GET", "/api/relay/config-files")
    def relay_config_files(req):
        manager_only()
        try:
            return {"ok": True, **relay._call("GET", "/api/config-files")}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e), "files": []}

    @app.route("GET", "/api/relay/config-files/{fid}")
    def relay_config_file(req):
        manager_only()
        if not re.match(r"^[a-z0-9-]+$", req.params["fid"]):
            raise mw.HttpError(400, "bad id")
        try:
            return relay._call("GET", f"/api/config-files/{req.params['fid']}")
        except Exception as e:  # noqa: BLE001
            raise mw.HttpError(502, str(e))

    # ---- services: this host's mock sensor only. The relay's services are the relay's: they are reloaded and
    # restarted on the relay, in its own console (Paul, 24 Sep 2026: no capability on Ingest Studio that can
    # touch the relay's configuration or its services).
    @app.route("GET", "/api/services")
    def services(req):
        rc, out, _ = mw.run_cmd(["systemctl", "is-active", "mock-sensor"])
        local = [{"name": "mock-sensor", "where": "this host", "state": out.strip() or "unknown", "active": out.strip() == "active"}]
        return {"services": local, "manager_note": "" if advanced() else NO_MANAGER_NOTE,
                "relay_note": "the relay's own services are reloaded and restarted on the relay, in the Log Relay Manager; "
                              "nothing here can touch them"}

    @app.route("POST", "/api/services/{where}/{name}/{action}")
    def service_action(req):
        where, name, action = req.params["where"], req.params["name"], req.params["action"]
        if where != "local":
            raise mw.HttpError(404, "not found")      # there is no relay service control here, in any edition
        if action not in ("start", "stop", "restart"):
            raise mw.HttpError(400, "bad action")
        if name != "mock-sensor":
            raise mw.HttpError(400, "only mock-sensor start/stop/restart is allowed here")
        rc, out, err = mw.run_cmd(SUDO + ["systemctl", action, "mock-sensor"], timeout=60)
        if rc != 0:
            raise mw.HttpError(500, f"{action} mock-sensor failed", detail=(err or out)[-400:])
        db.audit(req.user, "service", f"local mock-sensor {action}")
        return {"ok": True}

    @app.route("GET", "/api/audit")
    def audit(req):
        return {"items": db.audits(200)}

    return app


def restore_bind_ips():
    """Re-add every source's secondary IP after a reboot (ip addr add is not persistent). Best effort."""
    def _run():
        for src in db.sources():
            if src.get("bind_ip"):
                try:
                    r = ensure_bind_ip(src["bind_ip"])
                    if r.get("added"):
                        db.audit("system", "ip.restore", f"{src['name']} {src['bind_ip']} re-added to {r.get('iface')}")
                except RuntimeError as e:
                    db.audit("system", "ip.restore.failed", f"{src['name']} {src['bind_ip']}: {e}")
    threading.Thread(target=_run, daemon=True).start()


def main():
    restore_bind_ips()
    port = int(cfg("LISTEN_PORT", "8443"))
    cert, key = cfg("TLS_CERT", "/etc/stellar-lab/ingest-studio.crt"), cfg("TLS_KEY", "/etc/stellar-lab/ingest-studio.key")
    if cfg("NO_TLS") == "1":
        cert = key = None
    else:
        mw.ensure_self_signed_cert(cert, key, "stellar-ingest-studio")
    global HTTPD
    httpd = mw.serve(build_app(), cfg("LISTEN_HOST", "0.0.0.0"), port, cert, key)
    HTTPD = httpd               # a certificate change is swapped in place (Settings -> Security)
    httpd.serve_forever()


if __name__ == "__main__":
    main()
