#!/usr/bin/env bash
# Install the Ingest Studio web app on the SENDER host (the machine that simulates the firewalls).
#
#   sudo bash apps/ingest-studio/install.sh [--port 8443] [--no-prompt] [--advanced | --standard]
#
#   The STANDARD Studio (the default) defines log sources and sends their logs to the syslog-ng relay's
#   listeners, exactly as the real devices would. It has NO management connection to the relay: it never
#   reads its state and cannot capture packets on it. Each log source defined here is created on the
#   relay too, there, by a person: that row decides the tenant and the sensor port.
#   --advanced adds a READ connection (the relay's status and map, run confirmation) plus packet capture
#   around a run, and needs the advanced code: $STELLAR_ADVANCED_CODE, or typed when asked. Neither
#   edition writes the relay's configuration. The flag is never offered and never prompted for without
#   it. Without either flag a re-run keeps the edition the host has.
#
# What it does (idempotent; re-run to upgrade the code, existing secrets and password are kept):
#   * creates the 'stellarlab' system user, copies apps/common + apps/ingest-studio + tools/stellar-send.py
#     to /opt/stellar-lab
#   * installs the root helper /usr/local/sbin/stellar-lab-ip (adds/removes secondary IPs) and a sudoers
#     allow-list for it and for systemctl start|stop|restart mock-sensor
#   * writes /etc/stellar-lab/ingest-studio.env with a random SECRET_KEY and the admin user/password hash
#   * generates a self-signed TLS certificate and installs + starts the ingest-studio systemd service
#
# Afterwards: https://<sender-ip>:8443 (open TCP 8443 in the security group from your IP only), then
# Settings: the relay's IP or host name, and (advanced) the Log Relay Manager URL (https://<relay-ip>:8444)
# and the API token printed by the relay-monitor installer.
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/../common/install-lib.sh"

PORT=8443; PROMPT=yes; EDITION=""
while [[ $# -gt 0 ]]; do
  case $1 in
    --port) PORT=$2; shift 2 ;;
    --no-prompt) PROMPT=no; shift ;;
    --advanced) EDITION=advanced; shift ;;
    --standard) EDITION=standard; shift ;;
    -h|--help) sed -n '2,25p' "$0"; exit 0 ;;
    *) echo "unknown option $1" >&2; exit 2 ;;
  esac
done

need_root; check_prereqs; ensure_user
ENVF=$LAB_ETC/ingest-studio.env
KIT=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)

echo "==> Copying application to $LAB_ROOT"
copy_app ingest-studio
[[ -f "$KIT/tools/stellar-send.py" ]] || { echo "tools/stellar-send.py not found next to apps/ (run from the kit directory)" >&2; exit 1; }
install -m 0644 "$KIT/tools/stellar-send.py" "$LAB_ROOT/common/stellar_send.py"
# Stellar Cyber's own CA, which a sensor card may check the sensor's certificate against (Settings -> Sensors).
# It is the same file the relay ships; the app looks for it beside itself.
if [[ -f "$KIT/syslog-ng/stellar-sensor-ca.pem" ]]; then
  install -m 0644 "$KIT/syslog-ng/stellar-sensor-ca.pem" "$LAB_ROOT/ingest-studio/stellar-sensor-ca.pem"
fi
install -m 0755 "$LAB_ROOT/ingest-studio/stellar-lab-ip" /usr/local/sbin/stellar-lab-ip
# the way back in when the password is forgotten: root on this host, never an e-mail. Deliberately
# NOT in the sudoers allow-list below - a person with root runs it, the web app cannot.
install -m 0755 "$LAB_ROOT/ingest-studio/stellar-studio-password" /usr/local/sbin/stellar-studio-password
# updating Ingest Studio itself, from a bundle Stellar Cyber signed. Allow-listed below, because the
# app offers it on its Settings page; it installs nothing that is not signed by our release key.
install -m 0755 "$LAB_ROOT/ingest-studio/stellar-studio-update" /usr/local/sbin/stellar-studio-update
# a log source's TLS private key, kept root-only and host-bound (systemd-creds) where the host has it; the app
# reaches it only through this helper, over a pipe, for a run (Paul, 2 Oct 2026: "the key must be stored securely")
install -m 0755 "$LAB_ROOT/ingest-studio/stellar-studio-secret" /usr/local/sbin/stellar-studio-secret
# this Studio's own HTTPS certificate (Settings -> Security): see it, reissue it, replace it. It is the relay console's
# certificate code (stellar-relay-config, installed root-owned beside it as a library) pointed at the Studio's files.
[[ -f "$KIT/apps/relay-monitor/stellar-relay-config" ]] || { echo "apps/relay-monitor/stellar-relay-config not found (run from the kit directory or the bundle)" >&2; exit 1; }
install -d -m 0755 /usr/local/lib/stellar-studio
install -m 0644 "$KIT/apps/relay-monitor/stellar-relay-config" /usr/local/lib/stellar-studio/stellar-relay-config
install -m 0755 "$LAB_ROOT/ingest-studio/stellar-studio-cert" /usr/local/sbin/stellar-studio-cert
# the same command as the relay's, and it reports on whichever of the two consoles is on this host
if [[ -f "$KIT/tools/stellar-update-doctor.py" ]]; then
  install -m 0755 "$KIT/tools/stellar-update-doctor.py" /usr/local/sbin/stellar-update-doctor
fi
mkdir -p /var/lib/stellar-lab/ingest-studio; chown "$LAB_USER:$LAB_USER" /var/lib/stellar-lab/ingest-studio; chmod 750 /var/lib/stellar-lab/ingest-studio

echo "==> Secrets and admin account"
SECRET=$(env_get "$ENVF" SECRET_KEY); [[ -n "$SECRET" ]] || SECRET=$(rand_hex 32)
ADMIN=$(env_get "$ENVF" ADMIN_USER);  [[ -n "$ADMIN" ]] || ADMIN=admin
HASH=$(env_get "$ENVF" ADMIN_HASH)
GENERATED_PW=""
if [[ "$PROMPT" == yes ]]; then
  if [[ -n "$HASH" ]]; then
    read -r -p "Keep the existing admin password? [Y/n] " keep; [[ "${keep,,}" == n* ]] && HASH=""
  fi
  [[ -n "$HASH" ]] || HASH=$(prompt_password_hash)
elif [[ -z "$HASH" ]]; then
  GENERATED_PW=$(rand_hex 8)
  HASH=$(PW="$GENERATED_PW" python3 -c "import os,sys; sys.path.insert(0,'$LAB_ROOT/common'); import microweb; print(microweb.hash_password(os.environ['PW']))")
fi

echo "==> TLS certificate"
[[ -f $LAB_ETC/ingest-studio.crt ]] || openssl req -x509 -newkey rsa:2048 -nodes -days 3650 -subj "/CN=stellar-ingest-studio" \
  -keyout "$LAB_ETC/ingest-studio.key" -out "$LAB_ETC/ingest-studio.crt" >/dev/null 2>&1
chown root:"$LAB_USER" "$LAB_ETC"/ingest-studio.{crt,key}; chmod 640 "$LAB_ETC"/ingest-studio.{crt,key}

write_env "$ENVF" \
  "LISTEN_PORT=$PORT" \
  "ADMIN_USER=$ADMIN" \
  "ADMIN_HASH=$HASH" \
  "SECRET_KEY=$SECRET" \
  "TLS_CERT=$LAB_ETC/ingest-studio.crt" \
  "TLS_KEY=$LAB_ETC/ingest-studio.key" \
  "DB_PATH=/var/lib/stellar-lab/ingest-studio/studio.db" \
  "IP_HELPER=/usr/local/sbin/stellar-lab-ip"

# The edition, beside the database, read by app.py's edition(). An install is the STANDARD Studio unless
# --advanced is given (or STELLAR_ADVANCED_CODE is set), and a standard install says nothing about it:
# naming the edition, or the command that changes it, tells a reader a hidden one exists.
STUDIO_STATE=/var/lib/stellar-lab/ingest-studio
advanced_code_ok() {
  local code="${STELLAR_ADVANCED_CODE:-}" want src
  src="$(dirname "${BASH_SOURCE[0]}")/../relay-monitor/advanced-code.sha256"
  want=$(tr -d ' \n' < "$src" 2>/dev/null || true)
  [[ -n "$want" ]] || want=$(tr -d ' \n' < "$LAB_ROOT/relay-monitor/advanced-code.sha256" 2>/dev/null || true)
  [[ -n "$want" ]] || return 1
  # only reached when --advanced was given or STELLAR_ADVANCED_CODE is set: the asker already knows it exists
  if [[ -z "$code" && "$PROMPT" == yes ]]; then code=$(read_secret "Advanced code: "); fi
  [[ -n "$code" ]] || return 1
  [[ "$(printf '%s' "$code" | python3 -c 'import hashlib,sys; print(hashlib.sha256(sys.stdin.buffer.read()).hexdigest())')" == "$want" ]]
}
if [[ -z "$EDITION" && -n "${STELLAR_ADVANCED_CODE:-}" ]]; then EDITION=advanced; fi
if [[ "$EDITION" == advanced ]]; then
  advanced_code_ok || { echo "the advanced code was not accepted; installing the STANDARD Ingest Studio" >&2; EDITION=standard; }
fi
if [[ -n "$EDITION" ]]; then
  mkdir -p "$STUDIO_STATE"
  printf '{"edition": "%s", "at": %s}\n' "$EDITION" "$(date +%s)" > "$STUDIO_STATE/edition.json"
  chown "$LAB_USER:$LAB_USER" "$STUDIO_STATE/edition.json"; chmod 640 "$STUDIO_STATE/edition.json"
  [[ "$EDITION" == advanced ]] && echo "==> Advanced Ingest Studio"
fi

echo "==> sudo allow-list"
install_sudoers stellar-ingest-studio \
  "$LAB_USER ALL=(root) NOPASSWD: /usr/local/sbin/stellar-lab-ip" \
  "$LAB_USER ALL=(root) NOPASSWD: /usr/local/sbin/stellar-studio-update" \
  "$LAB_USER ALL=(root) NOPASSWD: /usr/local/sbin/stellar-studio-secret" \
  "$LAB_USER ALL=(root) NOPASSWD: /usr/local/sbin/stellar-studio-cert" \
  "$LAB_USER ALL=(root) NOPASSWD: /usr/bin/systemctl start mock-sensor, /usr/bin/systemctl stop mock-sensor, /usr/bin/systemctl restart mock-sensor"

echo "==> systemd service"
install_unit ingest-studio "Stellar Cyber lab: Ingest Studio web app" "/usr/bin/python3 $LAB_ROOT/ingest-studio/app.py" "$ENVF"
sleep 1; systemctl --no-pager --lines=3 status ingest-studio | sed -n '1,4p'

cat <<SUMMARY

Done.
  URL:     https://$(primary_ip):$PORT   (self-signed certificate; accept the browser warning)
  Login:   $ADMIN${GENERATED_PW:+  password: $GENERATED_PW  (generated; change it by re-running the installer)}
  Config:  $ENVF          Logs: journalctl -u ingest-studio -f

Next, in the web UI:
  1. Settings: the log relay's IP or host name; advanced: the Log Relay Manager URL https://<relay-ip>:8444 and
     its API token (read only, plus packet capture), then "Test log relay manager".
  2. Log sources: one per simulated firewall, configured as the real device is. Each relay-path source needs its
     own source IP; the app adds it to this host, but you must ALSO add it as a secondary private IP on this
     instance's network interface in AWS (EC2 > Network interfaces > Actions > Manage IP addresses), or replies
     from the relay are dropped.
  3. On the relay, in the Log Relay Manager: create the same log source there. That row decides the tenant its
     logs land in and the sensor port; this Studio never writes it.
  4. Send: pick firewalls, pick a preset, Start.
SUMMARY
