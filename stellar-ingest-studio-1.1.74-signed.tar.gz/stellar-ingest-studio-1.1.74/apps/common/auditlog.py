"""
auditlog.py - who did what, when, from where, and whether it worked: one JSON line per event.

Written by the framework (microweb.App) for every request that can change something (anything but
GET/HEAD), for every sign-in attempt, sign-out, and for every write a read-only account was refused.
A route can add a sentence of its own with `req.audit_detail = "..."`; otherwise the app's label
table turns the method and path into words ("Added or changed the tenant mapping for 10.0.1.21").

The file is append-only and hash-chained: each line carries the SHA-256 of the previous line, so a
line that was edited or removed afterwards breaks the chain and `verify()` says where. That is
tamper-EVIDENT, not tamper-proof (whoever can write the file can rewrite the whole chain), which is
the honest thing a single host can offer; for proof, forward the file to a SIEM as well.

Never written here: passwords, tokens, secrets. The framework strips any body key whose name
contains 'pass', 'token' or 'secret' before it reaches a label, and labels only ever quote the
fields they name.
"""
import csv
import hashlib
import io
import json
import os
import re
import threading
import time

SECRET_KEY = re.compile(r"pass|token|secret|hash", re.I)


class AuditLog:
    def __init__(self, path):
        self.path = path
        self.lock = threading.Lock()
        self._last_hash = None
        self.labels = []          # (method, compiled path regex, label template)

    # ---- labels: turn a request into a sentence
    def label(self, method, pattern, text):
        """text may use {p.name} for a path parameter and {b.key} for a body field."""
        rx = re.compile("^" + re.sub(r"{(\w+)}", r"(?P<\1>[^/]+)", pattern) + "$")
        self.labels.append((method, rx, text))

    def describe(self, method, path, params=None, body=None):
        for m, rx, text in self.labels:
            if m != method:
                continue
            mm = rx.match(path)
            if not mm:
                continue
            p = dict(params or {}); p.update(mm.groupdict())
            b = {k: v for k, v in (body or {}).items() if not SECRET_KEY.search(k)} if isinstance(body, dict) else {}

            def sub(match):
                kind, key = match.group(1), match.group(2)
                src = p if kind == "p" else b
                v = src.get(key)
                if v is None:
                    return "?"
                s = str(v)
                return s if len(s) <= 80 else s[:77] + "..."
            return re.sub(r"{([pb])\.(\w+)}", sub, text)
        return f"{method} {path}"

    # ---- writing
    def _tail_hash(self):
        """The hash of the last line on disk (once, then tracked in memory)."""
        if self._last_hash is not None:
            return self._last_hash
        last = ""
        try:
            with open(self.path, "rb") as f:
                f.seek(0, 2); size = f.tell(); f.seek(max(0, size - 65536))
                lines = f.read().decode(errors="replace").splitlines()
            for line in reversed(lines):
                if line.strip():
                    last = line; break
        except OSError:
            pass
        self._last_hash = hashlib.sha256(last.encode()).hexdigest() if last else ""
        return self._last_hash

    def record(self, **entry):
        """Append one event. Keys: user, role, via, ip, method, path, status, ok, action, detail, kind."""
        e = {"ts": time.time()}
        for k, v in entry.items():
            if v is None:
                continue
            if isinstance(v, str) and len(v) > 600:
                v = v[:597] + "..."
            e[k] = v
        with self.lock:
            os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
            # The file is rotated under us (logrotate, daily and at 1 MB - 5 Oct 2026). The chain is kept in
            # memory, so without this the first line of a FRESH file would carry the previous file's hash
            # while verify() starts from an empty one, and every rotation would report the log as tampered
            # with. Each file is its own complete chain; the rotated .gz beside it verifies on its own.
            new = not os.path.exists(self.path) or os.path.getsize(self.path) == 0
            if new:
                self._last_hash = ""
            e["prev"] = self._tail_hash()
            line = json.dumps(e, sort_keys=True)
            with open(self.path, "a") as f:
                f.write(line + "\n")
            if new:
                try:
                    os.chmod(self.path, 0o640)
                except OSError:
                    pass
            self._last_hash = hashlib.sha256(line.encode()).hexdigest()
        return e

    # ---- reading
    def _lines(self, max_bytes=4_000_000):
        try:
            with open(self.path, "rb") as f:
                f.seek(0, 2); size = f.tell()
                f.seek(max(0, size - max_bytes))
                data = f.read().decode(errors="replace")
        except OSError:
            return [], False
        lines = data.splitlines()
        truncated = size > max_bytes
        if truncated and lines:
            lines = lines[1:]           # the first line is probably cut in half
        return lines, truncated

    def tail(self, n=200, user=None, q=None, since=None, only_failed=False):
        lines, truncated = self._lines()
        out = []
        ql = (q or "").lower()
        for line in reversed(lines):
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if user and e.get("user") != user:
                continue
            if since and e.get("ts", 0) < since:
                continue
            if only_failed and e.get("ok", True):
                continue
            if ql and ql not in json.dumps(e).lower():
                continue
            out.append(e)
            if len(out) >= n:
                break
        return out

    def count(self):
        lines, _ = self._lines()
        return sum(1 for l in lines if l.strip())

    def verify(self):
        """Walk the whole file and check every line's prev hash. {ok, entries, broken_at, reason}."""
        try:
            with open(self.path, "rb") as f:
                lines = f.read().decode(errors="replace").splitlines()
        except OSError:
            return {"ok": True, "entries": 0, "broken_at": None, "reason": "no audit file yet"}
        prev, n = "", 0
        for i, line in enumerate(lines, 1):
            if not line.strip():
                continue
            try:
                e = json.loads(line)
            except ValueError:
                return {"ok": False, "entries": n, "broken_at": i, "reason": f"line {i} is not JSON"}
            if e.get("prev", "") != prev:
                return {"ok": False, "entries": n, "broken_at": i, "reason": f"line {i} does not follow the line before it: something was edited, inserted or removed"}
            prev = hashlib.sha256(line.encode()).hexdigest()
            n += 1
        return {"ok": True, "entries": n, "broken_at": None, "reason": "every line follows the one before it"}

    def export_csv(self, n=100000):
        rows = self.tail(n)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["time", "user", "role", "via", "ip", "method", "path", "status", "ok", "action", "detail", "kind"])
        for e in reversed(rows):
            w.writerow([time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(e.get("ts", 0))), e.get("user", ""), e.get("role", ""), e.get("via", ""),
                        e.get("ip", ""), e.get("method", ""), e.get("path", ""), e.get("status", ""), e.get("ok", ""), e.get("action", ""),
                        e.get("detail", ""), e.get("kind", "")])
        return buf.getvalue()


def register_routes(app, log):
    """GET /api/audit?n=&user=&q=&failed=1 (admin), GET /api/audit/verify, GET /api/audit/export (CSV)."""
    @app.route("GET", "/api/audit", auth="session", role="admin")
    def audit_tail(req):
        n = max(1, min(int(req.query.get("n", 200) or 200), 2000))
        return {"entries": log.tail(n, user=req.query.get("user") or None, q=req.query.get("q") or None, only_failed=req.query.get("failed") == "1"),
                "path": log.path, "total": log.count()}

    @app.route("GET", "/api/audit/verify", auth="session", role="admin")
    def audit_verify(req):
        return log.verify() | {"path": log.path}

    @app.route("GET", "/api/audit/export", auth="session", role="admin")
    def audit_export(req):
        import microweb as mw
        return mw.Response(200, log.export_csv().encode(), "text/csv; charset=utf-8",
                           [("Content-Disposition", 'attachment; filename="audit-log.csv"'), ("Cache-Control", "no-store")])
