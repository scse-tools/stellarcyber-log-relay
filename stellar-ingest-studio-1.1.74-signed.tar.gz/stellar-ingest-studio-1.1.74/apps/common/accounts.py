"""
accounts.py - user accounts and the two roles the lab apps know, in one JSON file.

Roles:
  admin     can change anything the app can change
  readonly  can look at every page and download every file, but every write is refused with 403

Why app-local accounts rather than the host's Linux accounts: the web app runs as an unprivileged
service user, which cannot verify another Linux user's password (that needs root, or a setuid helper
that only checks the caller's own password). A root helper could be added, but the people who may
open this console are not the people who have a shell on the relay, and a role and an audit trail
have to live somewhere the app controls anyway. So accounts are local, passwords are scrypt hashes,
and the file is readable by the service user only.

The account the installer created (ADMIN_USER / ADMIN_HASH in the app's env file) is always present
as an admin and cannot be removed here; it can be disabled once another admin exists, and its
password can be changed (the new hash is stored in this file and wins over the env file).

Sessions are the framework's signed cookies. A cookie issued before an account's password was
changed, or before it was disabled, is refused, so "reset password" and "disable" take effect at
the next request, not at the next sign-in.
"""
import json
import os
import re
import tempfile
import threading
import time

import microweb as mw

ROLES = ("admin", "readonly")
NAME = re.compile(r"^[a-z0-9][a-z0-9._-]{1,31}$")
MIN_PASSWORD = 12


class AccountError(Exception):
    """A rule was broken; the message is the sentence to show the person."""


class UserStore:
    def __init__(self, path, bootstrap_user=None, bootstrap_hash=None):
        self.path = path
        self.bootstrap_user, self.bootstrap_hash = bootstrap_user, bootstrap_hash
        self.lock = threading.Lock()

    # ---- file
    def _load(self):
        try:
            with open(self.path) as f:
                d = json.load(f)
            return d if isinstance(d, dict) and isinstance(d.get("users"), dict) else {"users": {}}
        except (OSError, ValueError):
            return {"users": {}}

    def _save(self, d):
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(self.path) or ".", prefix=".users-")
        with os.fdopen(fd, "w") as f:
            json.dump(d, f, indent=1)
        os.chmod(tmp, 0o600)
        os.replace(tmp, self.path)

    # ---- reading
    def _records(self, d=None):
        """Every account, the installer's included, keyed by name. A stored record with the
        installer's name overrides the env file (that is how its password gets changed)."""
        d = d or self._load()
        users = {}
        if self.bootstrap_user and self.bootstrap_hash:
            users[self.bootstrap_user] = {"name": self.bootstrap_user, "role": "admin", "hash": self.bootstrap_hash,
                                          "source": "installer", "disabled": False, "created": None, "created_by": "installer",
                                          "last_login": None, "last_login_ip": None, "pw_changed": 0}
        for name, rec in d["users"].items():
            base = users.get(name, {"name": name, "source": "store", "created": None, "created_by": "", "last_login": None, "last_login_ip": None, "pw_changed": 0})
            merged = dict(base)
            merged.update({k: v for k, v in rec.items() if k != "name"})
            merged["name"] = name
            if merged["source"] == "installer":
                merged["role"] = "admin"          # the installer's account keeps its role whatever the file says
            users[name] = merged
        return users

    def users(self):
        """Public view: no hashes."""
        out = []
        for rec in sorted(self._records().values(), key=lambda r: (r["source"] != "installer", r["name"])):
            out.append({k: rec.get(k) for k in ("name", "role", "source", "disabled", "created", "created_by", "last_login", "last_login_ip", "pw_changed")})
        return out

    def get(self, name):
        return self._records().get(name)

    def role(self, name, issued_at=None):
        """The role an existing, enabled account has now, or None when the account is unknown,
        disabled, or its password changed after the session was issued (so that session is dead)."""
        rec = self.get(name)
        if not rec or rec.get("disabled"):
            return None
        # the cookie's issue time is a whole second (expiry - TTL), so a session made in the same second
        # as the password change must survive: two seconds of tolerance
        if issued_at is not None and rec.get("pw_changed") and issued_at + 2 < rec["pw_changed"]:
            return None
        return rec.get("role") if rec.get("role") in ROLES else None

    def verify(self, name, password):
        rec = self.get(name)
        if not rec or rec.get("disabled") or not rec.get("hash"):
            return None
        return rec if mw.verify_password(password, rec["hash"]) else None

    def touch_login(self, name, ip=None):
        """A successful sign-in: when, and from which address (the Users page shows both)."""
        with self.lock:
            d = self._load()
            rec = d["users"].setdefault(name, {})
            if self.bootstrap_user == name and "source" not in rec:
                rec["source"] = "installer"
            rec["last_login"] = time.time()
            if ip:
                rec["last_login_ip"] = str(ip)[:64]
            self._save(d)

    # ---- writing (every method raises AccountError with the sentence to show)
    def _admins_left(self, records, excluding=None):
        return [r["name"] for r in records.values() if r["role"] == "admin" and not r.get("disabled") and r["name"] != excluding]

    @staticmethod
    def _check_password(password):
        if not isinstance(password, str) or len(password) < MIN_PASSWORD:
            raise AccountError(f"the password must be at least {MIN_PASSWORD} characters")

    def add(self, name, password, role, by):
        name = (name or "").strip().lower()
        if not NAME.match(name):
            raise AccountError("a user name is 2 to 32 characters: lowercase letters, digits, dot, dash or underscore, starting with a letter or digit")
        if role not in ROLES:
            raise AccountError("the role is admin or readonly")
        self._check_password(password)
        with self.lock:
            d = self._load()
            if name in self._records(d):
                raise AccountError(f"there is already an account called {name}")
            d["users"][name] = {"role": role, "hash": mw.hash_password(password), "source": "store", "disabled": False,
                                "created": time.time(), "created_by": by or "?", "last_login": None, "pw_changed": time.time()}
            self._save(d)
        return self.get(name)

    def update(self, name, by, role=None, password=None, disabled=None):
        with self.lock:
            d = self._load()
            recs = self._records(d)
            rec = recs.get(name)
            if not rec:
                raise AccountError("no such account")
            new_role = rec["role"] if role is None else role
            if new_role not in ROLES:
                raise AccountError("the role is admin or readonly")
            new_disabled = bool(rec.get("disabled")) if disabled is None else bool(disabled)
            if rec["source"] == "installer" and new_role != "admin":
                raise AccountError("the installer's account is always an admin; disable it instead once another admin exists")
            if (new_role != "admin" or new_disabled) and rec["role"] == "admin" and not rec.get("disabled") and not self._admins_left(recs, excluding=name):
                raise AccountError("that would leave no enabled admin; make someone else an admin first")
            if new_disabled and name == by:
                raise AccountError("you cannot disable the account you are signed in with")
            stored = d["users"].setdefault(name, {"source": rec["source"], "created": rec.get("created"), "created_by": rec.get("created_by")})
            stored["role"] = new_role
            stored["disabled"] = new_disabled
            if password is not None:
                self._check_password(password)
                stored["hash"] = mw.hash_password(password)
                stored["pw_changed"] = time.time()
            if new_disabled and not rec.get("disabled"):
                stored["pw_changed"] = time.time()      # kills the disabled account's open sessions
            self._save(d)
        return self.get(name)

    def set_password(self, name, old_password, new_password):
        """Self-service: the current password must be given."""
        if not self.verify(name, old_password):
            raise AccountError("the current password is wrong")
        self._check_password(new_password)
        with self.lock:
            d = self._load()
            rec = self._records(d)[name]
            stored = d["users"].setdefault(name, {"source": rec["source"], "role": rec["role"], "created": rec.get("created"), "created_by": rec.get("created_by")})
            stored["hash"] = mw.hash_password(new_password)
            stored["pw_changed"] = time.time()
            self._save(d)

    def remove(self, name, by):
        with self.lock:
            d = self._load()
            recs = self._records(d)
            rec = recs.get(name)
            if not rec:
                raise AccountError("no such account")
            if rec["source"] == "installer":
                raise AccountError("the installer's account cannot be removed here (disable it, or remove ADMIN_USER from the env file)")
            if name == by:
                raise AccountError("you cannot remove the account you are signed in with")
            if rec["role"] == "admin" and not rec.get("disabled") and not self._admins_left(recs, excluding=name):
                raise AccountError("that would leave no enabled admin")
            d["users"].pop(name, None)
            self._save(d)


def register_routes(app, store):
    """The account management API, the same in every app that uses a UserStore.

      GET    /api/users                     every account (admin)
      POST   /api/users                     {name, password, role}            (admin)
      PUT    /api/users/{name}              {role?, password?, disabled?}     (admin; resets a password)
      DELETE /api/users/{name}                                                (admin)
      POST   /api/account/password          {current, new}                    (anyone, own account)
    """
    def _err(e):
        raise mw.HttpError(400, str(e))

    @app.route("GET", "/api/users", auth="session", role="admin")
    def users_list(req):
        return {"users": store.users(), "roles": list(ROLES), "path": store.path, "min_password": MIN_PASSWORD, "me": req.user}

    @app.route("POST", "/api/users", auth="session")
    def users_add(req):
        d = req.json()
        try:
            rec = store.add(d.get("name"), d.get("password"), d.get("role"), req.user)
        except AccountError as e:
            _err(e)
        req.audit_detail = f"created {rec['name']} as {rec['role']}"
        return {"ok": True, "user": {k: rec.get(k) for k in ("name", "role", "source", "disabled")}}

    @app.route("PUT", "/api/users/{name}", auth="session")
    def users_update(req):
        d = req.json()
        try:
            rec = store.update(req.params["name"], req.user, role=d.get("role"), password=d.get("password"), disabled=d.get("disabled"))
        except AccountError as e:
            _err(e)
        what = [k for k in ("role", "password", "disabled") if d.get(k) is not None]
        req.audit_detail = f"{req.params['name']}: changed {', '.join(what) or 'nothing'}" + (f" (role {rec['role']}, {'disabled' if rec.get('disabled') else 'enabled'})")
        return {"ok": True, "user": {k: rec.get(k) for k in ("name", "role", "source", "disabled")}}

    @app.route("DELETE", "/api/users/{name}", auth="session")
    def users_remove(req):
        try:
            store.remove(req.params["name"], req.user)
        except AccountError as e:
            _err(e)
        req.audit_detail = f"removed {req.params['name']}"
        return {"ok": True}

    @app.route("POST", "/api/account/password", auth="session", role="any")
    def account_password(req):
        d = req.json()
        try:
            store.set_password(req.user, d.get("current", ""), d.get("new", ""))
        except AccountError as e:
            _err(e)
        req.audit_detail = "changed own password"
        # the change invalidates every session issued before now, this one included: hand back a fresh cookie
        return mw.Response.json({"ok": True}, headers=[app.session_cookie(req.user)])
