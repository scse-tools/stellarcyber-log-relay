"""
logfields.py - break one log line into the fields a person can pick from, and mask what must not be shown.

Used by the Log Relay Manager's "Add log source" dialog: paste a raw log (or the JSON of a platform record),
see its key/value pairs, click the one that identifies the device (a FortiGate devid) or the one that splits
one device into sub-tenants (a FortiGate VDOM, vd=). The relay's own parser (syslog-ng kv-parser) reads the
RAW log, so the names here are the raw keys: that is why a raw log, not the platform's parsed record, is
what a mapping should be built from. A parsed record still helps to discover the fields, and is labelled.

Standard library only. Nothing here is executed; the text is only split.
"""
import json
import csv
import re

KV = re.compile(r'(?<![\w.-])([A-Za-z_][\w.-]{0,63})=("((?:[^"\\]|\\.)*)"|\'([^\']*)\'|([^\s,]+))')
# The same idea for a JSON body: "key": "value". The nginx relay forwards JSON, so without this a name
# sitting in a posted body was masked in the parsed FIELDS and still in the clear in the raw line.
JSONKV = re.compile(r'"([A-Za-z_][\w.-]{0,63})"(\s*:\s*)"((?:[^"\\]|\\.)*)"')
CEF = re.compile(r"^(?:<\d+>)?(?:\S+\s+)?CEF:(\d+)\|([^|]*)\|([^|]*)\|([^|]*)\|([^|]*)\|([^|]*)\|([^|]*)\|(.*)$", re.S)
PRI = re.compile(r"^<(\d{1,3})>")
IPV4 = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
# three colons at least: "10:21:33" is a time of day, not an address
IPV6 = re.compile(r"\b(?:[0-9a-fA-F]{1,4}:){3,7}[0-9a-fA-F]{1,4}\b")
MAC = re.compile(r"\b(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\b")
EMAIL = re.compile(r"\b[\w.+-]+@[\w-]+(?:\.[\w-]+)+\b")
# more classes of personal data in free text: phone numbers (7+ digits with separators), card-like digit runs,
# a user name inside a URL (scheme://user:secret@host), and Windows DOMAIN\user pairs
# Only SEPARATED digit groups are taken for a card number: a bare 15-digit run is a PAN-OS serial (the device's
# identity) and "2026-09-18 10" is a timestamp, so neither a free-text phone pattern nor an unseparated card
# pattern is safe in a log line. Phone numbers are masked by FIELD NAME (phone, msisdn) instead.
CARD = re.compile(r"\b\d{4}[ -]\d{4}[ -]\d{4}[ -]\d{1,7}\b")
URLUSER = re.compile(r"(\w+://)([^/\s:@]+)(:[^/\s@]*)?@")
DOMUSER = re.compile(r"\b([A-Za-z0-9_-]{2,})\\([A-Za-z0-9._-]{2,})\b")
# field names whose VALUES are personal: masked whatever they contain (a device's own identifiers are not here on purpose)
PERSONAL = {"user", "username", "srcuser", "dstuser", "suser", "duser", "email", "mail", "phone", "msisdn", "account",
            "login", "userid", "user_id", "src_user", "dst_user", "authuser", "cn", "displayname", "given_name", "surname",
            "name", "fullname", "firstname", "lastname", "first_name", "last_name", "targetusername", "subjectusername",
            "user_name", "src_user_name", "dst_user_name", "usr", "ssn", "passport", "dob", "birthdate", "employee_id",
            "recipient", "sender", "from", "to", "caller", "callee", "owner", "contact"}
MASKED_NOTE = "masked before leaving the relay: IP and MAC addresses, e-mail, card numbers, user names and personal fields (user, phone, name...) become tokens (the same value gives the same token); device identifiers stay, since the mapping keys on them"
# names that commonly identify the DEVICE (never masked: they are exactly what the mapping keys on)
IDENTITY_HINTS = ["devid", "serial", "sn", "device_id", "deviceid", "devname", "hostname", "host", "device_name", "origin", "dvc", "dvchost"]
SPLIT_HINTS = ["vd", "vdom", "vsys", "vrf", "zone", "tenant", "customer", "site", "context", "instance", "vsys_name"]


# ---------------------------------------------------------------- columns that have a documented name
# A comma-separated log carries no field names, so "column 16" says where a value is but not WHAT it is
# (Paul, 21 Sep 2026: "how do I know when one is the devid or serial number?"). Palo Alto publishes the
# field order per log TYPE, and the type is itself column 4 - so the names can be put beside the values.
#
# Only PAN-OS is listed, because it is the one device type in this kit whose logs have no key names.
# The names are Palo Alto's own, checked value by value against a real line from a lab firewall
# (col3 the serial, col16 vsys1, col21 the log-forwarding profile, col31 the action, and so on).
# A device on an older PAN-OS release, or a log type not listed here, gets no names rather than wrong
# ones: the console says where a name came from and that the value beside it is the proof.
PAN_COMMON = {
    1: "syslog header + FUTURE_USE", 2: "Receive Time", 3: "Serial Number", 4: "Type",
    5: "Threat/Content Type (subtype)", 6: "FUTURE_USE", 7: "Generated Time", 8: "Source Address",
    9: "Destination Address", 10: "NAT Source IP", 11: "NAT Destination IP", 12: "Rule Name",
    13: "Source User", 14: "Destination User", 15: "Application", 16: "Virtual System (vsys)",
    17: "Source Zone", 18: "Destination Zone", 19: "Inbound Interface", 20: "Outbound Interface",
    21: "Log Action", 22: "Time Logged", 23: "Session ID", 24: "Repeat Count", 25: "Source Port",
    26: "Destination Port", 27: "NAT Source Port", 28: "NAT Destination Port", 29: "Flags",
    30: "Protocol", 31: "Action",
}
PAN_TRAFFIC = {
    32: "Bytes", 33: "Bytes Sent", 34: "Bytes Received", 35: "Packets", 36: "Start Time",
    37: "Elapsed Time (sec)", 38: "Category", 39: "FUTURE_USE", 40: "Sequence Number",
    41: "Action Flags", 42: "Source Country", 43: "Destination Country", 44: "FUTURE_USE",
    45: "Packets Sent", 46: "Packets Received", 47: "Session End Reason",
    48: "Device Group Hierarchy 1", 49: "Device Group Hierarchy 2", 50: "Device Group Hierarchy 3",
    51: "Device Group Hierarchy 4", 52: "Virtual System Name", 53: "Device Name", 54: "Action Source",
    55: "Source VM UUID", 56: "Destination VM UUID", 57: "Tunnel ID/IMSI", 58: "Monitor Tag/IMEI",
    59: "Parent Session ID", 60: "Parent Start Time", 61: "Tunnel Type",
}
PAN_THREAT = {
    32: "URL / Filename", 33: "Threat ID", 34: "Category", 35: "Severity", 36: "Direction",
    37: "Sequence Number", 38: "Action Flags", 39: "Source Country", 40: "Destination Country",
    41: "FUTURE_USE", 42: "Content Type", 43: "PCAP ID", 44: "File Digest", 45: "Cloud Address",
    46: "URL Index", 47: "User Agent", 48: "File Type", 49: "X-Forwarded-For", 50: "Referer",
    51: "Sender", 52: "Subject", 53: "Recipient", 54: "Report ID",
    55: "Device Group Hierarchy 1", 56: "Device Group Hierarchy 2", 57: "Device Group Hierarchy 3",
    58: "Device Group Hierarchy 4", 59: "Virtual System Name", 60: "Device Name",
}
PAN_SYSTEM = {5: "Content/Threat Type (subsystem)", 8: "FUTURE_USE", 12: "Event ID", 13: "Object",
              16: "Virtual System (vsys)", 22: "Time Logged"}
CSV_COLUMNS = {
    "palo_alto_networks/firewall": {"": PAN_COMMON, "TRAFFIC": PAN_TRAFFIC, "THREAT": PAN_THREAT, "SYSTEM": PAN_SYSTEM},
}
# where the names come from, said wherever they are shown
COLUMN_SOURCE = {
    "palo_alto_networks/firewall": "Palo Alto's published field order for this log type (column 4 says which)",
}


def column_names(vendor, product, raw):
    """{position: documented name} for a log with no key names, or {} when nothing is known about it.
    The log TYPE decides the table past the columns every type shares, and the type is column 4."""
    table = CSV_COLUMNS.get(f"{vendor}/{product}")
    if not table:
        return {}
    cols = [c.strip() for c in PRI.sub("", raw or "").split(",")]
    kind = cols[3].upper() if len(cols) > 3 else ""
    out = dict(table.get("", {}))
    out.update(table.get(kind, {}))
    return out


def column_check(vendor, product, raw):
    """Does this log look like the published field order we hold for it? Three answers worth telling apart:
    the log TYPE is one we have a table for and its values line up (fine); the type is one we do NOT hold
    (only the columns every type shares are named, so most of the line is a bare position); or a value sits
    at a position INSIDE the documented range that has no name, which means the shape disagrees with the
    documentation - a different release, or not this device type at all. Values PAST the end of the table
    are normal: a real PAN-OS line runs to ~112 values and the published order here stops well before that."""
    table = CSV_COLUMNS.get(f"{vendor}/{product}")
    if not table:
        return {"have": False, "warn": "", "note": "No published field order is held here for this device type, so every value is known by its position only."}
    cols = [c.strip() for c in PRI.sub("", raw or "").split(",")]
    kind = cols[3].upper() if len(cols) > 3 else ""
    kinds = sorted(k for k in table if k)
    named = column_names(vendor, product, raw)
    top = max(named) if named else 0
    unnamed = [i for i, c in enumerate(cols, 1) if c and i <= top and i not in named]
    out = {"have": True, "kind": kind, "known_kind": kind in table, "documented_to": top, "values": len(cols), "unnamed": unnamed, "warn": "", "note": ""}
    if kind not in table:
        out["warn"] = (f"These fields do not match the documentation held here. This is a {kind or 'log with no type in column 4'} "
                       f"record, and the published field order here covers {', '.join(kinds)}. Only the columns every type shares are "
                       f"named; everything past column {top} is a bare position with no documented meaning. Check on the device what a "
                       f"value is before the relay is keyed on it.")
    elif unnamed:
        out["warn"] = (f"These fields do not match the documentation held here: column(s) {', '.join(str(i) for i in unnamed[:8])} carry a "
                       f"value but have no name in the published order for a {kind} record. The device may be on a different release, or "
                       f"this may not be a {vendor} log. Check on the device before keying the relay on any of them.")
    elif len(cols) > top:
        out["note"] = f"The published order held here names columns 1-{top}; this log carries {len(cols)} values, and the rest are positions with no name."
    return out


def csv_values(text):
    """The comma-separated values of a log AS IT ARRIVED, by position - value 1 is the first thing on the line,
    syslog header included (it carries no comma), exactly as syslog-ng's csv-parser splits the same line for a
    col<N>= row in the tenant map. Double quotes keep a value whole, as the parser's default quote pairs do.
    The relay recognizes a device by comparing one of these positions, so "seen" has to compare the same."""
    text = (text or "").strip()
    if not text:
        return []
    try:
        row = next(csv.reader([text]))
    except (csv.Error, StopIteration):
        row = text.split(",")
    return [c.strip() for c in row]


def parse(text, vendor="", product=""):
    """{"format": kv|json|cef|csv|text, "fields": [{"name", "value"}], "note": str}. Keys keep their raw
    spelling; a JSON object is flattened with dots (msg_origin.source) so nested names read as one path.
    vendor/product, when given, let a log with no key names carry the documented name of each column."""
    text = (text or "").strip()
    if not text:
        return {"format": "text", "fields": [], "note": "nothing to read"}
    if text.startswith("{") or text.startswith("["):
        try:
            obj = json.loads(text)
        except ValueError:
            obj = None
        if isinstance(obj, list) and obj and isinstance(obj[0], dict):
            obj = obj[0]
        if isinstance(obj, dict):
            fields = []
            _flatten(obj, "", fields)
            raw = next((f["value"] for f in fields if f["name"] in ("parser_raw_msg", "raw", "message", "msg", "_raw")), "")
            note = "a JSON record: field names are the platform's or the parser's, which may differ from the raw log"
            if raw and isinstance(raw, str) and "=" in raw:
                inner = parse(raw)
                if inner["fields"]:
                    return {"format": inner["format"], "fields": inner["fields"], "note": "read from the record's original log text (parser_raw_msg)", "record_fields": fields}
            return {"format": "json", "fields": fields, "note": note}
    m = CEF.match(text)
    if m:
        ver, vendor, product, version, sig, name, sev, ext = m.groups()
        fields = [{"name": "cef.vendor", "value": vendor}, {"name": "cef.product", "value": product}, {"name": "cef.version", "value": version},
                  {"name": "cef.signature", "value": sig}, {"name": "cef.name", "value": name}, {"name": "cef.severity", "value": sev}]
        fields += [{"name": k, "value": _unq(v)} for k, v in _kv_pairs(ext)]
        return {"format": "cef", "fields": fields, "note": "CEF: the header fields, then the extension's key=value pairs"}
    pairs = _kv_pairs(text)
    if len(pairs) >= 2:
        fields = [{"name": k, "value": _unq(v)} for k, v in pairs]
        return {"format": "kv", "fields": fields, "note": "key=value pairs (quoted values shown without their quotes), the shape syslog-ng's kv-parser reads"}
    body = PRI.sub("", text)
    if body.count(",") >= 5:
        # Positions, not names. syslog-ng's csv-parser splits the same line the same way, so "the 16th value"
        # is something the relay can match exactly: a row keyed col16=vsys1 sends that virtual system's logs
        # to its own tenant. Removing the <PRI> does not move any comma, so these numbers are the relay's.
        cols = [c.strip() for c in body.split(",")]
        named = column_names(vendor, product, text)
        fields = [{"name": f"col{i}", "value": c, "pos": i, "label": named.get(i, "")}
                  for i, c in enumerate(cols, 1) if c != ""]
        note = ("comma-separated with no key names (PAN-OS style): each value is named by its POSITION in the "
                "line (col1, col2, ...), which is how the relay matches it - syslog-ng splits the line the same "
                "way with its csv-parser. The position is counted from the start of the log as it arrives.")
        if named:
            note += " The name beside each value is " + COLUMN_SOURCE.get(f"{vendor}/{product}", "the vendor's published field order") + "."
        check = column_check(vendor, product, text)
        if check.get("note"):
            note += " " + check["note"]
        return {"format": "csv", "fields": fields, "columns": {str(k): v for k, v in named.items()},
                "columns_warn": check.get("warn", ""), "note": note}
    return {"format": "text", "fields": [], "note": "no key=value pairs, JSON or CSV columns found in this text"}


def _flatten(obj, prefix, out):
    for k, v in obj.items():
        name = f"{prefix}{k}"
        if isinstance(v, dict):
            _flatten(v, name + ".", out)
        elif isinstance(v, list):
            out.append({"name": name, "value": json.dumps(v)[:200]})
        else:
            out.append({"name": name, "value": "" if v is None else str(v)})


def _kv_pairs(text):
    return [(m.group(1), m.group(2)) for m in KV.finditer(text)]


def _unq(v):
    if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
        return v[1:-1].replace('\\"', '"')
    return v


class Masker:
    """Consistent masking inside one answer: the same address becomes the same token everywhere, so a reader
    can still see that two logs came from one place. Device identifiers are left alone on purpose."""

    def __init__(self):
        self.seen = {}

    def _tok(self, kind, value):
        key = (kind, value)
        if key not in self.seen:
            self.seen[key] = f"{kind}-{len([k for k in self.seen if k[0] == kind]) + 1}"
        return self.seen[key]

    def _kv_personal(self, m):
        """key=value in raw text whose KEY is personal: the value becomes a token, quotes kept."""
        name, whole = m.group(1), m.group(2)
        if name.rsplit(".", 1)[-1].lower() not in PERSONAL:
            return m.group(0)
        val = _unq(whole)
        if not val:
            return m.group(0)
        tok = self._tok("user", val)
        return f'{name}={whole[0] + tok + whole[0] if whole[:1] in ("\"", "\'") else tok}'

    def _json_personal(self, m):
        """"key": "value" in a JSON body whose KEY is personal: the value becomes the same token the
        key=value form would have given it, so one person reads as one token across both shapes."""
        name, sep, val = m.group(1), m.group(2), m.group(3)
        if name.rsplit(".", 1)[-1].lower() not in PERSONAL or not val:
            return m.group(0)
        return f'"{name}"{sep}"{self._tok("user", val)}"'

    def text(self, s):
        if not s:
            return s
        s = JSONKV.sub(self._json_personal, s)
        s = KV.sub(self._kv_personal, s)
        s = EMAIL.sub(lambda m: self._tok("email", m.group(0)), s)
        s = URLUSER.sub(lambda m: m.group(1) + self._tok("user", m.group(2)) + "@", s)
        s = DOMUSER.sub(lambda m: m.group(1) + "\\" + self._tok("user", m.group(2)), s)
        s = MAC.sub(lambda m: self._tok("mac", m.group(0)), s)
        s = IPV6.sub(lambda m: self._tok("ip6", m.group(0)), s)
        s = IPV4.sub(lambda m: self._tok("ip", m.group(0)), s)
        s = CARD.sub(lambda m: self._tok("number", m.group(0)), s)
        return s

    def field(self, name, value):
        base = name.rsplit(".", 1)[-1].lower()
        if base in PERSONAL:
            return self._tok("user", value) if value else value
        return self.text(value)

    def fields(self, fields):
        return [{"name": f["name"], "value": self.field(f["name"], f["value"])} for f in fields]


def summarize(samples):
    """Across several parsed logs from one source: which fields are present in all of them and constant
    (candidates for the device identity), which vary (candidates for a sub-tenant split), with the values seen."""
    if not samples:
        return []
    by = {}
    for i, s in enumerate(samples):
        for f in s:
            d = by.setdefault(f["name"], {"name": f["name"], "in": set(), "values": []})
            d["in"].add(i)
            if f["value"] not in d["values"]:
                d["values"].append(f["value"])
    out = []
    n = len(samples)
    for d in by.values():
        base = d["name"].rsplit(".", 1)[-1].lower()
        everywhere = len(d["in"]) == n
        constant = len(d["values"]) == 1
        role = ""
        if base in IDENTITY_HINTS and everywhere and constant:
            role = "identity"
        elif base in SPLIT_HINTS and everywhere:
            role = "split"
        out.append({"name": d["name"], "in_all": everywhere, "constant": constant, "values": d["values"][:6], "distinct": len(d["values"]),
                    "role": role, "identity_hint": base in IDENTITY_HINTS, "split_hint": base in SPLIT_HINTS})
    rank = {"identity": 0, "split": 1, "": 2}
    out.sort(key=lambda d: (rank[d["role"]], not d["in_all"], d["name"]))
    return out


# One log line per log source in the vendor's DOCUMENTED format, for the "Add log source" dialog when no real
# log has arrived yet. Shapes follow each vendor's public log reference (FortiOS log reference: key=value with
# devid/devname/vd; PAN-OS syslog field order: comma-separated, serial in field 3; Meraki: epoch + type;
# SonicOS: id=/sn=/fw= pairs; Check Point Log Exporter: RFC 5424 with a structured-data element; Sophos XG:
# key="value" with device_id; Cisco ASA %ASA-n-nnnnnn messages; Snare / Windows DNS / NXLog tab or key forms).
# Values are made up (lab serials, RFC 5737 addresses); a line is an EXAMPLE of the format, not a log from the
# customer's device, and the dialog says so.
VENDOR_SAMPLES = {
    "fortinet/fortigate": 'date=2026-09-18 time=10:21:33 devname="FGT-HQ" devid="FGTLAB0000000001" eventtime=1789896093000000000 tz="-0700" logid="0000000013" type="traffic" subtype="forward" level="notice" vd="root" srcip=192.0.2.10 srcport=51522 srcintf="port1" dstip=198.51.100.20 dstport=443 dstintf="port2" proto=6 action="accept" policyid=7 service="HTTPS" sentbyte=1420 rcvdbyte=5210 duration=12',
    "palo_alto_networks/firewall": '<14>Sep 18 10:21:33 PA-HQ 1,2026/09/18 10:21:33,007951000123456,TRAFFIC,end,2561,2026/09/18 10:21:33,192.0.2.10,198.51.100.20,0.0.0.0,0.0.0.0,allow-web,,,ssl,vsys1,trust,untrust,ethernet1/2,ethernet1/1,default,2026/09/18 10:21:33,12345,1,51522,443,0,0,0x400019,tcp,allow,6630,1420,5210,14,2026/09/18 10:21:21,12,any,0,7654321,0x0,192.0.2.0-192.0.2.255,United States,0,8,6,tcp-fin,0,0,0,0,,PA-HQ,from-policy',
    "cisco/meraki": '<134>1 1789896093.123456789 MX_HQ flows src=192.0.2.10 dst=198.51.100.20 mac=00:11:22:33:44:55 protocol=tcp sport=51522 dport=443 pattern: allow all',
    "sonicwall/firewall": '<134>id=firewall sn=0017C5LAB001 time="2026-09-18 10:21:33 UTC" fw=203.0.113.1 pri=6 c=1024 m=98 msg="Connection Opened" app=49 n=12345 src=192.0.2.10:51522:X0 dst=198.51.100.20:443:X1 proto=tcp/https',
    "checkpoint/firewall": '<134>1 2026-09-18T10:21:33Z cp-gw-hq CheckPoint 12345 - [action:"Accept"; flags:"411908"; ifdir:"inbound"; ifname:"eth0"; loguid:"{0x5f1a2b3c,0x0,0x1,0xc0000000}"; origin:"203.0.113.5"; originsicname:"CN=cp-gw-hq,O=cp-mgmt"; time:"1789896093"; version:"5"; dst:"198.51.100.20"; proto:"6"; product:"VPN-1 & FireWall-1"; rule_name:"Web out"; service:"443"; src:"192.0.2.10"; s_port:"51522"]',
    "sophos/firewall": 'device="SFW" date=2026-09-18 time=10:21:33 timezone="UTC" device_name="XG135" device_id=C01001LAB00001 log_id=010101600001 log_type="Firewall" log_component="Firewall Rule" log_subtype="Allowed" status="Allow" priority=Information fw_rule_id=7 user_name="" src_ip=192.0.2.10 src_port=51522 dst_ip=198.51.100.20 dst_port=443 protocol="TCP" in_interface="Port1" out_interface="Port2" sent_bytes=1420 recv_bytes=5210',
    "cisco/asa": '<166>Sep 18 2026 10:21:33 asa-hq : %ASA-6-302013: Built outbound TCP connection 12345 for outside:198.51.100.20/443 (198.51.100.20/443) to inside:192.0.2.10/51522 (203.0.113.1/51522)',
    "cisco/custom_vpn": '<166>Sep 18 2026 10:21:33 asa-hq : %ASA-6-722051: Group <VPN-Users> User <user1> IP <203.0.113.77> IPv4 Address <10.10.10.5> IPv6 address <::> assigned to session',
    "snare/snare_agent": '<13>Sep 18 10:21:33 WINSRV01 MSWinEventLog\t1\tSecurity\t12345\tThu Sep 18 10:21:33 2026\t4624\tMicrosoft-Windows-Security-Auditing\tN/A\tAudit Success\tWINSRV01\tLogon\t\tAn account was successfully logged on.\t12345',
    "windows/dns_server": '<13>Sep 18 10:21:33 WINDNS01 9/18/2026 10:21:33 AM 0A1C PACKET  000000ABCDEF UDP Rcv 192.0.2.10 0002 Q [0001 D NOERROR] A (3)www(7)example(3)com(0)',
    "nxlog/nxlog": '{"EventTime":"2026-09-18 10:21:33","Hostname":"WINSRV01","Keywords":-9214364837600034816,"EventType":"AUDIT_SUCCESS","SeverityValue":2,"Severity":"INFO","EventID":4624,"SourceName":"Microsoft-Windows-Security-Auditing","Channel":"Security","Message":"An account was successfully logged on.","TargetUserName":"user1","IpAddress":"192.0.2.10"}',
}


def vendor_sample(vendor, product):
    """The documented example line for one log source, or None."""
    return VENDOR_SAMPLES.get(f"{vendor}/{product}")


# The keys in a log that NAME a device. Only their example values are refused as map keys: "root" is a real
# VDOM name as well as an example one, but no real firewall has the serial printed in our sample line.
# --- what a log LOOKS like, from its own shape -------------------------------------------------------
# The device type on a record the relay forwarded comes from the TENANT MAP, so a device that is not in
# the map yet is wrapped with the CATCH-ALL row's vendor - a real FortiGate arrives labelled
# "palo_alto_networks/firewall" if that is what the catch-all says (Paul, 21 Sep 2026, watching his own
# FortiGate: "it does not see that it is fortigate in the filter"). The label is not wrong, it is just not
# about this device; the log itself says what it is, so read that and say both.
#
# Each signature must be something only that vendor writes. A key several vendors write (srcip=, action=)
# is not a signature. Mirrors tools/mock-sensor.py RAW_SIGNATURES, in the map's vendor/product pairs -
# keep the two in step when a vendor is added.
LOOKS_LIKE = [
    ("fortinet", "fortigate", re.compile(r'\bdevname="[^"]*" (?:devid="[^"]*" )?eventtime=\d+')),
    ("palo_alto_networks", "firewall",
     re.compile(r'^(?:<\d+>)?(?:\w{3} +\d+ \d\d:\d\d:\d\d \S+ )?1,[\d/]+ [\d:]+,[^,]*,'
                r'(?:TRAFFIC|THREAT|SYSTEM|CONFIG|HIPMATCH|USERID|GLOBALPROTECT|DECRYPTION),')),
    ("cisco", "meraki", re.compile(r'^<\d+>1 \d+(?:\.\d+)? \S+ '
                                   r'(?:flows|urls|ids-alerts|events|security_event|air_marshal_events)\b')),
    ("sonicwall", "firewall", re.compile(r'^(?:<\d+>)?\s*id=firewall sn=\S+')),
    ("checkpoint", "firewall", re.compile(r'^<\d+>1 \S+ \S+ CheckPoint \S+ - \[action:"')),
    ("sophos", "firewall", re.compile(r'^(?:<\d+>)?device="SFW" date=\S+ time=\S+')),
    ("cisco", "asa", re.compile(r'%ASA-\d-\d+:')),
]
# CEF says who it is in its own header, so it needs no signature of its own: CEF:0|Fortinet|FortiGate|...
CEF_VENDORS = {
    ("fortinet", "fortigate"): ("fortinet", "fortigate"), ("fortinet", "fortios"): ("fortinet", "fortigate"),
    ("palo alto networks", "pan-os"): ("palo_alto_networks", "firewall"),
    ("sonicwall", "sonicwall"): ("sonicwall", "firewall"),
    ("check point", "vpn-1 & firewall-1"): ("checkpoint", "firewall"),
    ("sophos", "sfw"): ("sophos", "firewall"), ("sophos", "xg"): ("sophos", "firewall"),
    ("cisco", "meraki"): ("cisco", "meraki"),
}


def looks_like(raw):
    """(vendor, product) that the log's own shape says it is, or None when nothing is sure enough to say.

    Deliberately conservative: None is a fine answer and is better than a guess, because this is shown
    next to the map's own label and is used to filter what a person is watching for."""
    text = raw if isinstance(raw, str) else ""
    if not text:
        return None
    m = CEF.match(text.strip())
    if m:
        return CEF_VENDORS.get((m.group(2).strip().lower(), m.group(3).strip().lower()))
    for vendor, product, rx in LOOKS_LIKE:
        if rx.search(text):
            return (vendor, product)
    return None


IDENTITY_KEYS = ("devid", "devname", "serial", "sn", "hostname", "host", "device_id", "device_name", "origin", "dvc", "deviceid")


def example_values():
    """The DEVICE IDENTIFIERS that appear in the documented example lines. A map row built on one of these
    would match nothing: the field names in those lines are real, the values are invented. Used to refuse a
    save that was built from an example instead of from the device's own log."""
    out = set()
    for raw in VENDOR_SAMPLES.values():
        for f in parse(raw)["fields"]:
            name = (f.get("name") or "").strip().lower()
            v = (f.get("value") or "").strip()
            if name in IDENTITY_KEYS and len(v) >= 4 and not v.isdigit():
                out.add(v)
    return out
