"""
microweb.py - a small, dependency-free web framework for the lab apps.

Standard library only (http.server, ssl, sqlite3, hmac, json). Provides:

  * Router with path parameters:  @app.route("GET", "/api/runs/{run_id}")
  * JSON request/response helpers, static file serving with cache headers
  * Signed, expiring session cookies (HMAC-SHA256), CSRF defence for
    state-changing requests (SameSite=Strict cookie + required custom header)
  * Two auth modes: browser session (login form) and API token (X-Api-Token)
  * Threaded HTTPS server with a self-signed certificate generated on first run

It is deliberately small. It is not a general-purpose framework; it is what
these two apps need, written so a non-developer can read it top to bottom.
"""
import base64
import hashlib
import hmac
import json
import mimetypes
import os
import re
import secrets
import socket
import ssl
import subprocess
import sys
import threading
import time
import traceback
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

SESSION_COOKIE = "lab_session"
SESSION_TTL = 12 * 3600          # seconds a login stays valid
# A session SLIDES: once it is past this fraction of its life, any authenticated request re-issues the
# cookie for another full TTL. Without it the 12 hours run from the sign-in whatever the person is doing,
# so someone half-way through configuring a log source is signed out mid-form and loses the work (Paul,
# 22 Sep 2026: "I've been working on getting this set up, and then I get to the end and find I'm logged
# out"). Idle still expires, which is the point of having a TTL at all.
SESSION_RENEW_AFTER = 0.5
# A request renews the session only when a PERSON is behind it: a write, or a read the page marks with this
# header because a key, click, scroll or touch happened in the last 30 s. A page refreshing itself every 5 s
# is not activity, or an open tab would keep a sign-in alive for ever (Paul, 24 Sep 2026: an inactivity
# timeout, one hour by default, set in Admin > Settings).
ACTIVE_HEADER = "X-Active"
CSRF_HEADER = "X-Requested-With"  # browsers cannot add this cross-site without CORS preflight


# ----------------------------------------------------------------------------- errors
class HttpError(Exception):
    def __init__(self, status, message, **extra):
        super().__init__(message)
        self.status, self.message, self.extra = status, message, extra


# ----------------------------------------------------------------------------- request
class Request:
    def __init__(self, handler, params):
        self.h = handler
        self.method = handler.command
        parts = urlsplit(handler.path)
        self.path = parts.path
        self.query = {k: v[0] for k, v in parse_qs(parts.query).items()}
        self.params = params
        self.headers = handler.headers
        self.client_ip = handler.client_address[0]
        self.user = None            # set by auth
        self.auth_kind = None       # "session" | "token"
        self.role = None            # "admin" | "readonly" once authenticated
        self.session_exp = None     # the cookie's expiry (session auth only)
        self.session_ttl = None     # the cookie's own inactivity timeout, seconds
        self.audit_detail = None    # a route may set this: one sentence for the audit log
        self._body = None

    # The most a request body read into memory may be. Every JSON route reads its body whole (req.json()), and
    # so did the audit hook for a request refused by role - so a token or an account could POST hundreds of
    # megabytes to any route and have this process hold them (measured: a 96 MB body took the console from 43
    # to 427 MB RSS; review, 7 Oct 2026). On a 2 GB relay holding syslog-ng under a backlog that is the OOM
    # killer's choice. The largest legitimate body here is a log-source CSV of a few thousand rows or a
    # configuration file of a few hundred KB; an update bundle goes through save_body, which streams.
    MAX_BODY = 16 * 1024 * 1024

    def body(self):
        if self._body is None:
            try:
                n = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                raise HttpError(400, "the request's Content-Length is not a number")
            if n > self.MAX_BODY:
                self.h.close_connection = True      # nothing of it is read: the connection is dropped after the answer
                self.h.body_read = n
                raise HttpError(413, f"that request is {n} bytes; the most this console reads is {self.MAX_BODY}")
            self._body = self.h.rfile.read(n) if n else b""
            self.h.body_read = n
        return self._body

    def save_body(self, path, max_bytes, mode=0o600):
        """Stream the request body to a file, never through memory, and never past max_bytes.

        An update bundle is half a megabyte today and could be larger; req.body() would read the whole
        of it into the console's address space, and a caller who declares a huge Content-Length would
        decide how much memory this process uses. Written to a .part first and renamed, so a half-sent
        upload is never mistaken for a whole one. Returns (bytes written, sha256 hex)."""
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0:
            raise HttpError(400, "no file was sent")
        if n > max_bytes:
            raise HttpError(413, f"that file is {n} bytes; the most this accepts is {max_bytes}")
        h = hashlib.sha256()
        tmp = path + ".part"
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        got = 0
        try:
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, mode)
            with os.fdopen(fd, "wb") as f:
                while got < n:
                    chunk = self.h.rfile.read(min(1 << 20, n - got))
                    if not chunk:
                        break
                    got += len(chunk)
                    h.update(chunk)
                    f.write(chunk)
        except OSError as e:
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise HttpError(500, f"the upload could not be written: {e}")
        self.h.body_read = got
        self._body = b""                       # it is on disk; nothing may re-read it from the socket
        if got != n:
            os.remove(tmp)
            raise HttpError(400, f"the upload stopped after {got} of {n} bytes")
        os.replace(tmp, path)
        return got, h.hexdigest()

    def json(self):
        raw = self.body()
        if not raw:
            return {}
        try:
            data = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise HttpError(400, "request body is not valid JSON")
        if not isinstance(data, dict):
            raise HttpError(400, "request body must be a JSON object")
        return data

    def cookie(self, name):
        c = SimpleCookie(self.headers.get("Cookie", ""))
        return c[name].value if name in c else None


# ----------------------------------------------------------------------------- response
class Response:
    def __init__(self, status=200, body=b"", content_type="application/json", headers=None):
        # A body handed over as TEXT is encoded here, once, for every route. The writer sends the headers and
        # THEN writes the body as bytes; a str body passed the Content-Length line, failed at the write, and the
        # connection closed with nothing after the headers - which a browser reports as "Failed to fetch", with
        # the request apparently never answered. That was the CA download on 1.1.49 (Paul, 5 Oct 2026: "I still
        # cannot download the CA"), and the syslog-ng certificate downloads had the same shape. Encoding here
        # also makes Content-Length count bytes, not characters, for any text that is not plain ASCII.
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.status, self.body, self.content_type = status, body, content_type
        self.headers = headers or []

    @staticmethod
    def json(data, status=200, headers=None):
        return Response(status, json.dumps(data, default=str).encode(), "application/json", headers)

    @staticmethod
    def text(s, status=200, content_type="text/plain; charset=utf-8"):
        return Response(status, s.encode(), content_type)

    @staticmethod
    def redirect(location):
        return Response(302, b"", "text/plain", [("Location", location)])


# ----------------------------------------------------------------------------- sessions
class SessionSigner:
    """user|expiry|hmac  -> base64; tamper-proof and expiring."""

    def __init__(self, secret: bytes):
        self.secret = secret

    def make(self, user, ttl=SESSION_TTL):
        """user|expiry|ttl|hmac. The ttl rides in the cookie so "when was this issued" (expiry - ttl, which is how a
        password change invalidates older sessions) stays right after an administrator changes the timeout."""
        ttl = int(ttl)
        exp = int(time.time()) + ttl
        payload = f"{user}|{exp}|{ttl}".encode()
        # the signature is hex so the '|' separator can never occur inside it
        sig = hmac.new(self.secret, payload, hashlib.sha256).hexdigest().encode()
        return base64.urlsafe_b64encode(payload + b"|" + sig).decode()

    def verify(self, token):
        user, _ = self.verify_full(token)
        return user

    def verify_full(self, token):
        """(user, expiry) for a good token, (None, None) otherwise."""
        user, exp, _ttl, ok = self.parse(token)
        return (user, exp) if ok else (None, None)

    def parse(self, token):
        """(user, expiry, ttl, ok): a well-signed token with ok=False is one that has EXPIRED, which the app
        tells the person (signed out after N minutes without activity) rather than 'authentication required'.
        A token from before the ttl field (user|expiry|hmac) still verifies, with the framework's default ttl."""
        try:
            raw = base64.urlsafe_b64decode(token.encode())
            payload, sig = raw.rsplit(b"|", 1)
            parts = payload.decode().split("|")
            user, exp = parts[0], int(parts[1])
            ttl = int(parts[2]) if len(parts) > 2 else SESSION_TTL
        except Exception:  # noqa: BLE001
            return None, None, None, False
        good = hmac.new(self.secret, payload, hashlib.sha256).hexdigest().encode()
        if not hmac.compare_digest(good, sig):
            return None, None, None, False
        return user, exp, ttl, exp >= time.time()


# ----------------------------------------------------------------------------- password hashing (scrypt, stdlib)
def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    key = hashlib.scrypt(password.encode(), salt=salt, n=2 ** 14, r=8, p=1, dklen=32)
    return "scrypt$" + base64.b64encode(salt).decode() + "$" + base64.b64encode(key).decode()


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, salt, key = stored.split("$")
        if algo != "scrypt":
            return False
        calc = hashlib.scrypt(password.encode(), salt=base64.b64decode(salt), n=2 ** 14, r=8, p=1, dklen=32)
        return hmac.compare_digest(calc, base64.b64decode(key))
    except Exception:  # noqa: BLE001
        return False


# ----------------------------------------------------------------------------- app
class _Outcomes:
    """At-most-once writes (8 Oct 2026). The page tags every write with X-Request-Id. The first arrival runs the
    route and its answer is remembered here for a while; a second arrival with the same id - the page retrying
    after its connection dropped - is answered from memory instead of being applied again, and one that meets
    the first run still in progress waits for it. Keyed by (user, auth kind, id), so an account can only ever
    replay its own requests. Kept in memory: a console restart forgets them, and the outcome route says so."""
    TTL, MAX, WAIT = 1800, 500, 90

    def __init__(self):
        self.lock = threading.Lock()
        self.done = {}          # key -> (expires, record)
        self.inflight = {}      # key -> threading.Event

    def claim(self, key):
        """('done', record) if already answered; ('wait', event) if the first run is still going; ('mine', None)
        when this caller is the first and must run the route."""
        with self.lock:
            self._purge()
            e = self.done.get(key)
            if e:
                return "done", e[1]
            ev = self.inflight.get(key)
            if ev is not None:
                return "wait", ev
            ev = threading.Event()
            self.inflight[key] = ev
            return "mine", None

    def wait_for(self, key, ev):
        """The remembered record once the first run finishes, or None if it is still running after WAIT seconds."""
        ev.wait(self.WAIT)
        with self.lock:
            e = self.done.get(key)
            return e[1] if e else None

    def finish(self, key, resp, detail=None, ok=True):
        rec = (resp.status, resp.content_type, bytes(resp.body), list(resp.headers), detail, bool(ok))
        with self.lock:
            self.done[key] = (time.time() + self.TTL, rec)
            ev = self.inflight.pop(key, None)
        if ev is not None:
            ev.set()

    def state(self, key):
        with self.lock:
            if key in self.done:
                return "done", self.done[key][1]
            if key in self.inflight:
                return "inflight", None
            return None, None

    @staticmethod
    def replay(rec):
        status, ctype, body, headers, _detail, _ok = rec
        return Response(status, body, ctype, headers + [("X-Replayed", "1")])

    def _purge(self):
        now = time.time()
        for k in [k for k, (exp, _) in self.done.items() if exp < now]:
            del self.done[k]
        if len(self.done) > self.MAX:
            for k in sorted(self.done, key=lambda k: self.done[k][0])[:len(self.done) - self.MAX]:
                del self.done[k]


class App:
    def __init__(self, name, static_dirs, secret, admin_user, admin_hash, api_token=None, user_store=None, audit=None):
        """user_store: an accounts.UserStore; without one the single installer account is the only login
        and it is an admin. audit: an auditlog.AuditLog; with one, every state-changing request and every
        sign-in attempt is recorded (see handle())."""
        self.name = name
        self.static_dirs = [d for d in static_dirs if d and os.path.isdir(d)]
        self.signer = SessionSigner(secret)
        # How long a sign-in lives without activity: seconds, or a callable returning seconds, so an app can
        # read it from a setting an administrator changes live. The framework's default is SESSION_TTL.
        self.session_ttl = SESSION_TTL
        self.admin_user, self.admin_hash = admin_user, admin_hash
        self.api_token = api_token
        # An app may decide what its API TOKEN is allowed to do: token_policy(req) is called on every
        # request the token authenticated, and raises HttpError to refuse it. The Log Relay Manager uses
        # it to keep configuration changes from Ingest Studio off unless someone turned them on here.
        self.token_policy = None
        # An app may refuse an already-authenticated request before its route runs: request_policy(req)
        # raises HttpError to do it. The relay uses it so a console whose licence has not been accepted
        # can do nothing except accept it - a gate, rather than a page that is merely not shown.
        self.request_policy = None
        self.user_store, self.audit = user_store, audit
        self.routes = []            # (method, regex, fn, auth, csrf, role)
        self.login_attempts = {}    # ip -> [timestamps]
        self.lock = threading.Lock()
        self.outcomes = _Outcomes()
        self.started = time.time()

        # What became of a write whose answer the page never received (the connection dropped and the
        # console stayed unreachable past the page's retries): the remembered answer, "still running",
        # or no record - which means it never arrived, unless the console has restarted since (it says when).
        @self.route("GET", "/api/outcome/{rid}", auth="any")
        def _outcome(req):
            key = (req.user or "?", req.auth_kind or "?", req.params["rid"])
            state, rec = self.outcomes.state(key)
            if state == "inflight":
                return Response.json({"pending": True}, 202)
            if state is None:
                raise HttpError(404, "no record of that request here", since=self.started)
            status, ctype, body, _headers, detail, ok = rec
            answer = None
            if ctype.startswith("application/json"):
                try:
                    answer = json.loads(body.decode("utf-8", "replace"))
                except ValueError:
                    answer = None
            return {"status": status, "ok": 200 <= status < 300 and ok, "detail": detail, "answer": answer}

    # ---- routing --------------------------------------------------------------
    def route(self, method, pattern, auth="session", csrf=True, role=None):
        """auth: 'session' (browser login), 'token' (X-Api-Token), 'any' (either), None (public).
        csrf: require the X-Requested-With header on non-GET requests (default). Only routes that
        non-browser clients POST to without a login, such as a plain ingest endpoint, set csrf=False.
        role: 'admin' or 'any'. The default is the rule every page follows: GET and HEAD are open to
        every signed-in account, anything else needs an admin. A write a read-only account may do
        (changing its own password) says role='any'; a read only admins may see says role='admin'."""
        regex = re.compile("^" + re.sub(r"{(\w+)}", r"(?P<\1>[^/]+)", pattern) + "$")
        if role is None:
            role = "any" if method in ("GET", "HEAD") else "admin"

        def deco(fn):
            self.routes.append((method, regex, fn, auth, csrf, role))
            return fn
        return deco

    _RID = re.compile(r"[A-Za-z0-9_-]{8,64}")

    def _outcome_key(self, req):
        """(user, auth kind, id) for a write that carries a well-formed X-Request-Id; None for anything else."""
        if req.method in ("GET", "HEAD"):
            return None
        rid = (req.headers.get("X-Request-Id") or "").strip()
        if not self._RID.fullmatch(rid):
            return None
        return (req.user or "?", req.auth_kind or "?", rid)

    def _match(self, method, path):
        for m, rx, fn, auth, csrf, role in self.routes:
            if m == method:
                mm = rx.match(path)
                if mm:
                    return fn, (auth, csrf, role), mm.groupdict()
        return None, None, None

    # ---- auth -----------------------------------------------------------------
    def _authenticate(self, req, auth_spec):
        auth, csrf, role = auth_spec
        token = req.headers.get("X-Api-Token")
        if auth in ("token", "any") and token and self.api_token and hmac.compare_digest(token, self.api_token):
            req.user, req.auth_kind, req.role = "api", "token", "admin"     # the token is automation: it may write
            if self.token_policy:
                self.token_policy(req)      # ... as far as this app lets it
            return
        # CSRF: every state-changing browser request must carry the custom header, including login
        if csrf and req.method not in ("GET", "HEAD") and req.headers.get(CSRF_HEADER) != "microweb":
            raise HttpError(403, "missing CSRF header")
        if auth is None:
            return
        if auth in ("session", "any"):
            cookie = req.cookie(SESSION_COOKIE)
            user, exp, ttl, ok = self.signer.parse(cookie) if cookie else (None, None, None, False)
            if user and not ok:
                # well signed, expired: say what happened, in minutes a person recognizes
                mins = max(1, int((ttl or SESSION_TTL) // 60))
                raise HttpError(401, f"signed out after {mins} minute{'s' if mins != 1 else ''} without activity; sign in again")
            if user:
                req.user, req.auth_kind = user, "session"
                req.session_exp = exp        # the page's "your session" block reads issued/expires from it
                req.session_ttl = ttl
                req.role = self.role_of(user, exp - ttl if exp else None)
                if req.role is None:
                    raise HttpError(401, "this session is no longer valid; sign in again")
                # Still working: give the session its full life back rather than expiring under them. Only a
                # person's activity counts (a write, or a read the page marked X-Active); a page polling on its
                # own never renews, so an idle sign-in ends after the timeout however long the tab stays open.
                # A refused request is not renewed: the read-only account's refused sign-out used to come back
                # with a FRESH cookie, so pressing Sign out extended the session it was meant to end.
                if role == "admin" and req.role != "admin":
                    req.refused_role = True
                    raise HttpError(403, "this account is read-only: it can look, not change")
                active = req.method not in ("GET", "HEAD") or req.headers.get(ACTIVE_HEADER) == "1"
                if active and exp - time.time() < self.ttl() - 60:
                    req.renew_session = user
                return
        raise HttpError(401, "authentication required")

    def role_of(self, user, issued_at=None):
        """admin | readonly | None (unknown or disabled account, or a session older than its password)."""
        if self.user_store is not None:
            return self.user_store.role(user, issued_at)
        return "admin" if user == self.admin_user else None

    def check_login(self, user, password, ip):
        """Rate-limited credential check: 5 failures per 5 minutes per IP."""
        now = time.time()
        with self.lock:
            attempts = [t for t in self.login_attempts.get(ip, []) if now - t < 300]
            self.login_attempts[ip] = attempts
            if len(attempts) >= 5:
                raise HttpError(429, "too many failed logins; try again in a few minutes")
        if self.user_store is not None:
            ok = self.user_store.verify(user, password) is not None
            if ok:
                self.user_store.touch_login(user, ip)
        else:
            ok = user == self.admin_user and verify_password(password, self.admin_hash)
        if not ok:
            with self.lock:
                self.login_attempts.setdefault(ip, []).append(now)
        return ok

    def ttl(self):
        """The inactivity timeout in seconds, never under a minute."""
        v = self.session_ttl() if callable(self.session_ttl) else self.session_ttl
        try:
            return max(60, int(v))
        except (TypeError, ValueError):
            return SESSION_TTL

    def session_cookie(self, user):
        ttl = self.ttl()
        tok = self.signer.make(user, ttl)
        return ("Set-Cookie", f"{SESSION_COOKIE}={tok}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age={ttl}")

    @staticmethod
    def clear_cookie():
        return ("Set-Cookie", f"{SESSION_COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0")

    # ---- static ---------------------------------------------------------------
    def _static(self, path):
        rel = path.lstrip("/") or "index.html"
        if ".." in rel.split("/"):
            return None
        for d in self.static_dirs:
            full = os.path.join(d, rel)
            if os.path.isfile(full):
                ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
                if ctype.startswith("text/") or ctype in ("application/javascript", "application/json"):
                    ctype += "; charset=utf-8"
                # "no-cache" without a validator is advisory: Chrome may still hand back the copy it
                # has, which is how a console keeps showing yesterday's page.js after a deploy. The files
                # this kit edits are small and read from a lab console, so they are never stored.
                fresh = rel.endswith((".js", ".css", ".html"))
                with open(full, "rb") as f:
                    return Response(200, f.read(), ctype, [("Cache-Control", "no-store, must-revalidate" if fresh else "no-cache")])
        return None

    # ---- dispatch -------------------------------------------------------------
    build_id = ""          # set by the app: "<version> <build>", sent as X-App-Build on every answer

    def handle(self, handler):
        method = handler.command
        path = urlsplit(handler.path).path
        fn, auth, params = self._match(method, path)
        req = None
        key, owned = None, False
        try:
            if fn is None:
                if method == "GET":
                    resp = self._static(path)
                    if resp is None and not path.startswith("/api/"):
                        resp = self._static("/index.html")     # SPA fallback
                    if resp:
                        return resp
                raise HttpError(404, f"no route for {method} {path}")
            req = Request(handler, params)
            self._authenticate(req, auth)
            if self.request_policy is not None:
                self.request_policy(req)
            key = self._outcome_key(req)
            state, val = self.outcomes.claim(key) if key else ("mine", None)
            if state == "done":
                req.replayed = True
                resp = _Outcomes.replay(val)
            elif state == "wait":
                req.replayed = True
                rec = self.outcomes.wait_for(key, val)
                resp = _Outcomes.replay(rec) if rec else Response.json({"pending": True, "id": key[2]}, 202)
            else:
                owned = key is not None
                result = fn(req)
                resp = result if isinstance(result, Response) else Response.json(result if result is not None else {"ok": True})
        except HttpError as e:
            resp = Response.json({"error": e.message, **e.extra}, e.status)
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            resp = Response.json({"error": f"internal error: {e.__class__.__name__}: {e}"}, 500)
        # the answer is remembered BEFORE it is written, so a client whose connection dropped mid-write can ask
        # for it again and get this very answer, not a second application
        if owned:
            self.outcomes.finish(key, resp, detail=getattr(req, "audit_detail", None), ok=getattr(req, "audit_ok", True))
        # a session that was renewed carries its new cookie on whatever answer it was making - unless that answer
        # sets the session cookie itself. Sign-out clears it, and a renewal appended AFTER the clear is the one a
        # browser keeps: every sign-out more than a minute after the last renewal left the session alive.
        sets_own = any(k.lower() == "set-cookie" and v.startswith(SESSION_COOKIE + "=") for k, v in resp.headers)
        if req is not None and getattr(req, "renew_session", None) and resp.status != 401 and not sets_own:
            resp.headers = list(resp.headers) + [self.session_cookie(req.renew_session)]
        if self.audit is not None and req is not None and not getattr(req, "replayed", False):
            try:
                self._audit(req, resp)
            except Exception:  # noqa: BLE001  the record must never cost the answer
                traceback.print_exc()
        return resp

    def _audit(self, req, resp):
        """One line for every request that can change something, for every sign-in attempt, for every
        sign-out, and for every write refused because the account is read-only. Plain reads are not
        recorded: they would drown the file and say nothing about who changed what."""
        method, path = req.method, req.path
        is_login, is_logout = path.endswith("/api/login"), path.endswith("/api/logout")
        if method in ("GET", "HEAD") and not is_logout:
            return
        if resp.status == 401 and not is_login:
            return                      # not signed in at all: an expired session, not an act by a person
        # the body names what was attempted (which mapping, which account); a write refused before the
        # route ran has not read it yet, so read it here - it is what the drain would read anyway
        body = None
        try:
            body = req.json() if (is_login or method not in ("GET", "HEAD")) else None
        except (HttpError, OSError):
            body = None
        user = req.user
        if is_login and isinstance(body, dict):
            user = str(body.get("user", ""))[:64] or "?"
        # a route that answers 200 with a failure inside (a validator that rejected a draft) says so with req.audit_ok = False
        ok = 200 <= resp.status < 300 and getattr(req, "audit_ok", True)
        if is_login:
            action, kind = ("signed in" if ok else "sign-in refused" + (" (locked out)" if resp.status == 429 else "")), "login"
        elif is_logout:
            action, kind = "signed out", "login"
        elif getattr(req, "refused_role", False):
            action, kind = "refused: read-only account tried " + self.audit.describe(method, path, req.params, body), "refused"
        else:
            action, kind = self.audit.describe(method, path, req.params, body), "change"
        self.audit.record(user=user or "?", role=getattr(req, "role", None), via=req.auth_kind or ("login" if is_login else "?"),
                          ip=req.client_ip, method=method, path=path, status=resp.status, ok=ok, action=action,
                          detail=getattr(req, "audit_detail", None), kind=kind,
                          reason=None if ok else _failure_reason(resp))


def _failure_reason(resp):
    """Why a request failed, in the answer's own words, for the audit log. A failed row that says only
    "failed 400" makes the reader guess; the sentence the caller was shown is what they need."""
    try:
        if not resp.content_type.startswith("application/json"):
            return None
        data = json.loads(resp.body.decode("utf-8", "replace"))
    except (ValueError, AttributeError, UnicodeDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    parts = [str(data[k]) for k in ("error", "detail") if data.get(k)]
    return " - ".join(parts)[:600] or None


class _Handler(BaseHTTPRequestHandler):
    app: App = None
    server_version = "microweb/1.0"
    # Keep the TCP+TLS connection open for several requests (HTTP/1.1), instead of a fresh handshake per
    # request (the HTTP/1.0 default). A page polls itself every few seconds and loads a large source list,
    # so one request per connection meant a stream of TLS handshakes - and over a home/WAN link a fraction
    # of them stall or are aborted by the browser (certificate_unknown), which is why a Save on a busy relay
    # "did nothing" (Paul, 7 Oct 2026). Every answer carries an accurate Content-Length (see _serve), which
    # is what lets the client reuse the connection; _drain_body closes it when a body was left unread or a
    # request was refused. The 60 s socket timeout above reaps an idle connection.
    protocol_version = "HTTP/1.1"
    # applied to every connection's socket by StreamRequestHandler.setup(): a client that connects and then
    # sends nothing holds its thread for this long and no longer (the TLS path set 60 s on the wrapped socket;
    # the plain path had no timeout at all - review, 7 Oct 2026)
    timeout = 60

    def log_message(self, fmt, *args):  # quieter access log: only non-2xx
        try:
            code = int(args[1])
        except (IndexError, ValueError):
            code = 0
        if code >= 400:
            super().log_message(fmt, *args)

    def _serve(self):
        resp = self.app.handle(self)
        self._drain_body(resp.status)
        self.send_response(resp.status)
        self.send_header("Content-Type", resp.content_type)
        self.send_header("Content-Length", str(len(resp.body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:")
        # The build this process is running, on every answer. A page keeps running the JavaScript it loaded,
        # so an upgrade under an open tab leaves the person driving the old console with no sign of it - the
        # Cache-Control above is honoured but nothing re-fetches. lab.js remembers the first build it sees and
        # offers a reload when it changes (Paul, 25 Sep 2026: "I've had to do that a couple of times").
        if getattr(self.app, "build_id", ""):
            self.send_header("X-App-Build", self.app.build_id)
        for k, v in resp.headers:
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(resp.body)
            except (BrokenPipeError, ConnectionResetError):
                # The client went away while the answer was being sent - a browser leaving a page whose
                # /api/sources answer is megabytes long (relay3, 7 Oct 2026, a 4,702-source relay). That is
                # normal, not a fault, and it used to print a full Python traceback into the journal that
                # QA reads; nothing was wrong with the request or the answer.
                return

    do_GET = do_POST = do_PUT = do_DELETE = do_PATCH = do_HEAD = _serve

    # A handler that never asks for the body (POST /api/packets/stop, "mark as reviewed") leaves those
    # bytes unread in the socket. Closing a TCP socket with unread data makes the kernel send a RESET
    # instead of a normal close, and a reset can discard a reply the client has not read yet: Ingest
    # Studio saw "[Errno 104] Connection reset by peer" on a stop-capture call the relay had in fact
    # carried out. So whatever the handler did not read is read here, before the reply is written.
    # Also covers 401/404 answers, which never construct a Request at all.
    DRAIN_MAX = 1024 * 1024

    def _drain_body(self, status=200):
        """Read whatever a handler left unread, so the answer is a clean close and not a reset (17 Sep 2026) -
        but only a little of it, and never for a request that was refused before it was read: an unauthenticated
        client declaring a 16 MB body and sending none held a thread for the socket's whole timeout (review,
        7 Oct 2026). Anything else is dropped with the connection."""
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return
        left = n - getattr(self, "body_read", 0)
        if left > 0 and (status in (401, 403, 413) or left > self.DRAIN_MAX):
            self.close_connection = True
            self.body_read = n
            return
        if left > 0:
            try:
                self.rfile.read(left)
            except OSError:
                pass
        self.body_read = n


# ----------------------------------------------------------------------------- TLS + server
def ensure_self_signed_cert(cert_path, key_path, cn):
    if os.path.exists(cert_path) and os.path.exists(key_path):
        return
    os.makedirs(os.path.dirname(cert_path), exist_ok=True)
    subprocess.run(["openssl", "req", "-x509", "-nodes", "-newkey", "rsa:2048", "-days", "3650",
                    "-subj", f"/CN={cn}", "-keyout", key_path, "-out", cert_path],
                   check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    os.chmod(key_path, 0o600)


class _TLSServer(ThreadingHTTPServer):
    """TLS handshake per connection, in that connection's thread, with a timeout.

    Wrapping the *listening* socket would run every handshake on the accept thread with no
    timeout: a browser's speculative preconnect that never sends a Client Hello then blocks
    accept() forever and every later visitor hangs. Handshaking here avoids that."""
    ssl_context = None
    handshake_timeout = 10
    # One thread per connection has no ceiling of its own; past this many in flight a new connection is closed
    # at once rather than given a thread (a browser retries its poll; a flood does not get to exhaust the
    # console). Measured before: 300 idle connections = 302 threads (review, 7 Oct 2026).
    max_connections = 256
    _slots = threading.BoundedSemaphore(max_connections)

    def process_request(self, request, client_address):
        if not self._slots.acquire(blocking=False):
            try:
                request.close()
            except OSError:
                pass
            return
        try:
            super().process_request(request, client_address)
        except BaseException:
            self._slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._slots.release()

    def finish_request(self, request, client_address):
        if self.ssl_context is not None:
            try:
                request.settimeout(self.handshake_timeout)
                request = self.ssl_context.wrap_socket(request, server_side=True)
                request.settimeout(60)
            except (ssl.SSLError, OSError, socket.timeout) as e:
                # Say so, once a minute per client: a handshake that fails here shows up on the other
                # side as "connection reset by peer" and used to leave no trace at all on this side.
                self._note_handshake_failure(client_address[0], e)
                try:
                    request.close()
                except OSError:
                    pass
                return
        super().finish_request(request, client_address)

    _hs_last = {}

    def _note_handshake_failure(self, ip, e):
        now = time.time()
        if now - self._hs_last.get(ip, 0) < 60:
            return
        self._hs_last[ip] = now
        print(f"tls handshake with {ip} failed: {e.__class__.__name__}: {e}", file=sys.stderr, flush=True)


def tls_context(cert_path, key_path):
    """The server context for a certificate + key pair. Raises ssl.SSLError / OSError when the pair cannot be loaded."""
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(cert_path, key_path)
    return ctx


def reload_tls(httpd, cert_path, key_path):
    """Swap the certificate a running server presents, in place. _TLSServer handshakes per connection off
    httpd.ssl_context, so the new pair is used by the next connection and no listener is closed; a pair that
    cannot be loaded raises before anything changes, and the old context stays."""
    httpd.ssl_context = tls_context(cert_path, key_path)


def serve(app, host, port, cert_path=None, key_path=None):
    handler = type("Handler", (_Handler,), {"app": app})
    httpd = _TLSServer((host, port), handler)
    httpd.daemon_threads = True
    if cert_path and key_path:
        httpd.ssl_context = tls_context(cert_path, key_path)
    print(f"{app.name} listening on {'https' if cert_path else 'http'}://{host}:{port}", flush=True)
    return httpd


# ----------------------------------------------------------------------------- config
def load_env(path):
    """KEY=VALUE file -> dict. Lines starting with # are ignored. Quotes are stripped."""
    env = {}
    if not os.path.exists(path):
        return env
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip().strip('"').strip("'")
    return env


def run_cmd(argv, timeout=30, stdin=None, env=None):
    """Run a command, return (rc, stdout, stderr). Never raises on non-zero exit. stdin: text piped to the command;
    env: extra environment variables (on top of this process's), for a helper run unprivileged against copies."""
    try:
        full_env = dict(os.environ, **env) if env else None
        p = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, input=stdin, env=full_env)
        return p.returncode, p.stdout, p.stderr
    except FileNotFoundError:
        return 127, "", f"{argv[0]}: not found"
    except subprocess.TimeoutExpired:
        return 124, "", f"{' '.join(argv)}: timed out after {timeout}s"
