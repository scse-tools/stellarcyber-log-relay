/* Shared browser helpers for the lab apps: API calls with CSRF header, toasts, tiny DOM utils, login flow. */
window.Lab = (() => {
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  let LAST_ACTIVITY = Date.now();
  ["pointerdown", "keydown", "wheel", "touchstart"].forEach(ev => window.addEventListener(ev, () => { LAST_ACTIVITY = Date.now(); }, { passive: true, capture: true }));
  // ---- a drop-down inside a dialog is not clipped by it
  // .dd-menu is absolutely positioned inside its <details>, and a .modal is a scroll box, so a menu opened
  // near the bottom of a dialog was cut off and the dialog grew a scrollbar instead (Paul, 25 Sep 2026:
  // "when I go to add by CSV the window is too small... we have a scroll bar, but there is room to show the
  // full menu"). Inside a modal the menu is moved to the body and placed against its summary, the way the
  // Actions menu already is, so it can use the whole window and open upward when that is where the room is.
  //
  // While it is open the menu is NOT a child of the <details> any more, so the <details> has to remember it
  // (dd._ddmenu). Looking for it as a child again on close found nothing and returned, which stranded the
  // menu on the body with nothing left that could dismiss it - a second menu then opened over the first
  // (Paul, 25 Sep 2026: "after selecting import the drop down menu does not go away").
  function ddHome(dd) {                      // bring a floated menu back and stop listening for it
    const menu = dd._ddmenu; if (!menu) return;
    dd._ddmenu = null;
    if (dd._ddaway) { document.removeEventListener("mousedown", dd._ddaway, true); document.removeEventListener("keydown", dd._ddaway, true); dd._ddaway = null; }
    menu.removeAttribute("style");
    if (dd.isConnected) dd.appendChild(menu); else menu.remove();   // the dialog may have gone already
  }
  function ddCloseAll() {                    // a dialog going away must not leave its menu behind
    $$("details.dd").forEach(d => { if (d._ddmenu) { d.open = false; ddHome(d); } });
  }
  document.addEventListener("toggle", (e) => {
    const dd = e.target;
    if (!dd || dd.tagName !== "DETAILS" || !dd.classList.contains("dd") || !dd.closest(".modal")) return;
    if (!dd.open) { ddHome(dd); return; }
    const menu = dd._ddmenu || dd.querySelector(":scope > .dd-menu"); if (!menu) return;
    const sum = dd.querySelector(":scope > summary"); if (!sum) return;
    // one menu at a time: opening this one closes any other that is still floating
    $$("details.dd").forEach(o => { if (o !== dd && o._ddmenu) { o.open = false; ddHome(o); } });
    dd._ddmenu = menu;
    document.body.appendChild(menu);
    menu.style.position = "fixed"; menu.style.right = "auto"; menu.style.top = "0px"; menu.style.left = "0px";
    const r = sum.getBoundingClientRect(), w = menu.offsetWidth, h = menu.offsetHeight;
    const left = dd.classList.contains("left") ? r.left : r.right - w;
    menu.style.left = Math.max(8, Math.min(left, window.innerWidth - w - 8)) + "px";
    menu.style.top = (r.bottom + 6 + h > window.innerHeight ? Math.max(8, r.top - h - 6) : r.bottom + 6) + "px";
    // the menu now lives on the body, so it must not outlive the dialog: any press outside it, or Escape,
    // closes the <details> and brings the menu home - including the press on the dialog's own Close button.
    // The first Escape closes the menu only, never the dialog underneath it.
    const away = (ev) => {
      if (ev.type === "keydown") { if (ev.key !== "Escape") return; ev.stopPropagation(); }
      else if (menu.contains(ev.target)) return;
      dd.open = false; ddHome(dd);
    };
    dd._ddaway = away;
    setTimeout(() => { document.addEventListener("mousedown", away, true); document.addEventListener("keydown", away, true); }, 0);
  }, true);

  // ---- the console was upgraded under an open page
  // A page keeps running the JavaScript it loaded. The files are served no-store, so a reload gets the new
  // ones - but nothing reloads by itself, and the old page carries on looking right while behaving like the
  // old version (Paul, 25 Sep 2026: the CSV window was the previous build's; "I've had to [hard refresh] a
  // couple of times"). Every answer carries X-App-Build; the first one is what this page is running.
  let BUILD = null, BUILD_BAR = false, BUILD_PENDING = null;
  function noticeBuild(b) {
    if (!b) return;
    if (BUILD === null) { BUILD = b; return; }
    if (b === BUILD || BUILD_BAR) return;
    // while the update card is following an install, the new build is expected: the strip waits until the
    // card has shown the install finished, so the two never argue (Paul, 5 Oct 2026: "the reload on top of
    // the page appears before the ... update shows finished and then shows the reload again")
    if (UPDATING) { BUILD_PENDING = b; return; }
    showBuildBar(b);
  }
  function showBuildBar(b) {
    if (BUILD_BAR) return;
    BUILD_BAR = true;
    const bar = document.createElement("div");
    bar.className = "newbuild";
    // never reload by itself: someone may be part-way through a form
    bar.innerHTML = `<b>This console was updated</b> to ${esc(b.split(" ")[0])} while this page was open. The page is still running ${esc(BUILD.split(" ")[0])}. <button type="button" class="btn sm primary">Reload the page</button> <button type="button" class="btn sm" data-later>Not now</button>`;
    bar.querySelector("button.primary").onclick = () => location.reload();
    bar.querySelector("[data-later]").onclick = () => bar.remove();
    document.body.appendChild(bar);
  }

  // ---- downloading a file the console generates
  // A plain <a download> is a NAVIGATION: the browser's download manager opens its OWN connection,
  // and on a console with a self-signed certificate that connection has none of the trust the person
  // granted by clicking through the interstitial. Chrome aborts the handshake with
  // SSLV3_ALERT_CERTIFICATE_UNKNOWN and reports "Check internet connection", which sends the reader
  // looking at their network - the request never reached the console at all (Paul, 2 Oct 2026; proven
  // from the relay's journal and by curl with and without verification).
  // Fetching the bytes on THIS page and saving them as a blob: URL opens no connection of its own, so
  // the certificate is never consulted a second time and the download works either way. The files the
  // console generates are small - a CSV, a JSON template, a capture, a configuration backup - so
  // holding one in memory for a moment is the right trade for a download that always works.
  async function download(url, name) {
    // A connection that breaks - before the answer, or half-way through the file - throws the BROWSER's words
    // ("Failed to fetch"), which say neither which file nor what to do. It gets our own sentence, as api() does.
    const broken = (e, where) => {
      const reason = where === "body"
        ? "the download did not complete: the console started sending the file and the connection closed before it arrived"
        : "the download did not complete: this console did not answer";
      const hint = whatToDo(0, reason, "GET", url);
      const err = new Error(reason + " - " + hint);
      err.status = 0; err.reason = reason; err.detail = (e && e.message) || String(e); err.hint = hint; err.network = true;
      return err;
    };
    try {
      let r;
      try { r = await fetch(url, { credentials: "same-origin", headers: { "X-Requested-With": "microweb" } }); }
      catch (e) { throw broken(e, "answer"); }
      if (!r.ok) {
        let why = ""; try { why = ((await r.clone().json()) || {}).error || ""; } catch (e) { /* not json */ }
        throw new Error(why || `the console refused the download (${r.status})`);
      }
      let blob;
      try { blob = await r.blob(); } catch (e) { throw broken(e, "body"); }
      const url2 = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url2; a.download = name || "download";
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url2), 10000);
      return true;
    } catch (e) {
      toast((e && e.message) || "the download did not complete", "bad");      // our sentence; the browser's words stay in e.detail
      return false;
    }
  }
  // Every <a download> pointing at this console goes that way, including ones written long before
  // this existed: one listener rather than a rewrite of every link, and any added later is covered.
  document.addEventListener("click", (e) => {
    const a = e.target && e.target.closest && e.target.closest("a[download]");
    if (!a) return;
    const href = a.getAttribute("href") || "";
    if (!href.startsWith("/") || href.startsWith("//")) return;      // same origin only; blob: and data: are already fine
    e.preventDefault();
    download(href, a.getAttribute("download"));
  }, true);

  // ---- the console stopped answering
  // A page polls itself every few seconds. A console that is restarting answers none of those polls -
  // and restarting is exactly what updating the console IS, which the update card tells the reader to
  // expect. The failure used to arrive as a red box in the middle of the screen for nine seconds, on a
  // relay that had just updated itself perfectly (Paul, 1 Oct 2026: "when I update the relay I get this
  // error"). Saying nothing instead would be worse, because the page would go on showing numbers that
  // had stopped being true. So a poll nobody asked for gets a quiet strip, and the next answer takes it
  // away. A request a PERSON made still reports itself, loudly: that one has a decision waiting on it.
  let OFFLINE = null, UPDATING = false;
  function offline(kind) {
    if (!document.body) return;
    const k = kind || (UPDATING ? "updating" : "");
    const html = k === "working" ? "<b>Still working.</b> This console is applying your last change; the result appears here when it is done."
      : k === "updating" ? "<b>This console is restarting</b> to finish the update. Nothing is wrong; the page catches up by itself when it answers again."
      : "<b>This console is not answering.</b> The page catches up by itself when it answers again.";
    if (OFFLINE) { if (OFFLINE.dataset.kind !== k) { OFFLINE.dataset.kind = k; OFFLINE.innerHTML = html; } return; }
    OFFLINE = document.createElement("div");
    OFFLINE.className = "notanswering"; OFFLINE.dataset.kind = k;
    OFFLINE.innerHTML = html;
    document.body.appendChild(OFFLINE);
  }
  function online() { if (OFFLINE) { OFFLINE.remove(); OFFLINE = null; } }
  function updating(on) {
    UPDATING = !!on;
    if (!UPDATING && BUILD_PENDING) { const b = BUILD_PENDING; BUILD_PENDING = null; showBuildBar(b); }
  }
  // The error from a poll nobody asked for: true when it was the console not answering, which the strip
  // now carries, and false for anything the console REFUSED - a refusal is the caller's to report.
  function pollFailed(e) { if (!e || !e.network) return false; offline(); return true; }

  // Has this document ever had an authenticated answer? It decides whether a 401 means "your session
  // ended" or simply "you are not signed in yet". Declared above api(), which reads it: a const or let
  // read by a function defined earlier is the temporal-dead-zone trap this project has hit five times.
  let EVER_OK = false;

  const _sleep = (ms) => new Promise((res) => setTimeout(res, ms));
  const newId = () => {
    try { if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID().replace(/-/g, ""); } catch (e) { /* below */ }
    let id = ""; for (let i = 0; i < 32; i++) id += "0123456789abcdef"[Math.floor(Math.random() * 16)]; return id;
  };
  // A write whose answer never came back (the console stayed unreachable past the retries) is kept, by its id,
  // until the console answers again; then /api/outcome/{id} says what became of it and the person is told, in
  // the console's own words - never "reload and check" (Paul, 8 Oct 2026: "can you just figure this out").
  const PENDING_KEY = "pending-writes", PENDING_MAX_AGE = 25 * 60 * 1000;
  const pendingList = () => { try { return JSON.parse(sessionStorage.getItem(PENDING_KEY) || "[]"); } catch (e) { return []; } };
  const pendingSave = (l) => { try { sessionStorage.setItem(PENDING_KEY, JSON.stringify(l.slice(-20))); } catch (e) { /* this page only */ } };
  function rememberPending(rid, method, path) { const l = pendingList(); l.push({ rid, method, path, at: Date.now() }); pendingSave(l); }
  let RECONCILING = false;
  async function reconcilePending() {
    if (RECONCILING) return;
    const l = pendingList(); if (!l.length) return;
    RECONCILING = true;
    const keep = [];
    try {
      for (let i = 0; i < l.length; i++) {
        const p = l[i];
        if (Date.now() - p.at > PENDING_MAX_AGE) continue;        // too old for the console to remember: say nothing
        let said = "", kind = "ok";
        try {
          const oc = await api("GET", "/api/outcome/" + encodeURIComponent(p.rid));
          if (oc && oc.pending) { keep.push(p); continue; }       // still being applied: asked again on the next answer
          said = oc.ok ? "Your earlier change went through: " + (oc.detail || (p.method + " " + p.path))
                       : "Your earlier change was refused: " + ((oc.answer && oc.answer.error) || oc.detail || (p.method + " " + p.path));
          kind = oc.ok ? "ok" : "bad";
        } catch (e) {
          if (e && e.network) { keep.push(...l.slice(i)); break; }    // still unreachable: every one waits for later
          if (e && e.status === 404) {
            const since = e.body && e.body.since ? e.body.since * 1000 : 0;
            said = since > p.at ? "This console restarted after your earlier change was sent, so it has no record of it; the page now shows the current state: " + p.method + " " + p.path
                                : "Your earlier change never reached this console, so nothing was changed - do it again: " + p.method + " " + p.path;
            kind = "warn";
          } else { said = "Your earlier change: " + ((e && e.message) || "no answer"); kind = "warn"; }
        }
        try { toast(said, kind); } catch (e) { /* a message that cannot be shown must not cost anything */ }
      }
    } finally { pendingSave(keep); RECONCILING = false; }
  }
  async function api(method, path, body, o) {
    o = o || {};
    // Nothing is asked of the relay on behalf of a page that is signed out: a poll that keeps firing
    // after the session ended is a request made by nobody.
    if (LOCKED) { const e = new Error("signed out: sign in again to continue"); e.status = 401; throw e; }
    const opts = { method, headers: { "X-Requested-With": "microweb" } };
    // a read within 30 s of a key, click, scroll or touch is a person's; the server renews the sign-in only
    // for those (and for writes), so a page refreshing itself does not keep an idle sign-in alive
    if (Date.now() - LAST_ACTIVITY < 30000) opts.headers["X-Active"] = "1";
    if (body !== undefined) { opts.headers["Content-Type"] = "application/json"; opts.body = JSON.stringify(body); }
    // A request that never completes throws the BROWSER's words - "Failed to fetch" in Chrome, "Load
    // failed" in Safari - which name neither what did not answer nor anything to do about it. This console
    // is reached over a network that can drop (Paul saw it on the Tenancy page while the path to the relay
    // was flapping), so it gets our own sentence, with the browser's text kept as the detail.
    // Ride out a blip, and never apply a change twice (8 Oct 2026). A home/WAN link drops the odd TLS
    // handshake, and until now one dropped connection threw the red box within a second (Paul, 7 Oct 2026:
    // "This message appears when there is any delay in the UI. This cannot happen"). A READ is idempotent, so it
    // is simply tried again, up to four times, each bounded, with the calm top strip meanwhile. A WRITE carries an
    // X-Request-Id: the console runs it once and remembers the answer, so the page retries the SAME id whatever
    // happened to the connection - a retry gets the remembered answer, or waits while the first attempt is still
    // being applied (202 pending). Only a console unreachable for the whole budget ends in an error, and then the
    // id is kept so the outcome is fetched and shown as soon as it answers again (reconcilePending above).
    const safe = method === "GET" || method === "HEAD";
    const rid = safe ? null : newId();
    if (rid) opts.headers["X-Request-Id"] = rid;
    const maxTries = safe ? 4 : 3, perTry = safe ? 15000 : 100000;
    let r, tries = 0, waits = 0;
    for (;;) {
      tries++;
      const ctrl = (typeof AbortController !== "undefined") ? new AbortController() : null;
      const timer = ctrl ? setTimeout(() => { try { ctrl.abort(); } catch (e) { /* settled */ } }, perTry) : null;
      try {
        r = await fetch(path, ctrl ? Object.assign({}, opts, { signal: ctrl.signal }) : opts);
        if (timer) clearTimeout(timer);
      } catch (e) {
        if (timer) clearTimeout(timer);
        if (tries < maxTries) { offline(); await _sleep(Math.min(400 * tries, 1600)); continue; }
        if (rid && !o.fire) rememberPending(rid, method, path);
        const reason = rid ? "this console stopped answering: what became of this change is shown here as soon as it answers again"
                           : "this console did not answer: the request never completed";
        const hint = whatToDo(0, reason, method, path);
        const err = new Error(reason + " - " + hint);
        err.status = 0; err.reason = reason; err.detail = (e && e.message) || String(e); err.hint = hint;
        err.method = method; err.path = path; err.network = true; err.rid = rid;
        throw err;
      }
      // a retry met the first attempt still being applied: the console says so (202) and this asks again shortly
      if (rid && r.status === 202) {
        let d = null;
        try { d = await (r.clone ? r.clone() : r).json(); } catch (e) { d = null; }
        if (d && d.pending && waits++ < 12) { offline("working"); await _sleep(1500); continue; }
        if (!o.fire) rememberPending(rid, method, path);
        const reason = "this console is still applying this change after a long time: what became of it is shown here when it finishes";
        const err = new Error(reason); err.status = 202; err.reason = reason; err.method = method; err.path = path; err.pending = true; err.rid = rid;
        throw err;
      }
      break;
    }
    online();          // it answered: whatever it said, it is there
    if (!RECONCILING) reconcilePending();
    noticeBuild(r.headers && r.headers.get("X-App-Build"));
    let data = {};
    try { data = await r.json(); } catch (e) { /* empty body */ }
    if (r.status === 401) {
      let why = ""; try { why = ((await r.clone().json()) || {}).error || ""; } catch (e) { /* no body */ }
      // A first visit is not an ended session. The page opens by asking /api/me, and a visitor who has
      // never signed in was being told "Your session ended, so the page was cleared" - which reads as a
      // failure before they have typed anything, and is the first half of why a sign-in looked broken.
      // Only a document that HAS been signed in says a session ended.
      showLogin(!EVER_OK ? "" :
        /without activity/.test(why) ? `You were ${why}. The page was cleared.`
          : "Your session ended, so the page was cleared. Sign in again to carry on.");
      throw new Error("your session ended: sign in again");
    }
    if (r.ok) EVER_OK = true;
    if (!r.ok) {
      const reason = data.error || `${method} ${path} failed (${r.status})`;
      // the relay's own "what to do" (fix) beats our generic one; the whole answer rides on the error as .body,
      // so a dialog can list the rows that were refused (it used to look for e.body and never find it)
      const hint = data.fix || whatToDo(r.status, reason, method, path);
      const err = new Error(reason + (hint ? " - " + hint : ""));
      err.status = r.status; err.reason = reason; err.detail = data.detail || ""; err.hint = hint; err.body = data;
      err.method = method; err.path = path;
      throw err;
    }
    return data;
  }

  // What a person should DO about a failure. A refusal that only says what was wrong leaves the
  // reader stuck, and these few are nearly every failure this console produces.
  const ADVICE = [
    [/must be syslog, nginx or both|unknown map/i, "the page sent an unknown map name, which is a bug here, not something you did: reload the page (Shift-Reload) and try again, and tell us if it comes back"],
    [/missing CSRF header/i, "the page has been open a long time: reload it and repeat the action"],
    [/read-only/i, "this account may look but not change; sign in as an administrator"],
    [/no longer valid|authentication required|login required/i, "your session ended: sign in again"],
    [/too many failed logins/i, "wait a few minutes; the lockout clears by itself"],
    [/does not resolve|Name or service not known/i, "the host name has no address here: check the spelling, or type the IP address instead"],
    [/already (exists|mapped)/i, "that device is already in the map: edit the existing row instead of adding a second one"],
    [/map helper failed/i, "the relay refused the change and kept the configuration it had: the detail below is syslog-ng's or nginx's own message, usually a value it cannot parse"],
    [/syslog-ng -s|nginx -t|configuration (check|test) failed/i, "the new configuration did not validate, so nothing was applied and the old one is still running: fix the line named in the detail"],
    [/changed on disk|stale|409/i, "someone else saved this file while you were editing: open the current version, merge your change, then save"],
    [/not installed on this host|not managed/i, "this console configures and tests a program you install: 'sudo stellar-relay prereq syslog' (or nginx) prints the steps and checks this host, then 'sudo stellar-relay add <syslog|nginx>'"],
    [/does not accept configuration changes from Ingest Studio|applies them itself/i, "this is the relay's own setting, not a fault here: on the Log Relay Manager, Settings -> Configuration sync from Ingest Studio. It is off until someone there turns it on"],
    [/relay monitor unreachable|connection refused|timed out|reset by peer/i, "the relay did not answer: check that it is up and reachable on its management port, then try again"],
    [/tenant ?id|32 lowercase/i, "pick the tenant from the list rather than typing it: the 32-character ID is filled in for you"],
  ];
  function whatToDo(status, reason, method, path) {
    const said = (t) => {                 // the hint must add something, not echo the refusal
      const words = t.toLowerCase().match(/[a-z]{4,}/g) || [];
      const inReason = words.filter((w) => reason.toLowerCase().includes(w)).length;
      return words.length && inReason / words.length > 0.6;
    };
    for (const [rx, text] of ADVICE) if (rx.test(reason)) return said(text) ? "" : text;
    // status 0 is not an answer at all: nothing was changed, and the page's own polling recovers a blip
    if (status === 0) return (/shown here/.test(reason) ? "" : "nothing was changed, and the page recovers on its own if that was a blip. ")
      + "If it keeps happening: check you can still open this console's address, that the service is running "
      + "(systemctl status relay-monitor), and whether the network between you and it has changed";
    if (status === 400) return /nothing (was )?changed/i.test(reason) ? "" : "the relay refused the request as invalid; nothing was changed";
    if (status === 403) return "this account is not allowed to do that";
    if (status === 404) return "it is no longer there: reload the page to see what is";
    if (status >= 500) return "the relay hit an error and changed nothing; the service journal has the traceback (journalctl -u relay-monitor)";
    return "";
  }
  // A root helper colours its output whether or not anything is a terminal, so an error can reach the
  // page as "\x1b[1;31mERROR: ...\x1b[0m". Every message a person reads goes through here, so the
  // escapes come off here (Paul saw them in the update checks, 1 Oct 2026).
  const noSGR = (t) => String(t == null ? "" : t).replace(/\x1b\[[0-9;]*m/g, "");
  const errText = (e) => noSGR((e && e.message ? e.message : String(e)) + (e && e.detail ? ": " + e.detail : ""));

  let toastTimer;
  function toast(msg, kind = "") {
    let t = $("#toast");
    if (!t) {
      t = document.createElement("div"); t.id = "toast";
      // the message, and an × at the top right. A click anywhere on the box clears it, but a person looks
      // for a close control where every other window has one (Paul, 23 Sep 2026: "for any pop up that
      // says click to dismiss, ensure there is also an x on the top right").
      t.innerHTML = '<span class="toast-msg"></span><button type="button" class="toast-x" aria-label="Dismiss" title="Dismiss">×</button>';
      document.body.appendChild(t);
      t.addEventListener("click", () => t.classList.add("hidden"));       // in the way on purpose; one click clears it
    }
    t.className = "toast " + kind; $(".toast-msg", t).textContent = msg; t.classList.remove("hidden");
    // something that went wrong is read, not glimpsed: it sits in the middle of the screen for longer
    const bad = kind === "bad" || kind === "warn";
    clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.add("hidden"), bad ? 9000 : 4500);
  }

  // Signed out has to MEAN signed out. showLogin() used to toggle one class, which left every tenant ID,
  // device serial and map row sitting in the DOM behind the form - and modals are appended to <body>, not
  // inside #app, so an open "Add log source" dialog stayed fully on screen with its contents (Paul, 22 Sep
  // 2026: "I cannot get logs or even be in the app if I'm not logged in. This is a huge security hole").
  // So a lock removes the dialogs, empties the application shell and refuses further requests; signing in
  // again reloads the page, which is the only way to be certain the shell is whole and nothing is stale.
  let LOCKED = false, WIPED = false;
  function showLogin(why) {
    LOCKED = true;
    ddCloseAll(); $$(".modal-bg").forEach((m) => m.remove());
    const app = $("#app");
    if (app) {
      if (!app.classList.contains("hidden")) { app.innerHTML = ""; WIPED = true; }
      app.classList.add("hidden");
    }
    const box = $("#login");
    if (box) box.classList.remove("hidden");
    const err = $("#loginErr");
    if (err && why) err.textContent = why;
    const u = $("#login input[name=user]"); if (u) setTimeout(() => u.focus(), 0);
  }
  function showApp() {
    if (WIPED) { location.reload(); return; }   // the shell was emptied: start from a clean document
    LOCKED = false;
    $("#login")?.classList.add("hidden"); $("#app")?.classList.remove("hidden");
  }
  const locked = () => LOCKED;

  async function login(user, password) {
    const r = await fetch("/api/login", { method: "POST", headers: { "Content-Type": "application/json", "X-Requested-With": "microweb" }, body: JSON.stringify({ user, password }) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || "login failed");
    // AELDEV-76750. A lock EMPTIES the shell (showLogin above), so #who, #hostname and every other
    // element a caller writes into after signing in no longer exist. Both apps' handlers did exactly
    // that on the next line - `$("#who").textContent = d.user` - which threw on a null BEFORE
    // showApp() was ever reached: the sign-in had really worked, the session was valid, and the page
    // sat on the form looking as though the password was wrong. Re-entering the URL "fixed" it
    // because a fresh document rebuilds the shell.
    // So the reload happens HERE, the moment the sign-in succeeds, and this promise never resolves:
    // no caller code can run against a dead shell, whatever any of them does next.
    if (WIPED) { location.reload(); return new Promise(() => {}); }
    return d;
  }
  // Signing out is never refused by role (a read-only account's button did nothing: the route was admin-only
  // and the rejection went unhandled). If the console cannot be reached, say so rather than show a sign-in
  // form over a cookie that is still valid; a 401 means it already ended, and api() has shown the form.
  async function logout() {
    try { await api("POST", "/api/logout"); }
    catch (e) { if (e.status !== 401) toast("Not signed out: " + errText(e), "bad"); return; }
    showLogin();
  }

  const fmt = {
    n: (x) => (x ?? 0).toLocaleString(),
    ago: (ts) => { if (!ts) return ""; const s = Math.max(0, (Date.now() / 1000) - ts); if (s < 60) return `${Math.round(s)}s ago`; if (s < 3600) return `${Math.round(s / 60)}m ago`; if (s < 86400) return `${(s / 3600).toFixed(1)}h ago`; return `${(s / 86400).toFixed(1)}d ago`; },
    time: (ts) => ts ? new Date(ts * 1000).toLocaleTimeString([], { hour12: false }) : "",
    dt: (ts) => ts ? new Date(ts * 1000).toLocaleString([], { hour12: false }) : "",
    bytes: (b) => { if (b == null) return ""; const u = ["B", "KB", "MB", "GB"]; let i = 0; while (b >= 1024 && i < 3) { b /= 1024; i++; } return `${b.toFixed(i ? 1 : 0)} ${u[i]}`; },
    // a LENGTH of time, in the units a person would say it in ("about 20 minutes"), for an estimate
    dur: (s) => { if (s == null) return ""; s = Math.max(0, Math.round(s)); if (s < 90) return `${s}s`;
      if (s < 5400) return `${Math.round(s / 60)} minutes`; if (s < 48 * 3600) return `${(s / 3600).toFixed(1)} hours`;
      return `${(s / 86400).toFixed(1)} days`; },
    short: (id) => id ? String(id).slice(0, 8) + "…" : "",
  };

  function pill(state, text) { return `<span class="pill ${state}">${esc(text)}</span>`; }
  function spark(values, max) { const m = max || Math.max(1, ...values); return `<span class="spark">${values.map(v => `<i style="height:${Math.max(2, Math.round(24 * v / m))}px"></i>`).join("")}</span>`; }

  // hash router: #/page
  function router(pages, onChange) {
    function go() {
      // the query is stripped BEFORE the fallback: "#/?srcq=acme" is the first page with a query, not a
      // page called "" - which matched no [data-page] section and left the window blank (25 Sep 2026)
      const name = location.hash.replace(/^#\/?/, "").split("?")[0] || Object.keys(pages)[0];
      // Say in the URL which page this is. A bare address rendered the first page but left the bar
      // reading "https://host:8444/", so there was nothing to bookmark, nothing to copy to a colleague,
      // and after signing in it did not look as though anywhere had been reached (AELDEV-76750).
      // replaceState, so it adds no history entry and fires no hashchange: this is the same page.
      if (!location.hash) { try { history.replaceState(null, "", "#/" + name); } catch (e) { /* file:// */ } }
      $$(".nav a").forEach(a => a.classList.toggle("active", a.getAttribute("href") === "#/" + name));
      $$("[data-page]").forEach(el => el.classList.toggle("hidden", el.dataset.page !== name));
      (pages[name] || pages[Object.keys(pages)[0]])();
      onChange && onChange(name);
    }
    window.addEventListener("hashchange", go);
    return go;
  }

  function modal(html, opts = {}) {
    // opts.wide: a form with several columns of decisions to make at once (the log-source dialog)
    // opts.keep: this dialog holds work someone typed, so neither a stray Escape nor a click beside it
    //   throws it away (Paul, 21 Sep 2026: "when I click esc the modal goes away, don't do that").
    //   It is closed by its own Cancel button, which is a decision rather than a slip.
    const bg = document.createElement("div"); bg.className = "modal-bg";
    // opts.expand: a ⤢ that fills the window. For a dialog whose content is a file, a diff or a list, where
    // the useful size is "as big as the screen" (Paul, 25 Sep 2026: "let me expand to fill size when
    // reviewing"). The blocks inside grow with it; Esc leaves full size before it closes the dialog.
    bg.innerHTML = `<div class="modal${opts.wide ? " wide" : ""}">${opts.expand ? '<button type="button" class="fsbtn m-exp" title="Fill the window">⤢</button>' : ""}${html}</div>`;
    // opts.onClose: what a dialog has to stop when it goes, however it goes (a watch timer polling the relay
    //   every two seconds went on for 90 s after an Escape, and the next Collect press stopped it instead of
    //   starting - review, 7 Oct 2026)
    const close = () => { ddCloseAll(); bg.remove(); document.removeEventListener("keydown", onKey); if (opts.onClose) { try { opts.onClose(); } catch (e) { console.error(e); } } };
    // only the TOP modal answers Escape: each one listens on the document, so two open together used to
    // close together - Escape in the log explorer took the dialog underneath it as well
    const onTop = () => { const all = document.querySelectorAll(".modal-bg"); return all[all.length - 1] === bg; };
    function onKey(e) {
      if (!document.body.contains(bg)) { document.removeEventListener("keydown", onKey); return; }
      if (e.key !== "Escape" || opts.keep || !onTop()) return;
      e.stopPropagation();
      close();
    }
    if (!opts.keep) bg.addEventListener("click", (e) => { if (e.target === bg) close(); });
    document.addEventListener("keydown", onKey);
    document.body.appendChild(bg);
    const exp = bg.querySelector(".m-exp");
    if (exp) {
      const box = bg.querySelector(".modal");
      exp.onclick = () => { box.classList.toggle("full"); exp.title = box.classList.contains("full") ? "Back to the dialog's size" : "Fill the window"; };
      // Escape steps back out of full size first, then closes, so it never throws away a dialog someone
      // had only just expanded
      document.addEventListener("keydown", function esc2(e) {
        if (!document.body.contains(bg)) { document.removeEventListener("keydown", esc2); return; }
        if (e.key === "Escape" && box.classList.contains("full")) { e.stopPropagation(); box.classList.remove("full"); }
      }, true);
    }
    return bg;
  }


  // ---- a grid keeps no empty columns when a method's cards are hidden
  // Hiding one of two cards used to leave the space it had; a four-card row losing two would otherwise
  // stretch the rest. Count what is actually visible and give the grid that many columns (never more than
  // it was built with), so switching nginx off closes the gap instead of leaving it.
  function fitCols(root = document) {
    root.querySelectorAll(".grid").forEach((g) => {
      const kids = Array.from(g.children);
      if (kids.length < 2) return;
      // the .hidden class only: offsetParent is null for every grid on a page that is not the open one
      const vis = kids.filter((c) => !c.classList.contains("hidden")).length;
      const want = Math.min(vis, kids.length);
      g.classList.remove("cols-1", "cols-2", "cols-3");
      if (want >= 1 && want < kids.length && want <= 3) g.classList.add("cols-" + want);
    });
  }

  // ---- boxes in a row line up, whatever their labels and hints say
  // CSS gets most of the way (the row is top-aligned, hints sink to the bottom), but a label that wraps
  // to two lines in ONE field would still push that field's input below its neighbours'. So after every
  // render each row's labels are given a common height, per visual line - the fields wrap on a narrow
  // screen, and each wrapped line is levelled on its own. tools/ui-smoke.py fails the run if any row drifts.
  let alignTimer = null, alignObs = null;
  function alignRows(root = document) {
    root.querySelectorAll(".row").forEach((row) => {
      const fields = Array.from(row.children).filter((el) => el.classList.contains("field") && el.offsetParent);
      if (fields.length < 2) return;
      const lines = new Map();
      for (const f of fields) {
        const k = Math.round(f.offsetTop / 8);
        if (!lines.has(k)) lines.set(k, []);
        lines.get(k).push(f);
      }
      for (const items of lines.values()) {
        if (items.length < 2) continue;
        const labels = items.map((f) => f.querySelector(":scope > label")).filter(Boolean);
        if (labels.length < 2) continue;
        for (const l of labels) if (l.style.minHeight) l.style.minHeight = "";
        let max = 0;
        for (const l of labels) max = Math.max(max, l.getBoundingClientRect().height);
        const want = max ? Math.ceil(max) + "px" : "";
        for (const l of labels) if (l.style.minHeight !== want) l.style.minHeight = want;
      }
    });
  }
  function scheduleAlign() {
    clearTimeout(alignTimer);
    alignTimer = setTimeout(() => {
      if (alignObs) alignObs.disconnect();          // our own writes must not wake the observer
      try { alignRows(); } catch (e) { /* never let levelling break a page */ }
      if (alignObs) alignObs.observe(document.body, { childList: true, subtree: true });
    }, 60);
  }
  function watchAlign() {
    if (alignObs || !document.body) return;
    alignObs = new MutationObserver(scheduleAlign);
    alignObs.observe(document.body, { childList: true, subtree: true });
    window.addEventListener("resize", scheduleAlign);
    scheduleAlign();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", watchAlign);
  else watchAlign();

  // ---- topology diagram: sender -> relay (syslog-ng lane + nginx lane) -> sensor. Inline SVG, live values.
  // d = { sender:{name, ips:[...], sources:[{name, tenant, lane:'syslog'|'nginx'|'direct'}]},
  //       relay:{name, ip, syslogOk, nginxOk, syslogPorts:'udp/tcp 514 · tcp 601 · tls 6514', nginxPort:80, debugLog:true},
  //   a source may carry `arrow`, the word drawn on its arrow to the relay (else the first two words of its transport)
  //       sensor:{name, ip, tls, parserPorts:'5515 5152 5172 5517', jsonPort:5200},
  //       flow:{syslog:true, nginx:false}  // lanes that carried traffic recently (lit) }
  // ---- topology diagram: one lane per log source. Sender -> relay (syslog-ng lane / nginx lane) -> sensor.
  // d = { sender:{name, ip}, relay:{name, ip, ip2, syslogOk, nginxOk, syslogPorts, nginxPort, debugLog},
  //       sensor:{name, ip, tls},                       one sensor, or
  //       sensors:[{name, ip, tls, role:'active'|'standby'}],   up to two (drawn stacked)
  //       sources:[{name, vendor, product, format, ip, transport, identity, lane:'syslog'|'nginx'|'direct'|'raw',
  //       tenant, tenantHex, port, ports:[...], sensor:'1'|'2', live:{sent, failed, confirmed}}] }
  //       `ports` (optional) lists every sensor port the source is delivered to, so one source can
  //       land in two places: its parser port and the capture port 5564.
  //       lane 'direct' = HTTP JSON :5200 with a tenant in the request; 'raw' = the device's own syslog straight
  //       to its parser port, no tenant (lands under the sensor's own tenant).
  // The curves are drawn by the overlay from where the panels REALLY are, so they survive a scroll, a
  // resize and a filter without the picture being rebuilt. One entry per rendered picture; entries whose
  // element has left the document are dropped on the next sweep.
  const TOPO = {}; let TOPO_N = 0, topoQueued = false;

  function topoAnchor(root, base, a) {
    const el = root.querySelector('[data-a="' + a + '"]');
    if (!el) return null;
    const r = el.getBoundingClientRect(), sc = el.closest(".tc-scroll");
    // a row scrolled out of its own panel has no line: a curve to where it would have been is a lie
    if (sc) { const v = sc.getBoundingClientRect(); if (r.bottom < v.top + 6 || r.top > v.bottom - 6) return null; }
    return { l: r.left - base.left, r: r.right - base.left, y: r.top - base.top + r.height / 2 };
  }

  function topoDraw(root) {
    const data = TOPO[root.dataset.topo], svg = root.querySelector(".topo-wires");
    if (!data || !svg) return;
    const base = root.getBoundingClientRect();
    if (!base.width || !base.height) return;
    const W = Math.round(base.width), H = Math.round(base.height);
    svg.setAttribute("viewBox", `0 0 ${W} ${H}`); svg.setAttribute("width", W); svg.setAttribute("height", H);
    const ok = "#35c46f", line = "#364152", txt = "#e6eaf0", mut = "#9aa5b5", CARD = "#131821";
    const paths = [], labels = [];
    data.links.forEach(k => {
      const a = topoAnchor(root, base, k.from), b = topoAnchor(root, base, k.to);
      if (!a || !b) return;
      const x1 = a.r, x2 = b.l - 9, y1 = a.y, y2 = b.y, c = k.lit ? ok : line;
      if (x2 - x1 < 12) return;
      paths.push(`<path d="M${x1.toFixed(1)},${y1.toFixed(1)} C${(x1 + 46).toFixed(1)},${y1.toFixed(1)} ${(x2 - 46).toFixed(1)},${y2.toFixed(1)} ${x2.toFixed(1)},${y2.toFixed(1)}" fill="none" stroke="${c}" stroke-width="${k.lit ? 2.2 : 1.3}" marker-end="url(#${k.lit ? "topo-on" : "topo-off"})"${k.lit ? ' stroke-dasharray="6 5"><animate attributeName="stroke-dashoffset" from="22" to="0" dur="1s" repeatCount="indefinite"/></path>' : "/>"}`);
      if (!k.label) return;
      // every word sits at the same point in its gap, so they stack in one column, each on its own
      // backing, and they are all emitted after the curves so nothing is drawn through them
      const lx = (x1 + x2) / 2, ly = y1 + (y2 - y1) * 0.5 - 6, w = String(k.label).length * 5.9 + 10;
      labels.push(`<rect x="${(lx - w / 2).toFixed(1)}" y="${(ly - 9).toFixed(1)}" width="${w.toFixed(1)}" height="13" rx="3" fill="${CARD}"/>`
        + `<text x="${lx.toFixed(1)}" y="${ly.toFixed(1)}" fill="${k.lit ? txt : mut}" font-size="10" text-anchor="middle" font-family="ui-monospace,Menlo,monospace">${esc(k.label)}</text>`);
    });
    const marker = (mid, c) => `<marker id="${mid}" markerWidth="9" markerHeight="7" refX="8" refY="3.5" orient="auto"><path d="M0,0 L9,3.5 L0,7 z" fill="${c}"/></marker>`;
    svg.innerHTML = `<defs>${marker("topo-on", ok)}${marker("topo-off", line)}</defs>` + paths.join("") + labels.join("");
  }

  function topoSweep() {
    topoQueued = false;
    Object.keys(TOPO).forEach(id => {
      const root = document.querySelector(`[data-topo="${id}"]`);
      if (!root) { delete TOPO[id]; return; }
      if (!root._topoBound) {
        root._topoBound = true;
        root.querySelectorAll(".tc-scroll").forEach(sc => sc.addEventListener("scroll", topoLater, { passive: true }));
        if (window.ResizeObserver) new ResizeObserver(topoLater).observe(root);
      }
      topoDraw(root);
    });
  }
  function topoLater() {
    if (topoQueued) return;
    topoQueued = true;
    requestAnimationFrame(topoSweep);
  }
  // Scheduled by topology() itself, never by a MutationObserver watching the document: drawing the curves
  // CHANGES the DOM (it fills the overlay), so an observer would retrigger itself every frame for ever.
  // The three moments a picture needs drawing are the one it is inserted at, the one the fonts and the
  // panels settle at, and whenever it is scrolled or resized - the last two are bound per picture.
  function topoSoon() {
    if (typeof requestAnimationFrame !== "function") return;
    topoLater();
    setTimeout(topoSweep, 0);
    setTimeout(topoSweep, 150);
  }
  if (typeof window !== "undefined" && window.addEventListener) window.addEventListener("resize", topoLater);

  function topology(d) {
    const s = d.sender || {}, r = d.relay || {}, n = d.sensor || {};
    const all = d.sources || [];
    // Up to eight sensor boxes, by NUMBER (a relay forwards to as many as a hundred, 6 Oct 2026): the first
    // sensor always, then the sensors that have a log source pinned to them, then the rest while room lasts.
    const given = (d.sensors && d.sensors.length ? d.sensors : [n]).map((sn, i) => Object.assign({}, sn, { num: sn.num || i + 1 }));
    const pinned = new Set((d.sources || []).map(x => String(x.sensor || "")));
    const keep = given.filter((sn, i) => i === 0 || pinned.has(String(sn.num))).concat(given.filter((sn, i) => i !== 0 && !pinned.has(String(sn.num))));
    const sensors = keep.slice(0, 8);
    const notDrawn = given.length - sensors.length;
    const two = given.length > 1;
    let undrawnSources = 0;          // pinned to a sensor that has no box: never drawn as if it landed on sensor 1
    const OWN = "sensor's own tenant";
    // one landing row per distinct sensor/port/tenant. An as-is (raw) source lands under the sensor's own
    // tenant: no tenant travels with the log.
    const landing = {}, order = [];
    all.forEach(x => {
      let si = two ? sensors.findIndex(sn => String(sn.num) === String(x.sensor)) : 0;
      if (two && si < 0 && !x.sensor) si = 0;                      // no sensor named: the first takes it
      if (si < 0) { undrawnSources += 1; x._landings = []; return; }
      // a direct source sends as-is (no tenant: the sensor's own) or, `wrapped`, inside the Stellar JSON record
      // with a tenant of its own (Ingest Studio, 8 Oct 2026)
      const raw = x.lane === "raw", tenant = raw && !x.wrapped ? OWN : x.tenant;
      const plist = (x.ports && x.ports.length ? x.ports : [x.port]);
      x._landings = plist.map(port => {
        const k = `${si}|${raw ? (x.wrapped ? "rawt" : "raw") : ""}|${port}|${tenant}`;
        if (!landing[k]) { landing[k] = { si, port, tenant, hex: raw && !x.wrapped ? "" : x.tenantHex, names: [], lane: x.lane, wrapped: !!x.wrapped, lit: false, id: "l" + order.length }; order.push(k); }
        landing[k].names.push(x.name); landing[k].lit = landing[k].lit || (x.live && x.live.sent > 0);
        return k;
      });
    });
    const L = sensors.map((_, si) => order.map(k => landing[k]).filter(l => l.si === si));
    const hidden = { syslog: r.syslogHidden === true, nginx: r.nginxHidden === true };
    const shown = ["syslog", "nginx"].filter(k => !hidden[k]);
    const noProgram = { syslog: r.syslogProgram === false, nginx: r.nginxProgram === false };
    const srcMeta = (x) => `${x.vendor},${x.product}${x.format && x.format !== "syslog" ? "," + x.format : ""}`;
    // every link the overlay draws: from one anchor to another, with the word that rides on it
    const links = [];
    const rows = all.map((x, i) => {
      const live = x.live || {}, lit = live.sent > 0, raw = x.lane === "raw";
      const id = "s" + i;
      const lane = x.lane === "nginx" ? "nginx" : x.lane === "direct" ? "direct" : raw ? "raw" : "syslog";
      if (lane === "direct" || lane === "raw") {
        (x._landings || []).forEach(k => links.push({ from: id, to: landing[k].id, lit, gap: 0,
          label: raw ? (x.arrow || `${String(x.transport).split(" ")[0]} :${landing[k].port} ${x.wrapped ? "wrapped" : "as-is"}`) : "HTTPS :5200 + tenant" }));
      } else {
        links.push({ from: id, to: "lane-" + lane, lit, gap: 0,
                     label: x.arrow || String(x.transport || "").split(" ").slice(0, 2).join(" ") });
      }
      const cnt = live.sent != null ? `<b class="${lit ? "tc-on" : ""}">${live.sent}${live.failed ? "/" + live.failed + "✗" : ""}</b>` : "";
      const tenant = raw && !x.wrapped ? "→ as-is, no tenant" : `→ ${x.tenant == null ? "" : x.tenant}`;
      return `<div class="tc-row${lit ? " lit" : ""}${live.failed && !live.sent ? " failed" : ""}" data-a="${id}">
        <div class="tc-line"><i class="tc-dot${x.enabled === false ? " off" : lit ? " on" : ""}"></i><b>${esc(x.name || "")}</b><span class="tc-ten">${esc(tenant)}</span>${cnt}</div>
        <div class="tc-meta">${esc(x.identity ? `${x.identity} · ${srcMeta(x)}` : srcMeta(x))}</div>
        <div class="tc-meta">${esc(`from ${x.ip || "default IP"} · ${x.transport || ""}`)}</div></div>`;
    }).join("");
    const empty = all.length
      ? `<p class="tc-empty"><b>No log source matches the filter.</b><br>${d.sourcesAll || all.length} are hidden by it.</p>`
      : `<p class="tc-empty"><b>No log sources yet.</b><br>Add the first one on Log sources &amp; tenants,<br>then its logs appear here.</p>`;
    const lane = (key, title, sub1, sub2, on, installed) => installed === false
      ? `<div class="tc-lane off" data-a="lane-${key}"><div class="tc-line"><b>${esc(title)}</b></div>
         <div class="tc-meta">not installed on this relay</div>
         <div class="tc-meta">${esc(noProgram[key] ? (key === "syslog" ? "syslog-ng" : "nginx") + " is not on this host: stellar-relay prereq " + key : "add it any time: stellar-relay add " + key)}</div></div>`
      : `<div class="tc-lane${on ? " lit" : ""}" data-a="lane-${key}"><div class="tc-line"><i class="tc-dot${on === undefined ? " off" : on ? " on" : " bad"}"></i><b>${esc(title)}</b></div>
         <div class="tc-meta">${esc(sub1)}</div><div class="tc-meta">${esc(sub2)}</div></div>`;
    let lanes = "";
    if (!hidden.syslog) lanes += lane("syslog", "syslog-ng relay", r.syslogPorts || "udp/tcp 514 · tcp 601 · tls 6514", "wraps: tenantid + msg_origin", r.syslogOk, r.syslogInstalled);
    if (!hidden.nginx) lanes += lane("nginx", "nginx relay", "http :" + (r.nginxPort || 80) + " /httpjson", "adds header Stellar-TenantID", r.nginxOk, r.nginxInstalled);
    const boxes = sensors.map((sn, si) => {
      sn = sn || {};
      const standby = sn.role === "standby";
      const list = L[si].map(l => {
        const cap = String(l.port) === "5564";
        const head = l.lane === "raw" ? `:${l.port} ${l.wrapped ? "wrapped" : "as-is"}  →  ${l.wrapped ? "tenant " : ""}${l.tenant}`
          : `${l.lane === "nginx" || l.lane === "direct" ? "HTTP JSON :5200" : (cap ? "capture :" : "parser :") + l.port}  →  tenant ${l.tenant}`;
        // the word on the wire names the sessions when there are several to this port ("tls ×4"): the relay opens
        // CONNECTIONS_PER_PORT sessions per parser port so the sensor's workers share it, and a person asked to see them
        const nsess = ((sn.sessions || {})[String(l.port)] || []).length;
        if (l.lane !== "direct" && l.lane !== "raw") links.push({ from: "lane-" + (l.lane === "nginx" ? "nginx" : "syslog"), to: l.id, lit: l.lit, gap: 1,
                                                                   label: l.lane === "nginx" ? "https" : (nsess > 1 ? `tls ×${nsess}` : "tls") });
        return `<div class="tc-row${l.lit ? " lit" : ""}" data-a="${l.id}">
          <div class="tc-line"><b>${esc(head)}</b></div>
          <div class="tc-meta">${esc(`${l.hex ? l.hex.slice(0, 12) + "…  " : ""}${l.names.join(", ")}`)}</div></div>`;
      }).join("");
      const none = two ? (standby ? "receives nothing while sensor 1 is up" : "no sources assigned yet")
                       : ("parser ports 5515 5152 5172 5517" + (hidden.nginx ? "" : " · HTTP JSON :5200"));
      return `<section class="topo-box${standby ? " standby" : ""}">
        <h4>${esc((sn.title || (two ? `Sensor ${sn.num}` : (sn.name || "Modular Sensor"))) + (standby ? "  (standby)" : ""))}</h4>
        <div class="tc-sub mono">${esc((sn.ip || "sensor address not set") + (sn.tls === false ? "  (plain)" : "  (TLS)"))}</div>
        ${(() => {
          // the sessions open to it right now, per port - "8 sessions open · 5515 ×4 · 5517 ×4" - read from this
          // host's socket table (Paul, 6 Oct 2026: "show this in the overview")
          const se = sn.sessions || {}, ports = Object.keys(se).sort((a, b) => a - b);
          const total = ports.reduce((a, p) => a + (se[p] || []).length, 0);
          if (!total) return "";
          const words = ports.map(p => `${p} ×${(se[p] || []).length}`).join(" · ");
          return `<div class="tc-sub mono" title="${esc(ports.map(p => `:${p} from this relay's ports ${(se[p] || []).filter(v => v != null).join(", ")}`).join("; "))}">${esc(`${total} session${total === 1 ? "" : "s"} open · ${words}`)}</div>`;
        })()}
        ${two ? "" : `<div class="tc-kicker">WHERE EACH SOURCE LANDS</div>`}
        ${list ? `<div class="tc-scroll">${list}</div>` : `<p class="tc-empty">${esc(none)}</p>`}</section>`;
    }).join("");
    // A caller that redraws the same picture on a timer passes its own id: with the global counter the html
    // differed on every call, so "unchanged, leave the DOM alone" could never fire and the picture - and the
    // scroll inside it - was thrown away every 5 seconds (Paul, 6 Oct 2026).
    const id = d.id ? "tp-" + String(d.id).replace(/[^a-z0-9_-]/gi, "") : "tp" + (++TOPO_N);
    TOPO[id] = { links };
    topoSoon();
    // Three panels and an overlay, not one drawing: the log source column SCROLLS, so every device is in
    // the picture rather than the first eight, and the relay and the sensors stay where they are while it
    // moves (Paul, 3 Oct 2026). The curves are redrawn from the real element positions on every scroll,
    // so a line always points at the row it belongs to, and a row scrolled out of sight has no line.
    // r.hidden: nothing drawn goes through a relay (Ingest Studio sending straight to its sensors), so there is
    // no relay box at all - a box with no lane into it reads as a relay the logs pass through, which they do not
    const relayBox = r.hidden ? "" : `<section class="topo-col tc-relay">
          <h4>${esc(r.name || "Relay")}</h4><div class="tc-sub mono">${esc(r.ip || "relay IP not set")}</div>
          ${r.ip2 ? `<div class="tc-sub mono">${esc(r.ip2)}</div>` : ""}
          ${lanes}
          ${r.debugLog === false ? `<p class="tc-warn">debug copy off: arrivals not visible here</p>` : ""}
        </section>`;
    return `<div class="topo" data-topo="${id}">
      <div class="topo-cols${r.hidden ? " norelay" : ""}">
        <section class="topo-col tc-src">
          <h4>${esc(s.name || "Sender")}</h4><div class="tc-sub mono">${esc(s.ip || "")}</div>
          <div class="tc-kicker">${esc(s.sub || "LOG SOURCES")}</div>
          ${rows ? `<div class="tc-scroll" data-scroll-key="${id}-src">${rows}</div>` : empty}
        </section>
        ${relayBox}
        <div class="topo-col-plain">${boxes}${notDrawn > 0 ? `<p class="tc-empty">+ ${notDrawn} more sensor${notDrawn === 1 ? "" : "s"} not drawn${undrawnSources ? ` (${undrawnSources} log source${undrawnSources === 1 ? "" : "s"} pinned to them)` : " (no log source pinned)"}</p>` : ""}</div>
      </div>
      <svg class="topo-wires" aria-hidden="true"></svg></div>`;
  }


  // ---- text frames: a scrollable block of lines (a config file, a service log, a run log) that a timer
  // refreshes. Three rules, each from a real complaint: (1) a frame whose content did not change is not
  // touched, so the reader's place and selection survive the refresh; (2) a frame that did change keeps
  // its scroll position, unless it "follows" (a log) and the reader was already at the bottom; (3) one
  // search per frame, kept across refreshes, marks every matching line and every matching word.
  // State is keyed by NAME, not by element, because a page rebuild replaces the element and the reader's
  // search and scroll must outlive that. `render(line, i, {hl, hit, cls})` must return exactly ONE
  // element per line, in order: navigation finds a line by child index.
  const FRAMES = new Map();
  const hashParams = () => new URLSearchParams(location.hash.split("?")[1] || "");
  const rxEsc = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  // marker(q) -> a function that escapes text and wraps every case-insensitive match of q in <mark>.
  // The raw text is split first and escaped piece by piece: escaping first and then matching would let
  // a query such as "&" match the entities of the escaped text.
  function marker(q) {
    q = String(q || "");
    if (!q) return (t) => esc(t);
    const rx = new RegExp(rxEsc(q), "gi");
    return (t) => {
      t = String(t ?? ""); let out = "", last = 0;
      for (const m of t.matchAll(rx)) { out += esc(t.slice(last, m.index)) + "<mark>" + esc(m[0]) + "</mark>"; last = m.index + m[0].length; }
      return out + esc(t.slice(last));
    };
  }
  function frameState(name) {
    if (!FRAMES.has(name)) FRAMES.set(name, { name, el: null, lines: [], q: "", wrap: true, hits: [], cur: -1, follow: false, render: null, text: null, empty: "", bar: null });
    return FRAMES.get(name);
  }
  const defaultRender = (l, i, { hl, cls }) => `<div class="${cls}">${hl(l)}</div>`;
  // set(name, el, lines, opts): opts.render, opts.text (line -> string to search), opts.follow (a log:
  // stick to the bottom while the reader is there), opts.empty (html when there are no lines),
  // opts.q (replace the frame's query), opts.restore ({top,left} carried over from a replaced element)
  function frameSet(name, el, lines, opts = {}) {
    const st = frameState(name);
    st.el = el; st.lines = lines || [];
    for (const k of ["render", "text", "follow", "empty"]) if (k in opts) st[k] = opts[k];
    if ("q" in opts) { st.q = opts.q || ""; st.cur = -1; }
    framePaint(name, opts.restore);
  }
  function framePaint(name, restore) {
    const st = frameState(name), el = st.el;
    if (!el || !el.isConnected) return;
    const q = st.q.trim(), lq = q.toLowerCase(), hl = marker(q), render = st.render || defaultRender, text = st.text || ((l) => String(l ?? ""));
    st.hits = [];
    const html = st.lines.map((l, i) => {
      const hit = !!lq && text(l).toLowerCase().includes(lq);
      if (hit) st.hits.push(i);
      return render(l, i, { hl, hit, cls: hit ? " hit" : "" });
    }).join("") || st.empty;
    el.classList.toggle("nowrap", !st.wrap);
    if (el._frameHtml === html) { frameCount(name); return; }        // unchanged: leave the DOM alone
    const fresh = el._frameHtml === undefined, top = el.scrollTop, left = el.scrollLeft;
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 8;
    el.innerHTML = html; el._frameHtml = html;
    if (restore) { el.scrollTop = restore.top; el.scrollLeft = restore.left; }
    else if (st.follow && (fresh || atBottom)) el.scrollTop = el.scrollHeight;
    else if (!fresh) { el.scrollTop = top; el.scrollLeft = left; }
    if (st.cur >= 0 && st.cur < st.hits.length) { const row = el.children[st.hits[st.cur]]; if (row) row.classList.add("cur"); }
    frameCount(name);
  }
  function frameCount(name) {
    const st = frameState(name), c = st.bar && st.bar.querySelector(".cnt");
    if (!c) return;
    c.textContent = !st.q.trim() ? "" : !st.hits.length ? "no match" : st.cur >= 0 ? `${st.cur + 1} of ${st.hits.length}` : `${st.hits.length} line${st.hits.length === 1 ? "" : "s"}`;
    st.bar.classList.toggle("nomatch", !!st.q.trim() && !st.hits.length);
  }
  // reveal(name, lineIndex): scroll the frame (only the frame, never the page) so that line sits a third
  // of the way down, and mark it as the current match when it is one.
  function frameReveal(name, idx) {
    const st = frameState(name), el = st.el, row = el && el.children[idx];
    if (!row) return;
    $$(".cur", el).forEach(x => x.classList.remove("cur"));
    row.classList.add("cur");
    st.cur = st.hits.indexOf(idx);
    // measured, not offsetTop: a row's offsetParent is whatever positioned ancestor it has, not always the frame
    const y = row.getBoundingClientRect().top - el.getBoundingClientRect().top + el.scrollTop;
    el.scrollTop = Math.max(0, y - el.clientHeight / 3);
    frameCount(name);
  }
  function frameGo(name, dir) {
    const st = frameState(name);
    if (!st.hits.length) return;
    const n = st.hits.length;
    frameReveal(name, st.hits[((st.cur + dir) % n + n) % n]);
  }
  // search(name, mount, opts): the find bar for one frame - a box, the count, previous / next, and a
  // wrap toggle. Enter = next, Shift+Enter = previous, Escape = clear. Re-attaching to a new mount (the
  // page was rebuilt) keeps the frame's query.
  function frameSearch(name, mount, opts = {}) {
    if (!mount) return;
    const st = frameState(name);
    mount.innerHTML = `<span class="fsearch"><input type="search" placeholder="${esc(opts.placeholder || "Find")}" aria-label="${esc(opts.placeholder || "Find in this frame")}" spellcheck="false" autocomplete="off"><span class="cnt"></span><button type="button" class="prev" title="Previous match (Shift+Enter, or ↑)">‹</button><button type="button" class="next" title="Next match (Enter, or ↓)">›</button>${opts.wrap === false ? "" : `<label class="wrap" title="Wrap long lines to the width of the frame"><input type="checkbox"${st.wrap ? " checked" : ""}>wrap</label>`}</span>`;
    const inp = mount.querySelector("input[type=search]");
    inp.value = st.q;
    inp.oninput = () => { st.q = inp.value; st.cur = -1; framePaint(name); if (st.hits.length) frameGo(name, 1); };
    inp.onkeydown = (e) => {
      if (e.key === "Enter" || e.key === "ArrowDown") { e.preventDefault(); frameGo(name, e.key === "Enter" && e.shiftKey ? -1 : 1); }
      if (e.key === "ArrowUp") { e.preventDefault(); frameGo(name, -1); }
      if (e.key === "Escape") { e.preventDefault(); inp.value = ""; inp.oninput(); inp.blur(); }
    };
    mount.querySelector(".prev").onclick = () => frameGo(name, -1);
    mount.querySelector(".next").onclick = () => frameGo(name, 1);
    const w = mount.querySelector(".wrap input");
    if (w) w.onchange = () => { st.wrap = w.checked; if (st.el) st.el.classList.toggle("nowrap", !st.wrap); };
    st.bar = mount.firstElementChild;
    frameCount(name);
  }
  const frame = { set: frameSet, paint: framePaint, search: frameSearch, go: frameGo, reveal: frameReveal, state: frameState, marker, rxEsc };

  // ---- full screen for any card that holds a frame (a log, a config view, the packet list...). A button
  // goes into the card's head once; the card becomes fixed and its frame grows to fill it; Esc leaves.
  const FS_SEL = ".log, .cfg-text, .pk-list, #pk-detail, .cfg-edshell, .frame-fill";
  function fsToggle(card, on) {
    const want = on === undefined ? !card.classList.contains("fs") : on;
    card.classList.toggle("fs", want);
    document.body.classList.toggle("has-fs", !!document.querySelector(".card.fs"));
    const b = card.querySelector(".fsbtn"); if (b) { b.textContent = want ? "⤡" : "⤢"; b.title = want ? "Leave full screen (Esc)" : "Full screen"; }
  }
  function fullscreen(root) {
    $$(".card", root || document).forEach(card => {
      if (card.querySelector(".fsbtn") || !card.querySelector(`:scope > ${FS_SEL.split(", ").join(", :scope > ")}`)) return;
      const head = card.querySelector(":scope > .head"); if (!head) return;
      const b = document.createElement("button"); b.type = "button"; b.className = "fsbtn"; b.textContent = "⤢"; b.title = "Full screen";
      b.onclick = () => fsToggle(card);
      head.appendChild(b);
    });
  }
  document.addEventListener("keydown", e => { if (e.key === "Escape") $$(".card.fs").forEach(c => fsToggle(c, false)); });
  // cards are rendered and re-rendered by every page; watch for new ones instead of asking each page to call this
  if (window.MutationObserver) new MutationObserver(() => fullscreen()).observe(document.documentElement, { childList: true, subtree: true });

  // ---- Dismiss a warning (Paul, 4 Oct 2026: "for message like this, or any warning, let me ... dismiss" - then
  // "or just dismiss, I don't need to officially acknowledge"). Any element rendered with data-dismiss="<scope>"
  // gets an × after its sentence. Pressing it hides the element and remembers THAT SENTENCE in this browser
  // (localStorage), so it stays gone across the page's own polls and across reloads, and comes back by itself
  // the moment its words change - a count that went up, another port. Where one or more are hidden, a faint
  // line counts them and brings them back; a brought-back warning carries ↩ to un-dismiss it for good. Nothing
  // is sent to the console: it is a tidy-up, not an acknowledgement, and the warning is still in the data.
  const DISMISS_KEY = "dismissed-warnings", DISMISS_KEEP_DAYS = 60;
  let DISMISSED = null;
  function dismissed() {
    if (DISMISSED) return DISMISSED;
    try { DISMISSED = JSON.parse(localStorage.getItem(DISMISS_KEY) || "{}") || {}; } catch (e) { DISMISSED = {}; }
    const cut = Date.now() - DISMISS_KEEP_DAYS * 86400000;
    for (const k of Object.keys(DISMISSED)) if (!(DISMISSED[k] > cut)) delete DISMISSED[k];
    return DISMISSED;
  }
  function dismissSave() { try { localStorage.setItem(DISMISS_KEY, JSON.stringify(dismissed())); } catch (e) { /* this page only */ } }
  function dismissHash(s) { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h * 33) ^ s.charCodeAt(i)) >>> 0; return h.toString(36); }
  const dismissKeyOf = (el) => `${el.dataset.dismiss}:${dismissHash((el.dataset.dismissText || el.textContent || "").replace(/\s+/g, " ").trim())}`;
  function dismissNote(parent) {
    let note = parent.querySelector(":scope > .dismissed-note");
    const hidden = Array.from(parent.children).filter(c => c.classList.contains("dismissed"));
    if (!hidden.length) { if (note) note.remove(); return; }
    if (!note) { note = document.createElement("div"); note.className = "dismissed-note small faint"; parent.appendChild(note); }
    note.innerHTML = `${hidden.length} warning${hidden.length === 1 ? "" : "s"} dismissed · <a href="#">show</a>`;
    note.querySelector("a").onclick = (e) => { e.preventDefault(); hidden.forEach(c => { c.classList.remove("dismissed"); c.classList.add("dismissed-shown"); }); note.remove(); };
  }
  function dismissables(root) {
    const parents = new Set();
    $$("[data-dismiss]", root || document).forEach(el => {
      if (el.dataset.dismissDone) return;
      el.dataset.dismissDone = "1";
      const key = dismissKeyOf(el), parent = el.parentElement;
      if (!parent) return;
      const b = document.createElement("button"); b.type = "button"; b.className = "dismiss-x";
      const paint = () => {
        const off = !!dismissed()[key];
        b.textContent = off ? "↩" : "×";
        b.title = off ? "Bring this warning back" : "Dismiss this warning (it comes back if its words change)";
        b.setAttribute("aria-label", b.title);
      };
      b.onclick = (e) => {
        e.preventDefault(); e.stopPropagation();
        if (dismissed()[key]) { delete dismissed()[key]; el.classList.remove("dismissed", "dismissed-shown"); }
        else { dismissed()[key] = Date.now(); el.classList.add("dismissed"); el.classList.remove("dismissed-shown"); }
        dismissSave(); paint(); dismissNote(parent);
      };
      el.appendChild(b);
      if (dismissed()[key]) el.classList.add("dismissed");
      paint();
      parents.add(parent);
    });
    parents.forEach(dismissNote);
  }
  if (window.MutationObserver) new MutationObserver(() => dismissables()).observe(document.documentElement, { childList: true, subtree: true });

  // ---- Notices: every problem this console has, in ONE place, seen and dismissed there (Paul, 7 Oct 2026: "You
  // can have a notification icon where they can see errors and dismiss errors"). A page hands over the whole
  // current list on every poll (notices.set), so a problem that went away disappears by itself; a dismissed one
  // stays away until its words change (a count went up, another port), which is the dismissables rule above.
  // Nothing is shown at all while the product is not yet configured: a relay with no log source has nothing
  // that can be wrong ("If I don't have anything configured yet, don't give me errors").
  const NOTICE_KEY = "dismissed-notices", NOTICE_KEEP_DAYS = 30;
  let NOTICES = [], NOTICE_CFG = false, NOTICE_PANEL = null, NOTICE_SHOW_OFF = false;
  const nhash = (t) => { let h = 2166136261; for (let i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h.toString(16); };
  const noticeId = (n) => (n.key || "") + ":" + nhash((n.title || "") + "|" + (n.text || ""));
  function noticesOff() {
    let d = {};
    try { d = JSON.parse(localStorage.getItem(NOTICE_KEY) || "{}") || {}; } catch (e) { d = {}; }
    const cut = Date.now() - NOTICE_KEEP_DAYS * 86400000, out = {};
    for (const [k, t] of Object.entries(d)) if (t > cut) out[k] = t;
    return out;
  }
  function noticesSave(d) { try { localStorage.setItem(NOTICE_KEY, JSON.stringify(d)); } catch (e) { /* this page only */ } }
  function noticesMount() {
    let host = $(".side .notices");
    if (host) return host;
    const brand = $(".side .brand > div"); if (!brand) return null;
    host = document.createElement("div"); host.className = "notices hidden";
    host.innerHTML = '<button type="button" class="notices-btn" aria-haspopup="true" aria-expanded="false" aria-label="Notifications" title="Notifications">'
      + '<svg class="notices-bell" viewBox="0 0 16 16" width="15" height="15" aria-hidden="true"><path fill="currentColor" d="M8 1.4a.95.95 0 0 1 .95.95v.4a4 4 0 0 1 3.05 3.88v2.1l.96 1.64a.55.55 0 0 1-.47.83H3.51a.55.55 0 0 1-.47-.83L4 8.73v-2.1A4 4 0 0 1 7.05 2.75v-.4A.95.95 0 0 1 8 1.4Z"/><path fill="currentColor" d="M6.45 12.1a1.55 1.55 0 0 0 3.1 0h-3.1Z"/></svg>'
      + '<span class="notices-badge" hidden></span></button>';
    brand.appendChild(host);
    const btn = host.querySelector(".notices-btn");
    btn.onclick = (e) => { e.preventDefault(); e.stopPropagation(); noticesToggle(); };
    return host;
  }
  function noticesLive() { const off = noticesOff(); return NOTICES.filter(n => !off[noticeId(n)]); }
  function noticesRender() {
    const host = noticesMount(); if (!host) return;
    if (!NOTICE_CFG) { host.classList.add("hidden"); if (NOTICE_PANEL) noticesToggle(false); return; }
    host.classList.remove("hidden");
    const live = noticesLive(), bad = live.filter(n => n.level === "bad").length;
    const btn = host.querySelector(".notices-btn");
    btn.classList.toggle("lv-bad", bad > 0); btn.classList.toggle("lv-warn", bad === 0 && live.length > 0);
    // a bell with a count, never the word "problem" on the button (Paul, 7 Oct 2026); the sentence lives on the title/label
    const badge = btn.querySelector(".notices-badge");
    if (live.length) { badge.textContent = live.length > 99 ? "99+" : String(live.length); badge.hidden = false; }
    else { badge.textContent = ""; badge.hidden = true; }
    const say = live.length ? `${live.length} problem${live.length === 1 ? "" : "s"} need${live.length === 1 ? "s" : ""} resolution: open the list, go to the page, or dismiss one` : "Notifications: nothing needs resolution right now";
    btn.title = say; btn.setAttribute("aria-label", say);
    if (NOTICE_PANEL) noticesPanelFill();
  }
  function noticesPanelFill() {
    const off = noticesOff(), live = [], gone = [];
    NOTICES.forEach(n => (off[noticeId(n)] ? gone : live).push(n));
    const row = (n, dismissed) => `<div class="notice lv-${n.level === "bad" ? "bad" : "warn"}${dismissed ? " off" : ""}" data-nid="${esc(noticeId(n))}">
        <span class="dot"></span><div class="grow"><b>${esc(n.title || "")}</b>${n.text ? `<div class="small">${esc(n.text)}</div>` : ""}${n.page ? `<a class="small" href="${esc(n.page)}">Open the page</a>` : ""}</div>
        <button type="button" class="notice-x" title="${dismissed ? "Bring it back" : "Dismiss (it comes back if its words change)"}">${dismissed ? "↩" : "×"}</button></div>`;
    NOTICE_PANEL.innerHTML = `<div class="notice-head"><b>${live.length ? `${live.length} problem${live.length === 1 ? "" : "s"} need${live.length === 1 ? "s" : ""} resolution` : "Nothing needs resolution"}</b><button type="button" class="notice-close" title="Close">×</button></div>`
      + (live.length ? live.map(n => row(n, false)).join("") : `<div class="small muted notice-empty">Everything this console watches is fine. A problem appears here when something that is set up stops working, and stays until it is fixed or dismissed.</div>`)
      + (gone.length ? `<div class="notice-foot small muted"><a href="#" class="notice-showoff">${NOTICE_SHOW_OFF ? "Hide" : "Show"} ${gone.length} dismissed</a></div>${NOTICE_SHOW_OFF ? gone.map(n => row(n, true)).join("") : ""}` : "");
    NOTICE_PANEL.querySelector(".notice-close").onclick = () => noticesToggle(false);
    const so = NOTICE_PANEL.querySelector(".notice-showoff"); if (so) so.onclick = (e) => { e.preventDefault(); NOTICE_SHOW_OFF = !NOTICE_SHOW_OFF; noticesPanelFill(); };
    NOTICE_PANEL.querySelectorAll(".notice").forEach(el => {
      el.querySelector(".notice-x").onclick = (e) => {
        e.preventDefault(); e.stopPropagation();
        const d = noticesOff(), id = el.dataset.nid;
        if (d[id]) delete d[id]; else d[id] = Date.now();
        noticesSave(d); noticesRender();
      };
      el.querySelectorAll("a[href^='#']").forEach(a => a.onclick = () => noticesToggle(false));
    });
  }
  function noticesToggle(open) {
    const want = open == null ? !NOTICE_PANEL : !!open;
    const host = noticesMount(); if (!host) return;
    if (!want) { if (NOTICE_PANEL) { NOTICE_PANEL.remove(); NOTICE_PANEL = null; } host.querySelector(".notices-btn").setAttribute("aria-expanded", "false"); return; }
    if (NOTICE_PANEL) return;
    NOTICE_PANEL = document.createElement("div"); NOTICE_PANEL.className = "notice-panel";
    document.body.appendChild(NOTICE_PANEL);
    const r = host.getBoundingClientRect(); NOTICE_PANEL.style.top = Math.max(8, r.top) + "px"; NOTICE_PANEL.style.left = (r.right + 8) + "px";
    host.querySelector(".notices-btn").setAttribute("aria-expanded", "true");
    noticesPanelFill();
    setTimeout(() => document.addEventListener("click", function away(e) {
      if (!NOTICE_PANEL) { document.removeEventListener("click", away); return; }
      if (NOTICE_PANEL.contains(e.target) || host.contains(e.target)) return;
      document.removeEventListener("click", away); noticesToggle(false);
    }), 0);
  }
  // set(list, {configured}): the whole current list, every poll. configured=false hides everything.
  const notices = {
    set(list, opts) { NOTICES = Array.isArray(list) ? list.filter(n => n && n.key) : []; NOTICE_CFG = !!(opts && opts.configured); noticesRender(); },
    live: noticesLive, open: () => noticesToggle(true), close: () => noticesToggle(false), id: noticeId,
  };

  // A <details> the reader opened must still be open after the card redraws (Paul, 6 Oct 2026: "if I open a
  // chevron, let it stay open"). Every polled card rewrites its innerHTML, which throws the open state away
  // with the old nodes - the same family as the frame rules of 17 Sep and the Sensors page's openInfo, but
  // this one is global, so a disclosure added to any page in future is covered without anyone remembering.
  // The key is data-keep when given - a summary whose words carry a count ("The 22 archived files") cannot
  // key on itself, since the next poll's count would be a different disclosure - else the summary's own text
  // scoped to the nearest id. Page-session only: nothing is stored, so a reload starts closed as before.
  const OPEN_D = new Set();
  function keepKey(d) {
    if (d.dataset.keep) return d.dataset.keep;
    const sum = d.querySelector(":scope > summary");
    if (!sum) return "";
    const scope = d.closest("[id]");
    return (scope ? scope.id + "|" : "") + (sum.textContent || "").replace(/\s+/g, " ").trim();
  }
  // toggle does not bubble, so this listens in the CAPTURE phase, which reaches a non-bubbling event's target.
  document.addEventListener("toggle", (e) => {
    const d = e.target;
    if (!d || d.tagName !== "DETAILS") return;
    const k = keepKey(d);
    if (!k) return;
    if (d.open) OPEN_D.add(k); else OPEN_D.delete(k);
  }, true);
  function keepOpen(root) {
    if (!OPEN_D.size) return;
    $$("details", root || document).forEach(d => {
      if (d.open) return;
      const k = keepKey(d);
      if (k && OPEN_D.has(k)) d.open = true;      // an attribute, and attributes are not observed: no loop
    });
  }
  if (window.MutationObserver) new MutationObserver(() => keepOpen()).observe(document.documentElement, { childList: true, subtree: true });

  // setHtml(el, html): write a polled container WITHOUT throwing the reader's scroll away (Paul, 6 Oct 2026:
  // "when I scroll it does not stick, it keeps rolling back up", on the Overview's log-flow picture with
  // 1,136 log sources in it). Lab.frame has had these rules since 17 Sep; a container written with a bare
  // innerHTML on a 5 s timer had none of them. Same two rules: unchanged HTML is not touched at all, and a
  // changed one keeps where the reader was.
  // Scrollers INSIDE the container are restored too, by name: the Overview's picture puts the log sources in
  // a scrolling column of its own (.tc-scroll), and that column is what the reader is actually moving, so
  // keeping only the outer element's position would have fixed nothing. A scroller opts in with
  // data-scroll-key, which has to be stable across redraws for the same reason a frame's name does.
  const INNER_SCROLL = "[data-scroll-key]";
  function setHtml(el, html) {
    if (!el) return;
    if (el._setHtml === html) return;
    const fresh = el._setHtml === undefined, top = el.scrollTop, left = el.scrollLeft;
    const inner = {};
    if (!fresh) $$(INNER_SCROLL, el).forEach(n => { inner[n.dataset.scrollKey] = [n.scrollTop, n.scrollLeft]; });
    el.innerHTML = html; el._setHtml = html;
    if (!fresh) {
      el.scrollTop = top; el.scrollLeft = left;
      $$(INNER_SCROLL, el).forEach(n => {
        const was = inner[n.dataset.scrollKey];
        if (was) { n.scrollTop = was[0]; n.scrollLeft = was[1]; }
      });
    }
  }

  // sortable(container, {items, handle, key, onOrder}): put rows or cards in a new order two ways. A plain
  // CLICK on the handle asks where the item should go (first, or after any other item) and moves it there;
  // a DRAG carries the item through its siblings and drops it. Either way onOrder(ids) gets the new order of
  // data-<key> values. Paul (18 Sep 2026): "anywhere we have the up and down arrows, we should just be able to
  // drag. Moving one at a time is hard", then "maybe instead of drag and drop, you click and ask where it
  // needs to go". Pointer events, so a mouse, a trackpad and touch all work; nothing is saved until the move.
  function sortable(container, opts) {
    if (!container) return;
    container._sortableOpts = opts;          // a re-rendered page updates the options; the listener is added once
    if (container._sortable) return;
    container._sortable = true;
    const itemOf = (el) => el && el.closest(container._sortableOpts.items);
    let drag = null, ghost = null;
    container.addEventListener("pointerdown", (e) => {
      const opts = container._sortableOpts;
      const h = opts.handle ? e.target.closest(opts.handle) : e.target.closest(opts.items);
      if (!h || (opts.handle && !itemOf(h))) return;
      const item = itemOf(h); if (!item || item.parentElement !== container && !container.contains(item)) return;
      if (e.button !== 0) return;
      e.preventDefault();
      drag = item; drag.classList.add("dragging");
      ghost = document.createElement("div"); ghost.className = "drag-ghost"; ghost.textContent = (item.dataset.label || item.textContent || "").trim().slice(0, 60);
      document.body.appendChild(ghost);
      const x0 = e.clientX, y0 = e.clientY; let moved = false;
      const move = (ev) => {
        if (!moved && Math.abs(ev.clientX - x0) + Math.abs(ev.clientY - y0) < 5) return;
        moved = true;
        ghost.style.left = (ev.clientX + 12) + "px"; ghost.style.top = (ev.clientY + 12) + "px";
        const over = document.elementFromPoint(ev.clientX, ev.clientY), it = itemOf(over);
        if (!it || it === drag || !container.contains(it) || it.parentElement !== drag.parentElement) return;
        const r = it.getBoundingClientRect(), before = ev.clientY < r.top + r.height / 2;
        it.parentElement.insertBefore(drag, before ? it : it.nextSibling);
      };
      const up = () => {
        document.removeEventListener("pointermove", move); document.removeEventListener("pointerup", up);
        drag.classList.remove("dragging"); ghost.remove(); ghost = null;
        const it = drag, parent = it.parentElement; drag = null;
        const ids = () => $$(opts.items, parent).filter(x => x.parentElement === parent).map(x => x.dataset[opts.key]);
        if (moved) { opts.onOrder(ids()); return; }
        // a click, not a drag: ask where it goes
        const label = (x) => (x.dataset.label || x.textContent || "").trim().slice(0, 60);
        const others = $$(opts.items, parent).filter(x => x.parentElement === parent && x !== it);
        const m = modal(`<h2>Move ${esc(label(it))}</h2><p class="small muted">Choose its new place; the change is saved at once.</p>
          <div class="field"><label>Put it</label><select id="mv-where"><option value="first">first</option>${others.map((x, i) => `<option value="${i}">after ${esc(label(x))}</option>`).join("")}</select></div>
          <div class="row" style="margin-top:14px;justify-content:flex-end"><button class="btn" id="mv-cancel">Cancel</button><button class="btn primary" id="mv-ok">Move</button></div>`);
        // the current position is the default: "after" the item just before it, or first
        const before = it.previousElementSibling && others.indexOf(it.previousElementSibling);
        if (before !== null && before >= 0) $("#mv-where", m).value = String(before);
        $("#mv-cancel", m).onclick = () => m.remove();
        $("#mv-ok", m).onclick = () => {
          const v = $("#mv-where", m).value;
          if (v === "first") parent.insertBefore(it, others[0] || null); else others[+v].after(it);
          m.remove(); opts.onOrder(ids());
        };
      };
      document.addEventListener("pointermove", move); document.addEventListener("pointerup", up);
    });
  }
  // A confirmation that cannot be clicked through: the person types the name of the thing (a device name, an
  // address) before Remove is enabled, so the wrong row is never removed by reflex. Resolves true or false.
  // Who did it is recorded server-side in the audit log with every removal (user, role, address, what).
  function confirmTyped({ title, text, mustType, button = "Remove" }) {
    return new Promise((resolve) => {
      const bg = modal(`<h2>${esc(title)}</h2><p class="small muted">${text}</p>
        <div class="field" style="margin-top:10px"><label>Type <code>${esc(mustType)}</code> to confirm</label><input id="ct-input" class="mono" autocomplete="off" spellcheck="false" placeholder="${esc(mustType)}"></div>
        <div class="row" style="margin-top:14px;justify-content:flex-end"><button class="btn" id="ct-cancel">Cancel</button><button class="btn danger" id="ct-ok" disabled>${esc(button)}</button></div>`);
      const inp = $("#ct-input", bg), ok = $("#ct-ok", bg);
      const done = (v) => { bg.remove(); resolve(v); };
      inp.oninput = () => { ok.disabled = inp.value.trim() !== mustType; };
      inp.onkeydown = (e) => { if (e.key === "Enter" && !ok.disabled) done(true); };
      ok.onclick = () => done(true);
      $("#ct-cancel", bg).onclick = () => done(false);
      bg.addEventListener("click", (e) => { if (e.target === bg) resolve(false); });
      setTimeout(() => inp.focus(), 0);
    });
  }
  // A plain yes/no, for something that is reversible but should not happen by a stray click: zeroing a
  // counter, for one. Anything that loses data uses confirmTyped instead. Resolves true or false.
  function confirm2({ title, text, button = "Yes", danger = false }) {
    return new Promise((resolve) => {
      const bg = modal(`<h2>${esc(title)}</h2><p class="small muted">${text}</p>
        <div class="row" style="margin-top:14px;justify-content:flex-end"><button class="btn" id="cf-cancel">Cancel</button><button class="btn ${danger ? "danger" : "primary"}" id="cf-ok">${esc(button)}</button></div>`);
      const done = (v) => { bg.remove(); resolve(v); };
      $("#cf-ok", bg).onclick = () => done(true);
      $("#cf-cancel", bg).onclick = () => done(false);
      bg.addEventListener("click", (e) => { if (e.target === bg) resolve(false); });
      setTimeout(() => $("#cf-ok", bg).focus(), 0);
    });
  }
  // A real drop-down for a box you can also type in (Paul, 21 Sep 2026: "make this a real drop down menu,
  // not this call out box"). <datalist> was doing this job and the browser draws it as a pale callout that
  // matches nothing else on the page, cannot show two columns, and hides on a second keystroke. This is one
  // list we draw ourselves: click the box or the caret for everything, type to narrow, arrows and Enter to
  // pick, Escape to close. The input keeps its value, so anything already reading the input still works.
  //
  //   Lab.combo(input, { items: [{value, label, hint, note}], onPick, onOpen })
  //
  // It returns a handle: .set(items) replaces the list (used when a search answers), .open(), .close().
  function combo(inp, opts = {}) {
    if (inp._combo) { if (opts.items) inp._combo.set(opts.items); return inp._combo; }
    const wrap = inp.closest(".cbox") || inp.parentElement;
    wrap.classList.add("cbox");
    let menu = wrap.querySelector(".cbox-menu");
    if (!menu) { menu = document.createElement("div"); menu.className = "cbox-menu hidden"; menu.setAttribute("role", "listbox"); wrap.appendChild(menu); }
    if (!wrap.querySelector(".cbox-caret")) {
      const c = document.createElement("button");
      c.type = "button"; c.className = "cbox-caret"; c.tabIndex = -1; c.textContent = "▾"; c.title = "Show the list";
      c.addEventListener("mousedown", (e) => { e.preventDefault(); open ? close() : (inp.focus(), show(true)); });
      inp.after(c);
    }
    let items = opts.items ? opts.items.slice() : [], open = false, cur = -1, shown = [], picked = "";
    // Putting the cursor back in the field after a pick or an Escape must not re-open the list the pick
    // just closed, and the field's focus handler is what opens it.
    let reopen = true;
    const backToField = () => { reopen = false; inp.focus(); setTimeout(() => { reopen = true; }, 0); };
    // The text a chosen item puts in the box. A caller can write its own form (a tenant box holds
    // "name · id"); the combo has to know that form or it reads it back as something typed.
    const disp = (t) => (opts.display ? opts.display(t) : (t.label || t.value || ""));
    // What is in the box is an ANSWER, not a query, when it is what a pick wrote - including a value the
    // box was BUILT with (editing an existing row). Without the second test the chosen value went on
    // filtering the list, so opening the box showed only the item already chosen and the rest were
    // unreachable until you cleared it (Paul, 21 Sep 2026: "as soon as I select a tenant, it becomes the
    // filter instead of a selection").
    const isPicked = () => { const v = (inp.value || "").trim(); return !!v && (v === picked || items.some(t => disp(t) === v)); };
    // Every drop-down in these apps offers the same thing: a list, and a box to narrow it with (Paul,
    // 22 Sep 2026: "make every drop down like the device type. I should have a filter"). For a combo the
    // box in the menu holds the QUERY while the field keeps the chosen value, so a picked tenant is still
    // readable while its list is being searched. Typing straight into the field still filters, which is
    // what a caller setting .value and firing "input" relies on.
    let filter = "";
    const query = () => filter || (isPicked() ? "" : (inp.value || "").trim());
    const matches = () => {
      const q = query().toLowerCase();
      if (!q) return items;                        // a chosen value is an answer, not a query
      return items.filter(t => `${t.label || ""} ${t.hint || ""} ${t.note || ""} ${t.value || ""}`.toLowerCase().includes(q));
    };
    const ask = (q) => { if (opts.onQuery) opts.onQuery(q); };
    const draw = (refocus) => {
      shown = matches();
      if (cur >= shown.length) cur = shown.length - 1;
      const q = query();
      // the list is redrawn whenever its items change - a platform search answering, a dependent box
      // being refilled - and that replaces the box being typed into, so its caret is put back
      const live = menu.querySelector(".cbox-filter input");
      const at = live && document.activeElement === live ? live.selectionStart : null;
      const list = shown.length
        ? shown.map((t, i) => `<button type="button" class="cbox-opt${i === cur ? " on" : ""}" role="option" data-i="${i}">
             <span class="t">${esc(t.label || t.value || "")}</span>${t.note ? `<span class="n">${esc(t.note)}</span>` : ""}${t.hint ? `<span class="h">${esc(t.hint)}</span>` : ""}</button>`).join("")
        : `<div class="cbox-none">${esc(opts.empty || "Nothing matches. Keep typing, or type a value of your own.")}</div>`;
      // a device can write a field nobody listed, and a tenant ID can be pasted before it is imported:
      // nothing typed here may become unreachable just because the list does not hold it
      const own = (!shown.length && q) ? `<button type="button" class="cbox-own" data-own>Use <b>${esc(q)}</b> as typed</button>` : "";
      menu.innerHTML = `<div class="cbox-filter"><input type="text" placeholder="Type to filter" value="${esc(filter)}" spellcheck="false" autocomplete="off"></div>` + list + own;
      const f = menu.querySelector(".cbox-filter input");
      f.oninput = () => { filter = f.value; cur = -1; ask(query()); draw(); };
      f.onkeydown = (e) => {
        if (e.key === "Escape") { e.stopPropagation(); close(); backToField(); }
        else if (e.key === "Enter") { e.preventDefault(); if (shown.length) pick(cur >= 0 ? cur : 0); else useTyped(); }
        else if (e.key === "ArrowDown" || e.key === "ArrowUp") {
          e.preventDefault();
          cur = Math.max(0, Math.min(shown.length - 1, cur + (e.key === "ArrowDown" ? 1 : -1)));
          draw(true);
          const on = menu.querySelector(".cbox-opt.on"); if (on) on.scrollIntoView({ block: "nearest" });
        }
      };
      if (at !== null) { f.focus(); f.setSelectionRange(at, at); }
      else if (refocus) f.focus();
    };
    const useTyped = () => {
      const q = query(); if (!q) return;
      inp.value = q; picked = q; filter = ""; close();
      if (menu.contains(document.activeElement)) backToField();
      inp.dispatchEvent(new Event("input", { bubbles: true }));
      if (opts.onPick) opts.onPick({ value: q, label: q, typed: true }, inp);
      picked = (inp.value || "").trim();
    };
    const place = () => {
      // inside a scrolling dialog: open upward when the list would not fit below the field
      const r = inp.getBoundingClientRect();
      menu.classList.toggle("up", r.bottom + 240 > window.innerHeight && r.top > 260);
    };
    // a box made read-only (a log source's predefined options lock its field) offers no list: a pick would write
    // into it all the same
    const show = (all) => { if (inp.readOnly || inp.disabled) return; if (all) { cur = -1; filter = ""; } draw(!!all); place(); menu.classList.remove("hidden"); open = true; if (opts.onOpen) opts.onOpen(); };
    const close = () => { menu.classList.add("hidden"); open = false; cur = -1; filter = ""; };
    const pick = (i) => {
      const t = shown[i]; if (!t) return;
      filter = "";
      inp.value = disp(t);
      picked = inp.value;
      close();
      if (menu.contains(document.activeElement)) backToField();
      inp.dispatchEvent(new Event("input", { bubbles: true }));
      if (opts.onPick) opts.onPick(t, inp);
      picked = (inp.value || "").trim();     // onPick may have written its own form of the same answer
    };
    menu.addEventListener("mousedown", (e) => {
      if (e.target.closest(".cbox-filter")) return;          // typing in the filter must keep its caret
      if (e.target.closest("[data-own]")) { e.preventDefault(); useTyped(); return; }
      const b = e.target.closest(".cbox-opt"); if (!b) return;
      e.preventDefault(); pick(+b.dataset.i);
    });
    // a box that already holds something PICKED selects itself on focus, so typing filters for a new one
    // instead of appending to the old (Paul, 21 Sep 2026: "if I have a value selected already, still let
    // me filter a new value"). A value typed by hand is left alone: it may be half-finished.
    inp.addEventListener("focus", () => {
      if (!reopen) return;
      const v = (inp.value || "").trim();
      if (isPicked()) picked = v;          // the filter box takes the typing now, so the value is left whole
      show(true);
    });
    inp.addEventListener("mousedown", () => { if (!open && reopen) setTimeout(() => { if (reopen && !open) show(true); }, 0); });
    inp.addEventListener("input", () => { if ((inp.value || "").trim() !== picked) picked = ""; filter = ""; ask(query()); show(); });
    wrap.addEventListener("focusout", () => setTimeout(() => { if (!wrap.contains(document.activeElement)) close(); }, 120));
    inp.addEventListener("keydown", (e) => {
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        if (!open) return show(true);
        cur = Math.max(0, Math.min(shown.length - 1, cur + (e.key === "ArrowDown" ? 1 : -1)));
        draw();
        const on = menu.querySelector(".cbox-opt.on"); if (on) on.scrollIntoView({ block: "nearest" });
      } else if (e.key === "Enter") {
        if (open && cur >= 0) { e.preventDefault(); pick(cur); }
      } else if (e.key === "Escape") {
        if (open) { e.stopPropagation(); close(); }     // the first Escape closes the list, not the dialog
      }
    });
    inp._combo = { set: (list) => { items = (list || []).slice(); if (open) draw(); }, items: () => items, open: () => show(true), close, isOpen: () => open };
    return inp._combo;
  }

  // Every <select> gets the same list, because the browser draws a native one as a white OS menu that
  // belongs to no page (Paul, 21 Sep 2026: "found more places we are not using our real drop down menu").
  // The <select> stays in the DOM and keeps the value - every line of code that reads .value, sets it, or
  // replaces the options still works - and a button plus our own menu are drawn over it. New selects are
  // picked up by a MutationObserver, so nothing has to call this after rendering.
  function skinSelect(sel) {
    if (sel.dataset.skin || sel.multiple || sel.size > 1) return;
    sel.dataset.skin = "1";
    const wrap = document.createElement("span");
    wrap.className = "sel";
    sel.parentNode.insertBefore(wrap, sel);
    wrap.appendChild(sel);
    const btn = document.createElement("button");
    btn.type = "button"; btn.className = "sel-btn";
    const menu = document.createElement("div");
    menu.className = "sel-menu hidden"; menu.setAttribute("role", "listbox");
    wrap.append(btn, menu);
    let open = false;
    const label = () => {
      // selectedIndex can still be -1 the instant a select is skinned (it is moved into the wrapper, and
      // the browser has not settled its selectedness yet): fall back to the option that carries the
      // selected attribute, then to the first one, so the button is never blank
      if (sel.selectedIndex < 0 && sel.options.length) {
        const i = Array.from(sel.options).findIndex(o => o.defaultSelected);
        sel.selectedIndex = i >= 0 ? i : 0;
      }
      const o = sel.options[sel.selectedIndex];
      btn.innerHTML = `<span class="t">${esc(o ? o.textContent : "")}</span><span class="c">▾</span>`;
      btn.disabled = sel.disabled;
      btn.classList.toggle("placeholder", !!o && !o.value);
    };
    let filter = "";
    // Every list gets one, however short it is: a drop-down that sometimes offers a filter and sometimes
    // does not is a different control each time (Paul, 22 Sep 2026, on a five-item organization list).
    const draw = () => {
      const q = filter.trim().toLowerCase();
      let html = "", group = null, shown = 0;
      Array.from(sel.options).forEach((o, i) => {
        if (q && !o.textContent.toLowerCase().includes(q)) return;
        shown += 1;
        const g = o.parentElement.tagName === "OPTGROUP" ? o.parentElement.label : null;
        if (g !== group) { group = g; if (g) html += `<div class="sel-grp">${esc(g)}</div>`; }
        html += `<button type="button" class="sel-opt${i === sel.selectedIndex ? " on" : ""}" role="option" data-i="${i}"${o.disabled ? " disabled" : ""}>${esc(o.textContent)}</button>`;
      });
      const box = `<div class="sel-filter"><input type="text" placeholder="Type to filter" value="${esc(filter)}" spellcheck="false" autocomplete="off"></div>`;
      menu.innerHTML = box + (html || `<div class="cbox-none">${q ? "Nothing matches " + esc(filter) : "Nothing to choose"}</div>`);
      const f = menu.querySelector(".sel-filter input");
      if (f) {
        f.oninput = () => { filter = f.value; const at = f.selectionStart; draw(); const g = menu.querySelector(".sel-filter input"); if (g) { g.focus(); g.setSelectionRange(at, at); } };
        f.onkeydown = (e) => {
          if (e.key === "Escape") { e.stopPropagation(); close(); btn.focus(); }
          else if (e.key === "Enter") { e.preventDefault(); const first = menu.querySelector(".sel-opt:not([disabled])"); if (first) choose(+first.dataset.i); }
          else if (e.key === "ArrowDown") { e.preventDefault(); const first = menu.querySelector(".sel-opt:not([disabled])"); if (first) first.focus(); }
        };
      }
    };
    const place = () => {
      const r = btn.getBoundingClientRect();
      menu.classList.toggle("up", r.bottom + Math.min(260, sel.options.length * 30 + 10) > window.innerHeight && r.top > 280);
    };
    const show = () => { filter = ""; draw(); place(); menu.classList.remove("hidden"); open = true;
      const on = menu.querySelector(".sel-opt.on"); if (on) on.scrollIntoView({ block: "nearest" });
      const f = menu.querySelector(".sel-filter input"); if (f) f.focus();
    };
    const close = () => { menu.classList.add("hidden"); open = false; filter = ""; };
    const choose = (i) => {
      const o = sel.options[i];
      if (!o || o.disabled) return;
      sel.selectedIndex = i; label(); close();
      sel.dispatchEvent(new Event("input", { bubbles: true }));
      sel.dispatchEvent(new Event("change", { bubbles: true }));
    };
    btn.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); open ? close() : show(); });
    btn.addEventListener("keydown", (e) => {
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        let i = sel.selectedIndex;
        do { i += e.key === "ArrowDown" ? 1 : -1; } while (sel.options[i] && sel.options[i].disabled);
        if (sel.options[i]) choose(i);
        if (open) show();
      } else if (e.key === "Escape" && open) { e.stopPropagation(); close(); }
      else if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open ? close() : show(); }
      else if (!open && e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
        e.preventDefault(); show(); filter = e.key; draw();
        const f = menu.querySelector(".sel-filter input"); if (f) { f.focus(); f.setSelectionRange(1, 1); }
      }
    });
    menu.addEventListener("click", (e) => {
      const b = e.target.closest(".sel-opt"); if (!b) return;
      e.preventDefault(); e.stopPropagation(); choose(+b.dataset.i);
    });
    // self-removing once the select has left the document: a dialog opened a hundred times in a long-lived tab
    // left a hundred of these behind (review, 7 Oct 2026)
    document.addEventListener("click", function outside(e) {
      if (!wrap.isConnected) { document.removeEventListener("click", outside); return; }
      if (open && !wrap.contains(e.target)) close();
    });
    // the options or the disabled state can change under us (a dependent select being refilled)
    new MutationObserver(() => { label(); if (open) draw(); }).observe(sel, { childList: true, subtree: true, attributes: true, attributeFilter: ["disabled"] });
    sel.addEventListener("change", label);
    sel._skin = label;          // kept for callers that already call it after setting .value
    // Code that SETS the value - a preset choosing "until I press Stop", a dialog filling itself in - fires no
    // change event, so the button went on showing the old choice while the select held the new one (Paul,
    // 8 Oct 2026, on the Send page's Steady stream preset: the button read "a number of events" under a hint
    // that said "until you press Stop"). This select's own value and selectedIndex setters now redraw the
    // button too: the browser's setter runs, then the label, so nothing that reads .value sees a difference.
    for (const prop of ["value", "selectedIndex"]) {
      let proto = Object.getPrototypeOf(sel), d = null;
      while (proto && !(d = Object.getOwnPropertyDescriptor(proto, prop))) proto = Object.getPrototypeOf(proto);
      if (!d || !d.get || !d.set) continue;
      Object.defineProperty(sel, prop, { configurable: true, enumerable: d.enumerable,
        get() { return d.get.call(this); }, set(v) { d.set.call(this, v); label(); } });
    }
    label();
    requestAnimationFrame(label);      // and once more after layout, for whatever settled late
  }
  function askText({ title, label, placeholder, note, ok, value }) {
    return new Promise((resolve) => {
      const m = modal(`<h2>${esc(title || "")}</h2>${note ? `<p class="small muted">${esc(note)}</p>` : ""}
        <div class="field"><label>${esc(label || "")}</label><input id="ask-v" value="${esc(value || "")}" placeholder="${esc(placeholder || "")}"></div>
        <div class="row" style="margin-top:14px;justify-content:flex-end"><button class="btn" id="ask-no">Cancel</button><button class="btn primary" id="ask-yes">${esc(ok || "OK")}</button></div>`);
      const inp = $("#ask-v", m);
      const done = (v) => { m.remove(); resolve(v); };
      $("#ask-no", m).onclick = () => done(null);      // Cancel is null; an empty answer with OK is "" (a note left blank is not a cancel)
      $("#ask-yes", m).onclick = () => done(inp.value.trim());
      inp.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); done(inp.value.trim()); } });
      setTimeout(() => inp.focus(), 0);
    });
  }
  function skinSelects(root) { $$("select", root || document).forEach(skinSelect); }
  if (typeof document !== "undefined") {
    const sweep = () => skinSelects(document);
    document.addEventListener("DOMContentLoaded", sweep);
    new MutationObserver((recs) => {
      for (const r of recs) for (const n of r.addedNodes) {
        if (n.nodeType !== 1) continue;
        if (n.tagName === "SELECT") skinSelect(n); else skinSelects(n);
      }
    }).observe(document.documentElement, { childList: true, subtree: true });
    sweep();
  }

  // ---- (i): the paragraph a label needs the first time and never again. A long hint under a box pushes
  // the thing it explains off the screen (Paul, 21 Sep 2026: "too big... better to have that as an (i)"),
  // so the text sits in a .infotext block that its own (i) button shows and hides.
  //   <label>What this is <button class="infob" data-info="ID">i</button></label>  …  <div class="infotext hidden" id="ID">…</div>
  function infoButtons(root) {
    $$("button.infob[data-info]", root || document).forEach(b => {
      if (b._info) return;
      b._info = true;
      b.type = "button";
      b.setAttribute("aria-label", b.title || "What this means");
      b.onclick = (e) => {
        e.preventDefault();
        const box = (root || document).querySelector("#" + b.dataset.info) || document.getElementById(b.dataset.info);
        if (!box) return;
        const open = box.classList.toggle("hidden");
        b.classList.toggle("on", !open);
      };
    });
  }


  // ---- "Update this X" card: upload a release bundle, see whether it is genuinely ours, install it.
  // Both apps have it and it behaves identically in both, because a feature whose whole job is to be
  // trusted must not be two implementations that can drift apart.
  //
  // The whole decision is the SIGNATURE. There is no hash for anyone to copy and compare by eye: a hash
  // proves only that a download was not corrupted, and whoever hands you the file hands you the hash
  // beside it. The host verifies with the public key installed on it, refuses anything else, and says
  // so in one line. Upload, read that line, press the button.
  //
  // opts: {what: "console"|"Ingest Studio", impact: () => html, confirm: {...}, rollback: {...}}
  // ---- the Update card: one step at a time.
  // Choose a bundle -> Verify it -> Install -> Done. The card shows the panel for the step it is on, and
  // nothing from the other three, under a strip that says where that is. The previous update, when it is
  // not the step on screen, is one line behind a disclosure. Paul, 1 Oct 2026, on the old card - a Done
  // box with its bar and log, then the picker, the still-staged bundle, the outage note, the Update button
  // and the check output, all at once and most of them green: "it's not clear what I'm done if I'm
  // progressing through the bottom". Green now means one thing: the update finished.
  //
  // updatePanel() is the whole decision and is pure, so apps/tests/test_lab.js drives it without a DOM.
  // What the helper reports (STATE): running / started / target / pid / slow; ended / ok / rc; stalled
  // (ended without recording a result, judged on installed_version against target); cleared (someone
  // pressed Stop waiting); staged {name, size, sha256, version, signature_ok, signature}; running_version
  // {version, build}; can_rollback / previous_version.
  function updatePanel(st, check) {
    st = st || {};
    const sd = st.staged && st.staged.name ? st.staged : null, v = st.running_version || {};
    const inst = st.installed_version || v.version || "";
    const onTarget = !!(st.target && inst && st.target === inst);
    const overtaken = !!(st.ended && !st.ok && onTarget);           // it failed, and the host got there anyway
    // A result holds the card for a while. A failure needs a person, so it stays a day. A success offers
    // only Roll back (Paul, 4 Oct 2026: "only have a rollback"), so it gives the card back after 15
    // minutes - long enough to see it worked and change your mind, and short enough that the next release
    // can be uploaded the same day. After that it is the history line under Choose, with Roll back still there.
    const age = st.ended ? Date.now() / 1000 - st.ended : Infinity;
    const fresh = age < ((st.ok || overtaken) ? 900 : 86400);
    const sameVer = !!(sd && sd.version && inst && sd.version === inst);
    const out = { sd, inst, sameVer, overtaken, fresh, history: false };
    if (st.running) return Object.assign(out, { panel: "install" });
    if (st.ended && !st.cleared && fresh) {
      // a different bundle staged since that run is the next job; the run becomes history
      if (sd && !sameVer && sd.version && sd.version !== st.target) return Object.assign(out, { panel: "verify", history: true });
      if (st.ok || overtaken) return Object.assign(out, { panel: "done" });
      return Object.assign(out, { panel: "failed" });
    }
    if (sd) return Object.assign(out, { panel: "verify", history: !!st.ended });
    return Object.assign(out, { panel: "choose", history: !!st.ended });
  }

  // The checker's lines, as a list rather than a block: "    ok   name: detail" / "    FAIL name: detail",
  // one summary line ("ERROR: ..." or "dry run: ...") and nothing else. Anything that does not parse is
  // kept as text, so a helper that could not even run still shows what it said.
  function parseChecks(output) {
    const items = [], rest = []; let summary = "";
    (output || "").split("\n").forEach(l => {
      const m = /^\s*(ok|FAIL)\s+([^:]+):\s*(.*)$/.exec(l);
      if (m) { items.push({ ok: m[1] === "ok", name: m[2].trim(), detail: m[3].trim() }); return; }
      const e = /^\s*(?:ERROR:|dry run:)\s*(.*)$/.exec(l);
      if (e) { summary = e[1].trim(); return; }
      if (l.trim() && !/^(==>|OK\s)/.test(l.trim())) rest.push(l);
    });
    return { items, summary, rest: rest.join("\n") };
  }

  function updateCard(opts) {
    let STATE = null, TIMER = null, CHECK = null, CHECKED = "", CHECKING = false, CLEANED = false, REFUSED = "", FIRST = null, STALE = false;
    const plain = noSGR;        // root helpers colour their output; keep every word, drop the codes
    const impactHtml = () => (opts.impact ? opts.impact() : "");
    const stop = () => { if (TIMER) { clearInterval(TIMER); TIMER = null; } updating(false); };
    const what = opts.what || "this console";

    const STEPS = ["Choose a bundle", "Verify it", "Install", "Done"];
    // each step's state for the strip: "done" (green tick), "cur" (where you are), "bad" (where it stopped), "ok" (finished), ""
    function stepsHtml(panel, failedAt) {
      const st = { choose: ["cur", "", "", ""], verify: ["done", failedAt ? "bad" : "cur", "", ""],
                   install: ["done", "done", "cur", ""], done: ["done", "done", "done", "ok"],
                   failed: ["done", "done", "bad", ""] }[panel] || ["cur", "", "", ""];
      return `<ol class="upsteps" id="up-steps">${STEPS.map((t, i) => {
        const k = st[i], mark = k === "done" || k === "ok" ? "✓" : k === "bad" ? "✗" : String(i + 1);
        return `<li class="${k}"><i>${mark}</i>${t}</li>`; }).join("")}</ol>`;
    }
    const when = (ts) => ts ? `<span class="upwhen">${esc(fmt.dt(ts))}</span>` : "";
    const tail = (log, n) => plain(log || "").split("\n").filter(l => l.trim()).slice(-n);
    const disc = (id, label, inner) => `<details class="updisc" id="${id}"><summary>${label}</summary>${inner}</details>`;

    function checksHtml(sd) {
      if (!CHECK) return `<div class="small muted" id="up-checkout" style="margin-top:8px">Checking that this host can take it…</div>`;
      const c = parseChecks(plain(CHECK.output || ""));
      const list = (items) => `<ul class="upchecks">${items.map(x => `<li class="${x.ok ? "pass" : "fail"}"><span class="ck ${x.ok ? "ok" : "bad"}">${x.ok ? "✓" : "✗"}</span><span><b>${esc(x.name)}</b>${x.detail ? `: <span class="d">${esc(x.detail)}</span>` : ""}</span></li>`).join("")}</ul>`;
      if (CHECK.ok) {
        return `<div id="up-checkout" style="margin-top:8px"><span class="ck ok">✓</span> <b>All ${c.items.length} checks passed</b> <span class="muted small">— this host can take it.</span>
          ${c.items.length ? disc("up-checks-d", "Show the checks", list(c.items)) : ""}</div>`;
      }
      const bad = c.items.filter(x => !x.ok);
      // An older release is refused on purpose: an update only moves forward. Say what going back IS,
      // rather than leaving a red line that reads like the bundle is broken (QA, 4 Oct 2026).
      const older = bad.some(x => /downgrade/i.test(x.name));
      const prev = STATE && STATE.previous_version;
      // Paul, 4 Oct 2026: "that's actually fine, we just need to make that clear" - so say the rule
      // plainly: no older release installs, and the one way back is ONE step, to a version we name.
      const back = older ? `<div class="small" style="margin-top:6px"><b>An older release cannot be installed</b>: an update only moves forward. ${
        STATE && STATE.can_rollback
          ? `The one way back is <b>Roll back</b>, and it goes back <b>one step only</b>: to v${esc(prev || "?")}, the version this host ran just before its last update. No other older version can be put on this host.`
          : `The one way back is a Roll back, which goes back one step to the version this host ran before its last update, and this host has none to go back to.`}</div>` : "";
      return `<div id="up-checkout" class="upfail"><b>${bad.length ? `${bad.length} check${bad.length === 1 ? "" : "s"} did not pass` : "The checks could not be run"}</b>, so nothing can be installed yet. ${when(CHECK.at)}
        ${bad.length ? list(bad) : ""}${c.summary ? `<div class="small" style="margin-top:6px">${esc(c.summary)}</div>` : ""}${back}
        ${c.rest && !bad.length ? `<pre class="small" style="margin:6px 0 0;white-space:pre-wrap">${esc(c.rest)}</pre>` : ""}
        ${c.items.length > bad.length ? disc("up-checks-d", "Show every check", list(c.items)) : ""}</div>`;
    }

    function stageHtml(d, v) {
      const sd = d.sd, prevV = STATE.previous_version ? "v" + esc(STATE.previous_version) : "the previous version";
      const rollback = STATE.can_rollback
        ? `<button class="btn" id="up-rollback" title="Put ${prevV} back">Roll back to ${prevV}</button>` : "";
      const pick = (label, primary) => `<input type="file" id="up-file" accept=".gz,.tgz,application/gzip,application/octet-stream" style="display:none"><button class="btn${primary ? " primary" : ""}" id="up-pick">${label}</button>`;
      if (d.panel === "choose") {
        return `<div class="upstage"><h4>Choose the release bundle</h4>
          ${REFUSED ? `<div class="upfail" id="up-refused" style="margin:0 0 10px"><b>That file was not accepted.</b> ${esc(REFUSED)}</div>` : ""}
          <p class="lead">${opts.bundle ? `The file is <code>${esc(opts.bundle)}</code>, on your own computer. ` : ""}It is checked on this host before anything is installed.</p>
          <div class="row actrow">${pick("Choose a release bundle…", true)}${rollback}<span class="small faint" id="up-note"></span></div>
          ${STATE.can_rollback ? "" : `<div class="small faint" style="margin-top:8px">Nothing to roll back to yet: no update has run on this host.</div>`}</div>`;
      }
      if (d.panel === "verify") {
        const sig = sd.signature_ok;
        const file = `<div class="upfile"><b>${esc(sd.name)}</b><span class="faint small">${fmt.n(sd.size)} bytes</span></div>
          <div class="small"><span class="ck ${sig ? "ok" : "bad"}">${sig ? "✓" : "✗"}</span> ${esc(sd.signature || (sig ? "signed by Stellar Cyber" : "not signed by Stellar Cyber"))}</div>`;
        if (!sig) return `<div class="upstage failed"><h4>This bundle was refused</h4>${file}
          <p class="lead" style="margin-top:8px">Only a release Stellar Cyber signed is ever installed. Nothing on this host was changed.</p>
          <div class="row actrow"><button class="btn primary" id="up-discard">Discard it</button>${pick("Choose another bundle")}<span class="small faint" id="up-note"></span></div></div>`;
        const ready = !!(CHECK && CHECK.ok);
        const older = !!(CHECK && !CHECK.ok && parseChecks(plain(CHECK.output || "")).items.some(x => !x.ok && /downgrade/i.test(x.name)));
        const same = d.sameVer ? `<div class="upwarn">This is the version already running (v${esc(sd.version)}): there is nothing new in it. Discard it unless you mean to put the same files back.</div>` : "";
        const go = ready ? `<button class="btn${d.sameVer ? "" : " primary"}" id="up-go">${d.sameVer ? `Install v${esc(sd.version)} again` : `Update ${esc(what)} now`}</button>` : "";
        return `<div class="upstage"><h4>${ready ? (d.sameVer ? "Already running this version" : `Ready to install v${esc(sd.version || "?")}`) : "Verifying the bundle"}</h4>${file}${checksHtml(sd)}${same}
          ${ready ? `<div class="upimpact">${impactHtml()}</div>` : ""}
          <div class="row actrow" style="margin-top:10px">${go}${CHECK && !CHECK.ok && !older ? `<button class="btn primary" id="up-recheck">Run the checks again</button>` : ""}<button class="btn${(d.sameVer && ready) || older ? " primary" : ""}" id="up-discard">Discard it</button>${older ? rollback : ""}${ready ? `<button class="btn" id="up-recheck">Run the checks again</button>` : ""}<span class="small faint" id="up-note"></span></div></div>`;
      }
      if (d.panel === "done") {
        const stalled = !!STATE.stalled;
        const title = d.overtaken ? `This host is on v${esc(d.inst)}.` : "Done.";
        const body = d.overtaken
          ? `The update started here did not report back, but the version it was installing is what is running now, so there is nothing outstanding.`
          : `${esc(what)} is now v${esc(v.version || d.inst || "?")}${v.build ? " (" + esc(String(v.build).split(" ")[0]) + ")" : ""}.${stalled ? " The installer stopped reporting when the service restarted, which is part of an install; this host is on the version that bundle installs, so it got there." : ""}`;
        // The page is behind the host: the card first saw another version, or lab.js noticed a new build. The
        // strip at the top says so too once the card is done, and BOTH carry a Reload - the one on the panel is
        // where the hand already is (Paul, 5 Oct 2026: "I like having both ... it is more convenient"); 1.1.39
        // dropped this one while the strip was up, which was not the ask - only the strip's timing was.
        const stale = STALE || BUILD_BAR;
        // No bar once it is done: a full bar says "in progress, at the end", and the thing a reader
        // wants here is that it finished and which version is running (Paul, 3 Oct 2026: "the progress
        // bar doesn't need to be there, just show it is done, and it's running in green").
        return `<div class="upstage good"><h4>${title}</h4>
          <p class="lead" style="margin-top:8px;color:var(--text)">${body} ${when(STATE.ended)}</p>
          ${stale ? `<p class="lead">This page is still running the previous one. Reload it to run the new one.</p>` : ""}
          <div class="row actrow">${stale ? `<button class="btn primary" id="up-reload">Reload the page</button>` : ""}${pick("Choose the next release…")}${rollback}<span class="small faint" id="up-note"></span></div>
          ${STATE.can_rollback ? `<div class="small faint" style="margin-top:8px">Roll back goes one step, to the version this host ran before this update. A newer release can be uploaded at any time; an older one is refused.</div>` : ""}
          ${STATE.log ? disc("up-log-d", "Show the installer’s log", `<div class="frame small uplog" id="up-hist-log"></div>`) : ""}</div>`;
      }
      if (d.panel === "failed") {
        const stalled = !!STATE.stalled;
        const title = stalled ? "That update stopped without reporting back." : "That update did not finish.";
        const why = stalled
          ? `It ended without recording a result, and this host is still on v${esc(d.inst || "?")}. Nothing here changed anything afterwards.`
          : `The installer reported a failure, and this host is still on v${esc(d.inst || "?")}. The last lines it wrote say where it stopped:`;
        const recover = stalled && opts.recover
          ? `<div class="small" style="margin-top:8px"><b>On the host, over SSH:</b> <code>${esc(opts.recover.cmd)}</code> <button class="infob" type="button" data-info="${esc(opts.recover.info)}">i</button></div>`
          : stalled ? `<div class="small" style="margin-top:8px">Upload the bundle and press Update again.</div>` : "";
        const lines = tail(STATE.log, 8);
        return `<div class="upstage failed"><h4>${title}</h4><p class="lead" style="color:var(--text)">${why} ${when(STATE.ended)}</p>
          ${lines.length ? `<pre class="small" style="margin:0;white-space:pre-wrap;color:var(--muted)">${esc(lines.join("\n"))}</pre>` : ""}${recover}
          <div class="row actrow" style="margin-top:10px">${sd && sd.signature_ok && !d.sameVer ? `<button class="btn primary" id="up-go">Try the update again</button>` : pick("Choose a release bundle…", true)}${sd ? `<button class="btn" id="up-discard">Discard the bundle</button>` : ""}${rollback}<button class="btn" id="up-dismiss" title="Stop showing this result. It changes nothing on the host.">Dismiss</button><span class="small faint" id="up-note"></span></div>
          ${STATE.log ? disc("up-log-d", "Show the whole log", `<div class="frame small uplog" id="up-hist-log"></div>`) : ""}</div>`;
      }
      return "";
    }

    function historyHtml(d) {
      if (!d.history || !STATE.ended) return "";
      const what2 = STATE.cleared ? "you stopped waiting on it" : STATE.ok ? `installed v${esc(STATE.target || d.inst || "?")}` : d.overtaken ? `did not report back, but v${esc(d.inst)} is running` : "did not finish";
      const why = STATE.cleared ? "You stopped waiting on that update. If it was still installing, the version shown above is what it reached."
        : STATE.stalled && !STATE.ok ? `It ended without recording a result, and this host was still on v${esc(d.inst || "?")}.` : "";
      return `<div class="uphist">${disc("up-history", `Previous update: ${what2} ${when(STATE.ended)}`,
        `${why ? `<div class="small muted" style="margin-top:6px">${why}</div>` : ""}<div class="frame small uplog" id="up-hist-log"></div>`)}</div>`;
    }

    function render(st) {
      STATE = st || {};
      const box = $("#up-body"), pillEl = $("#up-pill");
      if (!box) return;
      const v = STATE.running_version || {};
      // "Reload the page" is offered only when the page really is running an older build than the host:
      // the version the card first saw changed under it, or lab.js noticed a new X-App-Build.
      if (v.version) { const cur = v.version + "|" + (v.build || ""); if (FIRST === null) FIRST = cur; else if (cur !== FIRST) STALE = true; }
      const sd = STATE.staged && STATE.staged.name ? STATE.staged : null;
      if (sd && CHECK && CHECK.sha !== sd.sha256) CHECK = null;   // another bundle: the old answer is not about it
      const d = updatePanel(STATE, CHECK);
      // The pill answers two things in one glance: which version is running, and whether the last
      // attempt to change it worked (Paul, 2 Oct 2026). Green is the ordinary state - it is running,
      // and this is what it is running. Red is the one case that needs a person: the install failed,
      // so the version they chose is NOT the one running, and the pill says so rather than stating
      // the old version as though nothing had happened. Blue while an install is in flight, because
      // the version on the pill is true but is about to stop being true.
      if (pillEl) {
        const target = STATE.target || (sd && sd.version) || "";
        pillEl.innerHTML =
          d.panel === "failed" ? pill("bad", target ? "not running v" + target : "not running")
            : !v.version ? ""
              : pill(d.panel === "install" ? "info" : "ok", "running v" + v.version);
      }

      if (d.panel === "install") {
        // What is really known is how many steps the installer has ANNOUNCED - it prints one "==> ..."
        // line per step - and how long it has been going. The expected number of steps is only an
        // expectation, so the bar never reaches the end on it: it is capped until the run reports that
        // it ended, and the step it names is the installer's own words.
        const log = plain(STATE.log || ""), lines = log.split("\n").filter(l => l.startsWith("==> "));
        const nsteps = lines.length, expect = Math.max(opts.steps || 6, nsteps + 1);
        const pct = Math.max(4, Math.min(95, Math.round(100 * nsteps / expect)));
        const secs = STATE.started ? Math.max(0, Math.round(Date.now() / 1000 - STATE.started)) : null;
        const now = nsteps ? lines[nsteps - 1].slice(4) : "starting…";
        const back = STATE.action === "rollback";
        // Built ONCE, then patched. Rewriting the whole card on every two-second poll made the page
        // shorter for an instant each time, and a browser answers a shorter page by clamping the
        // window's scroll - which is why reading the bottom of this page kept throwing the reader back
        // to the top (Paul, 1 Oct 2026). The log is a frame for the same reason: it keeps its own
        // scroll across refreshes and follows the end only while the reader is already there.
        if (!$("#up-run")) {
          box._html = null;
          box.innerHTML = stepsHtml("install") + `<div id="up-run" class="upstage"><h4 id="up-title"></h4>
            <div class="upbar" role="progressbar" aria-valuemin="0" aria-valuemax="100"><i></i></div>
            <div class="small" style="margin-top:6px" id="up-step"></div>
            <div class="small muted" style="margin-top:4px" id="up-says"></div>
            <div class="row actrow" style="margin-top:8px"><button class="btn sm" id="up-stopwait">Stop waiting</button>
              <span class="small faint">Asks whether this is still running. It never stops an install part-way.</span></div>
            <div class="frame small uplog" id="up-log"></div></div>`;
          $("#up-stopwait").onclick = async () => {
            try { await api("POST", "/api/update/clear", {}); CHECK = null; await load(); }
            catch (e) { toast(errText(e), "bad"); }
          };
        }
        $("#up-title").textContent = (back ? "Putting the previous version back" : "Installing")
          + (STATE.target && !back ? " v" + STATE.target : "") + "…";
        const bar = $("#up-run .upbar");
        bar.setAttribute("aria-valuenow", pct);
        bar.firstElementChild.style.width = pct + "%";
        $("#up-step").textContent = `Step ${nsteps || 1} of about ${expect}: ${now}`
          + (secs !== null ? ` · ${secs < 90 ? secs + "s" : Math.round(secs / 60) + " min"} so far` : "");
        $("#up-says").textContent = STATE.slow
          ? "This has been going a long time, and it is still running (process " + (STATE.pid || "?") + "). An installer waiting for apt says so in the log below."
          : "This restarts as part of it, so the page may stop answering for a few seconds. The bar goes to the end when the new version answers.";
        frame.set("update-log", $("#up-log"), log.split("\n"),
                  { follow: true, empty: '<div class="faint">waiting for the installer’s first line…</div>' });
        return;
      }

      const failedAt = d.panel === "verify" && (!sd.signature_ok || (CHECK && !CHECK.ok));
      const html = stepsHtml(d.panel, failedAt) + stageHtml(d, v) + historyHtml(d);
      // An unchanged card is left alone, and an open disclosure stays open across a rebuild: the page
      // re-reads this card after every action, and a reader who opened the log must not lose it.
      if (html !== box._html) {
        const open = $$("details[id]", box).filter(x => x.open).map(x => x.id);
        box.innerHTML = html; box._html = html;
        open.forEach(id => { const x = $("#" + id, box); if (x) x.open = true; });
        bind(sd);
        infoButtons(box);
      }
      if ($("#up-hist-log")) frame.set("update-log-prev", $("#up-hist-log"), plain(STATE.log || "").split("\n"), { empty: '<div class="faint">no log was kept</div>' });
      // Once the version a bundle installs is the one running, the bundle has done its job: it is removed
      // here rather than left for someone to press "Discard" on (Paul, 4 Oct 2026: "shouldn't it show roll
      // back to previous version after the version has been updated?"). Roll back does not need it - it
      // uses the copy of the previous version kept on the host - and a failed run keeps its bundle, since
      // "Try the update again" does.
      if (d.panel === "done" && sd && d.sameVer && !CLEANED) {
        CLEANED = true;
        api("DELETE", "/api/update?installed=1").then(() => load()).catch(() => { CLEANED = false; });
      }
      // the checks run on their own as soon as a signed bundle is staged: a reader should not have to ask
      if (d.panel === "verify" && sd.signature_ok && !CHECK && !CHECKING && CHECKED !== sd.sha256) { CHECKED = sd.sha256; runCheck(); }
    }

    function bind(sd) {
      const file = $("#up-file"), note = $("#up-note");
      if ($("#up-pick") && file) $("#up-pick").onclick = () => file.click();
      if (file) file.onchange = async () => {
        const f = file.files && file.files[0];
        if (!f) return;
        if (note) note.textContent = `Uploading ${f.name}…`;
        try {
          // the bytes as they are: this is a file, not a form, and nothing about it is interpreted here
          const buf = await f.arrayBuffer();
          const r = await fetch(`/api/update/upload?name=${encodeURIComponent(f.name)}`,
            { method: "POST", headers: { "X-Requested-With": "microweb", "Content-Type": "application/octet-stream" }, body: buf });
          const dd = await r.json().catch(() => ({}));
          // A refusal at upload (an older release, the other product's bundle) stays IN the card, above the
          // Roll back it points to, rather than in a pop-up that is gone in nine seconds. Nothing was kept.
          if (!r.ok && dd.error) { if (note) note.textContent = ""; REFUSED = dd.error; file.value = ""; render(STATE); return; }
          if (!r.ok) throw new Error(`upload failed (${r.status})`);
          if (note) note.textContent = "";
          REFUSED = ""; CHECK = null; CHECKED = "";
          toast(dd.signature_ok ? "Signature verified: this bundle is from Stellar Cyber" : "Refused: " + (dd.signature || ""),
                dd.signature_ok ? "ok" : "bad");
          await load();
        } catch (e) { if (note) note.textContent = ""; toast(errText(e), "bad"); }
        file.value = "";
      };
      if ($("#up-discard")) $("#up-discard").onclick = async () => {
        try { await api("DELETE", "/api/update"); CHECK = null; CHECKED = ""; await load(); } catch (e) { toast(errText(e), "bad"); }
      };
      if ($("#up-dismiss")) $("#up-dismiss").onclick = async () => {
        try { await api("POST", "/api/update/clear", {}); await load(); } catch (e) { toast(errText(e), "bad"); }
      };
      if ($("#up-reload")) $("#up-reload").onclick = () => location.reload();
      if ($("#up-recheck")) $("#up-recheck").onclick = () => runCheck();
      if ($("#up-rollback")) $("#up-rollback").onclick = async () => {
        const r = opts.rollback || {};
        const yes = await confirmTyped({ title: r.title || "Go back to the previous version?",
                                         text: (r.text || "The previous version is put back.") + impactHtml(),
                                         mustType: r.mustType || "go back", button: r.button || "Go back" });
        if (!yes) return;
        try { await api("POST", "/api/update/rollback", {}, { fire: true }); }
        catch (e) { if (!e.network) return toast(errText(e), "bad"); }
        watch();
      };
      if ($("#up-go")) $("#up-go").onclick = async () => {
        const res = CHECK && CHECK.ok && CHECK.sha === (sd && sd.sha256) ? CHECK : await runCheck();
        if (!res || !res.ok) { toast("The checks did not pass, so nothing was installed. The card says which one.", "bad"); return; }
        const c = opts.confirm || {};
        const yes = await confirmTyped({
          title: c.title || "Update now?",
          text: `<b>${esc(sd.name)}</b> is signed by Stellar Cyber and passed every check.${impactHtml()}
                 A backup is taken first. If this stops answering within 45 seconds of the install, the version running now is put back automatically.`,
          mustType: c.mustType || "update", button: c.button || "Update now",
        });
        if (!yes) return;
        // Installing RESTARTS this console, so the answer to the request that starts it can legitimately
        // be lost - and losing it is not a failure. Reporting it as one put a red box on the screen in
        // the middle of a normal upgrade (Paul, 2 Oct 2026: "it flashed momentarily... we need to be
        // careful and not show the banner if it's part of the normal process"), AND skipped watch(), so
        // the card stopped following the install it had just started. Anything the console actually
        // ANSWERED is a real refusal and is still reported. watch() turns the quiet "restarting" strip
        // on, and its first poll says whether a run is really going: if the console never got this, the
        // card simply returns to the verify step.
        try { await api("POST", "/api/update/apply", {}, { fire: true }); }
        catch (e) { if (!e.network) return toast(errText(e), "bad"); }
        watch();
      };
    }

    // "Checking" is a STATE the card renders, never text written into the DOM behind render's back.
    // It used to be written straight into #up-checkout, and when the re-run gave the same answer as
    // before (a downgrade refused twice) render() found its cached HTML unchanged and left the DOM
    // alone - so "Checking…" stayed in the red box for good and the button looked hung (QA, 4 Oct 2026).
    async function runCheck() {
      if (CHECKING) return CHECK;
      const sha = STATE && STATE.staged ? STATE.staged.sha256 : "";
      const prev = CHECK;
      CHECKING = true; CHECK = null; render(STATE);
      try { CHECK = await api("POST", "/api/update/check"); }
      catch (e) {
        // a console that did not answer has not judged the bundle: saying the checks failed would
        // blame the file for the connection, so the last answer stands
        if (e.network) { pollFailed(e); CHECK = prev; CHECKING = false; render(STATE); return CHECK; }
        CHECK = { ok: false, output: errText(e) };
      }
      CHECKING = false;
      CHECK.sha = sha; CHECK.at = Date.now() / 1000;
      render(STATE);
      return CHECK;
    }

    function watch() {
      stop();
      // it restarts under us, so a failed poll is expected rather than an error
      updating(true);
      TIMER = setInterval(async () => {
        try { const st = await api("GET", "/api/update"); if (!st.running) stop(); render(st); }
        catch (e) { pollFailed(e); /* restarting: keep waiting, and say which it is */ }
      }, 2000);
      load().catch(() => {});
    }

    async function load() {
      if (!$("#up-body")) return;
      try { const st = await api("GET", "/api/update"); render(st); if (st.running && !TIMER) watch(); }
      catch (e) { $("#up-body").innerHTML = `<p class="small faint">${esc(errText(e))}</p>`; }
    }

    return { load, render, stop, recheck: runCheck };
  }

  // ---- certificate card (HTTPS and TLS): ONE card for every certificate either console manages
  const certDaysLeft = (f) => f && f.days_left != null ? (f.days_left < 0 ? `<span class="bad">expired ${-f.days_left} day(s) ago</span>` : f.days_left < 30 ? `<span class="warn">expires in ${f.days_left} day(s)</span>` : `expires in ${f.days_left} days`) : "";
  function certNames(list) { return (list || []).map(x => String(x).replace(/^IP Address:/, "").replace(/^DNS:/, "").trim()).filter(Boolean); }
  function certCovers(sans, host) {
    host = String(host || "").toLowerCase().replace(/^\[|\]$/g, "");
    return certNames(sans).some(n => { n = n.toLowerCase(); if (n === host) return true; if (n.startsWith("*.")) { const i = host.indexOf("."); return i > 0 && host.slice(i + 1) === n.slice(2); } return false; });
  }
  // ONE certificate card, built twice: this console's HTTPS (Settings -> Security) and syslog-ng's TLS listener on
  // 6514 (Log relay services -> Security). Paul, 5 Oct 2026: "there should be the syslog NG settings similar to the
  // HTTPS settings". A second copy of 150 lines would drift from the first within a week; the options carry what
  // differs - the routes, the ids, who has to trust it, and what happens after a change (the console swaps its
  // TLS context in place and the page must reload; syslog-ng is reloaded and the page carries on).
  function certCard(o) {
    let STATE = null, PANEL = null, NOTE = "";
    const I = (x) => `#${o.id}-${x}`, D = (w) => `${o.api}/download?which=${w}`;
    const open = (name) => { PANEL = name; if (STATE) render(STATE); };
    function render(c) {
      STATE = c;
      const box = $(o.body), pillEl = $(o.pill); if (!box) return;
      const u = c.in_use || null, here = o.here ? o.here(c) : null, csr = c.csr || null;
      const issued = u ? (u.self_signed ? (u.generated ? o.generatedWords : "self-signed") : `issued by ${u.issuer || "?"}`) : "no certificate file";
      if (pillEl) pillEl.innerHTML = !u ? pill(o.noneLevel || "bad", o.noneWords || "no certificate") : u.self_signed ? pill("warn", o.selfPill) : (u.days_left || 0) < 0 ? pill("bad", "expired") : (u.days_left || 0) < 21 ? pill("warn", `expires in ${u.days_left} days`) : pill("ok", "signed by a CA");
      const covers = u && here ? certCovers(u.sans, here) : false;
      const names = u ? certNames(u.sans) : [];
      // Reissue (Paul, 8 Oct 2026: "make it easy to re-issue the TLS certificate and HTTPS certificate"): the same
      // names, a new key and new dates, issued the way the server says it will be (c.reissue.via). Offered whenever
      // a certificate is in use and the root helper can change it.
      const rp = c.reissue || {}, canReissue = !!(u && rp.possible && c.helper !== false);
      const reissueTip = rp.via === "authority" ? "A new certificate for the same names, signed by this relay's own certificate authority" : "A new self-signed certificate for the same names";
      const warnings = (o.warnings ? o.warnings(c, u) : []);
      if (c.helper === false) warnings.push(o.helperMissing || "The root helper that changes this certificate is not installed on this host, so the certificate can be seen here but not changed. Run the installer again.");
      if (u && u.self_signed && o.selfWarning) warnings.push(o.selfWarning);
      if (u && !u.self_signed && here && !covers) warnings.push(`The certificate does not name <b>${esc(here)}</b>, the address you are using, so ${o.who} warn even though a CA signed it. Make a request that lists it${names.length ? ` (it names ${esc(names.join(", "))})` : ""}.`);
      box.innerHTML = `${o.purpose ? `<p class="small muted" style="margin:0 0 8px">${o.purpose}</p>` : ""}<dl class="kv"><dt>In use</dt><dd>${u ? `<b>${esc(u.subject || "")}</b> · ${esc(issued)}` : (o.noneText || "none")}</dd>
          ${u ? `<dt>Names it covers</dt><dd>${names.length ? esc(names.join(", ")) : "<span class=\"faint\">none: only a common name, which " + o.who + " ignore</span>"} ${u.self_signed || !here ? "" : covers ? pill("ok nodot", `covers ${esc(here)}`) : pill("warn nodot", `does not name ${esc(here)}`)}</dd>
          <dt>Expires</dt><dd>${certDaysLeft(u)}</dd><dt>Key</dt><dd>${esc(u.key || "")}</dd>
          <dt>Fingerprint</dt><dd><code class="small">${esc(u.fingerprint || "")}</code></dd>
          <dt>Files</dt><dd><code class="small">${esc(c.active_path || c.cert_path || "")}</code>${c.previous ? ` <span class="faint small">· the previous pair is kept as .prev (${esc(c.previous.subject || "")})</span>` : ""}${c.ca ? ` <span class="faint small">· CA on file: ${esc((c.ca.items || []).map(x => x.subject).join("; "))}</span>` : ""}</dd>` : ""}</dl>
        ${warnings.map(w => `<p class="small warn" style="margin:8px 0 0">⚠ ${w}</p>`).join("")}
        ${NOTE ? `<p class="small ok" id="${o.id}-note" style="margin:8px 0 0">${NOTE}</p>` : ""}
        <div class="toolbar" style="margin-top:10px">
          ${canReissue ? `<button class="btn sm primary ro-ok" id="${o.id}-reissue" title="${esc(reissueTip)}">Reissue this certificate</button>` : ""}
          <button class="btn sm ${canReissue ? "" : "primary "}ro-ok" id="${o.id}-b-install" ${c.helper === false ? "disabled" : ""}>${csr ? "Install the signed certificate" : "Install a certificate and its key"}</button>
          <button class="btn sm ro-ok" id="${o.id}-b-csr" ${c.helper === false ? "disabled" : ""}>${csr ? "Signing request (waiting for the certificate)" : "Or: create a signing request here"}</button>
          ${c.previous ? `<button class="btn sm ro-ok" id="${o.id}-restore">Put the previous certificate back</button>` : ""}
          ${u && !u.generated ? `<button class="btn sm ro-ok" id="${o.id}-reset">Back to a self-signed certificate</button>` : ""}
          ${u ? `<a class="btn sm" href="${D("cert")}" download="${o.dl.cert}">Download the certificate</a>` : ""}
          ${c.ca ? `<a class="btn sm" href="${D("ca")}" download="${o.dl.ca}">Download its CA</a>` : ""}
        </div>
        <div id="${o.id}-panel" style="margin-top:10px"></div>`;
      $(I("b-csr")).onclick = () => open(PANEL === "csr" ? null : "csr");
      $(I("b-install")).onclick = () => open(PANEL === "install" ? null : "install");
      const ri = $(I("reissue")); if (ri) ri.onclick = async () => {
        const how = rp.via === "authority"
          ? `It is signed by this relay's own certificate authority${rp.authority ? ` (${esc(rp.authority)})` : ""}, so everything that already trusts that authority trusts the new certificate too.`
          : `It is self-signed, because ${rp.authority_state === "off" ? "this host's own certificate authority is switched off" : "there is no certificate authority on this host"}. ${o.selfCost || ""}`;
        if (!await confirm2({ title: "Reissue this certificate?", button: "Reissue",
          text: `A new certificate and a new private key for the same names: <b>${esc((rp.names || []).join(", "))}</b>. ${how} The certificate in use now is kept as the previous one, so this can be undone with one click.${o.changeCost ? " " + o.changeCost : ""}` })) return;
        ri.disabled = true; ri.textContent = "Reissuing…";
        try { const r = await api("POST", `${o.api}/reissue`, {}); NOTE = o.after("reissue", r); PANEL = null; render(r.info); toast("Certificate reissued", "ok"); if (o.changed) o.changed(r, "reissue"); }
        catch (e) { ri.disabled = false; ri.textContent = "Reissue this certificate"; toast(errText(e), "bad"); } };
      const rs = $(I("restore")); if (rs) rs.onclick = async () => {
        if (!await confirm2({ title: "Put the previous certificate back?", text: `${esc((c.previous || {}).subject || "")} goes back into use. The one in use now becomes the previous one, so this can be undone the same way.${o.changeCost ? " " + o.changeCost : ""}` })) return;
        try { const r = await api("POST", `${o.api}/restore`, {}); NOTE = o.after("restore", r); PANEL = null; render(r.info); toast("Previous certificate restored", "ok"); if (o.changed) o.changed(r); } catch (e) { toast(errText(e), "bad"); } };
      const re = $(I("reset")); if (re) re.onclick = async () => {
        if (!await confirm2({ title: "Back to a self-signed certificate?", text: `A fresh self-signed certificate is made and used. ${o.selfCost} The certificate in use now is kept as the previous one.${o.changeCost ? " " + o.changeCost : ""}` })) return;
        try { const r = await api("POST", `${o.api}/reset`, {}); NOTE = o.after("reset", r); PANEL = null; render(r.info); toast("Self-signed certificate in use", "ok"); if (o.changed) o.changed(r); } catch (e) { toast(errText(e), "bad"); } };
      const panel = $(I("panel"));
      if (PANEL === "csr" && csr) {
        const when = csr.made_at ? new Date(csr.made_at * 1000).toLocaleString() : "";
        panel.innerHTML = `<p class="small" style="margin:0 0 6px">Request made ${esc(when)} for <b>${esc(csr.subject || "")}</b>${csr.sans && csr.sans.length ? `, naming ${esc(certNames(csr.sans).join(", "))}` : ""} (${esc(csr.key || "")}). Give this text, or the downloaded <code>.csr</code> file, to your certificate authority. The private key it belongs to stays on this host${csr.key_present ? "" : " <b class=\"bad\">- but its key file is missing: make a new request</b>"}. When the signed certificate comes back, press <b>2 · Install the signed certificate</b>.</p>
          <textarea readonly id="${o.id}-csr-text" rows="9" class="mono" style="width:100%;font-size:12px">${esc(csr.pem || "")}</textarea>
          <div class="toolbar" style="margin-top:6px"><button class="btn sm" id="${o.id}-csr-copy">Copy</button><a class="btn sm" href="${D("csr")}" download="${o.dl.csr}">Download (.csr)</a><button class="btn sm primary ro-ok" id="${o.id}-csr-next">2 · Install the signed certificate</button><button class="btn sm ro-ok" id="${o.id}-csr-new">Make a new request</button><button class="btn sm danger ro-ok" id="${o.id}-csr-rm">Discard the request</button></div>`;
        $(I("csr-copy")).onclick = async () => { try { await navigator.clipboard.writeText(csr.pem || ""); toast("Request copied", "ok"); } catch (e) { $(I("csr-text")).select(); toast("Clipboard blocked by the browser; the text is selected, copy it by hand", "bad"); } };
        $(I("csr-next")).onclick = () => open("install");
        $(I("csr-new")).onclick = () => open("csr-new");
        $(I("csr-rm")).onclick = async () => { if (!await confirm2({ title: "Discard the pending request?", danger: true, text: "The request and its private key are removed. A certificate your CA returns for it could then not be installed." })) return;
          try { const r = await api("DELETE", `${o.api}/csr`); PANEL = null; render(r.info); toast("Request discarded", "ok"); } catch (e) { toast(errText(e), "bad"); } };
      } else if (PANEL === "csr" || PANEL === "csr-new") {
        const hosts = []; [c.console_name, here].concat(c.url_hosts || []).forEach(h => { if (h && !hosts.includes(h) && h !== "localhost" && h !== "127.0.0.1") hosts.push(h); });
        const cn = c.console_name || hosts.find(h => !/^\d+\.\d+\.\d+\.\d+$/.test(h)) || hosts[0] || "";
        panel.innerHTML = `<div class="row"><div class="field" style="flex:1 1 320px"><label>Host name or domain (the common name)</label><input id="${o.id}-cn" value="${esc(cn)}"><div class="hint">${o.cnHint}</div></div>
            <div class="field" style="flex:0 0 200px"><label>Key</label><select id="${o.id}-key"><option value="rsa2048">RSA 2048 (usual)</option><option value="rsa4096">RSA 4096</option><option value="ec256">EC P-256</option></select></div></div>
          <div class="field"><label>${o.sansLabel} (one per line)</label><textarea id="${o.id}-sans" rows="3" style="width:100%">${esc(hosts.join("\n"))}</textarea><div class="hint">${o.sansHint}</div></div>
          <div class="row"><div class="field" style="flex:1 1 200px"><label>Organization</label><input id="${o.id}-org" placeholder="Acme Managed Security"></div><div class="field" style="flex:1 1 160px"><label>Department</label><input id="${o.id}-ou" placeholder="SOC"></div>
            <div class="field" style="flex:0 0 120px"><label>Country (2 letters)</label><input id="${o.id}-country" placeholder="US" maxlength="2"></div><div class="field" style="flex:1 1 140px"><label>State or region</label><input id="${o.id}-state"></div><div class="field" style="flex:1 1 140px"><label>City</label><input id="${o.id}-locality"></div></div>
          <div class="toolbar" style="margin-top:6px"><button class="btn sm primary ro-ok" id="${o.id}-csr-make">Create the request</button><button class="btn sm" id="${o.id}-csr-cancel">Cancel</button></div>
          <p class="small faint" style="margin:6px 0 0">A new private key is made on this host, readable by root only, and never shown or sent anywhere. The certificate in use is not touched until the signed one is installed. ${csr ? "<b>This replaces the pending request</b>: a certificate returned for the old one could no longer be installed." : ""}</p>`;
        $(I("csr-cancel")).onclick = () => open(null);
        $(I("csr-make")).onclick = async () => {
          const v = (x) => $(I(x)).value.trim();
          const body = { cn: v("cn"), key: $(I("key")).value, sans: $(I("sans")).value.split(/[\n,]+/).map(x => x.trim()).filter(Boolean),
            org: v("org"), ou: v("ou"), country: v("country"), state: v("state"), locality: v("locality") };
          if (!body.cn) { toast("Give the host name or domain the certificate is for", "bad"); return; }
          try { const r = await api("POST", `${o.api}/csr`, body); PANEL = "csr"; render(r.info); toast("Signing request made; give it to your CA", "ok"); } catch (e) { toast(errText(e), "bad"); } };
      } else if (PANEL === "install") {
        panel.innerHTML = `<p class="small muted" style="margin:0 0 8px"><b>What this certificate is for:</b> ${o.installFor}</p>
          <div class="row">
            <div class="field" style="flex:1 1 260px"><label>Certificate file (.pem, .crt, .cer or .key)</label><label class="btn sm pk" style="cursor:pointer;display:inline-block"><span class="pk-t">Choose the certificate file</span><input type="file" id="${o.id}-pem-file" accept=".pem,.crt,.cer,.key,.txt" style="display:none"></label><div class="hint" id="${o.id}-pem-name">${csr ? "The certificate your CA returned for the pending request." : "The server certificate issued for it."}</div></div>
            <div class="field" style="flex:1 1 260px" ${csr ? 'hidden' : ""}><label>Private key file (.key, .pem; no passphrase)</label><label class="btn sm pk" style="cursor:pointer;display:inline-block"><span class="pk-t">Choose the key file</span><input type="file" id="${o.id}-key-file" accept=".key,.pem,.crt,.cer,.txt" style="display:none"></label><div class="hint" id="${o.id}-key-name">The key that belongs to it. It goes straight to the root helper and is kept root-only; it is never shown back.</div></div>
            <div class="field" style="flex:1 1 260px"><label>CA certificate file (.pem, .crt, .cer) - recommended</label><label class="btn sm pk" style="cursor:pointer;display:inline-block"><span class="pk-t">Choose the CA file</span><input type="file" id="${o.id}-ca-file" accept=".pem,.crt,.cer,.key,.txt" style="display:none"></label><div class="hint" id="${o.id}-ca-name">The CA (root, and intermediates if any) that signed it: the chain is checked here before anything changes.</div></div>
          </div>
          <details style="margin-top:6px"><summary class="small">Paste instead of choosing files</summary>
            <div class="field" style="margin-top:6px"><label>Certificate (PEM)</label><textarea id="${o.id}-pem" rows="5" style="width:100%" placeholder="-----BEGIN CERTIFICATE-----"></textarea></div>
            ${csr ? "" : `<div class="field"><label>Private key (PEM)</label><textarea id="${o.id}-keytext" rows="4" style="width:100%" placeholder="-----BEGIN PRIVATE KEY-----"></textarea></div>`}
            <div class="field"><label>CA certificate (PEM)</label><textarea id="${o.id}-ca" rows="3" style="width:100%" placeholder="-----BEGIN CERTIFICATE-----"></textarea></div></details>
          <div class="toolbar" style="margin-top:8px"><button class="btn sm primary ro-ok" id="${o.id}-install">Install</button><button class="btn sm" id="${o.id}-install-cancel">Cancel</button></div>
          <p class="small faint" style="margin:6px 0 0">The pair is checked (key belongs to the certificate, not expired, loads in the TLS library, chains to the CA if given) before the one in use is replaced; the previous pair is kept and can be put back with one click.${o.changeCost ? " " + o.changeCost : ""}</p>`;
        // Once a file is picked, the button names it and both it and the line below turn to the success colour
        // (Paul, 2 Oct 2026: "that should show the name of the cert").
        const pick = (id, into, nameEl) => { const inp = $(I(id)); if (!inp) return; inp.onchange = async () => { const f = inp.files[0]; if (!f) return; const t = await f.text(); const tb = $(I(into)); if (tb) tb.value = t; const lab = inp.closest("label"), span = lab && lab.querySelector(".pk-t"); if (span) span.textContent = f.name; if (lab) lab.classList.add("ok"); const n = $(I(nameEl)); if (n) { n.innerHTML = `<b>Added:</b> ${esc(f.name)} (${f.size} bytes) — click again to pick a different file.`; n.classList.add("added"); } }; };
        pick("pem-file", "pem", "pem-name"); pick("ca-file", "ca", "ca-name"); pick("key-file", "keytext", "key-name");
        $(I("install-cancel")).onclick = () => open(null);
        $(I("install")).onclick = async () => {
          const cert = $(I("pem")).value.trim(), ca = $(I("ca")).value.trim(), keyBox = $(I("keytext")), key = keyBox ? keyBox.value.trim() : "";
          if (!cert) { toast("Choose the certificate file (or paste the certificate) first", "bad"); return; }
          if (!csr && !key && !/PRIVATE KEY-----/.test(cert)) { toast("Choose the private key file as well: without a pending request the key has to come with the certificate", "bad"); return; }
          const pem = key ? cert + "\n" + key + "\n" : cert;        // the route takes one PEM: certificate(s) + key
          try { const r = await api("POST", o.api, { pem, ca });
            NOTE = o.after("install", r); PANEL = null; render(r.info); toast("Certificate installed", "ok"); if (o.changed) o.changed(r); }
          catch (e) { toast(errText(e), "bad"); } };
      } else panel.innerHTML = "";
    }
    return { render, open, get panel() { return PANEL; }, set panel(v) { PANEL = v; } };
  }

  return { $, $$, esc, api, toast, showLogin, showApp, locked, login, logout, fmt, pill, spark, router, modal, topology, frame, hashParams, fullscreen, dismissables, keepOpen, setHtml, updating, sortable, confirmTyped, confirm: confirm2, combo, skinSelects, askText, whatToDo, infoButtons, errText, alignRows, fitCols, updateCard, updatePanel, parseChecks, pollFailed, offline, online, download, notices, certCard, certNames, certCovers };
})();
