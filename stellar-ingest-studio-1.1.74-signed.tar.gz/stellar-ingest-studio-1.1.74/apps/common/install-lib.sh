# Shared installer steps for the lab web apps. Sourced by apps/*/install.sh. Bash, root, Ubuntu/Debian
# and RHEL-family both fine (only python3, openssl, systemd and sudo are needed).
set -euo pipefail

LAB_USER=stellarlab
LAB_ROOT=/opt/stellar-lab
LAB_ETC=/etc/stellar-lab

need_root() { [[ $EUID -eq 0 ]] || { echo "run with sudo" >&2; exit 1; }; }

# The releases this is tested on. 22.04 was dropped on 2 Oct 2026 (Paul): "remove 22.04 for the
# install to show it's not supported on either relay or ingest". Read by BOTH kit installers through
# check_prereqs. packaging/install.sh ships alone in the bundle and cannot source this, so it carries
# its own copy of the same string and a packaging test holds the two equal.
SUPPORTED_UBUNTU="Ubuntu 24.04, 26.04"

# Says so and carries on: the host is the administrator's, and an untested release may well work.
check_os() {
  local id="" ver=""
  [[ -r /etc/os-release ]] && { . /etc/os-release; id="${ID:-}"; ver="${VERSION_ID:-}"; }
  case "$id:$ver" in
    ubuntu:24.04|ubuntu:26.04) return 0 ;;
    *) echo "note: this is tested on $SUPPORTED_UBUNTU; this host is ${PRETTY_NAME:-unknown} [not tested]" >&2 ;;
  esac
}

check_prereqs() {
  check_os
  for b in python3 openssl systemctl sudo; do
    command -v "$b" >/dev/null || { echo "missing: $b" >&2; exit 1; }
  done
  python3 - <<'EOF' || { echo "python3 >= 3.8 with sqlite3 and ssl is required" >&2; exit 1; }
import sys, sqlite3, ssl, hashlib
assert sys.version_info >= (3, 8)
assert hasattr(hashlib, "scrypt")
EOF
}

ensure_user() {
  id -u "$LAB_USER" >/dev/null 2>&1 || useradd --system --home-dir "$LAB_ROOT" --shell /usr/sbin/nologin "$LAB_USER"
}

# copy_app <app-name>   copies apps/common and apps/<app-name> from the kit into /opt/stellar-lab
# The code directories are STAGED beside the live ones and swapped in, so there is never a moment with
# no code on disk (the old shape removed the live directory first and then copied: a copy that failed
# half-way - a full disk, an interrupted session - left the service with nothing to start). The version
# that was running is kept at <dir>.prev until the next install, which is what `rollback` uses.
# /opt/stellar-lab holds CODE ONLY, root-owned and not writable by the service user, so nothing anyone
# typed into the console can live there and nothing an upgrade replaces can be a record.
copy_app() {
  local app=$1 src root
  src=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)     # .../apps
  root=$(cd "$src/.." && pwd)                               # the kit
  mkdir -p "$LAB_ROOT" "$LAB_ETC"
  for d in common "$app"; do
    rm -rf "$LAB_ROOT/$d.new"
    cp -r "$src/$d" "$LAB_ROOT/$d.new" || { rm -rf "$LAB_ROOT/$d.new"; echo "copy of $d failed; the installed version was not touched" >&2; exit 1; }
    find "$LAB_ROOT/$d.new" -name __pycache__ -type d -exec rm -rf {} + 2>/dev/null || true
    python3 -m compileall -q "$LAB_ROOT/$d.new" >/dev/null 2>&1 || { rm -rf "$LAB_ROOT/$d.new"; echo "$d does not compile; the installed version was not touched" >&2; exit 1; }
    find "$LAB_ROOT/$d.new" -name __pycache__ -type d -exec rm -rf {} + 2>/dev/null || true
    rm -rf "$LAB_ROOT/$d.prev"
    [[ -d "$LAB_ROOT/$d" ]] && mv "$LAB_ROOT/$d" "$LAB_ROOT/$d.prev"
    mv "$LAB_ROOT/$d.new" "$LAB_ROOT/$d"
  done
  # the version the console shows: the release number, and the exact build when the kit is a git checkout
  {
    cat "$root/packaging/VERSION" 2>/dev/null || echo "0.0.0"
    if command -v git >/dev/null 2>&1 && git -C "$root" rev-parse --short HEAD >/dev/null 2>&1; then
      echo "build $(git -C "$root" rev-parse --short HEAD)$(git -C "$root" status --porcelain 2>/dev/null | grep -q . && echo -modified) $(date -u +%Y-%m-%dT%H:%MZ)"
    fi
  } > "$LAB_ROOT/VERSION"
  chown -R root:root "$LAB_ROOT"; chmod -R go-w "$LAB_ROOT"
  chmod 750 "$LAB_ETC"; chown root:"$LAB_USER" "$LAB_ETC"
}

rand_hex() { openssl rand -hex "$1"; }

# hash_password  reads a password from the terminal twice, prints the scrypt hash

# Read a secret with visible feedback: a * per character, so an empty line is never mistaken for
# a frozen terminal. Backspace deletes. Falls back to a plain silent read where there is no tty.
read_secret() {
  local prompt="$1" out="" ch saved=""
  if [[ ! -r /dev/tty ]]; then read -r out; printf '%s' "$out"; return; fi
  # Echo is turned off ONCE for the whole loop. Using read -s per character toggles it between
  # characters, and anything typed ahead in that window is echoed in the clear - measured.
  saved=$(stty -g </dev/tty 2>/dev/null) || saved=""
  [[ -n "$saved" ]] && stty -echo </dev/tty 2>/dev/null
  printf '%s' "$prompt" >&2
  while IFS= read -r -n1 ch </dev/tty; do
    [[ -z "$ch" ]] && break
    if [[ "$ch" == $'\177' || "$ch" == $'\b' ]]; then
      [[ -n "$out" ]] && { out="${out%?}"; printf '\b \b' >&2; }
    else
      out+="$ch"; printf '*' >&2
    fi
  done
  [[ -n "$saved" ]] && stty "$saved" </dev/tty 2>/dev/null
  printf '\n' >&2
  printf '%s' "$out"
}

prompt_password_hash() {
  local p1 p2
  while true; do
    p1=$(read_secret "Admin password for the web UI (at least 12 characters): ")
    p2=$(read_secret "Again: ")
    [[ "$p1" == "$p2" ]] || { echo "passwords differ, try again" >&2; continue; }
    [[ ${#p1} -ge 12 ]] || { echo "use at least 12 characters" >&2; continue; }
    break
  done
  PW="$p1" python3 -c "import os,sys; sys.path.insert(0,'$LAB_ROOT/common'); import microweb; print(microweb.hash_password(os.environ['PW']))"
}

# env_get <file> <key>  -> value or empty
env_get() { [[ -f "$1" ]] && sed -n "s/^$2=//p" "$1" | head -1 | tr -d '"' || true; }

# write_env <file> KEY=VALUE...   (0640 root:stellarlab)
# Writes the keys it is given with the values it is given - the installer decides those (a new password,
# a --port) - and KEEPS every other key the file already has. keep_or below is for the installer's path
# keys: an upgrade used to rewrite every path to its default, so an administrator who had moved STATE_DIR
# to a bigger disk would have had an empty console afterwards, every record still on the old disk
# (review, 22 Sep 2026).
write_env() {
  local f=$1; shift
  local tmp="$f.tmp" keys="" kv
  for kv in "$@"; do keys="$keys|${kv%%=*}"; done
  { echo "# generated by the stellar-mt-lab installer on $(date -Is); edit and restart the service to apply"
    printf '%s\n' "$@"
    [[ -f "$f" ]] && grep -vE "^(#|(${keys#|})=)" "$f" || true
  } > "$tmp"
  mv "$tmp" "$f"
  chown root:"$LAB_USER" "$f"; chmod 640 "$f"
}
# keep_or <file> <key> <default>  -> the value the file has for key, else the default
keep_or() { local v; v=$(env_get "$1" "$2"); [[ -n "$v" ]] && printf '%s' "$v" || printf '%s' "$3"; }

# install_unit <name> <description> <exec> <env-file>
install_unit() {
  local name=$1 desc=$2 exec=$3 envf=$4
  cat > "/etc/systemd/system/$name.service" <<EOF
[Unit]
Description=$desc
After=network.target

[Service]
User=$LAB_USER
Group=$LAB_USER
EnvironmentFile=$envf
ExecStart=$exec
Restart=on-failure
RestartSec=3
PrivateTmp=yes
# The apps call a small allow-list of root helpers through sudo (see /etc/sudoers.d), so
# NoNewPrivileges and ProtectSystem must stay off.

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable "$name" >/dev/null
  systemctl restart "$name"
}

# install_sudoers <name> <rule-lines...>
install_sudoers() {
  local name=$1; shift
  # no "Defaults requiretty" line: Ubuntu's sudo build does not know that setting and rejects the file
  { echo "# stellar-mt-lab: allow-list of root commands for the $name web app"; printf '%s\n' "$@"; } > "/etc/sudoers.d/$name"
  chmod 440 "/etc/sudoers.d/$name"
  visudo -cf "/etc/sudoers.d/$name" >/dev/null || { echo "sudoers rule failed validation" >&2; rm -f "/etc/sudoers.d/$name"; exit 1; }
}

primary_ip() { ip -o -4 route get 1.1.1.1 2>/dev/null | sed -n 's/.*src \([0-9.]*\).*/\1/p' | head -1; }
# The address a browser can actually reach. On a cloud instance the interface address is private
# and useless to the person who will open the console, so ask the instance metadata service for the
# public one and print that, with the private address named beside it. Never guessed: if the host
# has no metadata service, or no public address, only the interface address is printed.
public_ip() {
  local tok ip
  tok=$(curl -s --max-time 1 -X PUT "http://169.254.169.254/latest/api/token" \
        -H "X-aws-ec2-metadata-token-ttl-seconds: 60" 2>/dev/null) || return 1
  [[ -n "$tok" ]] || return 1
  ip=$(curl -s --max-time 1 -H "X-aws-ec2-metadata-token: $tok" \
       "http://169.254.169.254/latest/meta-data/public-ipv4" 2>/dev/null) || return 1
  [[ "$ip" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || return 1
  printf '%s' "$ip"
}

