#!/usr/bin/env python3
"""What an administrator must do before this tool can manage a relay method - in ONE place.

The Log Relay Manager is a configuration manager and tester for syslog-ng and nginx. It does not install
them, does not upgrade them behind your back and does not own them: the program, its packages, its license
and its service are the administrator's. What this tool owns is its own configuration file beside yours,
the tenant map, and the checks that say whether the result works.

So when a program is missing, "not installed" is not an answer - the admin needs the steps. They are here,
and every place that needs them reads THIS file:

    packaging/install.sh          python3 prereq.py syslog      (the bundle ships this file next to it)
    stellar-relay prereq syslog   the same text on an installed host, --check to test this host
    the console                   GET /api/methods/prereq?key=syslog  -> the steps and the live checks

Run it:  python3 prereq.py syslog|nginx [--check] [--json]
"""
import json
import os
import re
import shutil
import subprocess
import sys
import textwrap

# --------------------------------------------------------------------------- the instructions
# Each step: what to run, why this relay needs it, and what a good answer looks like. Commands are exactly
# what an administrator types - no placeholders except <angle brackets>, which are always explained.
PREREQ = {
    "syslog": {
        "program": "syslog-ng",
        "label": "syslog-ng relay",
        "service": "syslog-ng",
        "what": "firewalls and other devices send syslog here; each log is wrapped with its tenant "
                "and forwarded to the parser's port on the Modular Sensor",
        "responsibility": [
            "syslog-ng is YOUR deployment. It comes from Ubuntu under its own license, you choose the "
            "version, and you keep the service, its updates and its system logging.",
            "This tool is a configuration manager and tester for it: it writes ONE file of its own, "
            "/etc/syslog-ng/conf.d/stellar-relay.conf, adds ONE line to /etc/syslog-ng/syslog-ng.conf "
            "(@include \"/etc/syslog-ng/conf.d/*.conf\") if it is not already there, and keeps the tenant "
            "map at /etc/syslog-ng/stellar-tenants.csv.src.",
            "Every change is checked with syslog-ng -s before it is applied and rolled back if syslog-ng "
            "refuses it. Nothing else in your syslog-ng configuration is read, rewritten or removed.",
            "It never installs, upgrades or removes syslog-ng. The Software updates card can run YOUR "
            "apt upgrade for it when you ask, and says what the restart costs.",
        ],
        "steps": [
            {
                "title": "Install syslog-ng and the two modules this relay uses",
                "run": ["sudo apt update",
                        "sudo apt install syslog-ng-core syslog-ng-scl syslog-ng-mod-add-contextual-data"],
                "why": "syslog-ng-core is the daemon. syslog-ng-scl is the configuration library the relay "
                       "configuration includes. syslog-ng-mod-add-contextual-data is the module that looks "
                       "each log's tenant up in the map - without it syslog-ng will not start with the relay "
                       "configuration, and there is no other way to key a tenant off a source address or a "
                       "field in the log.",
                "expect": "apt installs them and starts the service. On Ubuntu they are in the universe "
                          "component of the main archive; nothing from Stellar Cyber is involved.",
                "check": "installed",
            },
            {
                "title": "Confirm the version is 3.22 or newer",
                "run": ["syslog-ng --version | head -1"],
                "why": "The relay configuration uses failover() on its destinations (3.22+) and the 4.x "
                       "config version. Ubuntu 24.04 ships 4.3 and 26.04 ships 4.8, so a supported "
                       "Ubuntu is already fine; an older, hand-built syslog-ng may not be.",
                "expect": "syslog-ng 4 (4.8.1) - or any version 3.22 or higher.",
                "check": "version",
            },
            {
                "title": "Confirm the add-contextual-data module really loaded",
                "run": ["syslog-ng --version | grep add-contextual-data"],
                "why": "A package can be installed and the module still be missing on a hand-built or "
                       "stripped-down syslog-ng. This is the one module the relay cannot work without.",
                "expect": "add-contextual-data is printed. Nothing printed means the module is not there: "
                          "install syslog-ng-mod-add-contextual-data.",
                "check": "module",
            },
            {
                "title": "Have the service running and starting at boot",
                "run": ["sudo systemctl enable --now syslog-ng",
                        "systemctl status syslog-ng --no-pager"],
                "why": "This tool reloads and restarts syslog-ng, but it never enables a service you have "
                       "deliberately turned off. If syslog-ng is not running, no log is received at all.",
                "expect": "active (running), and enabled.",
                "check": "service",
            },
            {
                "title": "Make sure nothing else holds the syslog ports",
                "run": ["sudo ss -lnup | grep 514",
                        "sudo ss -lntp | grep 514",
                        "sudo ss -lntp | grep 601"],
                "why": "Ubuntu often has rsyslog installed. It does not listen on the network by default, "
                       "but if its imudp/imtcp modules were turned on it owns 514 and syslog-ng will fail "
                       "to bind. The listeners this relay opens are udp/tcp 514, tcp 601 (RFC 6587 octet "
                       "framing, what FortiGate reliable mode uses) and tcp 6514 (TLS).",
                "expect": "free, or held by syslog-ng itself. If rsyslog holds them, either turn its network "
                          "inputs off in /etc/rsyslog.conf, or: sudo systemctl disable --now rsyslog "
                          "(your own system logs then go to journald and syslog-ng).",
                "check": "ports",
            },
            {
                "title": "Confirm your own syslog-ng configuration is valid before anything is added to it",
                "run": ["sudo syslog-ng -s"],
                "why": "This is a syntax check only; it changes nothing. If YOUR configuration is already "
                       "broken, the relay's first apply would be blamed for it. Start from a clean check.",
                "expect": "no output at all. Any error here is in your existing configuration and must be "
                          "fixed first.",
                "check": None,
            },
            {
                "title": "Let the devices reach this host",
                "run": ["sudo ufw allow 514/udp", "sudo ufw allow 514/tcp",
                        "sudo ufw allow 601/tcp", "sudo ufw allow 6514/tcp"],
                "why": "Only the ports you actually use. In a cloud, the security group has to allow them "
                       "as well - it is a separate firewall and it is the usual reason a device 'sends and "
                       "nothing arrives'. The console's Firewall page does the same thing with a tick box.",
                "expect": "Rules added (or 'Skipping adding existing rule').",
                "check": None,
            },
        ],
        "then": {
            "title": "Then hand it to this console",
            "run": ["sudo stellar-relay add syslog",
                    "sudo stellar-relay setup syslog --sensor-ip <the Modular Sensor's address> --debug-log"],
            "why": "add installs the management package for syslog-ng (it refuses while syslog-ng is "
                   "missing). setup writes the relay configuration, renders it from the tenant map and "
                   "reloads syslog-ng. --debug-log also writes every forwarded record to a file, which is "
                   "what lets the console show you real logs while you pick the field that names a device; "
                   "turn it off later with setup --no-debug-log.",
        },
        "install_cmd": "sudo apt install syslog-ng-core syslog-ng-scl syslog-ng-mod-add-contextual-data",
    },
    "nginx": {
        "program": "nginx",
        "label": "nginx relay",
        "service": "nginx",
        "what": "log sources that POST webhook JSON (PAN-OS HTTP profiles, Meraki, CrowdStrike, Okta, "
                "cloud services) send here; the tenant travels in the Stellar-TenantID header",
        "responsibility": [
            "nginx is YOUR deployment: Ubuntu's package, your version, your service, your other sites.",
            "This tool writes /etc/nginx/conf.d/stellar-tenant-proxy.conf and the two tenant maps beside "
            "it, and nothing else. Every change is checked with nginx -t before it is applied.",
            "One thing it WILL do to your nginx, and says so when it does: Ubuntu's default site owns "
            "port 80 and would answer instead of the relay, so setup removes the "
            "/etc/nginx/sites-enabled/default link (the file in sites-available is kept, and the command "
            "that puts it back is printed). If port 80 is already serving something of yours, give the "
            "relay another port with setup --listen-port.",
        ],
        "steps": [
            {
                "title": "Install nginx",
                "run": ["sudo apt update", "sudo apt install nginx"],
                "why": "Ubuntu's own package, under its own license. No modules beyond the stock build are "
                       "needed: the relay uses map, geo and proxy_pass, which are all built in.",
                "expect": "apt installs it and the service starts.",
                "check": "installed",
            },
            {
                "title": "Have the service running and starting at boot",
                "run": ["sudo systemctl enable --now nginx", "systemctl status nginx --no-pager"],
                "why": "This tool reloads nginx; it does not enable a service you turned off.",
                "expect": "active (running), and enabled.",
                "check": "service",
            },
            {
                "title": "Decide what owns the port the log sources will POST to",
                "run": ["sudo ss -lntp | grep 80",
                        "sudo ss -lntp | grep 443",
                        "ls -l /etc/nginx/sites-enabled/"],
                "why": "If this host already serves a site on port 80, the relay must not take it. The "
                       "relay's own server block is a default_server, which is exactly what stops the "
                       "stock 'Welcome to nginx' site from hijacking the port - and is why setup removes "
                       "that site's link.",
                "expect": "Either nothing else on 80, or you choose another port for the relay with "
                          "setup --listen-port <port>.",
                "check": "default_site",
            },
            {
                "title": "Confirm your own nginx configuration is valid first",
                "run": ["sudo nginx -t"],
                "why": "A syntax check that changes nothing. Start from a clean one so the relay's first "
                       "apply is not blamed for an error that was already there.",
                "expect": "syntax is ok / test is successful.",
                "check": None,
            },
            {
                "title": "Let the log sources reach this host",
                "run": ["sudo ufw allow 80/tcp", "sudo ufw allow 443/tcp"],
                "why": "Only the port you use. In a cloud the security group must allow it too.",
                "expect": "Rules added.",
                "check": None,
            },
        ],
        "then": {
            "title": "Then hand it to this console",
            "run": ["sudo stellar-relay add nginx",
                    "sudo stellar-relay setup nginx --sensor-ip <the Modular Sensor's address> "
                    "--default-tenant <32-character tenant ID>"],
            "why": "add installs the management package for nginx (it refuses while nginx is missing). "
                   "setup writes the proxy configuration and the tenant maps and reloads nginx. The "
                   "default tenant is where a POST from a client that is in no map lands - use a catch-all "
                   "tenant so stray logs are quarantined rather than mixed into a real one.",
        },
        "install_cmd": "sudo apt install nginx",
    },
}

HEADLINE = ("The Stellar Cyber Log Relay Manager configures and tests {program}. It does not install it, "
            "and {program} stays your responsibility.")


# --------------------------------------------------------------------------- checking this host
def _run(argv, timeout=6):
    try:
        p = subprocess.run(argv, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except (OSError, subprocess.SubprocessError):
        return 127, ""


def _syslog_version():
    exe = shutil.which("syslog-ng") or "/usr/sbin/syslog-ng"
    if not os.path.exists(exe):
        return None, ""
    rc, out = _run([exe, "--version"])
    m = re.search(r"syslog-ng\s+\d+\s+\(([0-9.]+)\)", out) or re.search(r"Installer-Version:\s*([0-9.]+)", out)
    return (m.group(1) if m else None), out


def _service_state(name):
    rc, active = _run(["systemctl", "is-active", name])
    rc2, enabled = _run(["systemctl", "is-enabled", name])
    return active.strip(), enabled.strip()


def _checks_syslog():
    out = []
    exe = shutil.which("syslog-ng") or ("/usr/sbin/syslog-ng" if os.path.exists("/usr/sbin/syslog-ng") else "")
    ver, verout = _syslog_version()
    out.append({"id": "installed", "title": "syslog-ng is installed",
                "state": "ok" if exe else "missing",
                "detail": f"{exe}" if exe else "syslog-ng is not on this host",
                "fix": PREREQ["syslog"]["install_cmd"]})
    if ver:
        parts = [int(x) for x in re.findall(r"\d+", ver)[:2]] or [0]
        newer = (parts[0] > 3) or (parts[0] == 3 and len(parts) > 1 and parts[1] >= 22)
        out.append({"id": "version", "title": "version 3.22 or newer",
                    "state": "ok" if newer else "warn", "detail": f"syslog-ng {ver}",
                    "fix": "" if newer else "upgrade syslog-ng: the relay configuration uses failover(), which needs 3.22 or newer"})
        has = "add-contextual-data" in verout
        out.append({"id": "module", "title": "the add-contextual-data module is present",
                    "state": "ok" if has else "missing",
                    "detail": "listed in Available-Modules" if has else "not in this build's Available-Modules",
                    "fix": "" if has else "sudo apt install syslog-ng-mod-add-contextual-data"})
        scl = os.path.isdir("/usr/share/syslog-ng/include/scl")
        out.append({"id": "scl", "title": "the syslog-ng configuration library (scl) is present",
                    "state": "ok" if scl else "missing",
                    "detail": "/usr/share/syslog-ng/include/scl" if scl else "/usr/share/syslog-ng/include/scl is missing",
                    "fix": "" if scl else "sudo apt install syslog-ng-scl"})
    active, enabled = _service_state("syslog-ng")
    out.append({"id": "service", "title": "the syslog-ng service is running and enabled",
                "state": "ok" if (active == "active" and enabled == "enabled") else ("warn" if active == "active" else "missing"),
                "detail": f"{active or 'unknown'}, {enabled or 'unknown'}",
                "fix": "" if (active == "active" and enabled == "enabled") else "sudo systemctl enable --now syslog-ng"})
    rs_active, _ = _service_state("rsyslog")
    out.append({"id": "ports", "title": "nothing else is expected to hold udp/tcp 514",
                "state": "warn" if rs_active == "active" else "ok",
                "detail": "rsyslog is running (it does not listen on the network unless imudp/imtcp were turned on)"
                          if rs_active == "active" else "rsyslog is not running",
                "fix": "sudo ss -lnup | grep 514  - if rsyslog holds it, turn its network inputs off or: sudo systemctl disable --now rsyslog"
                       if rs_active == "active" else ""})
    return out


def _checks_nginx():
    out = []
    exe = shutil.which("nginx") or ("/usr/sbin/nginx" if os.path.exists("/usr/sbin/nginx") else "")
    ver = ""
    if exe:
        rc, o = _run([exe, "-v"])
        ver = o.strip().splitlines()[0] if o.strip() else "nginx"
    out.append({"id": "installed", "title": "nginx is installed", "state": "ok" if exe else "missing",
                "detail": ver or "nginx is not on this host", "fix": PREREQ["nginx"]["install_cmd"]})
    active, enabled = _service_state("nginx")
    out.append({"id": "service", "title": "the nginx service is running and enabled",
                "state": "ok" if (active == "active" and enabled == "enabled") else ("warn" if active == "active" else "missing"),
                "detail": f"{active or 'unknown'}, {enabled or 'unknown'}",
                "fix": "" if (active == "active" and enabled == "enabled") else "sudo systemctl enable --now nginx"})
    dflt = os.path.exists("/etc/nginx/sites-enabled/default")
    out.append({"id": "default_site", "title": "Ubuntu's default site does not own the relay's port",
                "state": "warn" if dflt else "ok",
                "detail": "/etc/nginx/sites-enabled/default is still enabled" if dflt else "the default site is not enabled",
                "fix": "setup removes that link for you (the file in sites-available is kept, and the command "
                       "that restores it is printed). Serving your own site on port 80? Give the relay another "
                       "port: setup --listen-port <port>" if dflt else ""})
    return out


def run_checks(key):
    """Read-only tests of THIS host, in the order of the steps. Nothing is written and no sudo is used, so a
    check that needs root (syslog-ng -s, ss -p) is a step to run by hand rather than a check here.
    A satisfied check carries no fix: "what fixes it" beside a green line reads as something still to do."""
    out = _checks_syslog() if key == "syslog" else _checks_nginx()
    for c in out:
        if c["state"] == "ok":
            c["fix"] = ""
    return out


def data(key, check=False):
    p = PREREQ[key]
    d = dict(p)
    d["key"] = key
    d["headline"] = HEADLINE.format(program=p["program"])
    if check:
        d["checks"] = run_checks(key)
    return d


# --------------------------------------------------------------------------- the same thing as text
def _wrap(text, indent="    ", width=96, hang=""):
    """One paragraph, wrapped. `hang` indents the continuation lines further, so a bullet or a "Why:" label
    stands out from the sentence that follows it."""
    return textwrap.fill(" ".join(text.split()), width=width, initial_indent=indent,
                         subsequent_indent=indent + hang)


def text(key, check=False, width=96):
    p = PREREQ[key]
    L = []
    bar = "=" * min(width, 96)
    L.append(bar)
    L.append(f"  {p['program'].upper()} IS NOT SET UP ON THIS HOST YET - what an administrator needs to do")
    L.append(bar)
    L.append("")
    L.append(_wrap(HEADLINE.format(program=p["program"]), indent="  "))
    L.append("")
    L.append(_wrap(f"What this relay method is for: {p['what']}.", indent="  ", hang="  "))
    L.append("")
    L.append("  Who owns what")
    for s in p["responsibility"]:
        L.append(_wrap("- " + s, indent="    ", hang="  "))
    L.append("")
    for i, st in enumerate(p["steps"], 1):
        L.append(f"  Step {i}. {st['title']}")
        for c in st["run"]:
            L.append(f"        {c}")
        L.append(_wrap("Why: " + st["why"], indent="        ", hang="     "))
        L.append(_wrap("You should see: " + st["expect"], indent="        ", hang="     "))
        L.append("")
    t = p["then"]
    L.append(f"  {t['title']}")
    for c in t["run"]:
        L.append(f"        {c}")
    L.append(_wrap("Why: " + t["why"], indent="        ", hang="     "))
    L.append("")
    if check:
        L.append("  This host, right now")
        for c in run_checks(key):
            mark = {"ok": "[ ok ]", "warn": "[warn]", "missing": "[ -- ]"}.get(c["state"], "[ ?? ]")
            L.append(f"    {mark} {c['title']}: {c['detail']}")
            if c["fix"]:
                L.append(_wrap("fix: " + c["fix"], indent="           ", hang="     "))
        L.append("")
    return "\n".join(L)


def main(argv):
    key = ""
    check = as_json = False
    for a in argv:
        if a in PREREQ:
            key = a
        elif a == "--check":
            check = True
        elif a == "--json":
            as_json = True
        elif a in ("-h", "--help"):
            print(__doc__.strip()); return 0
        else:
            print(f"unknown argument: {a}", file=sys.stderr); return 2
    if not key:
        print("which one? python3 prereq.py syslog|nginx [--check] [--json]", file=sys.stderr); return 2
    print(json.dumps(data(key, check=check), indent=2) if as_json else text(key, check=check))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
