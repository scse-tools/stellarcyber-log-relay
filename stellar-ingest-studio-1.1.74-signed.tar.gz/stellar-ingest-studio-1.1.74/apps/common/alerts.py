"""
alerts.py - email alerts through an SMTP relay, and the watcher that decides when to send one.

Two parts:

  Mailer   the SMTP settings (host, port, STARTTLS / TLS / none, optional sign-in, from, to) kept in
           a 600-permission JSON file, a send() that speaks to the relay with a timeout and turns every
           failure into our own sentence, and a test() that sends one message right now.

  Watcher  runs a list of CHECKS every interval. A check returns {key: {"ok": bool, "title": ..,
           "detail": ..}}. The watcher remembers what was bad last time: when something turns bad it
           mails "ALERT", when it turns good again it mails "RESOLVED", and while it stays bad it mails
           a reminder every `reminder_min`. Several changes in one interval go in one message. A one-off
           happening (a failover, a role change) is sent with event(). Every message, sent or not, is
           written to a history file the page shows, so "did it alert?" is answerable without a mailbox.

The password is never returned to the browser (the API shows whether one is set) and never logged.
Standard library only (smtplib, ssl, email).
"""
import json
import os
import smtplib
import socket
import ssl
import tempfile
import threading
import time
from email.message import EmailMessage
from email.utils import formatdate, make_msgid

DEFAULTS = {
    "enabled": False,
    "smtp_host": "", "smtp_port": 587, "security": "starttls",     # starttls | tls | none
    "username": "", "password": "",
    "from": "", "to": [],
    "subject_prefix": "",
    "reminder_min": 60,             # while a problem persists, remind this often (0 = never)
    "interval_s": 30,               # how often the checks run
    "conditions": {},               # check key prefix -> False to mute (everything is on by default)
    # what counts as a problem for the estimates (a stopped service is a fact; these are judgment calls)
    "thresholds": {"disk_pct_free": 10, "mem_pct_available": 8, "queue_records": 1000},
    # per-entry mutes for a known outage: exact key (or a key prefix) -> {until: ts|None, reason, by, at}
    "mutes": {},
    # per-entry settings: exact key -> {"enabled": bool, "threshold": number|None}; an entry's own limit beats the family's
    "overrides": {},
}
THRESHOLD_RANGE = {"disk_pct_free": (1, 95), "mem_pct_available": (1, 95), "queue_records": (1, 10_000_000)}
SECURITY = ("starttls", "tls", "none")


class Mailer:
    def __init__(self, path, app_name="Stellar Cyber relay", host=None):
        self.path = path
        self.app_name, self.host = app_name, host or socket.gethostname()
        self.lock = threading.Lock()

    def load(self):
        d = dict(DEFAULTS)
        d["conditions"] = {}
        try:
            with open(self.path) as f:
                stored = json.load(f)
            if isinstance(stored, dict):
                for k in DEFAULTS:
                    if k in stored:
                        d[k] = stored[k]
        except (OSError, ValueError):
            pass
        return d

    def set_mute(self, key, until=None, reason="", by=None):
        """Silence one entry (an exact check key such as disk./var/log or sensor.10.0.1.50.5564, or a prefix such
        as dest.5564) until a time, or until someone unmutes it. Expired mutes are dropped on the way."""
        key = str(key or "").strip()
        if not key or len(key) > 120 or any(c.isspace() for c in key):
            return "a mute needs the condition's key"
        with self.lock:
            d = self.load()
            now = time.time()
            mutes = {k: v for k, v in (d.get("mutes") or {}).items() if not v.get("until") or v["until"] > now}
            mutes[key] = {"until": float(until) if until else None, "reason": str(reason or "")[:200], "by": by or "", "at": now}
            d["mutes"] = mutes
            self._write(d)
        return None

    def set_override(self, key, enabled=None, threshold=None, by=None):
        """One entry's own settings: switched off for good, or its own threshold. Both None = back to the family's."""
        key = str(key or "").strip()
        if not key or len(key) > 120 or any(c.isspace() for c in key):
            return "an override needs the condition's key"
        if threshold is not None:
            try:
                threshold = float(threshold)
            except (TypeError, ValueError):
                return "the threshold must be a number"
            if not 0 <= threshold <= 10_000_000:
                return "the threshold must be between 0 and 10000000"
        with self.lock:
            d = self.load()
            ov = d.get("overrides") or {}
            if enabled in (None, True) and threshold is None:
                ov.pop(key, None)
            else:
                ov[key] = {"enabled": True if enabled is None else bool(enabled), "threshold": threshold, "by": by or "", "at": time.time()}
            d["overrides"] = ov
            self._write(d)
        return None

    def threshold_for(self, key, default, settings=None):
        """The limit for one entry: its own override, else the family default given."""
        ov = ((settings or self.load()).get("overrides") or {}).get(key) or {}
        return ov["threshold"] if ov.get("threshold") is not None else default

    def clear_mute(self, key):
        with self.lock:
            d = self.load()
            d.get("mutes", {}).pop(str(key), None)
            self._write(d)

    def public(self):
        """The settings as the page may see them: no password, only whether one is set."""
        d = self.load()
        d["password_set"] = bool(d.get("password"))
        d.pop("password", None)
        return d

    def save(self, changes, by=None):
        """Merge and validate. Returns the sentence of the first problem, or None."""
        d = self.load()
        for k, v in changes.items():
            if k not in DEFAULTS:
                continue
            if k == "password":
                if v is None or (isinstance(v, str) and set(v) <= {"•"}):
                    continue                      # the masked value the page sends back = unchanged
            d[k] = v
        # validate
        d["enabled"] = bool(d.get("enabled"))
        d["smtp_host"] = str(d.get("smtp_host") or "").strip()
        try:
            d["smtp_port"] = int(d.get("smtp_port") or 0)
        except (TypeError, ValueError):
            return "the SMTP port must be a number"
        if d["security"] not in SECURITY:
            return "security must be starttls, tls or none"
        d["from"] = str(d.get("from") or "").strip()
        to = d.get("to")
        if isinstance(to, str):
            to = [x.strip() for x in to.replace(";", ",").split(",")]
        d["to"] = [x for x in (to or []) if x]
        for addr in [d["from"]] + d["to"]:
            if addr and ("@" not in addr or " " in addr):
                return f"{addr} is not an email address"
        th = dict(DEFAULTS["thresholds"])
        for k, (lo, hi) in THRESHOLD_RANGE.items():
            v = (d.get("thresholds") or {}).get(k, th[k])
            try:
                v = int(v)
            except (TypeError, ValueError):
                return f"the {k.replace('_', ' ')} threshold must be a number"
            if not lo <= v <= hi:
                return f"the {k.replace('_', ' ')} threshold must be between {lo} and {hi}"
            th[k] = v
        d["thresholds"] = th
        if not isinstance(d.get("mutes"), dict):
            d["mutes"] = {}
        if not isinstance(d.get("overrides"), dict):
            d["overrides"] = {}
        try:
            d["reminder_min"] = max(0, int(d.get("reminder_min") or 0))
            d["interval_s"] = max(10, min(600, int(d.get("interval_s") or 30)))
        except (TypeError, ValueError):
            return "reminder minutes and interval seconds must be numbers"
        if d["enabled"]:
            if not d["smtp_host"] or not (1 <= d["smtp_port"] <= 65535):
                return "alerts are enabled but no SMTP relay host and port are set"
            if not d["from"] or not d["to"]:
                return "alerts are enabled but the From address or the recipients are empty"
        if not isinstance(d.get("conditions"), dict):
            d["conditions"] = {}
        with self.lock:
            self._write(d)
        return None

    def _write(self, d):
        """The settings file, atomically, 0600 (the SMTP password is in it). Call with the lock held."""
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(self.path) or ".", prefix=".alerts-")
        with os.fdopen(fd, "w") as f:
            json.dump(d, f, indent=1)
        os.chmod(tmp, 0o600)
        os.replace(tmp, self.path)

    @staticmethod
    def _reason(e, d):
        """Our own sentence for a failed send, never the exception's."""
        if isinstance(e, smtplib.SMTPAuthenticationError):
            return "the SMTP relay rejected the user name or password"
        if isinstance(e, smtplib.SMTPRecipientsRefused):
            return "the SMTP relay refused the recipient address(es): " + ", ".join(e.recipients)
        if isinstance(e, smtplib.SMTPSenderRefused):
            return f"the SMTP relay refused the From address {d['from']}"
        if isinstance(e, smtplib.SMTPConnectError):
            return f"{d['smtp_host']}:{d['smtp_port']} answered but did not accept the connection"
        if isinstance(e, smtplib.SMTPNotSupportedError):
            return "the SMTP relay does not offer STARTTLS on this port; try security 'tls' on 465, or 'none' for a relay inside your network"
        if isinstance(e, ssl.SSLError):
            return "the TLS handshake with the SMTP relay failed (wrong security setting for this port, or an untrusted certificate)"
        if isinstance(e, (socket.timeout, TimeoutError)):
            return f"no answer from {d['smtp_host']}:{d['smtp_port']} within 20 s (a firewall, or the wrong host or port)"
        if isinstance(e, ConnectionRefusedError):
            return f"{d['smtp_host']}:{d['smtp_port']} refused the connection: nothing is listening there"
        if isinstance(e, socket.gaierror):
            return f"the name {d['smtp_host']} does not resolve"
        if isinstance(e, smtplib.SMTPException):
            return f"the SMTP relay answered with an error: {getattr(e, 'smtp_error', b'').decode(errors='replace') if hasattr(e, 'smtp_error') else e.__class__.__name__}"
        if isinstance(e, OSError):
            return f"could not reach the SMTP relay: {e.strerror or e.__class__.__name__}"
        return f"sending failed: {e.__class__.__name__}"

    def send(self, subject, body, settings=None, force=False):
        """(ok, sentence). force sends even when alerts are disabled (the Test button)."""
        d = settings or self.load()
        if not d["enabled"] and not force:
            return False, "alerts are disabled"
        if not d["smtp_host"] or not d["to"] or not d["from"]:
            return False, "the SMTP relay host, the From address and at least one recipient are needed first"
        msg = EmailMessage()
        prefix = (d.get("subject_prefix") or "").strip()
        msg["Subject"] = (prefix + " " if prefix else "") + subject
        msg["From"], msg["To"] = d["from"], ", ".join(d["to"])
        msg["Date"], msg["Message-ID"] = formatdate(localtime=True), make_msgid()
        msg["X-Stellar-Relay"] = self.host
        msg.set_content(body)
        try:
            ctx = ssl.create_default_context()
            if d["security"] == "tls":
                s = smtplib.SMTP_SSL(d["smtp_host"], d["smtp_port"], timeout=20, context=ctx)
            else:
                s = smtplib.SMTP(d["smtp_host"], d["smtp_port"], timeout=20)
            with s:
                s.ehlo()
                if d["security"] == "starttls":
                    s.starttls(context=ctx)
                    s.ehlo()
                if d.get("username"):
                    s.login(d["username"], d.get("password") or "")
                s.send_message(msg)
            return True, f"sent to {', '.join(d['to'])} through {d['smtp_host']}:{d['smtp_port']}"
        except Exception as e:  # noqa: BLE001
            return False, self._reason(e, d)

    def test(self):
        body = (f"This is a test message from the {self.app_name} on {self.host}.\n\n"
                f"If you are reading it, the SMTP relay settings work and alerts from this host will arrive at this address.\n"
                f"Sent {time.strftime('%Y-%m-%d %H:%M:%S %Z')}.\n")
        return self.send(f"Test from {self.host}", body, force=True)


class Watcher(threading.Thread):
    """Runs the checks, keeps the bad set, sends on transitions. checks: [callable() -> {key: item}]."""

    def __init__(self, mailer, checks, state_path, history_path, link=None):
        super().__init__(daemon=True, name="alert-watcher")
        self.mailer, self.checks = mailer, list(checks)
        self.state_path, self.history_path, self.link = state_path, history_path, link
        self.lock = threading.Lock()
        self.bad = {}                 # key -> {title, detail, since, last_mail}
        self.last_run, self.last_error, self.runs = None, "", 0
        self.current = {}             # every item from the last run, ok or not
        self.stop_event = threading.Event()
        self._load_state()

    # ---- state
    def _load_state(self):
        try:
            with open(self.state_path) as f:
                d = json.load(f)
            self.bad = d.get("bad", {}) if isinstance(d, dict) else {}
        except (OSError, ValueError):
            self.bad = {}

    def _save_state(self):
        try:
            os.makedirs(os.path.dirname(self.state_path) or ".", exist_ok=True)
            tmp = self.state_path + ".tmp"
            with open(tmp, "w") as f:
                json.dump({"bad": self.bad, "saved": time.time()}, f)
            os.replace(tmp, self.state_path)
        except OSError:
            pass

    def _history(self, entry):
        try:
            os.makedirs(os.path.dirname(self.history_path) or ".", exist_ok=True)
            with open(self.history_path, "a") as f:
                f.write(json.dumps(dict(entry, ts=time.time())) + "\n")
        except OSError:
            pass

    def history(self, n=50):
        try:
            with open(self.history_path, "rb") as f:
                f.seek(0, 2); size = f.tell(); f.seek(max(0, size - 300_000))
                lines = f.read().decode(errors="replace").splitlines()
        except OSError:
            return []
        out = []
        for line in reversed(lines):
            try:
                out.append(json.loads(line))
            except ValueError:
                continue
            if len(out) >= n:
                break
        return out

    def muted(self, key, settings, now=None):
        """Off by the coarse switch (conditions: a whole family), or by a mute for this exact entry or a
        prefix of it (mutes: "disk./var/log", "dest.5564") that has not expired."""
        conds = settings.get("conditions") or {}
        if any(conds.get(prefix) is False for prefix in (key, key.split(".")[0])):
            return True
        if ((settings.get("overrides") or {}).get(key) or {}).get("enabled") is False:
            return True
        now = now or time.time()
        for mk, m in (settings.get("mutes") or {}).items():
            if (key == mk or key.startswith(mk + ".")) and (not m.get("until") or m["until"] > now):
                return True
        return False

    # ---- one pass
    def run_checks(self):
        items = {}
        for check in self.checks:
            try:
                for k, v in (check() or {}).items():
                    items[k] = v
            except Exception as e:  # noqa: BLE001
                self.last_error = f"a check failed: {e.__class__.__name__}: {e}"
        return items

    def evaluate(self, items=None, now=None):
        """Compare with the bad set, send what changed. Returns the list of messages sent (for tests)."""
        now = now or time.time()
        settings = self.mailer.load()
        items = self.run_checks() if items is None else items
        with self.lock:
            self.current = items
            newly_bad, resolved, reminders = [], [], []
            for key, it in items.items():
                if self.muted(key, settings, now):
                    self.bad.pop(key, None)       # silenced: forgotten without a RESOLVED mail; alerts again if still bad when unmuted
                    continue
                if not it.get("ok", True):
                    if key not in self.bad:
                        self.bad[key] = {"title": it.get("title", key), "detail": it.get("detail", ""), "since": now, "last_mail": 0}
                        newly_bad.append(key)
                    else:
                        self.bad[key]["detail"] = it.get("detail", self.bad[key].get("detail", ""))
                        rm = settings.get("reminder_min") or 0
                        if rm and now - self.bad[key]["last_mail"] >= rm * 60 and self.bad[key]["last_mail"]:
                            reminders.append(key)
                elif key in self.bad:
                    resolved.append((key, self.bad.pop(key)))
            # something that was bad and is no longer reported at all (a port that vanished from the config) resolves too
            for key in [k for k in self.bad if k not in items]:
                resolved.append((key, self.bad.pop(key)))
            sent = []
            if newly_bad or resolved or reminders:
                sent = self._send_summary(newly_bad, resolved, reminders, settings, now)
            self._save_state()
            self.last_run, self.runs = now, self.runs + 1
            return sent

    def _send_summary(self, newly_bad, resolved, reminders, settings, now):
        lines, subjects = [], []
        host = self.mailer.host
        for k in newly_bad:
            b = self.bad[k]; subjects.append("ALERT: " + b["title"])
            lines.append(f"PROBLEM  {b['title']}\n         {b['detail']}")
        for k, b in resolved:
            subjects.append("RESOLVED: " + b["title"])
            mins = (now - b.get("since", now)) / 60
            lines.append(f"RESOLVED {b['title']}\n         was a problem for {mins:.0f} minute(s)")
        for k in reminders:
            b = self.bad[k]; subjects.append("still: " + b["title"])
            mins = (now - b.get("since", now)) / 60
            lines.append(f"STILL    {b['title']} (for {mins:.0f} minute(s))\n         {b['detail']}")
        subject = subjects[0] if len(subjects) == 1 else f"{len(subjects)} changes on {host}: " + "; ".join(subjects)[:120]
        subject = f"{host}: {subject}" if len(subjects) == 1 else subject
        body = "\n\n".join(lines) + f"\n\nHost: {host}\nTime: {time.strftime('%Y-%m-%d %H:%M:%S %Z', time.localtime(now))}\n"
        if self.link:
            body += f"Console: {self.link}\n"
        if self.bad:
            body += "\nStill open:\n" + "\n".join(f"  - {b['title']}" for b in self.bad.values()) + "\n"
        ok, reason = self.mailer.send(subject, body, settings)
        for k in newly_bad + reminders:
            if k in self.bad:
                self.bad[k]["last_mail"] = now if ok else self.bad[k]["last_mail"]
        entry = {"subject": subject, "to": settings.get("to", []), "ok": ok, "result": reason, "keys": newly_bad + [k for k, _ in resolved] + reminders,
                 "kind": "summary"}
        self._history(entry)
        return [entry]

    def event(self, key, title, detail):
        """A one-off happening (a failover, a role change): one message, no state."""
        settings = self.mailer.load()
        if self.muted(key, settings):
            return None
        body = f"{title}\n{detail}\n\nHost: {self.mailer.host}\nTime: {time.strftime('%Y-%m-%d %H:%M:%S %Z')}\n" + (f"Console: {self.link}\n" if self.link else "")
        ok, reason = self.mailer.send(f"{self.mailer.host}: {title}", body, settings)
        entry = {"subject": title, "to": settings.get("to", []), "ok": ok, "result": reason, "keys": [key], "kind": "event"}
        self._history(entry)
        return entry

    def status(self):
        with self.lock:
            return {"running": self.is_alive(), "last_run": self.last_run, "runs": self.runs, "last_error": self.last_error,
                    "problems": [{"key": k, **v} for k, v in sorted(self.bad.items())],
                    "checked": len(self.current), "items": self.current}

    def run(self):
        while not self.stop_event.is_set():
            try:
                self.evaluate()
            except Exception as e:  # noqa: BLE001
                self.last_error = f"watcher failed: {e.__class__.__name__}: {e}"
            interval = self.mailer.load().get("interval_s") or 30
            self.stop_event.wait(interval)


def register_routes(app, mailer, watcher, guard=None):
    """GET /api/alerts, PUT /api/alerts (admin), POST /api/alerts/test (admin). `guard()` runs first on every
    route when given (the relay uses it to keep alerts out of its standard console)."""
    import microweb as mw
    _g = guard or (lambda: None)

    @app.route("GET", "/api/alerts", auth="session")
    def alerts_get(req):
        _g()
        return {"settings": mailer.public(), "status": watcher.status(), "history": watcher.history(50)}

    @app.route("PUT", "/api/alerts", auth="session")
    def alerts_put(req):
        _g()
        d = req.json()
        err = mailer.save(d, by=req.user)
        if err:
            raise mw.HttpError(400, err)
        req.audit_detail = "changed the email alert settings (" + ", ".join(k for k in d if k != "password") + ")"
        return {"ok": True, "settings": mailer.public()}

    @app.route("POST", "/api/alerts/mute", auth="session")
    def alerts_mute(req):
        _g()
        """{key, hours (0 = until unmuted), reason}: silence one entry, or every entry under a prefix."""
        d = req.json() or {}
        try:
            hours = float(d.get("hours") or 0)
        except (TypeError, ValueError):
            raise mw.HttpError(400, "hours must be a number (0 = until unmuted)")
        until = time.time() + hours * 3600 if hours > 0 else None
        err = mailer.set_mute(d.get("key"), until=until, reason=d.get("reason", ""), by=req.user)
        if err:
            raise mw.HttpError(400, err)
        req.audit_detail = f"muted {d.get('key')} " + (f"for {hours:g} h" if until else "until unmuted") + (f": {str(d.get('reason', ''))[:120]}" if d.get("reason") else "")
        return {"ok": True, "mutes": mailer.load().get("mutes", {})}

    @app.route("POST", "/api/alerts/condition", auth="session")
    def alerts_condition(req):
        _g()
        """{key, enabled?, threshold?}: one entry's own switch and limit (both absent = back to the family's)."""
        d = req.json() or {}
        err = mailer.set_override(d.get("key"), enabled=d.get("enabled"), threshold=d.get("threshold"), by=req.user)
        if err:
            raise mw.HttpError(400, err)
        req.audit_detail = f"condition {d.get('key')}: " + ("switched off" if d.get("enabled") is False else "on") + (f", limit {d.get('threshold')}" if d.get("threshold") is not None else ", family limit")
        return {"ok": True, "overrides": mailer.load().get("overrides", {})}

    @app.route("POST", "/api/alerts/unmute", auth="session")
    def alerts_unmute(req):
        _g()
        d = req.json() or {}
        mailer.clear_mute(d.get("key", ""))
        req.audit_detail = f"unmuted {d.get('key')}"
        return {"ok": True, "mutes": mailer.load().get("mutes", {})}

    @app.route("POST", "/api/alerts/test", auth="session")
    def alerts_test(req):
        _g()
        ok, reason = mailer.test()
        watcher._history({"subject": "test message", "to": mailer.load().get("to", []), "ok": ok, "result": reason, "keys": ["test"], "kind": "test"})
        req.audit_detail = f"sent a test alert email: {reason}"
        if not ok:
            raise mw.HttpError(502, reason)
        return {"ok": True, "result": reason}
