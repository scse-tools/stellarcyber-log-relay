"""Planning a certificate REISSUE, shared by the Log Relay Manager and Ingest Studio (8 Oct 2026).

Stdlib only; imported by both consoles' app.py. The helpers that actually make the certificate are root programs
(stellar-relay-config, stellar-studio-cert); this only decides what a reissue asks them for.
"""
import re

_IPV4 = re.compile(r"^(?:\d{1,3}\.){3}\d{1,3}$")
_HOST = re.compile(r"^(?=.{1,253}$)[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$")


def is_ipv4(v):
    v = str(v or "").strip()
    return bool(_IPV4.match(v)) and all(int(p) <= 255 for p in v.split("."))


# What a REISSUE asks for (Paul, 8 Oct 2026: "make it easy to re-issue the TLS certificate and HTTPS
# certificate"): the certificate in use, again - its names, its subject and its key type - with new dates and a
# new key. A reissue that quietly changed the names would break every browser or device that reaches it by one
# of the old ones, so the names are carried over exactly; only a certificate that names nothing usable (the
# installer's own, CN=stellar-relay-monitor with no alternative names) is given the names the console suggests.
_DN_SPLIT = re.compile(r",\s*(?=[A-Za-z]+\s*=)")
_DN_KEYS = {"C": "country", "ST": "state", "L": "locality", "O": "org", "OU": "ou", "CN": "cn", "emailAddress": "email"}


def _hostlike(v):
    v = str(v or "").strip()
    return bool(v) and (is_ipv4(v) or bool(_HOST.match(v)))


def reissue_spec(in_use, suggested=()):
    """{cn, sans, key, org?, ou?, country?, state?, locality?, email?} for a reissue of the certificate `in_use`
    (the helper's facts: subject, sans, key). `suggested` names stand in only when it names nothing usable."""
    u = in_use or {}
    spec = {}
    for part in _DN_SPLIT.split(str(u.get("subject") or "").strip()):
        k, _, v = part.partition("=")
        k, v = k.strip(), v.strip().strip('"')
        if k in _DN_KEYS and v:
            spec[_DN_KEYS[k]] = v
    names, seen = [], set()
    for x in u.get("sans") or []:
        n = str(x).replace("IP Address:", "").replace("DNS:", "").strip()
        if _hostlike(n) and n.lower() not in seen:
            names.append(n); seen.add(n.lower())
    cn = spec.pop("cn", "")
    if not names:
        names = [n for n in suggested if _hostlike(n)]
    if not _hostlike(cn):
        cn = names[0] if names else ""
    kw = str(u.get("key") or "")
    spec.update(cn=cn, sans=[n for n in names if n.lower() != cn.lower()][:40],
                key="ec256" if kw.upper().startswith("EC") else "rsa4096" if "4096" in kw else "rsa2048")
    return spec
