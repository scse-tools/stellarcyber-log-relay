#!/usr/bin/env python3
"""release_sig.py - is this update bundle really one of ours?

An update bundle carries SHA256SUMS, which covers every file in it, and SHA256SUMS.sig, an Ed25519
signature over that file made with Stellar Cyber's release key. This module verifies the signature
against the PUBLIC key that is already installed on the host. Nothing else here decides anything.

    python3 release_sig.py <bundle.tar.gz | bundle-dir> [--pubkey FILE] [--json]

WHY A SIGNATURE RATHER THAN A HASH. A SHA-256 proves the file did not change in transit. It proves
nothing about where the file came from: whoever hands you the file usually hands you the hash beside
it, so a convincing page offering "stellar-relay-9.9.9.tar.gz" and its hash passes that check
perfectly. A signature cannot be produced without the private key, which never leaves Stellar Cyber,
so a bundle that verifies was built by us and has not been altered by one byte since - no file added,
no maintainer script edited, no .deb swapped. That is the difference between "this download was not
corrupted" and "this is ours", and only the second is worth installing as root.

WHICH KEY VERIFIES. Always the key already on this host, never one found inside the bundle being
checked: a bundle that brought its own key would simply be vouching for itself. find_pubkey() looks
only in installed locations, and the verification refuses outright if there is no key there.

WHY OPENSSL. Ed25519 is not in the Python standard library, and this kit takes no third-party
dependencies. openssl(1) is on every Ubuntu host and is already how this kit mints and reads
certificates. OpenSSL 1.1.1+ (Ubuntu 20.04 and later) speaks Ed25519.
"""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile

SUMS = "SHA256SUMS"
SIG = "SHA256SUMS.sig"

# Only places the INSTALLED product owns. Never the bundle, and never the working directory.
PUBKEY_PATHS = (
    "/opt/stellar-lab/common/release-pubkey.pem",
    "/usr/share/stellar-relay/release-pubkey.pem",
)


def find_pubkey(explicit=None):
    """The release public key INSTALLED on this host, or None.

    There is deliberately no "look beside this file" fallback. This module and upgrade_check.py also
    travel inside the bundle - that is how a newer release can check more than the installed one knows
    about - so a sibling lookup would let a hostile bundle ship its own key next to its own verifier
    and sign itself. Only an absolute installed path counts, or one a human named on the command line.

    A kit checkout has no installed key and will refuse: pass --pubkey, set STELLAR_RELEASE_PUBKEY, or
    use --allow-unsigned for a build you made yourself."""
    if explicit:
        return explicit if os.path.exists(explicit) else None
    env = os.environ.get("STELLAR_RELEASE_PUBKEY")
    if env:
        return env if os.path.exists(env) else None
    for p in PUBKEY_PATHS:
        if os.path.exists(p):
            return p
    return None


def openssl_ok():
    return shutil.which("openssl") is not None


def _verify_bytes(pubkey, data_path, sig_path):
    """True when sig_path is a valid Ed25519 signature over data_path under pubkey."""
    r = subprocess.run(["openssl", "pkeyutl", "-verify", "-pubin", "-inkey", pubkey,
                        "-rawin", "-in", data_path, "-sigfile", sig_path],
                       capture_output=True, text=True)
    return r.returncode == 0, (r.stdout or "") + (r.stderr or "")


def _bundle_dir(path, work):
    """A bundle is either the unpacked directory or the tarball; give back the directory holding
    SHA256SUMS. Members are checked for path escapes before anything is written."""
    if os.path.isdir(path):
        return path if os.path.exists(os.path.join(path, SUMS)) else None
    with tarfile.open(path, "r:gz") as tf:
        for m in tf.getmembers():
            name = os.path.normpath(m.name)
            if name.startswith(("/", "..")) or os.path.isabs(m.name):
                raise ValueError("the bundle holds a path outside itself: %s" % m.name)
            if m.issym() or m.islnk():
                raise ValueError("the bundle holds a link, which an update never needs: %s" % m.name)
        tf.extractall(work)
    for root, _dirs, files in os.walk(work):
        if SUMS in files:
            return root
    return None


def verify(path, pubkey=None, work=None):
    """(ok, detail, info). ok is True only when a signature made by the installed release key covers a
    SHA256SUMS that matches every file in the bundle."""
    key = find_pubkey(pubkey)
    if not key:
        # Every host installed before releases were signed is in exactly this state, and it is not a
        # failure of the bundle: trust has to start somewhere, and it cannot start with the file being
        # judged. Someone with root puts the key there once, deliberately, and every install from then
        # on carries it forward. Say which file, because "no key" on its own leaves a reader stuck.
        return False, ("this host has no Stellar Cyber release key, so no update can be shown to be "
                       "genuine. That is expected on a relay installed before releases were signed. "
                       "Put the key there once, with root on this host: copy the release-pubkey.pem "
                       "Stellar Cyber published to " + PUBKEY_PATHS[0] + " (owner root, mode 644). "
                       "Every install after that keeps it up to date."), {"signed": None, "key": None}
    if not openssl_ok():
        return False, "openssl is not on this host, so the signature cannot be checked", {"signed": None, "key": key}
    tmp = work or tempfile.mkdtemp(prefix="relsig-")
    try:
        try:
            d = _bundle_dir(path, tmp)
        except (tarfile.TarError, ValueError) as e:
            return False, "the bundle could not be read: %s" % e, {"signed": None, "key": key}
        if not d:
            return False, "the bundle has no %s, so there is nothing to verify" % SUMS, {"signed": None, "key": key}
        sums, sig = os.path.join(d, SUMS), os.path.join(d, SIG)
        if not os.path.exists(sig):
            return False, ("this bundle is NOT SIGNED: it carries no %s. A release from Stellar Cyber "
                           "always is. Do not install it." % SIG), {"signed": False, "key": key}
        ok, out = _verify_bytes(key, sums, sig)
        if not ok:
            return False, ("the signature on this bundle is not valid for this host's Stellar Cyber "
                           "release key. The file is either not ours or has been altered since it was "
                           "built. Do not install it."), {"signed": False, "key": key}
        # The signature covers SHA256SUMS; SHA256SUMS covers the files. Both halves, or neither counts.
        bad = []
        listed = 0
        for line in open(sums):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            want, _, name = line.partition("  ")
            if not name:
                continue
            listed += 1
            f = os.path.join(d, name)
            if not os.path.exists(f):
                bad.append("%s is missing" % name)
                continue
            h = hashlib.sha256()
            with open(f, "rb") as fh:
                for chunk in iter(lambda: fh.read(1 << 20), b""):
                    h.update(chunk)
            if h.hexdigest() != want:
                bad.append("%s does not match" % name)
        extra = [f for f in sorted(os.listdir(d))
                 if f not in (SUMS, SIG) and os.path.isfile(os.path.join(d, f))
                 and f not in {l.strip().partition("  ")[2] for l in open(sums) if l.strip()}]
        if bad:
            return False, ("the signature is valid but the files do not match it: %s. Do not install it."
                           % "; ".join(bad[:4])), {"signed": True, "key": key}
        if extra:
            return False, ("the bundle holds %d file(s) the signature does not cover (%s). A file added "
                           "after signing is exactly what a signature exists to catch. Do not install it."
                           % (len(extra), ", ".join(extra[:4]))), {"signed": True, "key": key}
        return True, ("signed by Stellar Cyber and every one of the %d files matches" % listed), {
            "signed": True, "key": key, "files": listed}
    finally:
        if work is None:
            shutil.rmtree(tmp, ignore_errors=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("bundle")
    ap.add_argument("--pubkey")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    ok, detail, info = verify(a.bundle, a.pubkey)
    if a.json:
        print(json.dumps({"ok": ok, "detail": detail, **info}))
    else:
        print(("OK   " if ok else "REFUSED  ") + detail)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
