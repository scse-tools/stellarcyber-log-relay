"""
stellarapi.py - a small client for the Stellar Cyber platform API, standard library only.

What the relay needs from the platform is short: the tenants and tenant groups (names and IDs) so that
mappings can be made from real data, and the sensors (which tenant each is registered in, which is the
relay's catch-all). The shape of the calls is the one the Stellar Cyber tools use:

  POST https://HOST/connect/api/v1/access_token   Authorization: Basic base64(user:api_key)   -> {"access_token", "expires_in"}
  GET  https://HOST/connect/api/v1/tenants          Authorization: Bearer <token>              -> tenants (cust_id, cust_name)
  GET  https://HOST/connect/api/v1/tenant_groups    (and a few other spellings, see GROUP_PATHS)
  GET  https://HOST/connect/api/v1/data_sensors[?cust_id=]                                     -> sensors

Security posture, because the API key is an all-access credential:
  * the key is never stored in this object: `key_getter` is called when a token is needed and the value is
    dropped as soon as the Basic header is built; only the short-lived bearer token is cached, in memory;
  * TLS is verified against the system CA bundle by default; a private CA file can be given; turning
    verification off is possible but the caller must say so explicitly (and should record who did);
  * every answer is size-capped and parsed as JSON only; nothing from the platform is ever executed.
"""
import base64
import json
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

TENANT_PATHS = ["/connect/api/v1/tenants", "/connect/api/v1/tenant", "/connect/api/v1/system/tenants"]
GROUP_PATHS = ["/connect/api/v1/tenant_groups", "/connect/api/v1/tenantgroups", "/connect/api/v1/tenant-groups", "/connect/api/v1/tenants/groups"]
SENSOR_PATHS = ["/connect/api/v1/data_sensors"]
# Log records: the platform's data API takes GET with a Lucene query string (no POST body, no scroll; the
# health analyzer learned that the hard way). parser_raw_msg on aella-syslog* holds the original log text.
LOG_INDEX = "aella-syslog*"
LOG_SAMPLE_MAX = 10
MAX_BODY = 8 * 1024 * 1024
HEX32 = re.compile(r"^[0-9a-f]{32}$")


class StellarError(Exception):
    """The message is our own sentence about what went wrong, safe to show a person."""


def clean_host(host):
    """'https://x.stellarcyber.cloud/' -> 'x.stellarcyber.cloud'; only a host[:port] is accepted."""
    h = (host or "").strip()
    h = re.sub(r"^https?://", "", h, flags=re.I).strip("/")
    h = h.split("/")[0]
    if not re.match(r"^[A-Za-z0-9.-]{1,253}(:\d{1,5})?$", h):
        raise StellarError("the platform host must be a host name such as mycompany.stellarcyber.cloud")
    return h


def _rows(data, *keys):
    """The list inside whatever envelope the platform used: a bare list, {data: [...]}, {tenants: [...]},
    {results: [...]}, or an Elasticsearch-style {hits: {hits: [{_source}]}}."""
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for k in keys + ("data", "results", "items"):
            v = data.get(k)
            if isinstance(v, list):
                return v
            if isinstance(v, dict):
                inner = _rows(v, *keys)
                if inner:
                    return inner
        hits = data.get("hits")
        if isinstance(hits, dict) and isinstance(hits.get("hits"), list):
            return [h.get("_source", h) for h in hits["hits"]]
    return []


def _first(d, *names):
    for n in names:
        v = d.get(n)
        if v not in (None, ""):
            return v
    return ""


class StellarClient:
    def __init__(self, host, user, key_getter, verify=True, cafile=None, timeout=20):
        self.host = clean_host(host)
        self.user = (user or "").strip()
        self.key_getter = key_getter
        self.timeout = timeout
        self._token, self._exp = None, 0
        self.ctx = ssl.create_default_context(cafile=cafile or None)
        if not verify:
            self.ctx.check_hostname = False
            self.ctx.verify_mode = ssl.CERT_NONE
        self.tried = []        # (path, status) of every request, for the connection test

    # ---- transport
    def _request(self, method, path, headers, body=None):
        url = f"https://{self.host}{path}"
        req = urllib.request.Request(url, data=body, method=method, headers=dict(headers, Accept="application/json", **{"User-Agent": "stellar-log-relay-manager"}))
        try:
            with urllib.request.urlopen(req, timeout=self.timeout, context=self.ctx) as r:
                raw = r.read(MAX_BODY + 1)
                status = r.status
        except urllib.error.HTTPError as e:
            raw = e.read(4096)
            status = e.code
        except ssl.SSLCertVerificationError as e:
            raise StellarError(f"the platform's certificate could not be verified ({e.reason or e}); give its CA certificate in Settings, or switch verification off for a lab")
        except urllib.error.URLError as e:
            raise StellarError(f"could not reach {self.host}: {getattr(e, 'reason', e)}")
        except (TimeoutError, OSError) as e:
            raise StellarError(f"could not reach {self.host}: {e}")
        self.tried.append((path, status))
        if len(raw) > MAX_BODY:
            raise StellarError("the platform's answer was larger than 8 MB; refusing to parse it")
        try:
            data = json.loads(raw.decode("utf-8", "replace")) if raw.strip() else {}
        except ValueError:
            data = None
        return status, data, raw[:300]

    def token(self):
        if self._token and time.time() < self._exp - 60:
            return self._token
        if not self.user:
            raise StellarError("no API user is set")
        key = self.key_getter()
        if not key:
            raise StellarError("no API key is stored on this relay; paste one in Settings")
        auth = "Basic " + base64.b64encode(f"{self.user}:{key}".encode()).decode()
        del key
        status, data, raw = self._request("POST", "/connect/api/v1/access_token", {"Authorization": auth, "Content-Type": "application/x-www-form-urlencoded"}, body=b"")
        if status == 401 or status == 403:
            raise StellarError("the platform refused the API user or key (401); use an All Access API key made under the user's profile, API Keys tab")
        if status != 200 or not isinstance(data, dict):
            raise StellarError(f"the token request answered HTTP {status}: {raw.decode('utf-8', 'replace')[:120]}")
        inner = data.get("data") if isinstance(data.get("data"), dict) else {}
        tok = data.get("access_token") or data.get("token") or inner.get("access_token")
        if not tok:
            raise StellarError("the token answer carried no access_token")
        self._token, self._exp = tok, time.time() + float(data.get("expires_in") or 600)
        return tok

    def get(self, path, params=None):
        q = ("?" + urllib.parse.urlencode(params)) if params else ""
        status, data, raw = self._request("GET", path + q, {"Authorization": "Bearer " + self.token()})
        if status == 401:
            self._token = None         # expired early: one retry with a fresh token
            status, data, raw = self._request("GET", path + q, {"Authorization": "Bearer " + self.token()})
        return status, data

    def _first_that_answers(self, paths, *keys):
        """Try each spelling; the first one that answers 200 with a list wins. Returns (path, rows) or (None, [])."""
        for p in paths:
            status, data = self.get(p)
            if status == 200:
                rows = _rows(data, *keys)
                if rows or isinstance(data, list):
                    return p, rows
        return None, []

    # ---- what the relay needs
    def tenants(self):
        """[{id, name, status}] with 32-hex ids only (anything else cannot be a relay tenant)."""
        path, rows = self._first_that_answers(TENANT_PATHS, "tenants")
        out = []
        for t in rows:
            if not isinstance(t, dict):
                continue
            tid = str(_first(t, "cust_id", "tenant_id", "tenantid", "id", "_id")).lower()
            name = str(_first(t, "cust_name", "tenant_name", "name", "display_name"))
            if HEX32.match(tid):
                out.append({"id": tid, "name": name, "status": str(_first(t, "status", "state"))})
        return path, out

    def tenant_groups(self):
        """[{id, name, tenant_ids}] or an empty list with path None when this platform does not expose groups."""
        path, rows = self._first_that_answers(GROUP_PATHS, "tenant_groups", "groups")
        out = []
        for g in rows:
            if not isinstance(g, dict):
                continue
            gid = str(_first(g, "id", "_id", "group_id", "tenant_group_id"))
            name = str(_first(g, "name", "group_name", "tenant_group_name"))
            members = g.get("tenants") or g.get("cust_ids") or g.get("tenant_ids") or g.get("members") or []
            tids = []
            for m in members:
                v = m if isinstance(m, str) else (_first(m, "cust_id", "tenant_id", "tenantid", "id") if isinstance(m, dict) else "")
                v = str(v).lower()
                if HEX32.match(v):
                    tids.append(v)
            if gid or name:
                out.append({"id": gid, "name": name or gid, "tenant_ids": tids})
        return path, out

    def search(self, lucene, size=5, index=LOG_INDEX, tenant_id=""):
        """Documents matching a Lucene query, newest first: GET /connect/api/data/<index>/_search?q=...&size=N&sort=timestamp:desc."""
        params = {"q": lucene, "size": str(max(1, min(int(size), 200))), "from": "0", "sort": "timestamp:desc"}
        path = f"/connect/api/data/{index}/_search?" + urllib.parse.urlencode(params)
        headers = {"Authorization": "Bearer " + self.token()}
        if tenant_id:
            headers["Stellar-Tenant-Id"] = tenant_id
        status, data, raw = self._request("GET", path, headers)
        if status == 401:
            self._token = None
            headers["Authorization"] = "Bearer " + self.token()
            status, data, raw = self._request("GET", path, headers)
        if status != 200:
            raise StellarError(f"the log search answered HTTP {status}: {raw.decode('utf-8', 'replace')[:160]}")
        hits = (data or {}).get("hits", {}) if isinstance(data, dict) else {}
        docs = [h.get("_source", {}) for h in (hits.get("hits") or []) if isinstance(h, dict)]
        total = hits.get("total")
        total = total.get("value") if isinstance(total, dict) else total
        return docs, (int(total) if isinstance(total, (int, float)) else len(docs))

    @staticmethod
    def log_queries(vendor="", product="", source="", tenant_id="", days=7, field="", value="", device_field="", device_value=""):
        """The Lucene queries worth trying for one log source, most precise first. The wrapper's msg_origin is
        stored on the record, so vendor+product is the exact match; msg_origin.source is what the platform's
        own parsers set; the last one is a free-text fallback. field/value: a query the person asked for
        (msg_origin.source:"fw_fortigate", dev_type:"..."), tried FIRST and shown as such."""
        when = f"timestamp:>now-{int(days)}d"
        ten = f" AND tenantid:{tenant_id}" if tenant_id else ""
        out = []
        # THIS device first (its identity field and value, then the value anywhere in the record), then devices like it
        if device_field and device_value:
            out.append(f'{when}{ten} AND {device_field}:"{device_value}"')
            out.append(f'{when}{ten} AND "{device_value}"')
        if field and value:
            out.append(f'{when}{ten} AND {field}:"{value}"')
        if vendor and product:
            out.append(f'{when}{ten} AND msg_origin.vendor:"{vendor}" AND msg_origin.product:"{product}"')
        for src in [source, product, f"{vendor}_{product}" if vendor and product else "", vendor]:
            if src and f'msg_origin.source:"{src}"' not in " ".join(out):
                out.append(f'{when}{ten} AND msg_origin.source:"{src}"')
        return out

    def sample_logs(self, vendor="", product="", source="", tenant_id="", n=5, days=7, field="", value="", device_field="", device_value=""):
        """Up to n recent records for one log source: (query that answered, [docs], tried). Each doc is the
        platform's record; parser_raw_msg, when present, is the original log text the relay would see."""
        n = max(1, min(int(n), LOG_SAMPLE_MAX))
        tried = []
        for q in self.log_queries(vendor, product, source, tenant_id, days, field, value, device_field, device_value):
            try:
                docs, total = self.search(q, size=n, tenant_id=tenant_id)
            except StellarError as e:
                tried.append({"query": q, "error": str(e)})
                continue
            tried.append({"query": q, "hits": total})
            if docs:
                return q, docs, tried
        return None, [], tried

    def sensors(self):
        """[{name, ip, nat_ip, tenant_id, tenant_name, status, version, mode}]"""
        path, rows = self._first_that_answers(SENSOR_PATHS, "sensors")
        out = []
        for x in rows:
            if not isinstance(x, dict):
                continue
            out.append({"name": str(_first(x, "hostname", "name", "sensor_id")), "ip": str(_first(x, "local_ip_address", "ip")), "nat_ip": str(_first(x, "nat_ip_address")),
                        "tenant_id": str(_first(x, "cust_id", "tenantid", "tenant_id")).lower(), "tenant_name": str(_first(x, "cust_name", "tenant_name")),
                        "status": str(_first(x, "connection_status", "status")), "version": str(_first(x, "sw_version", "version")), "mode": str(_first(x, "mode"))})
        return path, out
