#!/usr/bin/env python3
"""
upgrade_check.py - everything that must be TRUE about an update bundle before a single package is installed.

    python3 upgrade_check.py <bundle.tar.gz> --sha256 <hash> [--installed-version V] [--live-conf FILE]
                             [--render-cmd "..."] [--work DIR] [--json]

Pure standard library, and it reads .deb files itself (an `ar` archive holding a tar), so it runs on any
machine - which is how it is tested. It never installs anything. What it checks, in order, and stops at the
first failure:

  0. the bundle carries a valid Ed25519 signature from Stellar Cyber's release key, checked by the verifier
     INSTALLED ON THIS HOST against the public key INSTALLED ON THIS HOST - never either one found in the
     bundle, which would be the bundle vouching for itself. This is the only check that asks whether the
     file is OURS; every other one asks whether it is well formed. A hash cannot answer it, because whoever
     gives you the file gives you the hash beside it. A host that has neither file yet is told to put both
     there once; see NO_VERIFIER below.
  1. the bundle's SHA-256 is the one the customer was given, when they were given one (with a valid
     signature this is belt and braces; without one, with --allow-unsigned, it is required)
  2. the bundle unpacks and its own SHA256SUMS matches every file inside it
  3. it holds the four packages of one version; a lower version than the installed one is refused
  4. every Python file the console package carries compiles; every root helper is valid bash
  5. no maintainer script reloads or restarts syslog-ng or nginx (an upgrade never touches the running relay)
  6. with the NEW renderer, the CURRENT tenant map still renders - and whether what it renders differs from
     the configuration syslog-ng is running now (reported, never applied)

The report is a JSON object: {ok, version, installed, debs: {...}, checks: [{name, ok, detail}], drift, work}.
Exit 0 when every check passed, 1 otherwise.
"""
import argparse
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile

PACKAGES = ("stellar-relay-monitor", "stellar-relay-syslog", "stellar-relay-nginx", "stellar-relay")
TOUCHES_RELAY = re.compile(r"(apply-tenants|systemctl\s+(restart|reload|stop)\s+(syslog-ng|nginx)|syslog-ng-ctl\s+reload)")


# Read by check 3b; both are overridable for tests only.
PKG_CACHE = "/var/lib/stellar-relay/packages"
UPGRADER = "/usr/sbin/stellar-relay"
DPKG_QUERY = "dpkg-query"


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_ar(path):
    """{member: bytes} of an ar archive (a .deb)."""
    with open(path, "rb") as f:
        data = f.read()
    if data[:8] != b"!<arch>\n":
        raise ValueError("not a Debian package (ar archive)")
    pos, out = 8, {}
    while pos + 60 <= len(data):
        hdr = data[pos:pos + 60]
        name = hdr[:16].decode().strip().rstrip("/")
        size = int(hdr[48:58].decode().strip())
        out[name] = data[pos + 60:pos + 60 + size]
        pos += 60 + size + (size % 2)
    return out


def deb_members(path):
    """(control: {name: bytes}, data: {path: (mode, bytes)}) of a .deb."""
    ar = read_ar(path)
    ctrl_name = next(n for n in ar if n.startswith("control.tar"))
    data_name = next(n for n in ar if n.startswith("data.tar"))
    ctrl, data = {}, {}
    with tarfile.open(fileobj=io.BytesIO(ar[ctrl_name]), mode="r:*") as t:
        for m in t.getmembers():
            if m.isfile():
                ctrl[m.name.lstrip("./")] = t.extractfile(m).read()
    with tarfile.open(fileobj=io.BytesIO(ar[data_name]), mode="r:*") as t:
        for m in t.getmembers():
            if m.isfile():
                data[m.name.lstrip("./")] = (m.mode, t.extractfile(m).read())
    return ctrl, data


# Where the verifier may be loaded from: an INSTALLED path, never beside this file. On a host whose own
# stellar-relay predates signing, this checker is the one from inside the BUNDLE - that is deliberate, so a
# newer release can check more than the installed one knows about - and a sibling lookup would therefore let
# a hostile bundle ship its own release_sig.py, whose verify() need only return True. The installed key
# would never be read at all. Closing that hole for the key (release_sig.find_pubkey) while leaving it open
# for the code that reads the key would have been no protection whatever.
VERIFIER = "/opt/stellar-lab/common/release_sig.py"

# A relay installed before releases were signed has neither file, and refusing is the only safe answer:
# what judges a file cannot come from the file. Say the way out, because "not installed" on its own leaves
# a reader stuck, and the way out is two files from Stellar Cyber - not two files out of the bundle.
NO_VERIFIER = (
    "this host has no installed verifier at %s, so no update can be shown to be ours. That is expected on a "
    "relay installed before releases were signed, and it is not a fault in the bundle: what checks a file "
    "cannot come from the file. Once, with root on this host, copy BOTH of these into /opt/stellar-lab/common/ "
    "(owner root, mode 644), from Stellar Cyber and never from the bundle: release_sig.py and "
    "release-pubkey.pem. Then run this again - every install after that keeps both current." % VERIFIER
)


def _signature(bundle, pubkey):
    """(ok, detail, info) from release_sig, loaded by path from an installed location only.

    STELLAR_RELEASE_VERIFIER names one instead, for the test suite and for a checkout, exactly as
    --pubkey / STELLAR_RELEASE_PUBKEY name a key: a path a person chose is not a path a bundle chose."""
    try:
        import importlib.util
        for cand in (os.environ.get("STELLAR_RELEASE_VERIFIER") or "", VERIFIER):
            if cand and os.path.exists(cand):
                spec = importlib.util.spec_from_file_location("release_sig", cand)
                m = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(m)
                return m.verify(bundle, pubkey)
        return False, NO_VERIFIER, {"signed": None, "key": None}
    except Exception as e:                                   # noqa: BLE001 - a broken verifier must refuse, never pass
        return False, "the signature could not be checked (%s)" % e, {"signed": None, "key": None}


def version_key(v):
    """Enough of Debian version ordering for X.Y.Z[-N]: a tuple of ints."""
    return tuple(int(x) for x in re.findall(r"\d+", v or "0"))


# dpkg states that mean dpkg was interrupted and has not finished. `install ok installed` is the only
# settled one; triggers-awaited and triggers-pending are deliberately NOT here, because apt resolves
# those itself and flagging them would refuse upgrades that would have worked.
DPKG_UNFINISHED = ("half-configured", "unpacked", "half-installed")


def dpkg_unfinished(cmd=None):
    """Packages dpkg has not finished with, or None where there is no dpkg (a Mac, a test host)."""
    exe = cmd or os.environ.get("DPKG_QUERY_CMD") or DPKG_QUERY
    try:
        r = subprocess.run([exe, "-W", "-f", "${Package} ${Status}\n"],
                           capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.SubprocessError):
        return None
    if not r.stdout.strip():
        return None
    bad = []
    for line in r.stdout.splitlines():
        f = line.split()
        # package want error status
        if len(f) >= 4 and f[1] == "install" and f[3] in DPKG_UNFINISHED:
            bad.append(f[0])
    return bad


def check(bundle, want_sha, installed=None, live_conf=None, render_cmd=None, work=None,
          pubkey=None, allow_unsigned=False, pkg_cache=None, upgrader=None, dpkg_query=None):
    rep = {"ok": False, "bundle": bundle, "version": None, "installed": installed, "debs": {}, "checks": [],
           "drift": None, "work": None, "signed": None}
    checks = rep["checks"]

    def step(name, ok, detail=""):
        checks.append({"name": name, "ok": bool(ok), "detail": detail})
        return ok

    # 0. IS IT OURS? Everything below this line asks whether the bundle is well formed; only the
    #    signature asks whether it came from Stellar Cyber. A hash does not: whoever hands you a file
    #    hands you its hash beside it. The key is the one installed on THIS host - never one found in
    #    the bundle, which would be a file vouching for itself.
    sig_ok, sig_detail, sig_info = _signature(bundle, pubkey)
    rep["signed"] = sig_info.get("signed")
    rep["pubkey"] = sig_info.get("key")
    if allow_unsigned and not sig_ok:
        # staff only, never passed by the console: a development build, installed by someone who built it
        step("signature", True, "NOT CHECKED - --allow-unsigned was given. " + sig_detail)
    elif not step("signature", sig_ok, sig_detail):
        return rep

    # 1. the hash the customer was given, when they were given one. With a valid signature this is
    #    belt and braces; without one it is all there is, so it stays required in that case.
    if want_sha:
        have = sha256(bundle)
        if not step("bundle hash", have == want_sha.strip().lower(),
                    f"sha256 {have}" + ("" if have == want_sha.strip().lower() else f", expected {want_sha.strip().lower()}")):
            return rep
    elif not sig_ok:
        step("bundle hash", False, "no SHA-256 was given and the bundle is not signed; one of the two is required")
        return rep
    else:
        step("bundle hash", True, "not given, and not needed: the signature already proves the file is ours, whole")

    # 2. unpack; the bundle's own checksums
    work = work or tempfile.mkdtemp(prefix="stellar-upgrade-")
    rep["work"] = work
    try:
        with tarfile.open(bundle, "r:gz") as t:
            names = [m.name for m in t.getmembers()]
            bad = [n for n in names if n.startswith("/") or ".." in n.split("/")]
            if not step("bundle contents", not bad, "unsafe paths in the archive: " + ", ".join(bad[:3]) if bad else f"{len(names)} entries"):
                return rep
            t.extractall(work)
    except (tarfile.TarError, OSError) as e:
        step("bundle contents", False, f"the archive could not be unpacked: {e}")
        return rep
    tops = [d for d in os.listdir(work) if os.path.isdir(os.path.join(work, d))]
    bdir = os.path.join(work, tops[0]) if len(tops) == 1 else work
    sums = os.path.join(bdir, "SHA256SUMS")
    if not step("SHA256SUMS present", os.path.exists(sums), "found" if os.path.exists(sums) else "the bundle carries no SHA256SUMS"):
        return rep
    mismatched, listed = [], 0
    with open(sums) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            h, _, fn = line.partition("  ")
            listed += 1
            p = os.path.join(bdir, fn.strip())
            if not os.path.exists(p) or sha256(p) != h.strip():
                mismatched.append(fn.strip())
    if not step("every file matches SHA256SUMS", not mismatched, f"{listed} files listed" + (", mismatched: " + ", ".join(mismatched[:5]) if mismatched else "")):
        return rep

    # 3. the four packages, one version, not a downgrade
    debs = {}
    for fn in os.listdir(bdir):
        m = re.match(r"^(stellar-relay(?:-monitor|-syslog|-nginx)?)_(.+)_all\.deb$", fn)
        if m:
            debs[m.group(1)] = {"file": os.path.join(bdir, fn), "version": m.group(2)}
    missing = [p for p in PACKAGES if p not in debs]
    versions = {d["version"] for d in debs.values()}
    if not step("four packages of one version", not missing and len(versions) == 1,
                ("missing: " + ", ".join(missing)) if missing else ("mixed versions: " + ", ".join(sorted(versions)) if len(versions) != 1 else "version " + next(iter(versions)))):
        return rep
    rep["version"] = next(iter(versions))
    rep["debs"] = {k: v["file"] for k, v in debs.items()}
    if installed:
        down = version_key(rep["version"]) < version_key(installed)
        if not step("not a downgrade", not down, f"bundle {rep['version']}, installed {installed}"):
            return rep
    else:
        step("not a downgrade", True, "installed version unknown here (not a package install); not compared")

    # 3b. CAN THIS HOST EVEN RUN THE UPGRADE? `stellar-relay upgrade` runs the copy of itself that is
    #     ALREADY INSTALLED, so a bug in the running version is not fixed by the bundle that fixes it.
    #     Up to 1.1.3 that script looked for the running version's .debs in the package cache with
    #     `old=$(ls ... | head -1)` under `set -euo pipefail`, and an ls that matches nothing ENDS THE
    #     SCRIPT - with no message, right after "Backup first". The cache is empty on any host that did
    #     not reach its current version through a completed run of this command, which is exactly the
    #     host an interrupted update leaves behind (Paul, 1 Oct 2026: two attempts died there in
    #     silence). Both conditions are read from the host, so this only ever fires where it is true,
    #     and it says what to do. Where the installed script is the fixed one, a missing cached copy is
    #     only a note: it means no automatic way back, which the script now prints for itself.
    if installed:
        cached = os.path.join(pkg_cache or PKG_CACHE, "stellar-relay-monitor_%s_all.deb" % installed)
        have_cached = os.path.exists(cached)
        guarded = True
        try:
            with open(upgrader or UPGRADER) as f:
                txt = f.read()
            if "PKG_CACHE" in txt:
                guarded = "head -1 || true)" in txt
        except OSError:
            pass            # not a package install, or not readable: nothing to warn about
        if have_cached:
            step("a way back is cached", True, "%s_all.deb is in %s" % (installed, pkg_cache or PKG_CACHE))
        elif guarded:
            step("a way back is cached", True,
                 "no copy of %s is cached here, so a failure cannot be put back automatically "
                 "(the configuration backup is taken either way)" % installed)
        else:
            step("a way back is cached", False,
                 "no copy of %s is in %s, and the stellar-relay installed here (%s) stops silently in that "
                 "case, just after the backup - so this upgrade would appear to hang rather than run. Put the "
                 "running version's .deb files in that directory, or install the fixed stellar-relay from this "
                 "bundle first: tar xzf BUNDLE, then dpkg-deb --fsys-tarfile stellar-relay-monitor_*_all.deb | "
                 "tar -xO ./usr/sbin/stellar-relay | sudo tee /usr/sbin/stellar-relay >/dev/null"
                 % (installed, pkg_cache or PKG_CACHE, upgrader or UPGRADER))
            return rep

    # 3c. dpkg must have nothing half-done. apt refuses EVERY operation while it has ("E: dpkg was
    #     interrupted, you must manually run 'sudo dpkg --configure -a'"), so an upgrade started in
    #     that state fails after the backup, in apt's words rather than ours - and the host most
    #     likely to be in it is the one most in need of this upgrade. A console-driven update from
    #     1.1.3 or earlier ENDS that way by construction: the runner shares the console's control
    #     group, the monitor's postinst restarts the console, and systemd's stop kills dpkg
    #     mid-configure (measured on a real 1.1.4 host, 2 Oct 2026: stellar-relay-monitor left
    #     half-configured and stellar-relay-syslog never configured at all). Read from the host, so
    #     it only fires where it is true, and it says the one command that fixes it.
    half = dpkg_unfinished(dpkg_query)
    if half:
        step("dpkg has nothing half-done", False,
             "dpkg was interrupted and left %s unconfigured (%s). apt refuses every operation until "
             "that is finished, so this upgrade would stop just after the backup with a message from "
             "apt rather than from us. Run this first: sudo dpkg --configure -a"
             % ("a package" if len(half) == 1 else "%d packages" % len(half), ", ".join(sorted(half))))
        return rep
    if half is not None:
        step("dpkg has nothing half-done", True, "nothing is part-installed")

    # 4. the code compiles, the helpers are valid bash; 5. no script touches the running relay
    py_bad, sh_bad, touch = [], [], []
    for pkg, d in debs.items():
        try:
            ctrl, data = deb_members(d["file"])
        except (ValueError, tarfile.TarError, StopIteration) as e:
            step(f"{pkg} readable", False, str(e))
            return rep
        for path, (mode, blob) in data.items():
            # a root helper is python or bash; the shebang says which (most of /usr/sbin here is python)
            head = blob[:64]
            is_py = path.endswith(".py") or b"python" in head.split(b"\n", 1)[0]
            is_sh = path.endswith(".sh") or (b"bash" in head.split(b"\n", 1)[0] or b"/bin/sh" in head.split(b"\n", 1)[0])
            if is_py:
                try:
                    compile(blob, path, "exec")
                except SyntaxError as e:
                    py_bad.append(f"{path}:{e.lineno}")
            elif is_sh:
                r = subprocess.run(["bash", "-n"], input=blob, capture_output=True)
                if r.returncode != 0:
                    sh_bad.append(path)
        for name in ("preinst", "postinst", "prerm", "postrm"):
            if name not in ctrl:
                continue
            # commands only: a comment or an echo may NAME apply-tenants (the advice printed to the operator)
            cmds = "\n".join(l for l in ctrl[name].decode(errors="replace").splitlines() if not l.strip().startswith(("#", "echo ")))
            if TOUCHES_RELAY.search(cmds):
                touch.append(f"{pkg}/{name}")
    if not step("console code compiles", not py_bad, ", ".join(py_bad[:5]) if py_bad else "every .py compiles"):
        return rep
    if not step("root helpers are valid bash", not sh_bad, ", ".join(sh_bad[:5]) if sh_bad else "every helper parses"):
        return rep
    if not step("no package script touches the running relay", not touch, ", ".join(touch) if touch else "no maintainer script reloads or restarts syslog-ng or nginx"):
        return rep

    # 6. the new renderer against the current map; drift against the running configuration
    if render_cmd and "stellar-relay-syslog" in debs:
        _, data = deb_members(debs["stellar-relay-syslog"]["file"])
        rc_path = os.path.join(work, "render-config.py")
        blob = data.get("usr/lib/stellar-relay/render-config.py")
        if blob:
            with open(rc_path, "wb") as f:
                f.write(blob[1])
            env = dict(os.environ, RENDER_CONFIG=rc_path)
            r = subprocess.run(render_cmd, shell=True, env=env, capture_output=True, text=True, timeout=60)
            if not step("the new renderer renders the current map", r.returncode == 0, (r.stderr or r.stdout).strip()[-400:] if r.returncode else "rendered"):
                return rep
            if live_conf and os.path.exists(live_conf):
                live = open(live_conf, errors="replace").read().splitlines()
                cand = r.stdout.splitlines()
                if live != cand:
                    import difflib
                    sm = difflib.SequenceMatcher(a=live, b=cand, autojunk=False)
                    added = sum(j2 - j1 for tag, i1, i2, j1, j2 in sm.get_opcodes() if tag in ("insert", "replace"))
                    removed = sum(i2 - i1 for tag, i1, i2, j1, j2 in sm.get_opcodes() if tag in ("delete", "replace"))
                    rep["drift"] = {"differs": True, "added": added, "removed": removed}
                    step("running configuration unchanged by this version", True,
                         f"NOTE: this version renders the relay differently (+{added} -{removed} lines). The package install does not touch syslog-ng; the console applies this rendering, validated, on its first start under the new version and records it in the audit log.")
                else:
                    rep["drift"] = {"differs": False}
                    step("running configuration unchanged by this version", True, "this version renders exactly the configuration syslog-ng is running")
        else:
            step("the new renderer renders the current map", True, "the syslog package carries no renderer (nothing to compare)")
    rep["ok"] = all(c["ok"] for c in checks)
    return rep


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("bundle")
    ap.add_argument("--sha256", default="")
    ap.add_argument("--installed-version", default="")
    ap.add_argument("--live-conf", default="")
    ap.add_argument("--render-cmd", default="", help="shell command that renders the current map to stdout; RENDER_CONFIG is set to the bundle's renderer")
    ap.add_argument("--work", default="")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--keep", action="store_true", help="keep the unpacked bundle (the caller installs from it)")
    ap.add_argument("--pubkey", default="", help="the release public key to verify against (default: the one installed on this host)")
    ap.add_argument("--allow-unsigned", action="store_true",
                    help="STAFF ONLY: install a bundle that is not signed by Stellar Cyber. Never passed by the console.")
    ap.add_argument("--pkg-cache", default="", help=argparse.SUPPRESS)      # tests only
    ap.add_argument("--upgrader", default="", help=argparse.SUPPRESS)       # tests only
    a = ap.parse_args()
    rep = check(a.bundle, a.sha256, a.installed_version or None, a.live_conf or None, a.render_cmd or None,
                a.work or None, a.pubkey or None, a.allow_unsigned,
                a.pkg_cache or None, a.upgrader or None)
    if a.json:
        print(json.dumps(rep))
    else:
        for c in rep["checks"]:
            print(f"  {'ok  ' if c['ok'] else 'FAIL'} {c['name']}: {c['detail']}")
        print(("ready to install: version " + str(rep["version"])) if rep["ok"] else "NOT installed: the check above failed")
    if rep.get("work") and not a.keep and not rep["ok"]:
        shutil.rmtree(rep["work"], ignore_errors=True)
    return 0 if rep["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
