#!/usr/bin/env python3
"""
stellar-send.py  -  traffic generator for Stellar Cyber multi-tenant ingestion tests.

Standard library only (Python 3.8+). No pip installs needed.

Sub-commands
------------
  syslog   Send realistic firewall syslog (FortiOS 7 KV, Meraki MX, PAN-OS CSV,
           SonicOS KV): allowed traffic, denies, web-filter blocks, IPS signature
           hits, VPN and admin events drawn from a small site "scene" so a batch
           reads like one network's day. To the syslog-ng relay, or anything syslog.
  http     POST JSON events to the NGINX relay (Method 5), or straight to the
           sensor with a Stellar-TenantID header (Method 2) or tenantid field (Method 4).
  wrapped  Send a ready-made Stellar JSON wrapper record straight to the parser's
           port on the sensor (PAN 5515, SonicWall 5152, Meraki 5172, FortiGate
           5517), bypassing syslog-ng. Proves the sensor accepts the format.
  direct   Send firewall syslog AS-IS to the parser's port on the sensor: no relay,
           no tenant wrapper, TLS by default. Exactly what the firewall itself would
           send. The log lands in the sensor's own tenant unless a mapping on the
           sensor assigns one from the device identity in the log (see `fields`).
  fields   List, per vendor, the fields a device identifies itself by in its own
           logs (FortiGate devid=, PAN-OS serial, Meraki device name, SonicWall
           sn=) and the value the generator writes by default. `--device
           FIELD=VALUE` sets one; a sensor-side tenant mapping keys on it.
  probe    Try TLS and plain on a host:port and report which one answers, with the
           certificate's SHA-256 fingerprint; --cafile also verifies it against a CA
           (proves a certificate uploaded to the sensor has taken effect).

TLS and certificates: the sensor's parser ports and :5200 speak TLS once the sensor's
"Syslog TLS Enabled" toggle is on, presenting a self-signed certificate by default, so
every sender here accepts any certificate unless --cafile is given. To test the
sensor's own-certificate path, tools/make-sensor-cert.sh mints one to upload
(System | Saved Objects | Certificates, then Apply Certificate to Log Forwarder).

Every mode supports --size (pad the event to N bytes), --count, --rate and
--bind (source IP to send from, so one test box can impersonate several tenants).

Examples
--------
  # 50 realistic FortiGate events (mostly allowed traffic, some denies, web-filter
  # blocks, IPS hits, VPN and admin events) to the syslog-ng relay over UDP
  ./stellar-send.py syslog --target 10.0.1.10 --vendor fortigate --count 50

  # Demo mode: half of the events are alerts; --seed makes the batch repeatable
  ./stellar-send.py syslog --target 10.0.1.10 --vendor paloalto --count 50 --mix alerts --seed 7

  # Only IPS events, 2 KB each
  ./stellar-send.py syslog --target 10.0.1.10 --vendor meraki --count 10 --kind ips --size 2048

  # 100 KB event (UDP cannot carry it, so use TCP)
  ./stellar-send.py syslog --target 10.0.1.10 --proto tcp --size 102400

  # As-is to the sensor: FortiGate syslog over TLS to the FortiGate parser port 5517,
  # no wrapper, no tenant; the devid the sensor will see is set so a sensor-side
  # mapping (or your eyes) can find it
  ./stellar-send.py direct --target 10.0.1.50 --vendor fortigate --device devid=FGTLAB0000000042 --count 20
  ./stellar-send.py direct --target 10.0.1.50 --vendor meraki --device hostname=MX-TENANT-A --count 20
  ./stellar-send.py fields                       # which field per vendor, and the defaults

  # Exactly what a FortiGate in "reliable" mode with TLS sends: RFC 5425 on 6514,
  # octet-counted framing
  ./stellar-send.py syslog --target 10.0.1.10 --proto tls --port 6514 --framing octet --vendor fortigate

  # Impersonate tenant B by sending from a secondary IP on this box
  ./stellar-send.py syslog --target 10.0.1.10 --bind 10.0.1.22 --vendor fortigate

  # 50 JSON POSTs of 512 KB through the NGINX relay at 5/sec
  ./stellar-send.py http --url http://10.0.1.10/httpjson --count 50 --size 524288 --rate 5

  # Method 2 directly to the sensor (self-signed TLS). Tenant IDs are 32-char hex.
  ./stellar-send.py http --url https://10.0.1.50:5200/httpjson --insecure \
      --tenant-header 1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d

  # Method 3 record straight to the FortiGate parser port (5517 is picked from --vendor)
  ./stellar-send.py wrapped --target 10.0.1.50 --tls --vendor fortigate \
      --tenant 9f8e7d6c5b4a39281706f5e4d3c2b1a0

  # Which scheme does the sensor speak on 5200?
  ./stellar-send.py probe --host 10.0.1.50 --port 5200
"""
import argparse
import hashlib
import json
import random
import re
import socket
import ssl
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
try:
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError, available_timezones
except ImportError:                                  # Python < 3.9: no zones, only the UTC rule
    ZoneInfo = None

MARKER = "STELLAR-MT-TEST"
# A throughput run also stamps every record with its own tag, so ONE Lucene query counts exactly that
# run's records in Stellar Cyber. The marker alone cannot: a throughput run sends the same sequence
# numbers many times over, and a range of markers is not a query. STELLAR-PERF-<tag> is unique per run.
PERF_MARKER = "STELLAR-PERF"
TAG_RE = re.compile(r"^[a-z0-9]{4,16}$")
UDP_MAX_PAYLOAD = 65507  # IPv4 UDP hard limit; larger needs TCP


def marker_text(seq, tag=None):
    """What rides in the log's free-text field: the event's own marker, plus a throughput run's tag."""
    return f"{MARKER}-{seq}" + (f" {PERF_MARKER}-{tag}" if tag else "")

# --------------------------------------------------------------------------- event generator
# Every batch gets a small "scene": a handful of internal hosts with users, a set of
# ordinary internet destinations, and a few bad ones. Events are drawn from that
# scene so a batch reads like one site's traffic (the same laptop hits a blocked
# URL, then trips an IPS signature) instead of one static line repeated.

MIXES = {
    # kind -> weight
    "realistic": {"allow": 70, "deny": 13, "webfilter": 6, "ips": 4, "vpn": 3, "admin": 4},
    "alerts":    {"allow": 40, "deny": 20, "webfilter": 15, "ips": 15, "vpn": 5, "admin": 5},
    "traffic":   {"allow": 85, "deny": 15},
}

_INTERNAL = [  # ip, hostname, user
    ("10.1.20.11", "FIN-LT-0113", "mcarter"), ("10.1.20.24", "FIN-LT-0126", "jrivera"),
    ("10.1.30.7", "ENG-WS-0207", "aokafor"), ("10.1.30.19", "ENG-WS-0219", "lnguyen"),
    ("10.1.40.5", "HR-LT-0305", "sbrennan"), ("10.1.50.2", "SRV-FILE01", "svc_backup"),
    ("10.1.50.9", "SRV-AD01", "administrator"), ("10.1.60.33", "GUEST-WIFI-33", "guest"),
    ("10.1.70.14", "OT-HMI-014", "operator"), ("10.1.20.31", "FIN-LT-0133", "kpatel"),
]
_DEST = [  # ip, host, port, service, app, category
    ("142.250.72.14", "www.google.com", 443, "HTTPS", "Google", "Search Engines"),
    ("52.96.166.98", "outlook.office365.com", 443, "HTTPS", "Microsoft.Outlook", "Business"),
    ("13.107.42.14", "teams.microsoft.com", 443, "HTTPS", "Microsoft.Teams", "Business"),
    ("104.16.132.229", "cdnjs.cloudflare.com", 443, "HTTPS", "HTTPS.BROWSER", "Content Delivery"),
    ("140.82.112.4", "github.com", 443, "HTTPS", "GitHub", "Information Technology"),
    ("151.101.1.140", "www.reddit.com", 443, "HTTPS", "Reddit", "Social Networking"),
    ("8.8.8.8", "dns.google", 53, "DNS", "DNS", "Infrastructure"),
    ("1.1.1.1", "one.one.one.one", 53, "DNS", "DNS", "Infrastructure"),
    ("52.94.236.248", "s3.amazonaws.com", 443, "HTTPS", "Amazon.AWS", "Cloud Storage"),
    ("17.253.144.10", "ocsp.apple.com", 80, "HTTP", "Apple.Update", "Software Updates"),
    ("23.215.130.36", "download.windowsupdate.com", 80, "HTTP", "Windows.Update", "Software Updates"),
    ("162.159.136.234", "discord.com", 443, "HTTPS", "Discord", "Social Networking"),
]
_BAD = [  # ip, host, category, url path
    ("185.220.101.45", "mail-secure-verify.top", "Phishing", "/login/office365/index.php"),
    ("45.155.205.233", "cdn-update-check.xyz", "Malicious Websites", "/dl/invoice_0923.exe"),
    ("91.219.237.244", "free-vpn-proxy.cc", "Proxy Avoidance", "/connect"),
    ("194.26.29.108", "cryptominer-pool.pw", "Malware", "/xmr/pool.js"),
    ("103.75.190.12", "betting-wins-247.com", "Gambling", "/"),
    ("176.123.7.129", "torrent-mirror.site", "Peer-to-peer File Sharing", "/announce"),
]
_IPS = [  # signature name, severity, cve, snort-style sid
    ("Apache.Log4j.Error.Log.Remote.Code.Execution", "critical", "CVE-2021-44228", "1:58722"),
    ("MS.SMB.Server.SMB1.Trans2.Secondary.Handling.Code.Execution", "critical", "CVE-2017-0144", "1:41978"),
    ("HTTP.Unix.Shell.IFS.Remote.Code.Execution", "high", "", "1:1327"),
    ("SSH.Connection.Brute.Force", "medium", "", "1:19559"),
    ("Web.Server.Password.Files.Access", "medium", "", "1:1122"),
    ("Cisco.IOS.XE.Web.UI.Privilege.Escalation", "critical", "CVE-2023-20198", "1:62526"),
    ("Mirai.Botnet.Communication", "high", "", "1:44016"),
]
_ADMIN = [("admin", "192.168.1.50", "success"), ("admin", "192.168.1.50", "success"),
          ("admin", "203.0.113.77", "failed"), ("netops", "10.1.30.7", "success"),
          ("root", "45.155.205.233", "failed")]


class Scene:
    """Per-run random state so batches are varied but reproducible with --seed."""

    def __init__(self, seed=None, mix="realistic"):
        self.rng = random.Random(seed)
        self.weights = MIXES[mix]
        self.kinds = list(self.weights)
        self.wts = [self.weights[k] for k in self.kinds]
        self.session = self.rng.randint(100000, 900000)

    def kind(self):
        return self.rng.choices(self.kinds, weights=self.wts, k=1)[0]

    def host(self):
        return self.rng.choice(_INTERNAL)

    def dest(self):
        return self.rng.choice(_DEST)

    def bad(self):
        return self.rng.choice(_BAD)

    def ips(self):
        return self.rng.choice(_IPS)

    def admin(self):
        return self.rng.choice(_ADMIN)

    def sport(self):
        return self.rng.randint(49152, 65535)

    def bytes_pair(self, big=False):
        if big:
            return self.rng.randint(20000, 900000), self.rng.randint(200000, 40000000)
        return self.rng.randint(300, 9000), self.rng.randint(600, 120000)

    def duration(self):
        return self.rng.randint(1, 900)

    def next_session(self):
        self.session += self.rng.randint(1, 7)
        return self.session


SCENE = Scene()  # default; main() replaces it when --seed/--mix are given


# The zone the simulated devices' clocks are set to. A real firewall writes its OWN clock's time, and a
# sensor reads a log that cannot state an offset in the zone the SENSOR is set to - so the two have to agree,
# or every such event lands hours from now. Measured 7 Oct 2026: a sensor set to Pacific filed this
# generator's UTC Palo Alto records seven hours ahead, where no search ending "now" finds them (Paul: "I have
# the sensor set for our time with the time zone. Can the log be sent with the right time").
#   None (the default): the rule since 15 Sep 2026 - a format that cannot state its offset carries UTC,
#                       one that can carries this host's local time with its offset. Right for a sensor on UTC.
#   a zone:             every simulated device is on that clock. The formats that cannot state an offset are
#                       written in it, the ones that can are written in it WITH the offset. SonicWall and
#                       Sophos write the word UTC into the record, so they stay UTC whatever is set.
DEVICE_TZ = None
DEVICE_TZ_NAME = ""
ZONE_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_+\-]*(/[A-Za-z0-9_+\-]+){0,2}$")
# what a zone set here changes, in the words the page and the run log use
ZONE_LESS = ("Palo Alto", "Cisco ASA", "Snare", "Windows DNS", "NXLog")


def device_tz(name):
    """The tzinfo for an IANA zone name, or ValueError in our words. The name is only ever a key into the
    host's zone database - never a path."""
    name = str(name or "").strip()
    if not name:
        return None
    if ZoneInfo is None:
        raise ValueError("this host's Python has no time zone database (zoneinfo needs Python 3.9 or newer)")
    if not ZONE_RE.match(name) or ".." in name:
        raise ValueError(f"'{name[:40]}' is not a time zone name; use one like America/Los_Angeles, Europe/London or UTC")
    try:
        return ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError, OSError):
        raise ValueError(f"'{name[:40]}' is not a time zone this host knows; use one like America/Los_Angeles, "
                         f"Europe/London or UTC") from None


def set_device_tz(name):
    """Put every simulated device on this zone's clock ('' or None: back to the UTC rule). Process-wide:
    the generator is one module, and Ingest Studio has one setting for all its runs."""
    global DEVICE_TZ, DEVICE_TZ_NAME
    tz = device_tz(name)
    DEVICE_TZ, DEVICE_TZ_NAME = tz, (str(name).strip() if tz else "")
    return DEVICE_TZ_NAME


def zone_names():
    """Every zone this host knows, sorted, for a picker. Empty when there is no zone database."""
    if ZoneInfo is None:
        return []
    try:
        return sorted(z for z in available_timezones() if "/" in z or z == "UTC")
    except Exception:  # noqa: BLE001
        return []


def _t():
    # With no device zone: local time for the formats that also say what their offset is, UTC for the ones
    # that cannot. PAN-OS syslog has nowhere to state a time zone (neither its BSD header nor its CSV times),
    # nor have Cisco ASA's header, Snare, Windows DNS or NXLog; read without one, the event lands hours away
    # from now on any host that is not on UTC and no recent-time search finds it. FortiGate carries tz= and an
    # epoch eventtime, Meraki an epoch, Check Point an RFC 5424 offset, so those stay local.
    # With a device zone (set_device_tz): every device is on that clock, offset-free formats included.
    utc = datetime.now(timezone.utc)
    if DEVICE_TZ is None:
        now, bare = utc.astimezone(), utc          # bare = what a format that cannot state its offset carries
    else:
        now = utc.astimezone(DEVICE_TZ)
        bare = now
    return {
        "ts_pan": bare.strftime("%b %d %H:%M:%S"),
        "ts_pan_csv": bare.strftime("%Y/%m/%d %H:%M:%S"),
        "date": now.strftime("%Y-%m-%d"),
        "time": now.strftime("%H:%M:%S"),
        "bare_date": bare.strftime("%Y-%m-%d"),     # Windows DNS, NXLog: no offset anywhere in the record
        "bare_time": bare.strftime("%H:%M:%S"),
        "utc_date": utc.strftime("%Y-%m-%d"),       # Sophos: writes timezone="UTC" beside it, so always UTC
        "utc_time": utc.strftime("%H:%M:%S"),
        "ts_snare": bare.strftime("%a %b %d %H:%M:%S %Y"),
        "ts_asa": bare.strftime("%b %d %Y %H:%M:%S"),   # Cisco ASA `logging timestamp`: no zone
        "epoch": int(now.timestamp()),
        "ms": f"{now.microsecond // 1000:03d}",
        "ts_sw": utc.strftime("%Y-%m-%d %H:%M:%S UTC"),  # SonicWall writes the word UTC, so always UTC
        # RFC 5424 timestamp with an explicit offset (Check Point Log Exporter): states its own zone,
        # so it is allowed to be local time.
        "iso_local": now.isoformat(timespec="milliseconds"),
        "tz": now.strftime("%z")[:3] + ":" + now.strftime("%z")[3:],
    }


# ---- FortiGate (FortiOS 7.x key=value syslog) ------------------------------------
def gen_fortigate(sc, seq, kind, tag):
    t = _t(); sip, shost, user = sc.host(); sess = sc.next_session()
    devid = _ident(sc, "devid", "FGTLAB0000000001")
    devname = _ident(sc, "devname", "FGT-60F-BR01")
    # devid="" omits the field entirely: some log subtypes do not carry it, and a relay keyed on
    # it has to fall back rather than lose the log.
    dev = f'devid="{devid}" ' if devid else ""
    head = (f'<189>date={t["date"]} time={t["time"]} devname="{devname}" {dev}'
            f'eventtime={t["epoch"]}{t["ms"]}000000 tz="{t["tz"].replace(":", "")}" ')
    if kind in ("allow", "deny"):
        dip, dhost, dport, svc, app, cat = sc.dest()
        sent, rcvd = sc.bytes_pair(big=(svc == "HTTPS" and sc.rng.random() < 0.2))
        if kind == "allow":
            return (head + f'logid="0000000013" type="traffic" subtype="forward" level="notice" vd="root" '
                    f'srcip={sip} srcname="{shost}" srcport={sc.sport()} srcintf="internal" srcintfrole="lan" '
                    f'dstip={dip} dstport={dport} dstintf="wan1" dstintfrole="wan" srccountry="Reserved" '
                    f'dstcountry="United States" sessionid={sess} proto={17 if svc == "DNS" else 6} action="close" '
                    f'policyid=12 policytype="policy" poluuid="4a9b3e2c-1f4d-51ee-9c0b-0a1b2c3d4e5f" policyname="LAN-to-Internet" '
                    f'user="{user}" group="Domain Users" service="{svc}" trandisp="snat" transip=203.0.113.5 transport={sc.sport()} '
                    f'appid=15832 app="{app}" appcat="{cat}" apprisk="low" duration={sc.duration()} '
                    f'sentbyte={sent} rcvdbyte={rcvd} sentpkt={sent // 700 + 1} rcvdpkt={rcvd // 1200 + 1} '
                    f'dsthost="{dhost}" msg="{tag}"')
        bp = sc.rng.choice([23, 445, 3389, 1433, 8080])
        return (head + f'logid="0000000013" type="traffic" subtype="forward" level="notice" vd="root" '
                f'srcip={sip} srcname="{shost}" srcport={sc.sport()} srcintf="internal" srcintfrole="lan" '
                f'dstip={dip} dstport={bp} dstintf="wan1" dstintfrole="wan" '
                f'sessionid={sess} proto=6 action="deny" policyid=0 policytype="policy" policyname="Implicit Deny" '
                f'user="{user}" service="tcp/{bp}" duration=0 sentbyte=0 rcvdbyte=0 '
                f'sentpkt=0 rcvdpkt=0 appcat="unscanned" crscore=30 craction=131072 crlevel="high" msg="{tag}"')
    if kind == "webfilter":
        bip, bhost, bcat, path = sc.bad()
        return (head + f'logid="0316013056" type="utm" subtype="webfilter" eventtype="ftgd_blk" level="warning" vd="root" '
                f'policyid=12 sessionid={sess} srcip={sip} srcport={sc.sport()} srcintf="internal" srcintfrole="lan" '
                f'dstip={bip} dstport=443 dstintf="wan1" dstintfrole="wan" proto=6 service="HTTPS" hostname="{bhost}" '
                f'profile="default" action="blocked" reqtype="direct" url="https://{bhost}{path}" sentbyte=512 rcvdbyte=0 '
                f'direction="outgoing" user="{user}" msg="URL belongs to a denied category in policy: {tag}" method="domain" '
                f'cat=26 catdesc="{bcat}" crscore=30 craction=4194304 crlevel="high"')
    if kind == "ips":
        name, sev, cve, sid = sc.ips(); bip, bhost, _, _ = sc.bad()
        inbound = sc.rng.random() < 0.5
        return (head + f'logid="0419016384" type="utm" subtype="ips" eventtype="signature" level="alert" vd="root" '
                f'severity="{sev}" srcip={bip if inbound else sip} srccountry="{"Russian Federation" if inbound else "Reserved"}" '
                f'dstip={sip if inbound else bip} srcintf="{"wan1" if inbound else "internal"}" dstintf="{"internal" if inbound else "wan1"}" '
                f'sessionid={sess} action="dropped" proto=6 service="{"HTTP" if inbound else "HTTPS"}" policyid=12 '
                f'attack="{name}" srcport={sc.sport()} dstport={80 if inbound else 443} direction="{"incoming" if inbound else "outgoing"}" '
                f'attackid={sid.split(":")[1]} profile="protect_all_servers" ref="http://www.fortinet.com/ids/VID{sid.split(":")[1]}" '
                f'incidentserialno={sc.rng.randint(10**8, 10**9)} msg="{"applications3" if inbound else "backdoor"}: {name}, {tag}" '
                f'crscore=50 craction=16384 crlevel="critical"' + (f' cve="{cve}"' if cve else ""))
    if kind == "vpn":
        up = sc.rng.random() < 0.7
        return (head + f'logid="0101037{"127" if up else "128"}" type="event" subtype="vpn" level="notice" vd="root" '
                f'logdesc="IPsec phase 2 status change" msg="IPsec phase 2 status change: {tag}" action="phase2-{"up" if up else "down"}" '
                f'remip=198.51.100.23 locip=203.0.113.5 remport=500 locport=500 outintf="wan1" cookies="9f1c3b2a8e7d6c5b/0a1b2c3d4e5f6a7b" '
                f'user="N/A" group="N/A" xauthuser="N/A" xauthgroup="N/A" assignip=N/A vpntunnel="to-HQ-DC" tunnelid={sc.rng.randint(1, 9)} '
                f'status="{"up" if up else "down"}" init="local" mode="main" dir="outbound" stage=2 role="initiator" result="OK"')
    # admin
    who, frm, res = sc.admin()
    return (head + f'logid="0100032{"001" if res == "success" else "002"}" type="event" subtype="system" level="{"information" if res == "success" else "alert"}" vd="root" '
            f'logdesc="Admin login {"successful" if res == "success" else "failed"}" sn="{sc.rng.randint(10**9, 10**10)}" user="{who}" ui="https({frm})" '
            f'method="https" srcip={frm} dstip=192.168.1.99 action="login" status="{res}" reason="{"none" if res == "success" else "passwd_invalid"}" '
            f'profile="super_admin" msg="Administrator {who} {"logged in successfully" if res == "success" else "login failed"} from https({frm}): {tag}"')


# ---- Cisco Meraki MX (syslog, RFC 5424-ish header) --------------------------------
def gen_meraki(sc, seq, kind, tag):
    t = _t(); sip, shost, user = sc.host()
    head = f'<134>1 {t["epoch"]}.{t["ms"]}{sc.rng.randint(100, 999)} {_ident(sc, "hostname", "MX68-BR01")} '
    if kind in ("allow", "deny"):
        dip, dhost, dport, svc, app, cat = sc.dest()
        if kind == "allow":
            return (head + f'flows src={sip} dst={dip} mac={_mac(sc)} protocol={"udp" if svc == "DNS" else "tcp"} '
                    f'sport={sc.sport()} dport={dport} pattern: allow all note={tag}')
        return (head + f'flows src={sip} dst={dip} mac={_mac(sc)} protocol=tcp sport={sc.sport()} '
                f'dport={sc.rng.choice([23, 445, 3389, 1433])} pattern: deny all note={tag}')
    if kind == "webfilter":
        bip, bhost, bcat, path = sc.bad()
        return (head + f'urls src={sip}:{sc.sport()} dst={bip}:443 mac={_mac(sc)} agent=\'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                f'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36\' request: GET https://{bhost}{path} note={tag}')
    if kind == "ips":
        name, sev, cve, sid = sc.ips(); bip, _, _, _ = sc.bad()
        return (head + f'ids-alerts signature={sid}:{sc.rng.randint(1, 20)} priority={"1" if sev == "critical" else "2"} '
                f'timestamp={t["epoch"]}.{t["ms"]} dhost={_mac(sc)} direction=ingress protocol=tcp/ip src={bip}:{sc.sport()} dst={sip}:445 '
                f'message: {name.replace(".", " ")} note={tag}')
    if kind == "vpn":
        return (head + f'events type=vpn_connectivity_change vpn_type=\'site-to-site\' peer_contact=\'198.51.100.23:51820\' '
                f'peer_ident=\'a1b2c3d4e5f6\' connectivity=\'{"true" if sc.rng.random() < 0.7 else "false"}\' note={tag}')
    # admin / events
    return (head + f'events type=security_event security_event=security_filtering_file_scanned '
            f'url=https://{sc.bad()[1]}/dl/invoice_0923.exe src={sip}:{sc.sport()} dst={sc.bad()[0]}:443 mac={_mac(sc)} '
            f'name=\'Trojan.Win32.Emotet.gen\' sha256={sc.rng.getrandbits(256):064x} disposition=malicious action=block note={tag}')


def _mac(sc):
    return "00:18:0A:" + ":".join(f"{sc.rng.randint(0, 255):02X}" for _ in range(3))


# ---- Palo Alto PAN-OS (CSV syslog, TRAFFIC / THREAT / SYSTEM) --------------------
def gen_paloalto(sc, seq, kind, tag):
    t = _t(); sip, shost, user = sc.host(); sess = sc.next_session()
    dom_user = f"corp\\{user}"
    host, serial = _ident(sc, "hostname", "PA-3220-BR01"), _ident(sc, "serial", "012345678901")
    head = f'<14>{t["ts_pan"]} {host} 1,{t["ts_pan_csv"]},{serial},'
    if kind in ("allow", "deny"):
        dip, dhost, dport, svc, app, cat = sc.dest()
        sent, rcvd = sc.bytes_pair()
        if kind == "allow":
            return (head + f'TRAFFIC,end,2562,{t["ts_pan_csv"]},{sip},{dip},203.0.113.5,{dip},Allow-Outbound-Web,{dom_user},,'
                    f'{app.lower().replace(".", "-")},vsys1,trust,untrust,ethernet1/2,ethernet1/1,Forward-to-Stellar,{t["ts_pan_csv"]},{sess},1,'
                    f'{sc.sport()},{dport},{sc.sport()},{dport},0x400053,{"udp" if svc == "DNS" else "tcp"},allow,{sent + rcvd},{sent},{rcvd},'
                    f'{sent // 700 + rcvd // 1200 + 2},{t["ts_pan_csv"]},{sc.duration()},{cat.lower().replace(" ", "-")},,{sc.rng.randint(10**12, 10**13)},0x8000000000000000,'
                    f'10.0.0.0-10.255.255.255,United States,,{sent // 700 + 1},{rcvd // 1200 + 1},tcp-fin,0,0,0,0,,{host},from-policy,,,0,,0,,N/A,0,0,0,0,'
                    f'4a9b3e2c-1f4d-51ee-9c0b-0a1b2c3d4e5f,0,0,,,,,,,,,,,,,,,,,,,,,,,,,,0,{t["ts_pan_csv"]},,,{app.split(".")[0].lower()},networking,browser-based,4,"used-by-malware,able-to-transfer-file,has-known-vulnerability,tunnel-other-application,pervasive-use",,{app.lower()},no,no,0,{tag}')
        bp = sc.rng.choice([23, 445, 3389, 1433])
        return (head + f'TRAFFIC,deny,2562,{t["ts_pan_csv"]},{sip},{dip},0.0.0.0,0.0.0.0,Deny-Risky-Ports,{dom_user},,not-applicable,vsys1,trust,untrust,'
                f'ethernet1/2,ethernet1/1,Forward-to-Stellar,{t["ts_pan_csv"]},{sess},1,{sc.sport()},{bp},0,0,0x0,tcp,deny,60,60,0,1,{t["ts_pan_csv"]},0,any,,'
                f'{sc.rng.randint(10**12, 10**13)},0x0,10.0.0.0-10.255.255.255,United States,,1,0,policy-deny,0,0,0,0,,{host},from-policy,,,0,,0,,N/A,0,0,0,0,'
                f'7c1d2e3f-4a5b-6c7d-8e9f-0a1b2c3d4e5f,0,0,,,,,,,,,,,,,,,,,,,,,,,,,,0,{t["ts_pan_csv"]},,,unknown,unknown,unknown,1,"",,,no,no,0,{tag}')
    if kind == "webfilter":
        bip, bhost, bcat, path = sc.bad()
        return (head + f'THREAT,url,2562,{t["ts_pan_csv"]},{sip},{bip},203.0.113.5,{bip},Block-Malicious-URLs,{dom_user},,web-browsing,vsys1,trust,untrust,'
                f'ethernet1/2,ethernet1/1,Forward-to-Stellar,{t["ts_pan_csv"]},{sess},1,{sc.sport()},443,{sc.sport()},443,0x40f000,tcp,block-url,'
                f'"{bhost}{path}",(9999),{bcat.lower().replace(" ", "-")},informational,client-to-server,{sc.rng.randint(10**12, 10**13)},0xa000000000000000,'
                f'10.0.0.0-10.255.255.255,Netherlands,,,0,,,,,,,,,0,0,0,0,0,,{host},,,,,get,0,,0,,N/A,unknown,AppThreat-0-0,0x0,0,4294967295,,"{bcat}",'
                f'4a9b3e2c-1f4d-51ee-9c0b-0a1b2c3d4e5f,0,,,,,,,,,,,,,,,,,,,0,{t["ts_pan_csv"]},,,web-browsing,networking,browser-based,4,"",,,no,no,0,{tag}')
    if kind == "ips":
        name, sev, cve, sid = sc.ips(); bip, _, _, _ = sc.bad()
        return (head + f'THREAT,vulnerability,2562,{t["ts_pan_csv"]},{bip},{sip},{bip},203.0.113.9,Inbound-Web-Servers,,,web-browsing,vsys1,untrust,trust,'
                f'ethernet1/1,ethernet1/2,Forward-to-Stellar,{t["ts_pan_csv"]},{sess},1,{sc.sport()},443,{sc.sport()},443,0x80402000,tcp,reset-both,'
                f'"",{name.replace(".", " ")}({sid.split(":")[1]}),any,{sev},server-to-client,{sc.rng.randint(10**12, 10**13)},0xa000000000000000,'
                f'Russian Federation,10.0.0.0-10.255.255.255,,,{sc.rng.randint(10**9, 10**10)},,,,,,,,,0,0,0,0,0,,{host},,,,,,0,,0,,N/A,'
                f'{"code-execution" if "Code" in name else "brute-force"},AppThreat-8800-8000,0x0,0,4294967295,,"",{cve},0,,,,,,,,,,,,,,,,,,,0,{t["ts_pan_csv"]},,,'
                f'web-browsing,networking,browser-based,4,"",,,no,no,0,{tag}')
    if kind == "vpn":
        up = sc.rng.random() < 0.7
        return (head + f'SYSTEM,vpn,2562,{t["ts_pan_csv"]},0,0,0,0,,,,ipsec,vsys1,,,,,,{t["ts_pan_csv"]},0,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'
                f'"IKE phase-2 negotiation is {"succeeded" if up else "failed"} as initiator, quick mode. Established SA: 203.0.113.5[500]-198.51.100.23[500] '
                f'tunnel to-HQ-DC. {tag}",{t["ts_pan_csv"]},0,0,{"informational" if up else "high"},{host}')
    who, frm, res = sc.admin()
    return (head + f'SYSTEM,general,2562,{t["ts_pan_csv"]},0,0,0,0,,,,general,vsys1,,,,,,{t["ts_pan_csv"]},0,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'
            f'"User {who} {"logged in" if res == "success" else "failed authentication"} via Web from {frm} using https. {tag}",{t["ts_pan_csv"]},0,0,'
            f'{"informational" if res == "success" else "high"},{host}')


# ---- SonicWall (SonicOS syslog key=value) -----------------------------------------
def gen_sonicwall(sc, seq, kind, tag):
    t = _t(); sip, shost, user = sc.host()
    head = f'<134>id=firewall sn={_ident(sc, "sn", "0017C5AABBCC")} time="{t["ts_sw"]}" fw=203.0.113.9 '
    if kind in ("allow", "deny"):
        dip, dhost, dport, svc, app, cat = sc.dest()
        sent, rcvd = sc.bytes_pair()
        if kind == "allow":
            return (head + f'pri=6 c=1024 m=537 msg="Connection Closed" app={sc.rng.randint(10, 99)} appName="{app}" n={sc.next_session()} '
                    f'usr="{user}" src={sip}:{sc.sport()}:X0 dst={dip}:{dport}:X1 srcMac={_mac(sc)} dstMac=00:17:c5:aa:bb:cc '
                    f'proto={ {"DNS": "udp/dns", "HTTP": "tcp/http"}.get(svc, "tcp/https") } sent={sent} rcvd={rcvd} spkt={sent // 700 + 1} rpkt={rcvd // 1200 + 1} '
                    f'cdur={sc.duration() * 1000} rule="3 (LAN->WAN)" fw_action="NA" dpi=1 note="{tag}"')
        bp = sc.rng.choice([23, 445, 3389, 1433])
        return (head + f'pri=5 c=4 m=38 msg="TCP connection dropped" app=0 n={sc.next_session()} usr="{user}" src={sip}:{sc.sport()}:X0 '
                f'dst={dip}:{bp}:X1 srcMac={_mac(sc)} proto=tcp/{bp} '
                f'rule="Default Deny" fw_action="drop" note="{tag}"')
    if kind == "webfilter":
        bip, bhost, bcat, path = sc.bad()
        return (head + f'pri=5 c=8 m=14 msg="Web site access denied" app=49 n={sc.next_session()} usr="{user}" src={sip}:{sc.sport()}:X0 '
                f'dst={bip}:443:X1 srcMac={_mac(sc)} proto=tcp/https dstname={bhost} arg={path} code={sc.rng.randint(20, 60)} '
                f'Category="{bcat}" rule="CFS Default" fw_action="drop" note="{tag}"')
    if kind == "ips":
        name, sev, cve, sid = sc.ips(); bip, _, _, _ = sc.bad()
        return (head + f'pri=1 c=32 m=608 msg="IPS Prevention Alert: {name.replace(".", " ")}, SID: {sid.split(":")[1]}, Priority: '
                f'{"High" if sev in ("critical", "high") else "Medium"}" sid={sid.split(":")[1]} ipscat="{"EXPLOIT" if "Execution" in name else "ATTACK"}" '
                f'ipspri={1 if sev == "critical" else 2} n={sc.next_session()} src={bip}:{sc.sport()}:X1 dst={sip}:445:X0 proto=tcp/445 fw_action="drop" note="{tag}"')
    if kind == "vpn":
        up = sc.rng.random() < 0.7
        return (head + f'pri=6 c=64 m={"163" if up else "165"} msg="IPsec Tunnel {"established" if up else "torn down"}" n={sc.next_session()} '
                f'src=198.51.100.23:500:X1 dst=203.0.113.9:500 vpnpolicy="to-HQ-DC" note="{tag}"')
    who, frm, res = sc.admin()
    return (head + f'pri={6 if res == "success" else 5} c=16 m={"29" if res == "success" else "30"} '
            f'msg="Administrator {"login" if res == "success" else "login denied"} {"" if res == "success" else "due to bad credentials "}from {frm}" '
            f'usr="{who}" n={sc.next_session()} src={frm}:{sc.sport()}:{"X0" if frm.startswith(("10.", "192.")) else "X1"} dst=192.168.1.99:443:X0 '
            f'proto=tcp/https note="{tag}"')


# ---- Snare agent (Windows Security events forwarded as tab-delimited syslog) --------
_WIN_EVENTS = [  # event id, task, outcome
    (4624, "Logon", "Audit Success"), (4624, "Logon", "Audit Success"), (4634, "Logoff", "Audit Success"),
    (4625, "Logon", "Audit Failure"), (4672, "Special Logon", "Audit Success"), (4688, "Process Creation", "Audit Success"),
    (4720, "User Account Management", "Audit Success"), (4740, "User Account Management", "Audit Success"),
    (4776, "Credential Validation", "Audit Failure"), (1102, "Log clear", "Audit Success"),
]


def _win_event(sc, kind):
    if kind == "admin":
        return sc.rng.choice([(4672, "Special Logon", "Audit Success"), (4720, "User Account Management", "Audit Success"), (1102, "Log clear", "Audit Success")])
    if kind in ("ips", "deny"):
        return sc.rng.choice([(4625, "Logon", "Audit Failure"), (4776, "Credential Validation", "Audit Failure"), (4740, "User Account Management", "Audit Success")])
    return sc.rng.choice(_WIN_EVENTS)


def gen_snare(sc, seq, kind, tag):
    t = _t(); sip, shost, user = sc.host(); eid, task, outcome = _win_event(sc, kind)
    who, frm, res = sc.admin()
    dom_host = _ident(sc, "hostname", f"{shost}.corp.example.com")
    proc = sc.rng.choice(["cmd.exe", "powershell.exe", "svchost.exe", "wscript.exe"])
    msgs = {
        4624: f"An account was successfully logged on.    Subject:   Security ID:  S-1-0-0   Account Name:  -   Logon Type:  3   New Logon:   Security ID:  S-1-5-21-1004336348-1177238915-682003330-{sc.rng.randint(1000, 9999)}   Account Name:  {user}   Account Domain:  CORP   Logon ID:  0x{sc.rng.randint(0x10000, 0xFFFFFF):X}   Network Information:   Source Network Address:  {frm}   Source Port:  {sc.sport()}   Authentication Package:  Kerberos",
        4625: f"An account failed to log on.    Subject:   Security ID:  S-1-0-0   Account For Which Logon Failed:   Account Name:  {who}   Account Domain:  CORP   Failure Information:   Failure Reason:  Unknown user name or bad password.   Status:  0xC000006D   Sub Status:  0xC000006A   Logon Type:  3   Network Information:   Workstation Name:  {shost}   Source Network Address:  {frm}   Source Port:  {sc.sport()}",
        4634: f"An account was logged off.    Subject:   Security ID:  S-1-5-21-1004336348-1177238915-682003330-{sc.rng.randint(1000, 9999)}   Account Name:  {user}   Account Domain:  CORP   Logon Type:  3",
        4672: f"Special privileges assigned to new logon.    Subject:   Security ID:  S-1-5-21-1004336348-1177238915-682003330-500   Account Name:  {who}   Account Domain:  CORP   Privileges:  SeSecurityPrivilege  SeBackupPrivilege  SeRestorePrivilege  SeTakeOwnershipPrivilege  SeDebugPrivilege",
        4688: f"A new process has been created.    Creator Subject:   Account Name:  {user}   Account Domain:  CORP   Process Information:   New Process ID:  0x{sc.rng.randint(0x100, 0xFFFF):x}   New Process Name:  C:\\Windows\\System32\\{proc}   Token Elevation Type:  %%1938   Creator Process Name:  C:\\Windows\\explorer.exe",
        4720: f"A user account was created.    Subject:   Account Name:  {who}   Account Domain:  CORP   New Account:   Account Name:  svc_{sc.rng.choice(['backup', 'scan', 'temp', 'deploy'])}{sc.rng.randint(1, 99)}   Account Domain:  CORP   Attributes:   User Account Control:  Account Enabled",
        4740: f"A user account was locked out.    Subject:   Account Name:  SRV-AD01$   Account Domain:  CORP   Account That Was Locked Out:   Security ID:  S-1-5-21-1004336348-1177238915-682003330-{sc.rng.randint(1000, 9999)}   Account Name:  {user}   Additional Information:   Caller Computer Name:  {shost}",
        4776: f"The computer attempted to validate the credentials for an account.    Authentication Package:  MICROSOFT_AUTHENTICATION_PACKAGE_V1_0   Logon Account:  {who}   Source Workstation:  {shost}   Error Code:  0xC000006A",
        1102: f"The audit log was cleared.    Subject:   Security ID:  S-1-5-21-1004336348-1177238915-682003330-500   Account Name:  {who}   Domain Name:  CORP   Logon ID:  0x{sc.rng.randint(0x10000, 0xFFFFFF):X}",
    }
    crit = 1 if outcome == "Audit Failure" or eid in (1102, 4720) else 0
    acct = "N/A" if eid in (4625, 4776) else "CORP\\" + user
    return (f'<13>{t["ts_pan"]} {dom_host} MSWinEventLog\t{crit}\tSecurity\t{sc.rng.randint(10**5, 10**7)}\t'
            f'{t["ts_snare"]}\t{eid}\tMicrosoft-Windows-Security-Auditing\t'
            f'{acct}\tN/A\t{outcome}\t{dom_host}\t{task}\t\t{msgs[eid]}  {tag}\t{sc.rng.randint(10**5, 10**7)}')


# ---- Windows DNS Server (analytical/debug log forwarded via syslog) ---------------
def gen_windows_dns(sc, seq, kind, tag):
    t = _t(); sip, shost, user = sc.host()
    if kind in ("webfilter", "ips", "deny"):
        _, name, _, _ = sc.bad(); rcode = "NXDOMAIN" if sc.rng.random() < 0.5 else "NOERROR"
    else:
        _, name, _, _, _, _ = sc.dest(); rcode = "NOERROR"
    qtype = sc.rng.choice(["A", "A", "A", "AAAA", "TXT", "SRV", "MX"])
    tid = sc.rng.randint(0x1000, 0xFFFF)
    packet = f'{t["bare_date"].replace("-", "/")} {t["bare_time"]} 0B24 PACKET  000001E4A2B3C4D0 UDP Rcv {sip}    {tid:04x}   Q [0001   D   NOERROR] {qtype}      (7){name.split(".")[0]}(3){".".join(name.split(".")[1:])}(0)'
    if sc.rng.random() < 0.5:
        packet = f'{t["bare_date"].replace("-", "/")} {t["bare_time"]} 0B24 PACKET  000001E4A2B3C4D0 UDP Snd {sip}    {tid:04x} R Q [8081   DR  {rcode}] {qtype}      (7){name.split(".")[0]}(3){".".join(name.split(".")[1:])}(0)'
    return f'<30>{t["ts_pan"]} {_ident(sc, "hostname", "SRV-AD01.corp.example.com")} DNSServer: {packet} ; {tag}'


# ---- NXLog (Windows Security event forwarded as JSON over syslog) ------------------
def gen_nxlog(sc, seq, kind, tag):
    t = _t(); sip, shost, user = sc.host(); eid, task, outcome = _win_event(sc, kind); who, frm, res = sc.admin()
    host = _ident(sc, "hostname", None)
    doc = {
        "EventTime": f'{t["bare_date"]} {t["bare_time"]}', "Hostname": host or f"{shost}.corp.example.com", "Keywords": -9214364837600034816 if outcome == "Audit Success" else -9218868437227405312,
        "EventType": outcome.replace("Audit ", "AUDIT_").upper(), "SeverityValue": 2 if outcome == "Audit Success" else 4, "Severity": "INFO" if outcome == "Audit Success" else "ERROR",
        "EventID": eid, "SourceName": "Microsoft-Windows-Security-Auditing", "ProviderGuid": "{54849625-5478-4994-A5BA-3E3B0328C30D}",
        "Version": 2, "Task": 12544 if task == "Logon" else 13824, "OpcodeValue": 0, "RecordNumber": sc.rng.randint(10**6, 10**8), "ProcessID": 720, "ThreadID": sc.rng.randint(1000, 9000),
        "Channel": "Security", "Category": task, "Opcode": "Info",
        "SubjectUserName": who if eid in (4672, 4720, 1102) else "-", "SubjectDomainName": "CORP",
        "TargetUserName": user if eid not in (4625, 4776) else who, "TargetDomainName": "CORP",
        "LogonType": "3", "IpAddress": frm, "IpPort": str(sc.sport()), "AuthenticationPackageName": "Kerberos" if outcome == "Audit Success" else "NTLM",
        "EventReceivedTime": f'{t["bare_date"]} {t["bare_time"]}', "SourceModuleName": "in_security", "SourceModuleType": "im_msvistalog", "Message": f"{task} event {eid} ({outcome}). {tag}",
    }
    return f'<14>{t["ts_pan"]} {host or shost} nxlog: ' + json.dumps(doc)


# ---- Cisco ASA / AnyConnect remote-access VPN (custom_vpn) -------------------------
def gen_cisco_vpn(sc, seq, kind, tag):
    t = _t(); sip, shost, user = sc.host(); who, frm, res = sc.admin()
    pub = sc.rng.choice(["198.51.100.23", "203.0.113.77", "192.0.2.45", "198.51.100.200"])
    assigned = f"10.99.{sc.rng.randint(0, 3)}.{sc.rng.randint(2, 250)}"
    head = f'<166>{t["ts_pan"]} {_ident(sc, "hostname", "ASA-5516-HQ")} %ASA-'
    if kind in ("admin", "ips", "deny") and res == "failed":
        return head + f'6-113005: AAA user authentication Rejected : reason = AAA failure : server = 10.1.50.9 : user = {who} : user IP = {frm}. {tag}'
    if kind == "admin":
        return head + f'6-113004: AAA user authentication Successful : server =  10.1.50.9 : user = {who}. {tag}'
    if kind == "vpn" or sc.rng.random() < 0.5:
        return head + (f'4-722051: Group <AnyConnect-Employees> User <{user}> IP <{pub}> IPv4 Address <{assigned}> IPv6 address <::> assigned to session. {tag}')
    if kind in ("webfilter", "ips"):
        return head + f'4-113019: Group = AnyConnect-Employees, Username = {user}, IP = {pub}, Session disconnected. Session Type: SSL, Duration: {sc.duration() // 60}h:{sc.duration() % 60:02d}m:{sc.rng.randint(0, 59):02d}s, Bytes xmt: {sc.rng.randint(10**5, 10**8)}, Bytes rcv: {sc.rng.randint(10**5, 10**9)}, Reason: Idle Timeout. {tag}'
    return head + f'6-722055: Group <AnyConnect-Employees> User <{user}> IP <{pub}> Client Type: Cisco AnyConnect VPN Agent for Windows 4.10.07073. {tag}'


# ---- Check Point (Log Exporter: RFC 5424 with the fields in structured data) -------
_CP_PRODUCT = {"allow": "VPN-1 & FireWall-1", "deny": "VPN-1 & FireWall-1", "webfilter": "URL Filtering",
               "ips": "IPS", "vpn": "VPN-1 & FireWall-1", "admin": "SmartDashboard"}


def _cp_sd(pairs):
    """Check Point writes its fields inside one RFC 5424 structured-data element, each as key:"value"."""
    return "[" + "; ".join(f'{k}:"{v}"' for k, v in pairs.items()) + "]"


def gen_checkpoint(sc, seq, kind, tag):
    """Check Point gateway via Log Exporter. RFC 5424 header (which states its offset) plus an
    epoch `time` field, so this format may carry local time."""
    t = _t(); sip, shost, user = sc.host()
    host = _ident(sc, "hostname", "gw-hq-01")
    origin = _ident(sc, "origin", "203.0.113.5")
    base = {
        "action": "Accept", "flags": str(sc.rng.randint(400000, 460000)), "ifdir": "outbound", "ifname": "eth1",
        "logid": "0", "loguid": "{0x%08x,0x0,0x%08x,0x%08x}" % (sc.rng.getrandbits(32), sc.rng.getrandbits(32), sc.rng.getrandbits(32)),
        "origin": origin, "originsicname": f"CN={host},O=mgmt-01.corp.example.com.7kd8ap",
        "sequencenum": str(sc.next_session() % 100000), "time": str(t["epoch"]), "version": "5",
        "product": _CP_PRODUCT[kind], "layer_name": "Network", "layer_uuid": "8a1b2c3d-4e5f-6a7b-8c9d-0e1f2a3b4c5d",
    }
    if kind in ("allow", "deny"):
        dip, dhost, dport, svc, app, cat = sc.dest()
        sent, rcvd = sc.bytes_pair()
        drop = kind == "deny"
        bp = sc.rng.choice([23, 445, 3389, 1433]) if drop else dport
        base.update({"action": "Drop" if drop else "Accept", "rule_action": "Drop" if drop else "Accept",
                     "conn_direction": "Outgoing", "src": sip, "dst": dip, "proto": "17" if svc == "DNS" and not drop else "6",
                     "s_port": str(sc.sport()), "service": str(bp), "service_id": "domain-udp" if svc == "DNS" and not drop else ("https" if bp == 443 else f"TCP/{bp}"),
                     "inzone": "Internal", "outzone": "External", "match_id": str(sc.rng.randint(1, 40)), "parent_rule": "0",
                     "rule_uid": "1f2e3d4c-5b6a-7988-9a0b-1c2d3e4f5a6b", "rule_name": "Implicit Cleanup" if drop else "LAN-to-Internet",
                     "bytes": str(0 if drop else sent + rcvd), "client_outbound_bytes": str(0 if drop else sent),
                     "server_inbound_bytes": str(0 if drop else rcvd), "duration": "0" if drop else str(sc.duration()),
                     "xlatesrc": "" if drop else origin, "xlatesport": "0" if drop else str(sc.sport()),
                     "message": tag})
        return f'<134>1 {t["iso_local"]} {host} CheckPoint {sc.rng.randint(10000, 99999)} - ' + _cp_sd(base)
    if kind == "webfilter":
        bip, bhost, bcat, path = sc.bad()
        base.update({"action": "Block", "rule_action": "Block", "src": sip, "dst": bip, "proto": "6",
                     "s_port": str(sc.sport()), "service": "443", "service_id": "https", "web_client_type": "Chrome",
                     "resource": f"https://{bhost}{path}", "matched_category": bcat, "app_risk": "High",
                     "appi_name": bhost, "app_desc": f"Site categorised as {bcat}", "app_properties": bcat,
                     "inzone": "Internal", "outzone": "External", "message": tag})
        return f'<132>1 {t["iso_local"]} {host} CheckPoint {sc.rng.randint(10000, 99999)} - ' + _cp_sd(base)
    if kind == "ips":
        name, sev, cve, sid = sc.ips(); bip, _, _, _ = sc.bad()
        base.update({"action": "Prevent", "rule_action": "Prevent", "src": bip, "dst": sip, "proto": "6",
                     "s_port": str(sc.sport()), "service": "445", "attack": name.replace(".", " "),
                     "attack_info": f"{name.replace('.', ' ')} detected and blocked",
                     "protection_name": name.replace(".", " "), "protection_type": "IPS signature",
                     "protection_id": sid.split(":")[1], "severity": {"critical": "4", "high": "3"}.get(sev, "2"),
                     "confidence_level": "High", "performance_impact": "2", "industry_reference": cve or "N/A",
                     "inzone": "External", "outzone": "Internal", "message": tag})
        return f'<129>1 {t["iso_local"]} {host} CheckPoint {sc.rng.randint(10000, 99999)} - ' + _cp_sd(base)
    if kind == "vpn":
        up = sc.rng.random() < 0.7
        base.update({"action": "Key Install" if up else "Reject", "rule_action": "Key Install" if up else "Reject",
                     "peer_gateway": "198.51.100.23", "community": "to-HQ-DC", "scheme": "IKE",
                     "methods": "ESP: AES-256 + SHA256", "encryption_failure": "" if up else "Negotiation with peer failed",
                     "ike_ids": "to-HQ-DC", "vpn_feature_name": "IKE", "message": tag})
        return f'<134>1 {t["iso_local"]} {host} CheckPoint {sc.rng.randint(10000, 99999)} - ' + _cp_sd(base)
    who, frm, res = sc.admin()
    base.update({"action": "Accept" if res == "success" else "Reject", "product": "SmartDashboard",
                 "administrator": who, "machine": frm, "operation": "Log In" if res == "success" else "Failed Log In",
                 "operation_number": str(sc.rng.randint(1, 999)), "subject": "Administrator Login",
                 "audit_status": "Success" if res == "success" else "Failure", "client_ip": frm,
                 "additional_info": f"Authentication {res}", "message": tag})
    return f'<134>1 {t["iso_local"]} {host} CheckPoint {sc.rng.randint(10000, 99999)} - ' + _cp_sd(base)


# ---- Sophos Firewall XG/XGS (key=value; it states timezone="UTC", so it carries UTC) ------
def gen_sophos(sc, seq, kind, tag):
    t = _t(); sip, shost, user = sc.host()
    dev_id = _ident(sc, "device_id", "C0100ABCDEFG")
    dev_name = _ident(sc, "device_name", "XGS126")
    head = (f'<30>device="SFW" date={t["utc_date"]} time={t["utc_time"]} timezone="UTC" '
            f'device_name="{dev_name}" device_id={dev_id} ')
    if kind in ("allow", "deny"):
        dip, dhost, dport, svc, app, cat = sc.dest()
        sent, rcvd = sc.bytes_pair()
        allow = kind == "allow"
        bp = dport if allow else sc.rng.choice([23, 445, 3389, 1433])
        return (head + f'log_id=0101016000{"01" if allow else "02"} log_type="Firewall" log_component="Firewall Rule" '
                f'log_subtype="{"Allowed" if allow else "Denied"}" status="{"Allow" if allow else "Deny"}" priority=Information '
                f'duration={sc.duration() if allow else 0} fw_rule_id={3 if allow else 0} fw_rule_type={"User" if allow else "Default"} '
                f'nat_rule_id=2 policy_type=1 user_name="{user}" user_gp="Open Group" iap=2 ips_policy_id=0 appfilter_policy_id=1 '
                f'application="{app if allow else ""}" application_risk={1 if allow else 0} application_technology="Browser Based" '
                f'application_category="{cat if allow else ""}" in_interface="Port1" out_interface="{"Port2" if allow else ""}" '
                f'src_mac={_mac(sc)} src_ip={sip} src_country_code=R1 dst_ip={dip} dst_country_code=USA '
                f'protocol="{"UDP" if svc == "DNS" and allow else "TCP"}" src_port={sc.sport()} dst_port={bp} '
                f'sent_pkts={sent // 700 + 1 if allow else 0} recv_pkts={rcvd // 1200 + 1 if allow else 0} '
                f'sent_bytes={sent if allow else 0} recv_bytes={rcvd if allow else 0} '
                f'tran_src_ip={"203.0.113.9" if allow else ""} tran_src_port={sc.sport() if allow else 0} tran_dst_ip= tran_dst_port=0 '
                f'srczonetype="LAN" srczone="LAN" dstzonetype="WAN" dstzone="WAN" dir_disp="" connevent="{"Start" if allow else "Match"}" '
                f'connid="{sc.next_session()}" vconnid="" hb_health="No Heartbeat" message="{tag}" appresolvedby="Signature" app_is_cloud=0')
    if kind == "webfilter":
        bip, bhost, bcat, path = sc.bad()
        return (head + f'log_id=0204020001 log_type="Content Filtering" log_component="Web Filter" log_subtype="Denied" '
                f'status="" priority=Warning fw_rule_id=3 user_name="{user}" user_gp="Open Group" iap=2 category="{bcat}" '
                f'category_type="Objectionable" url="https://{bhost}{path}" domain={bhost} exceptions="" '
                f'activityname="Web Browsing" reason="Category Blocked" contenttype="text/html" override_token="" '
                f'httpresponsecode="403" src_ip={sip} dst_ip={bip} protocol="TCP" src_port={sc.sport()} dst_port=443 '
                f'sent_bytes=512 recv_bytes=0 domain_category="{bcat}" message="{tag}" ua="Mozilla/5.0" '
                f'response_time={sc.rng.randint(10, 400)} referer="" download_file_name="" download_file_type=""')
    if kind == "ips":
        name, sev, cve, sid = sc.ips(); bip, _, _, _ = sc.bad()
        return (head + f'log_id=0103010001 log_type="IDP" log_component="Anomaly" log_subtype="Drop" priority={sev.capitalize()} '
                f'idp_policy_id=2 idp_policy_name="LAN TO WAN" signature_id={sid.split(":")[1]} '
                f'signature_msg="{name.replace(".", " ")}" classification="Attempted Administrator Privilege Gain" '
                f'rule_priority={1 if sev == "critical" else 2} src_ip={bip} src_country_code=RUS dst_ip={sip} dst_country_code=R1 '
                f'protocol="TCP" src_port={sc.sport()} dst_port=445 platform="Windows" category="Exploit" '
                f'target="Server" cve_id="{cve or "N/A"}" message="{tag}"')
    if kind == "vpn":
        up = sc.rng.random() < 0.7
        return (head + f'log_id=0210{"6" if up else "7"}01001 log_type="Event" log_component="IPSec" '
                f'log_subtype="System" status="{"Successful" if up else "Failed"}" priority={"Information" if up else "Warning"} '
                f'user_name="" connectionname="to-HQ-DC" localgateway="203.0.113.9" remotegateway="198.51.100.23" '
                f'remotenetwork="10.90.0.0/16" localnetwork="10.1.0.0/16" '
                f'message="IPsec connection to-HQ-DC {"established" if up else "failed to establish"}: {tag}"')
    who, frm, res = sc.admin()
    return (head + f'log_id=0106010002 log_type="Event" log_component="Admin" log_subtype="Authentication" '
            f'status="{"Successful" if res == "success" else "Failed"}" priority={"Information" if res == "success" else "Warning"} '
            f'user_name="{who}" users="" usergroupname="Administrators" auth_client="Web Admin Console" '
            f'auth_mechanism="Local" reason="{"" if res == "success" else "Invalid credentials"}" src_ip={frm} '
            f'start_time={t["epoch"]} message="Administrator {who} login {res} from {frm}: {tag}"')


# ---- CEF encoders (ArcSight Common Event Format) for the firewall vendors ----------
def _cef_escape(v):
    return str(v).replace("\\", "\\\\").replace("|", "\\|").replace("=", "\\=").replace("\r", " ").replace("\n", " ")


def _cef(vendor, product, version, sig, name, sev, ext):
    header = "|".join(_cef_escape(x) for x in ("CEF:0", vendor, product, version, sig, name, sev))
    return header + "|" + " ".join(f"{k}={_cef_escape(v)}" for k, v in ext.items())


def _cef_scene(sc, kind, tag):
    """Shared CEF field set for allow/deny/webfilter/ips/vpn/admin, vendor-neutral."""
    t = _t(); sip, shost, user = sc.host()
    if kind in ("allow", "deny"):
        dip, dhost, dport, svc, app, cat = sc.dest(); sent, rcvd = sc.bytes_pair()
        bp = dport if kind == "allow" else sc.rng.choice([23, 445, 3389, 1433])
        return dict(sig=("traffic:allow" if kind == "allow" else "traffic:deny"), name=("Traffic allowed" if kind == "allow" else "Traffic denied"), sev=(1 if kind == "allow" else 4),
                    ext={"rt": t["epoch"] * 1000, "src": sip, "spt": sc.sport(), "shost": shost, "suser": user, "dst": dip, "dpt": bp, "dhost": dhost,
                         "proto": "UDP" if svc == "DNS" else "TCP", "app": app, "act": ("allow" if kind == "allow" else "deny"), "out": sent if kind == "allow" else 0,
                         "in": rcvd if kind == "allow" else 0, "deviceInboundInterface": "internal", "deviceOutboundInterface": "wan1", "msg": tag})
    if kind == "webfilter":
        bip, bhost, bcat, path = sc.bad()
        return dict(sig="webfilter:blocked", name="URL blocked", sev=5, ext={"rt": t["epoch"] * 1000, "src": sip, "spt": sc.sport(), "suser": user, "dst": bip, "dpt": 443, "dhost": bhost,
                    "request": f"https://{bhost}{path}", "requestMethod": "GET", "cat": bcat, "act": "blocked", "msg": tag})
    if kind == "ips":
        name, sev, cve, sid = sc.ips(); bip, _, _, _ = sc.bad()
        return dict(sig=f"ips:{sid.split(':')[1]}", name=name.replace(".", " "), sev=(10 if sev == "critical" else 8 if sev == "high" else 5),
                    ext={"rt": t["epoch"] * 1000, "src": bip, "spt": sc.sport(), "dst": sip, "dpt": 445, "proto": "TCP", "act": "dropped", "cs1Label": "cve", "cs1": cve or "n/a",
                         "cs2Label": "severity", "cs2": sev, "msg": tag})
    if kind == "vpn":
        up = sc.rng.random() < 0.7
        return dict(sig=("vpn:tunnel-up" if up else "vpn:tunnel-down"), name=("IPsec tunnel up" if up else "IPsec tunnel down"), sev=(2 if up else 6),
                    ext={"rt": t["epoch"] * 1000, "src": "198.51.100.23", "dst": "203.0.113.5", "spt": 500, "dpt": 500, "cs1Label": "tunnel", "cs1": "to-HQ-DC", "outcome": ("up" if up else "down"), "msg": tag})
    who, frm, res = sc.admin()
    return dict(sig=("admin:login" if res == "success" else "admin:login-failed"), name=("Administrator login" if res == "success" else "Administrator login failed"), sev=(3 if res == "success" else 7),
                ext={"rt": t["epoch"] * 1000, "src": frm, "suser": who, "dst": "192.168.1.99", "dpt": 443, "app": "https", "outcome": res, "msg": tag})


def gen_cef_fortigate(sc, seq, kind, tag):
    c = _cef_scene(sc, kind, tag); t = _t()
    devid, devname = _ident(sc, "devid", "FGTLAB0000000001"), _ident(sc, "devname", "FGT-60F-BR01")
    c["ext"] = {"deviceExternalId": devid, "dvchost": devname, "cat": {"allow": "traffic:forward", "deny": "traffic:forward", "webfilter": "utm:webfilter", "ips": "utm:ips", "vpn": "event:vpn"}.get(kind, "event:system"), **c["ext"]}
    return f'<189>{t["ts_pan"]} {devname} ' + _cef("Fortinet", "Fortigate", "v7.4.4,build2662", c["sig"], c["name"], c["sev"], c["ext"])


def gen_cef_paloalto(sc, seq, kind, tag):
    c = _cef_scene(sc, kind, tag); t = _t()
    host, serial = _ident(sc, "hostname", "PA-3220-BR01"), _ident(sc, "serial", "012345678901")
    c["ext"] = {"dvchost": host, "deviceExternalId": serial, "cs3Label": "Virtual System", "cs3": "vsys1", "cs4Label": "Rule", "cs4": "Forward-to-Stellar", **c["ext"]}
    return f'<14>{t["ts_pan"]} {host} ' + _cef("Palo Alto Networks", "PAN-OS", "11.1.4", c["sig"], c["name"], c["sev"], c["ext"])


def gen_cef_sonicwall(sc, seq, kind, tag):
    c = _cef_scene(sc, kind, tag); t = _t()
    c["ext"] = {"dvchost": "203.0.113.9", "deviceExternalId": _ident(sc, "sn", "0017C5AABBCC"), "cn1Label": "Category", "cn1": {"allow": 1024, "deny": 4, "webfilter": 8, "ips": 32, "vpn": 64}.get(kind, 16), **c["ext"]}
    return f'<134>{t["ts_pan"]} ' + _cef("SonicWall", "NSa", "7.1.1", c["sig"], c["name"], c["sev"], c["ext"])


def gen_cef_checkpoint(sc, seq, kind, tag):
    c = _cef_scene(sc, kind, tag); t = _t()
    host = _ident(sc, "hostname", "gw-hq-01")
    c["ext"] = {"dvchost": host, "deviceExternalId": _ident(sc, "origin", "203.0.113.5"), **c["ext"],
                "cs3Label": "Product", "cs3": _CP_PRODUCT[kind], "cs4Label": "Policy", "cs4": "Standard"}
    return f'<134>{t["ts_pan"]} {host} ' + _cef("Check Point", "VPN-1 & FireWall-1", "R81.20", c["sig"], c["name"], c["sev"], c["ext"])


def gen_cisco_asa(sc, seq, kind, tag):
    """Cisco ASA firewall: the sensor's own parser is on port 5518 (dev_type fw_cisco_asa), and that parser
    is NOT in the list of ~45 that accept the Stellar wrapper on their own port. That is the reason this
    source exists: sending it wrapped, to 5518, is the experiment that says whether the capture port is
    ever needed. %ASA-level-id messages after a `logging timestamp` header that carries no zone, so UTC."""
    t = _t(); sip, shost, user = sc.host(); sess = sc.next_session()
    head = f'<166>{t["ts_asa"]} {_ident(sc, "hostname", "ASA-5516-HQ")} : %ASA-'
    if kind == "allow":
        dip, dhost, dport, svc, app, cat = sc.dest(); udp = svc == "DNS"
        return head + (f'6-302013: Built outbound {"UDP" if udp else "TCP"} connection {sess} for outside:{dip}/{dport} ({dip}/{dport}) '
                       f'to inside:{sip}/{sc.sport()} (203.0.113.5/{sc.sport()}) ({user}) [{tag}]')
    if kind == "deny":
        dip, dhost, dport, svc, app, cat = sc.dest(); bp = sc.rng.choice([23, 445, 3389, 1433])
        return head + f'4-106023: Deny tcp src inside:{sip}/{sc.sport()} dst outside:{dip}/{bp} by access-group "inside_access_in" [0x0, 0x0] [{tag}]'
    if kind == "webfilter":
        bip, bhost, bcat, path = sc.bad()
        return head + f'5-304002: Access denied URL https://{bhost}{path} SRC {sip} DEST 443 on interface inside [{tag}]'
    if kind == "ips":
        bip, bhost, bcat, path = sc.bad()
        return head + (f'4-733100: [ Scanning] drop rate-1 exceeded. Current burst rate is {sc.rng.randint(5, 60)} per second, max configured rate is 10; '
                       f'Current average rate is {sc.rng.randint(2, 20)} per second, max configured rate is 5; '
                       f'Cumulative total count is {sc.rng.randint(100, 9999)} (source {bip}) [{tag}]')
    if kind == "vpn":
        if sc.rng.random() < 0.7:
            return head + (f'6-722055: Group <AnyConnect-Employees> User <{user}> IP <192.0.2.{sc.rng.randint(2, 250)}> '
                           f'Client Type: Cisco AnyConnect VPN Agent for Windows 4.10.07061 [{tag}]')
        return head + f'4-713903: Group = 198.51.100.23, IP = 198.51.100.23, Removing peer from correlator table failed, no match! IKE Phase 2 failed [{tag}]'
    who, frm, res = sc.admin()
    return head + (f'6-605005: Login permitted from {frm}/{sc.sport()} to inside:203.0.113.9/ssh for user "{who}" [{tag}]' if res == "success"
                   else f'6-605004: Login denied from {frm}/{sc.sport()} to inside:203.0.113.9/ssh for user "{who}" [{tag}]')


GENERATORS = {"fortigate": gen_fortigate, "meraki": gen_meraki, "paloalto": gen_paloalto, "sonicwall": gen_sonicwall,
              "checkpoint": gen_checkpoint, "sophos": gen_sophos,
              "snare": gen_snare, "windows_dns": gen_windows_dns, "nxlog": gen_nxlog, "cisco_vpn": gen_cisco_vpn,
              "cisco_asa": gen_cisco_asa}
CEF_GENERATORS = {"fortigate": gen_cef_fortigate, "paloalto": gen_cef_paloalto, "sonicwall": gen_cef_sonicwall,
                  "checkpoint": gen_cef_checkpoint}
SAMPLES = GENERATORS  # backwards-compatible name used by tests / --vendor choices

# vendor/product values that go in the wrapper's msg_origin, and the SENSOR PORT each log source
# is parsed on. Ports come from Stellar Cyber's parser table (reference/stellar-parser-ports.csv and
# the capture-port list): every source here has a parser of its own, and CEF has one shared port.
#
# Two ways to deliver a wrapped record, both testable (see WRAPPER_PORT_MODES):
#   parser   the log source's own parser port. The PORT selects the parser, so it cannot be
#            mis-routed. This is what the customer doc recommends.
#   capture  port 5564, the sensor's stellar_capture listener, which routes by KEYWORD from the
#            wrapper's msg_origin instead. Kept because it is the documented fallback and because
#            whether a given parser accepts the wrapper on its own port is a per-parser property.
CAPTURE_PORT = 5564
LEGACY_PORT_INT = CAPTURE_PORT          # the name this was called before it became a choice
CEF_PORT = 5143                         # every CEF parser shares this port (5870 for octet counting)
WRAPPER_ORIGIN = {
    "paloalto":    ("palo_alto_networks", "firewall", "syslog"),
    "fortigate":   ("fortinet", "fortigate", "syslog"),
    "meraki":      ("cisco", "meraki", "syslog"),
    "sonicwall":   ("sonicwall", "firewall", "syslog"),
    "checkpoint":  ("checkpoint", "firewall", "syslog"),
    "sophos":      ("sophos", "firewall", "syslog"),
    "snare":       ("snare", "snare_agent", "syslog"),
    "windows_dns": ("windows", "dns_server", "syslog"),
    "nxlog":       ("nxlog", "nxlog", "syslog"),
    "cisco_vpn":   ("cisco", "custom_vpn", "syslog"),
    # Not one of the documented wrapper pairs: the Cisco ASA parser (5518) is outside the wrapper-capable list, so
    # these values are the kit's own guess and the experiment is whether the parser honours the tenant at all.
    "cisco_asa":   ("cisco", "asa", "syslog"),
}
PARSER_PORT = {"paloalto": 5515, "fortigate": 5517, "meraki": 5172, "sonicwall": 5152,
               "checkpoint": 5519, "sophos": 5520,
               "snare": 5590, "windows_dns": 5599, "nxlog": 5601, "cisco_vpn": 5176, "cisco_asa": 5518}
# What the sensor's own parser table calls each source (msg_origin.source / dev_type). Not written
# into the wrapper today - the four documented ports take vendor/product/format - but it is what a
# parser outside those four identifies itself by, so it is recorded here and shown in the UI.
DEV_TYPE = {"paloalto": "fw_palo_alto", "fortigate": "fw_fortigate", "meraki": "meraki", "sonicwall": "sonicfw",
            "checkpoint": "fw_checkpoint", "sophos": "fw_sophos", "snare": "snare_agent",
            "windows_dns": "windows_dns_server", "nxlog": "nxlog", "cisco_vpn": "ciscovpn", "cisco_asa": "fw_cisco_asa"}
VENDOR_LABEL = {"fortigate": "FortiGate", "meraki": "Cisco Meraki", "paloalto": "Palo Alto Networks", "sonicwall": "SonicWall",
                "checkpoint": "Check Point firewall", "sophos": "Sophos Firewall (XG/XGS)",
                "snare": "Snare agent (Windows events)", "windows_dns": "Windows DNS Server", "nxlog": "NXLog (Windows events)", "cisco_vpn": "Cisco ASA / AnyConnect VPN",
                "cisco_asa": "Cisco ASA firewall (parser not in the wrapper list)"}
FORMATS_FOR = {v: (["syslog", "cef"] if v in CEF_GENERATORS else ["syslog"]) for v in GENERATORS}

# How a wrapped record may be delivered. The Studio and the relay map take one of these per source.
WRAPPER_PORT_MODES = {
    "parser":  "the log source's own parser port (the port selects the parser)",
    "capture": f"the capture port {CAPTURE_PORT}",
    "both":    "both, so the same logs can be compared side by side",
}


def origin_for(vendor, fmt="syslog"):
    """(vendor, product, format, port) to put in the wrapper / relay map for this vendor + format.
    The port is the log source's own parser port; `wrapper_ports` turns that into what to send to."""
    if fmt not in FORMATS_FOR[vendor]:
        raise ValueError(f"{vendor} does not support format {fmt}; choose from {FORMATS_FOR[vendor]}")
    v, p, _ = WRAPPER_ORIGIN[vendor]
    return v, p, fmt, (CEF_PORT if fmt == "cef" else PARSER_PORT[vendor])


def wrapper_ports(vendor, fmt="syslog", mode="parser"):
    """The sensor port(s) a wrapped record for this source should be sent to, for one of the two
    methods under test (or both). Always returns them in send order, parser port first."""
    if mode not in WRAPPER_PORT_MODES:
        raise ValueError(f"wrapper port mode must be one of {', '.join(WRAPPER_PORT_MODES)}")
    own = origin_for(vendor, fmt)[3]
    if mode == "capture":
        return [CAPTURE_PORT]
    if mode == "both":
        return [own] if own == CAPTURE_PORT else [own, CAPTURE_PORT]
    return [own]


# How each simulated device names itself INSIDE its own logs. A sensor-side parser mapping
# (Stellar Cyber's Approach 4: a customized parser that maps a device identifier to a tenant) or a
# field-keyed relay (render-config --key-mode field) reads one of these to find the tenant, so the
# field is chosen per log source and the value is shown before anything is sent.
#   field   the name as the parser sees it; the first entry per vendor is the recommended one
#   default what the generator writes when nothing is set (None = varies per event)
# Meraki syslog carries no serial number, only the device name in its header, which is why that is
# the only choice there.
DEVICE_FIELDS = {
    "fortigate":   [("devid", "devid= (appliance serial number)", "FGTLAB0000000001"),
                    ("devname", "devname= (host name)", "FGT-60F-BR01")],
    "paloalto":    [("serial", "serial number (CSV field 3, unique per appliance)", "012345678901"),
                    ("hostname", "host name (syslog header and the Device Name field)", "PA-3220-BR01")],
    "meraki":      [("hostname", "device name (syslog header; Meraki logs carry no serial)", "MX68-BR01")],
    "sonicwall":   [("sn", "sn= (appliance serial number)", "0017C5AABBCC")],
    "checkpoint":  [("hostname", "gateway host name (syslog header and dvchost)", "gw-hq-01"),
                    ("origin", 'origin:"" (the gateway IP the log came from)', "203.0.113.5")],
    "sophos":      [("device_id", "device_id= (appliance serial number)", "C0100ABCDEFG"),
                    ("device_name", 'device_name="" (appliance name)', "XGS126")],
    "cisco_vpn":   [("hostname", "host name (syslog header)", "ASA-5516-HQ")],
    "cisco_asa":   [("hostname", "host name (syslog header)", "ASA-5516-HQ")],
    "windows_dns": [("hostname", "host name (syslog header)", "SRV-AD01.corp.example.com")],
    "snare":       [("hostname", "host name (syslog header; the machine the agent runs on)", None)],
    "nxlog":       [("hostname", "host name (syslog header and the Hostname field)", None)],
}


def identity_for(vendor, field=None, value=None):
    """(field, value) a log source identifies itself by: the vendor's recommended field unless another
    of its fields is named; the value given, else the generator's default (None = varies per event).
    Raises ValueError naming the valid fields when `field` is not one the vendor's logs carry."""
    fields = DEVICE_FIELDS.get(vendor) or []
    if not fields:
        return None, None
    field = field or fields[0][0]
    for f, _, default in fields:
        if f == field:
            return f, (value if value else default)
    raise ValueError(f"{VENDOR_LABEL[vendor]} logs have no {field} field; choose from " + ", ".join(f for f, _, _ in fields))


def _ident(sc, field, default):
    """The value to write into `field`: the override set on the scene for this batch, else `default`."""
    v = (getattr(sc, "identity", None) or {}).get(field)
    return default if v is None else v


# Every log source here now has a parser port of its own, so any of them can be sent as-is; a device
# pointed straight at the sensor always sends to the port its parser listens on.
DIRECT_VENDORS = list(GENERATORS)


def direct_port(vendor, fmt="syslog"):
    """The parser port a device of this vendor sends to when nothing sits between it and the sensor."""
    return origin_for(vendor, fmt)[3]


HEX32 = re.compile(r"^[0-9a-f]{32}$")


def build_syslog(vendor: str, seq: int, size: int, kind=None, scene=None, fmt="syslog", devid=None, identity=None, tag=None) -> bytes:
    """Return one realistic event for `vendor` in `fmt` (syslog or cef), padded to at least `size` bytes.

    `kind` (allow|deny|webfilter|ips|vpn|admin) is drawn from the scene's mix when
    not given. The STELLAR-MT-TEST-<seq> marker rides in a free-text field so test
    events stay searchable without breaking the vendor's log format.

    `identity` is {field: value} for the vendor's DEVICE_FIELDS (a sensor-side tenant mapping or a
    field-keyed relay reads one of them); `devid` is the FortiGate shorthand kept for older callers:
    None = the generator's default serial, "" = emit no devid at all (some log subtypes lack it, and
    a relay keyed on it has to fall back rather than lose the log).
    """
    sc = scene or SCENE
    # Always assign, so a value left by a previous call on a shared scene never leaks into this batch.
    sc.identity = dict(identity or {})
    if devid is not None:
        sc.identity["devid"] = devid
    kind = kind or sc.kind()
    gen = CEF_GENERATORS[vendor] if fmt == "cef" else GENERATORS[vendor]
    line = gen(sc, seq, kind, marker_text(seq, tag))
    pad_needed = size - len(line.encode())
    if pad_needed > 5:
        line += " pad=" + ("x" * (pad_needed - 5))
    return line.encode()


# --------------------------------------------------------------------------- Method 5 payloads
# Method 5 (an HTTP relay adds the Stellar-TenantID header) is for log sources that natively POST
# JSON over HTTP. The tenant travels in the HEADER, so the BODY is whatever that product sends - its
# own webhook shape, not a firewall's syslog line. These are those shapes, close enough to the real
# thing to exercise a parser and to look right to someone comparing them with a vendor's docs.
#
# Each carries the run marker inside a field that is genuinely free-form in that product, so the
# records are findable in Stellar Cyber without inventing a field the vendor does not send.
WEBHOOK_SOURCES = {
    "paloalto_http": {"label": "Palo Alto PAN-OS (HTTP server profile)", "field": "serial",
                      "default": "012345678901", "marker_in": "misc"},
    "meraki_webhook": {"label": "Cisco Meraki (alert webhook)", "field": "deviceSerial",
                       "default": "Q2XX-ABCD-5678", "marker_in": "alertData.message"},
    "crowdstrike": {"label": "CrowdStrike Falcon (Fusion webhook)", "field": "ComputerName",
                    "default": "WIN-FIN-0113", "marker_in": "DetectDescription"},
    "okta": {"label": "Okta (event hook)", "field": "alternateId",
             "default": "mcarter@example.com", "marker_in": "displayMessage"},
    "generic": {"label": "Generic JSON log source", "field": "Device Name",
                "default": "SGI-TWR-000001", "marker_in": "marker"},
}


def webhook_identity(source, value=None):
    """(field, value) this webhook source identifies its device by, as the Studio's column shows it."""
    spec = WEBHOOK_SOURCES.get(source) or WEBHOOK_SOURCES["generic"]
    return spec["field"], (value or spec["default"])


def build_webhook(source: str, seq: int, size: int = 0, identity=None, tag=None) -> bytes:
    """One HTTP POST body in the shape the named product actually sends."""
    sc = SCENE
    marker = marker_text(seq, tag)
    now = datetime.now(timezone.utc)
    ident = (identity or {}).get(WEBHOOK_SOURCES.get(source, WEBHOOK_SOURCES["generic"])["field"])
    _, who = webhook_identity(source, ident)
    src = f"10.1.{seq % 60 + 10}.{seq % 200 + 5}"

    if source == "paloalto_http":
        # PAN-OS formats each log type into a JSON payload you define; these are the fields the
        # predefined Traffic format sends. Its times state no offset either, so they follow the device clock
        # (UTC unless a device zone is set), exactly as the syslog form does.
        bare = _t()["ts_pan_csv"]
        doc = {"receive_time": bare, "serial": who, "type": "TRAFFIC",
               "subtype": "end", "time_generated": bare,
               "src": src, "dst": "52.96.166.98", "natsrc": "203.0.113.5", "rule": "allow-web",
               "srcuser": "acme\\mcarter", "app": "ssl", "from": "trust", "to": "untrust",
               "inbound_if": "ethernet1/2", "outbound_if": "ethernet1/1", "sessionid": 100000 + seq,
               "action": "allow", "bytes": 4096 + seq, "bytes_sent": 2048 + seq, "bytes_received": 2048,
               "packets": 30, "session_end_reason": "tcp-fin", "device_name": "PA-3220-BR01",
               "misc": marker}
    elif source == "meraki_webhook":
        doc = {"version": "0.1", "sharedSecret": "", "sentAt": now.isoformat(timespec="milliseconds"),
               "organizationId": "2930418", "organizationName": "Acme Corp",
               "networkId": "N_24329156", "networkName": "Branch 1",
               "deviceSerial": who, "deviceName": "MX68-BR01", "deviceModel": "MX68",
               "alertId": f"{seq:016x}", "alertType": "Security event",
               "alertTypeId": "security_event", "occurredAt": now.isoformat(timespec="milliseconds"),
               "alertData": {"message": marker, "clientIp": src, "srcIp": src,
                             "destIp": "104.16.132.229", "protocol": "tcp", "priority": "2",
                             "signature": "1:2013504:5", "eventType": "IDS Alert"}}
    elif source == "crowdstrike":
        doc = {"metadata": {"customerIDString": "a89c97a78b344c04bd8da56e5fe605a2",
                            "offset": 100000 + seq, "eventType": "DetectionSummaryEvent",
                            "eventCreationTime": int(now.timestamp() * 1000), "version": "1.0"},
               "event": {"ProcessStartTime": int(now.timestamp()), "ComputerName": who,
                         "UserName": "mcarter", "DetectName": "Credential Theft",
                         "DetectDescription": f"A process attempted to read credentials. {marker}",
                         "Severity": 5, "SeverityName": "High", "FileName": "rundll32.exe",
                         "FilePath": "\\Device\\HarddiskVolume2\\Windows\\System32",
                         "SHA256String": f"{seq:064x}", "LocalIP": src,
                         "Tactic": "Credential Access", "Technique": "OS Credential Dumping",
                         "PatternDispositionValue": 2048}}
    elif source == "okta":
        doc = {"eventType": "com.okta.event_hook", "eventTypeVersion": "1.0",
               "cloudEventsVersion": "0.1", "source": "https://acme.okta.com",
               "eventId": f"{seq:032x}", "eventTime": now.isoformat(timespec="milliseconds"),
               "data": {"events": [{"uuid": f"{seq:032x}",
                                    "published": now.isoformat(timespec="milliseconds"),
                                    "eventType": "user.session.start",
                                    "version": "0", "severity": "INFO",
                                    "displayMessage": f"User login to Okta. {marker}",
                                    "outcome": {"result": "SUCCESS"},
                                    "actor": {"id": f"00u{seq:017x}", "type": "User",
                                              "alternateId": who, "displayName": "M Carter"},
                                    "client": {"ipAddress": src, "zone": "null",
                                               "device": "Computer",
                                               "userAgent": {"browser": "CHROME", "os": "Mac OS X",
                                                             "rawUserAgent": "Mozilla/5.0"}}}]}}
    else:
        return build_json_event(seq, size)

    raw = json.dumps(doc).encode()
    if size and size > len(raw):                    # pad the way build_json_event does
        doc["pad"] = "x" * (size - len(raw) - 11)
        raw = json.dumps(doc).encode()
    return raw


def build_json_event(seq: int, size: int, tenant_field=None, tag=None) -> bytes:
    """Return a JSON document (bytes) padded to at least `size` bytes."""
    doc = {
        "Event Type": "Device",
        "Event Name": "SystemSecurity",
        "Device Name": f"SGI-TWR-{seq:06d}",
        "IP Address": f"10.1.1.{seq % 250 + 1}",
        "OS": "Microsoft Windows 10",
        "marker": marker_text(seq, tag),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    if tenant_field:
        doc = {"tenantid": tenant_field, **doc}
    raw = json.dumps(doc).encode()
    overhead = len(json.dumps({"pad": ""})) - 2 + 2  # ', "pad": ""' == 11 bytes
    pad_needed = size - len(raw)
    if pad_needed > overhead:
        doc["pad"] = "x" * (pad_needed - overhead)
        raw = json.dumps(doc).encode()
    return raw


ORIGIN_FIELDS = ("vendor", "product", "format", "srcip")


def origin_fields(spec):
    """--origin: 'full' (the documented record), 'none' (no msg_origin block at all), or a comma-separated
    subset of vendor,product,format,srcip. Exists to MEASURE which of the four the sensor needs for the
    tenant to be honoured (Paul, 22 Sep 2026: "we want to see if we do need them"): each variant goes out
    under its own marker range and the platform says where each landed."""
    spec = (spec or "full").strip().lower()
    if spec == "full":
        return list(ORIGIN_FIELDS)
    if spec == "none":
        return []
    keep = [x.strip() for x in spec.split(",") if x.strip()]
    bad = [x for x in keep if x not in ORIGIN_FIELDS]
    if bad:
        raise SystemExit(f"--origin: unknown field(s) {', '.join(bad)}; choose from {', '.join(ORIGIN_FIELDS)}, or full / none")
    return keep


def wrap_record(vendor: str, fmt: str, tenant: str, srcip: str, original: str, origin="full") -> str:
    """One log inside the Stellar JSON wrapper, exactly as the relay writes it:
    {"stellar": {"tenantid", "msg_origin": {vendor, product, format, srcip}}, "parser_raw_msg"}.

    One line of JSON and no newline: the caller frames it. The FULL msg_origin is what the documented record
    carries, and measured on 17 Sep 2026 without it the sensor ignores the tenant, so `origin` other than
    "full" exists only for the --origin experiment. Shared by `wrapped` here and by Ingest Studio's direct
    path, so the two can never write different records."""
    v, p, f, _ = origin_for(vendor, fmt)
    keep = origin_fields(origin)
    full = {"vendor": v, "product": p, "format": f, "srcip": srcip}
    stellar = {"tenantid": tenant}
    if keep:
        stellar["msg_origin"] = {k: full[k] for k in ORIGIN_FIELDS if k in keep}
    return json.dumps({"stellar": stellar, "parser_raw_msg": original})


def build_wrapped(vendor: str, tenant: str, seq: int, size: int, srcip: str, kind=None, fmt="syslog", identity=None, origin="full") -> bytes:
    original = build_syslog(vendor, seq, size, kind=kind, fmt=fmt, identity=identity).decode()
    return (wrap_record(vendor, fmt, tenant, srcip, original, origin) + "\n").encode()


# --------------------------------------------------------------------------- transports
def tls_context(cafile=None):
    """Lab default: accept whatever certificate the sensor presents (it is self-signed out of the box, and the
    Stellar Cyber TLS-ingestion doc says senders must not validate it). With a CA file, verify the sensor's
    certificate against that CA and the address against the certificate's names, as a real client would:
    that is how to prove a certificate uploaded to the sensor has taken effect."""
    if cafile:
        ctx = ssl.create_default_context(cafile=cafile)
        ctx.verify_flags &= ~getattr(ssl, "VERIFY_X509_STRICT", 0)   # a lab CA has no key-usage extension; judge as openssl does
        return ctx
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def fingerprint(der):
    """SHA-256 of a DER certificate, in openssl's AA:BB:... form."""
    h = hashlib.sha256(der).hexdigest().upper()
    return ":".join(h[i:i + 2] for i in range(0, len(h), 2))


def _connect_tcp(host, port, bind, use_tls, timeout=10, cafile=None):
    s = socket.create_connection((host, port), timeout=timeout, source_address=(bind, 0) if bind else None)
    if use_tls:
        s = tls_context(cafile).wrap_socket(s, server_hostname=host)
    return s


def _pace(rate, started, sent):
    if rate and rate > 0:
        target = started + sent / rate
        delay = target - time.monotonic()
        if delay > 0:
            time.sleep(delay)


def send_stream(args, builder):
    """Send `args.count` payloads over UDP/TCP/TLS."""
    proto = args.proto
    if proto == "udp":
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        if args.bind:
            sock.bind((args.bind, 0))
    else:
        try:
            sock = _connect_tcp(args.target, args.port, args.bind, proto == "tls", cafile=getattr(args, "cafile", None))
        except ssl.SSLCertVerificationError as e:
            print(f"!! TLS: the certificate {args.target}:{args.port} presents does not verify against --cafile "
                  f"({getattr(e, 'verify_message', None) or e}). Nothing sent.", file=sys.stderr)
            return False
        except (ssl.SSLError, OSError) as e:
            print(f"!! could not connect to {args.target}:{args.port} over {proto}: {e}. Nothing sent.", file=sys.stderr)
            return False

    started = time.monotonic()
    ok = fail = total_bytes = 0
    for i in range(1, args.count + 1):
        payload = builder(i)
        if proto == "udp" and len(payload) > UDP_MAX_PAYLOAD:
            print(f"!! event {i}: {len(payload)} bytes exceeds the UDP maximum ({UDP_MAX_PAYLOAD}). "
                  f"Re-run with --proto tcp.", file=sys.stderr)
            fail += 1
            continue
        try:
            if proto == "udp":
                sock.sendto(payload, (args.target, args.port))
            else:
                if getattr(args, "framing", "newline") == "octet":
                    payload = f"{len(payload)} ".encode() + payload   # RFC 6587 octet counting
                elif not payload.endswith(b"\n"):
                    payload += b"\n"
                sock.sendall(payload)
            ok += 1
            total_bytes += len(payload)
            if args.verbose:
                print(f"[{i}] sent {len(payload)} bytes: {payload[:120]!r}...")
        except OSError as e:
            fail += 1
            print(f"!! event {i}: {e}", file=sys.stderr)
            if proto == "tcp" and getattr(e, "errno", None) == 104:
                print("   Connection reset on plain TCP usually means the port expects TLS. "
                      "Retry with --proto tls / --tls.", file=sys.stderr)
                break
        _pace(args.rate, started, i)
    # Close politely. With TLS 1.3 the server sends session tickets we never
    # read; closing with unread data makes the kernel send RST and the receiver
    # discards buffered records. unwrap() drains them and sends close_notify.
    try:
        if proto == "tls":
            sock.unwrap()
        elif proto == "tcp":
            sock.shutdown(socket.SHUT_WR)
    except OSError:
        pass
    sock.close()
    elapsed = time.monotonic() - started
    print(f"{proto.upper()} -> {args.target}:{args.port}  sent={ok} failed={fail} "
          f"bytes={total_bytes}  in {elapsed:.2f}s  ({ok / elapsed if elapsed else 0:.1f} evt/s)")
    return fail == 0


def send_http(args):
    ctx = None
    if args.url.lower().startswith("https"):
        ctx = ssl.create_default_context(cafile=args.cafile) if getattr(args, "cafile", None) else ssl.create_default_context()
        if args.insecure:
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
    # Source-IP binding for urllib: temporarily patch socket.create_connection
    _orig = socket.create_connection
    if args.bind:
        def _bound(address, timeout=None, source_address=None, **kw):
            return _orig(address, timeout, (args.bind, 0), **kw)
        socket.create_connection = _bound
    try:
        return _send_http_loop(args, ctx)
    finally:
        socket.create_connection = _orig


def _send_http_loop(args, ctx):
    started = time.monotonic()
    ok = fail = total_bytes = 0
    statuses = {}
    for i in range(1, args.count + 1):
        body = build_json_event(i, args.size, args.tenant_field)
        req = urllib.request.Request(args.url, data=body, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("User-Agent", "stellar-send/1.0")
        if args.tenant_header:
            req.add_header("Stellar-TenantID", args.tenant_header)
        try:
            with urllib.request.urlopen(req, timeout=args.timeout, context=ctx) as resp:
                code = resp.status
                resp.read()
        except urllib.error.HTTPError as e:
            code = e.code
        except (urllib.error.URLError, OSError) as e:
            code = f"ERR:{e.reason if hasattr(e, 'reason') else e}"
        statuses[code] = statuses.get(code, 0) + 1
        if isinstance(code, int) and 200 <= code < 300:
            ok += 1
            total_bytes += len(body)
        else:
            fail += 1
        if args.verbose:
            print(f"[{i}] {len(body)} bytes -> {code}")
        _pace(args.rate, started, i)
    elapsed = time.monotonic() - started
    print(f"HTTP POST {args.url}  ok={ok} failed={fail} bytes={total_bytes}  in {elapsed:.2f}s  "
          f"statuses={statuses}")
    if 413 in statuses:
        print("   413 = request body too large. On NGINX raise client_max_body_size.", file=sys.stderr)
    return fail == 0


def probe(args):
    """Report whether host:port speaks TLS, plain HTTP, plain TCP, or nothing."""
    host, port = args.host, args.port
    print(f"Probing {host}:{port} ...")
    # TCP reachability
    try:
        s = socket.create_connection((host, port), timeout=5)
        s.close()
        print("  tcp connect ........ OK")
    except OSError as e:
        print(f"  tcp connect ........ FAILED ({e})  -> check security group / IP / port")
        return False
    # TLS handshake
    tls_ok = False
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with socket.create_connection((host, port), timeout=5) as raw:
            with ctx.wrap_socket(raw, server_hostname=host) as tls:
                cert = tls.getpeercert(binary_form=True)
                print(f"  tls handshake ...... OK  ({tls.version()}, cert {len(cert)} bytes)")
                print(f"  certificate ........ SHA-256 {fingerprint(cert)}")
                tls_ok = True
    except (ssl.SSLError, OSError) as e:
        print(f"  tls handshake ...... no ({str(e)[:80]})")
    # With a CA file: does the sensor present a certificate that CA signed, valid for this address?
    verified = True
    if tls_ok and getattr(args, "cafile", None):
        try:
            with socket.create_connection((host, port), timeout=5) as raw:
                with tls_context(args.cafile).wrap_socket(raw, server_hostname=host) as tls:
                    subj = {k: v for pair in tls.getpeercert().get("subject", ()) for k, v in pair}
                    print(f"  verify with CA ..... OK  (CN={subj.get('commonName')}; signed by {args.cafile}, valid for {host})")
        except ssl.SSLCertVerificationError as e:
            verified = False
            print(f"  verify with CA ..... FAILED ({getattr(e, 'verify_message', None) or e})")
            print("     -> the sensor is not presenting a certificate signed by that CA: the self-signed default is still active,"
                  " the upload was not applied to the Log Forwarder, or this address is not among the certificate's names")
        except (ssl.SSLError, OSError) as e:
            verified = False
            print(f"  verify with CA ..... FAILED ({str(e)[:80]})")
    # HTTP over each
    for scheme in (("https", True), ("http", False)):
        name, use_tls = scheme
        if use_tls and not tls_ok:
            continue
        url = f"{name}://{host}:{port}{args.path}"
        ctx = None
        if use_tls:
            ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(url, data=b'{"probe":"stellar-send"}', method="POST")
        req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=5, context=ctx) as r:
                print(f"  POST {url} -> HTTP {r.status}")
        except urllib.error.HTTPError as e:
            print(f"  POST {url} -> HTTP {e.code} (server answered; check path/format)")
        except Exception as e:  # noqa: BLE001
            print(f"  POST {url} -> no HTTP answer ({str(e)[:70]})")
    print("Verdict:", "use https:// / transport tls" if tls_ok else "use http:// / transport tcp")
    return verified


# --------------------------------------------------------------------------- CLI
def parse_device_args(vendor, pairs):
    """--device FIELD=VALUE (repeatable) -> {field: value}, each field checked against the vendor's DEVICE_FIELDS."""
    identity = {}
    for pair in pairs or []:
        field, sep, value = pair.partition("=")
        if not sep or not field.strip():
            raise ValueError(f"--device expects FIELD=VALUE, got {pair!r}")
        f, _ = identity_for(vendor, field.strip(), None)       # raises with the valid fields
        identity[f] = value.strip()
    return identity


def print_fields(vendor=None):
    """The `fields` sub-command: what each simulated device writes about itself, and where."""
    print(f"{'vendor':<12} {'field':<9} {'default value':<26} where it appears in the log")
    for v, fields in DEVICE_FIELDS.items():
        if vendor and v != vendor:
            continue
        for i, (field, label, default) in enumerate(fields):
            print(f"{v if i == 0 else '':<12} {field:<9} {(default if default is not None else '(varies per event)'):<26} {label}{'  [recommended]' if i == 0 and len(fields) > 1 else ''}")
    print("\nSet one with --device FIELD=VALUE; a sensor-side tenant mapping (or a relay in --key-mode field) reads it.")
    return True


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    def common(p, default_port):
        p.add_argument("--count", type=int, default=1, help="number of events (default 1)")
        p.add_argument("--seq-from", type=int, default=1, help="number the markers from here (STELLAR-MT-TEST-N), so batches can be told apart on the platform")
        p.add_argument("--mix", choices=sorted(MIXES), default="realistic",
                       help="event mix: realistic (mostly allow traffic + some alerts), alerts, or traffic")
        p.add_argument("--kind", choices=["allow", "deny", "webfilter", "ips", "vpn", "admin"],
                       help="send only this event type (overrides --mix)")
        p.add_argument("--seed", type=int, help="random seed for a reproducible batch")
        p.add_argument("--size", type=int, default=0, help="pad each event to at least N bytes")
        p.add_argument("--rate", type=float, default=0, help="events per second (0 = as fast as possible)")
        p.add_argument("--bind", help="source IP to send from (must exist on this host)")
        p.add_argument("--devid", help="FortiGate appliance serial to write into every log (devid=), so a relay "
                                       "running --key-mode field maps the tenant from the log instead of the address")
        p.add_argument("--device", action="append", default=[], metavar="FIELD=VALUE",
                       help="how the device identifies itself in its logs, e.g. devid=FGTLAB0000000042 (FortiGate), "
                            "serial=001122334455 (PAN-OS), hostname=MX-TENANT-A (Meraki), sn=0017C5000001 (SonicWall); "
                            "repeatable; `fields` lists the choices and defaults")
        p.add_argument("--cafile", help="verify the TLS peer against this CA certificate (default: accept any, the sensor is self-signed)")
        p.add_argument("--tz", metavar="ZONE", help="the time zone the simulated device's clock is set to - set it to the "
                                                    "sensor's (e.g. America/Los_Angeles). Formats that cannot state an offset "
                                                    "(Palo Alto, Cisco ASA, Snare, Windows DNS, NXLog) are read by the sensor "
                                                    "in ITS zone; default: those in UTC")
        p.add_argument("--tag", help="stamp every record with STELLAR-PERF-<tag> as well as its marker, so one "
                                     "query counts exactly this batch in Stellar Cyber (4-16 lowercase letters/digits; "
                                     "what Ingest Studio's throughput test uses)")
        p.add_argument("-v", "--verbose", action="store_true")

    p = sub.add_parser("syslog", help="send firewall syslog to the syslog-ng relay")
    p.add_argument("--target", required=True, help="relay IP / hostname")
    p.add_argument("--port", type=int, default=514)
    p.add_argument("--proto", choices=["udp", "tcp", "tls"], default="udp")
    p.add_argument("--framing", choices=["newline", "octet"], default="newline",
                   help="TCP/TLS framing: newline (default) or RFC 6587 octet-counted (FortiGate reliable mode)")
    p.add_argument("--vendor", choices=sorted(SAMPLES), default="paloalto")
    p.add_argument("--format", choices=["syslog", "cef"], default="syslog", help="native syslog (default) or CEF (fortigate, paloalto, sonicwall only)")
    common(p, 514)

    p = sub.add_parser("http", help="POST JSON to the NGINX relay or the sensor")
    p.add_argument("--url", required=True, help="e.g. http://relay/httpjson or https://sensor:5200/httpjson")
    p.add_argument("--tenant-header", help="add Stellar-TenantID header (Method 2)")
    p.add_argument("--tenant-field", help="add tenantid field to the JSON body (Method 4)")
    p.add_argument("--insecure", action="store_true", help="accept self-signed TLS certs")
    p.add_argument("--timeout", type=float, default=30)
    common(p, 80)

    p = sub.add_parser("wrapped", help="send Stellar JSON wrapper records straight to the parser port")
    p.add_argument("--target", required=True)
    p.add_argument("--port", type=int, help="send to exactly this port, whatever --ports says")
    p.add_argument("--ports", choices=sorted(WRAPPER_PORT_MODES), default="parser",
                   help="which method to send with: parser (the source's own parser port, default), "
                        "capture (5564), or both - the SAME batch "
                        "to each port in turn, so the two can be compared on the sensor")
    p.add_argument("--tls", action="store_true", help="use TLS (default: plain TCP)")
    p.add_argument("--tenant", required=True, help="Stellar tenant ID to put in the wrapper")
    p.add_argument("--vendor", choices=sorted(WRAPPER_ORIGIN), default="paloalto")
    p.add_argument("--format", choices=["syslog", "cef"], default="syslog", help="msg_origin.format and the matching payload (cef: fortigate, paloalto, sonicwall)")
    p.add_argument("--srcip", default="10.1.1.1", help="value for msg_origin.srcip")
    p.add_argument("--origin", default="full", help="which msg_origin fields to send: full (default), none (no block), "
                                                     "or a comma list of vendor,product,format,srcip - an EXPERIMENT on what the sensor needs")
    common(p, 5564)

    p = sub.add_parser("direct", help="send firewall syslog AS-IS to the parser's port on the sensor: no relay, no tenant wrapper")
    p.add_argument("--target", required=True, help="sensor IP / hostname")
    p.add_argument("--port", type=int, help="parser port (default: the vendor's own, e.g. FortiGate 5517)")
    p.add_argument("--proto", choices=["udp", "tcp", "tls"], default="tls", help="default tls (the sensor profile's TLS toggle covers the parser ports)")
    p.add_argument("--framing", choices=["newline", "octet"], default="newline",
                   help="TCP/TLS framing: newline (default) or RFC 6587 octet-counted (FortiGate reliable mode)")
    p.add_argument("--vendor", choices=sorted(DIRECT_VENDORS), default="fortigate",
                   help="only the vendors with a dedicated parser port can be sent as-is")
    common(p, 5517)

    p = sub.add_parser("fields", help="list, per vendor, the fields a device identifies itself by and their default values")
    p.add_argument("--vendor", choices=sorted(DEVICE_FIELDS), help="one vendor only")

    p = sub.add_parser("probe", help="detect TLS vs plain on a host:port")
    p.add_argument("--host", required=True)
    p.add_argument("--port", type=int, required=True)
    p.add_argument("--path", default="/httpjson")
    p.add_argument("--cafile", help="also check the certificate verifies against this CA (proves an uploaded sensor certificate took effect)")

    args = ap.parse_args(argv)

    if args.cmd == "fields":
        return print_fields(args.vendor)
    if getattr(args, "tag", None) and not TAG_RE.match(args.tag):
        print(f"ERROR: --tag {args.tag} is not 4-16 lowercase letters or digits; it goes into every log and is "
              f"searched as one word in Stellar Cyber", file=sys.stderr)
        return False
    if getattr(args, "tz", None):
        try:
            set_device_tz(args.tz)
        except ValueError as e:
            print(f"ERROR: --tz {e}", file=sys.stderr)
            return False
    if args.cmd in ("syslog", "wrapped") and args.format not in FORMATS_FOR[args.vendor]:
        print(f"ERROR: {args.vendor} has no {args.format} generator; the sensor lists cef only for fortigate, paloalto and sonicwall", file=sys.stderr)
        return False
    identity = {}
    if args.cmd in ("syslog", "wrapped", "direct"):
        try:
            identity = parse_device_args(args.vendor, args.device)
        except ValueError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            return False
    if args.cmd == "syslog":
        return send_stream(args, lambda i: build_syslog(args.vendor, i, args.size, kind=args.kind, fmt=args.format, tag=args.tag,
                                                        devid=getattr(args, "devid", None), identity=identity))
    if args.cmd == "direct":
        try:
            natural = direct_port(args.vendor)
        except ValueError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            return False
        if args.port is None:
            args.port = natural
        elif args.port != natural:
            print(f"WARNING: {VENDOR_LABEL[args.vendor]} logs are parsed on port {natural}; on {args.port} the sensor runs a different parser.", file=sys.stderr)
        if args.devid:
            identity["devid"] = args.devid
        field, value = identity_for(args.vendor, next(iter(identity), None), None)
        shown = identity.get(field, value)
        print(f"NOTE: as-is, no tenant wrapper: these land in the sensor's own tenant unless a mapping on the sensor assigns one "
              f"from the device identity in the log ({field}={shown if shown is not None else 'varies per event'}).", file=sys.stderr)
        return send_stream(args, lambda i: build_syslog(args.vendor, i, args.size, kind=args.kind, identity=identity, tag=args.tag))
    if args.cmd == "http":
        return send_http(args)
    if args.cmd in ("wrapped", "http"):
        tid = args.tenant if args.cmd == "wrapped" else (args.tenant_header or args.tenant_field)
        if tid and not HEX32.match(tid):
            print(f"WARNING: tenant ID '{tid}' is not a 32-character lowercase hex ID; "
                  f"the sensor will ignore it and use its own tenant.", file=sys.stderr)
    if args.cmd == "wrapped":
        args.proto = "tls" if args.tls else "tcp"
        ports = [args.port] if args.port else wrapper_ports(args.vendor, args.format, args.ports)
        # Build the batch ONCE and replay the same bytes to each port: comparing two ports is only
        # meaningful if the records are identical, and a second pass over the scene would not be.
        first = getattr(args, "seq_from", 1) or 1
        payloads = [build_wrapped(args.vendor, args.tenant, i, args.size, args.srcip, kind=args.kind,
                                  fmt=args.format, identity=identity, origin=args.origin) for i in range(first, first + args.count)]
        if args.origin != "full":
            print(f"--> msg_origin: {args.origin} (an experiment: the documented record carries all four fields)", file=sys.stderr)
        ok = True
        for port in ports:
            args.port = port
            own = origin_for(args.vendor, args.format)[3]
            where = (f"{VENDOR_LABEL[args.vendor]}'s own parser port" if port == own
                     else "the capture port" if port == CAPTURE_PORT
                     else "a port this source is not parsed on")
            print(f"--> {len(payloads)} wrapped records to {args.target}:{port}, {where}", file=sys.stderr)
            ok = send_stream(args, lambda i: payloads[i - 1]) and ok
        if len(ports) > 1:
            print(f"Same {len(payloads)} records sent to each of {', '.join(map(str, ports))}. In Stellar Cyber, search the "
                  f"marker {MARKER} and compare which port's copies landed in tenant {args.tenant[:12]}...", file=sys.stderr)
        return ok
    if args.cmd == "probe":
        return probe(args)
    return False


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
