#!/usr/bin/env bash
# make-sensor-cert.sh - mint a lab certificate to upload to a Stellar Cyber Modular Sensor for TLS log ingestion.
#
# What the sensor does by default: with "Syslog TLS Enabled" on (System | Data Source Management | Sensors |
# edit the Modular Sensor), the parser ports and :5200 present a SELF-SIGNED certificate. Senders must then
# skip certificate validation (the kit's syslog-ng uses peer-verify(no), the Python tools use CERT_NONE, the
# Windows forwarder pins the thumbprint). Nothing has to be uploaded for TLS to work.
#
# What this script is for: testing the "own certificate" path. It creates
#   1. a lab certificate authority (CA), kept here, that senders can be told to TRUST, and
#   2. a server certificate for the sensor, signed by that CA, with the sensor's address(es) as
#      subjectAltName (IP and/or DNS), which is what a verifying client checks.
# Upload the server certificate + its private key in Stellar Cyber at
#   System | Saved Objects | Certificates  ->  add, type "Server Certificate" (certificate file + key file),
# then in the Sensors list select the Modular Sensor and use
#   Apply Certificate | Apply Certificate to Log Forwarder.
# Re-enabling the TLS toggle later reverts the sensor to its self-signed certificate; re-apply if so.
# Server Sensors cannot take a custom certificate (Modular Sensors only).
#
# Verify it took: stellar-send probe --host <sensor> --port 5517 --cafile <out>/stellar-lab-ca.crt
# prints the certificate the sensor presents and whether it verifies against this CA.
#
# A new certificate on the sensor also means the Windows forwarder's PIN no longer matches: re-pin it
# (stellar-forwarder configure --sensor <host> --trust pin, or Pin on the sensor card in the console).
#
# Lab grade: the CA key is unencrypted in the output directory. Do not use outside a lab.
#
# Usage:
#   make-sensor-cert.sh --san IP:192.168.1.100 --san IP:162.205.134.253 [--san DNS:sensor.example.com]
#                       [--cn "Stellar Cyber Modular Sensor"] [--days 825] [--out ./sensor-cert]
set -euo pipefail

CN="Stellar Cyber Modular Sensor (lab)"
DAYS=825
OUT="./sensor-cert"
SANS=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --san)  SANS+=("$2"); shift 2 ;;
    --cn)   CN="$2"; shift 2 ;;
    --days) DAYS="$2"; shift 2 ;;
    --out)  OUT="$2"; shift 2 ;;
    -h|--help) sed -n '2,30p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "unknown option: $1 (see --help)" >&2; exit 2 ;;
  esac
done
[[ ${#SANS[@]} -gt 0 ]] || { echo "give at least one --san IP:<address> or --san DNS:<name> (what senders connect to)" >&2; exit 2; }
for s in "${SANS[@]}"; do
  [[ "$s" =~ ^(IP|DNS):.+$ ]] || { echo "--san must be IP:<address> or DNS:<name>, got '$s'" >&2; exit 2; }
done
command -v openssl >/dev/null || { echo "openssl is required" >&2; exit 1; }

mkdir -p "$OUT"; chmod 700 "$OUT"
SAN_LIST=$(IFS=,; echo "${SANS[*]}")

# 1. the lab CA (created once; re-runs reuse it so every sensor certificate chains to the same trust anchor)
if [[ ! -f "$OUT/stellar-lab-ca.key" ]]; then
  openssl req -x509 -newkey rsa:3072 -nodes -sha256 -days $((DAYS + 365)) \
    -subj "/O=Stellar Cyber lab/CN=Stellar Cyber lab CA" \
    -addext "basicConstraints=critical,CA:TRUE,pathlen:0" -addext "keyUsage=critical,keyCertSign,cRLSign" \
    -keyout "$OUT/stellar-lab-ca.key" -out "$OUT/stellar-lab-ca.crt" 2>/dev/null
  chmod 600 "$OUT/stellar-lab-ca.key"
fi

# 2. the sensor's server certificate: key, request, signed by the CA with the SANs a client checks
openssl req -new -newkey rsa:2048 -nodes -sha256 -subj "/O=Stellar Cyber lab/CN=$CN" \
  -keyout "$OUT/sensor.key" -out "$OUT/sensor.csr" 2>/dev/null
chmod 600 "$OUT/sensor.key"
cat > "$OUT/sensor.ext" <<EXT
basicConstraints=CA:FALSE
keyUsage=critical,digitalSignature,keyEncipherment
extendedKeyUsage=serverAuth
subjectAltName=$SAN_LIST
EXT
openssl x509 -req -in "$OUT/sensor.csr" -CA "$OUT/stellar-lab-ca.crt" -CAkey "$OUT/stellar-lab-ca.key" -CAcreateserial \
  -days "$DAYS" -sha256 -extfile "$OUT/sensor.ext" -out "$OUT/sensor.crt" 2>/dev/null
cat "$OUT/sensor.crt" "$OUT/stellar-lab-ca.crt" > "$OUT/sensor-chain.crt"
rm -f "$OUT/sensor.csr" "$OUT/sensor.ext"
openssl verify -CAfile "$OUT/stellar-lab-ca.crt" "$OUT/sensor.crt" >/dev/null

FP=$(openssl x509 -in "$OUT/sensor.crt" -noout -fingerprint -sha256 | cut -d= -f2)
cat <<MSG

Sensor certificate ready in $OUT/
  sensor.crt            upload to Stellar Cyber as the Server Certificate  (System | Saved Objects | Certificates)
  sensor.key            upload alongside it as the private key            (same dialog; never leaves the lab otherwise)
  sensor-chain.crt      the same certificate followed by the CA, if the upload asks for a chain
  stellar-lab-ca.crt    what a SENDER trusts to verify the sensor (stellar-send --cafile, syslog-ng ca-file())
  stellar-lab-ca.key    the CA's private key: keep it here, upload it nowhere

  subject   CN=$CN
  SAN       $SAN_LIST
  valid     $DAYS days
  SHA-256   $FP

Then: Sensors list -> select the Modular Sensor -> Apply Certificate | Apply Certificate to Log Forwarder.
Check it took: stellar-send probe --host <sensor> --port 5517 --cafile $OUT/stellar-lab-ca.crt
(the fingerprint it prints must equal the SHA-256 above). Re-pin the Windows forwarder afterwards.
MSG
