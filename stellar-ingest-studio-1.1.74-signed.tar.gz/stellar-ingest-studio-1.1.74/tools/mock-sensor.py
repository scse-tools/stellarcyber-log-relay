#!/usr/bin/env python3
"""
mock-sensor.py  -  a fake Stellar Cyber Modular Sensor for relay testing.

Listens exactly where a real sensor would and shows you what arrives:

  * :5200  HTTPS (or HTTP with --plain)   the HTTP JSON parser endpoint.
           Prints the Stellar-TenantID header, path and body size for every
           POST and validates the body is JSON.
  * :5515 :5152 :5172 :5517  TLS (or TCP with --plain)   the per-parser ports
           (PAN, SonicWall, Meraki, FortiGate). A JSON line is a Method 3
           wrapper record: validated against the schema (stellar.tenantid,
           msg_origin.vendor/product, parser_raw_msg) and checked to have
           arrived on the port that matches its msg_origin. Anything else is
           what a device pointed straight at the parser port sends (or
           `stellar-send direct`): its own syslog, no wrapper, no tenant. Those
           are recorded as `raw` with the vendor they look like, the device
           identity they carry (devid, serial, device name, sn) and a warning
           when they landed on another vendor's parser port. Add --legacy-5564
           to also listen on the deprecated port.

Everything received is appended as JSON lines to --out-dir (default ./mock-sensor-out)
so tests can assert on it, and a per-tenant tally prints on Ctrl-C.

Standard library only. Needs `openssl` on PATH to mint a self-signed cert.

Usage:
  ./mock-sensor.py                 # TLS on both ports, like the real sensor
  ./mock-sensor.py --plain         # plain HTTP / TCP
  ./mock-sensor.py --json-ports 5515,5152,5172,5517 --legacy-5564 --out-dir /tmp/mock
"""
import argparse
import json
import os
import re
import signal
import socket
import socketserver
import ssl
import subprocess
import sys
import tempfile
import threading
import time
from collections import Counter
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

TALLY = Counter()
TALLY_LOCK = threading.Lock()
OUT_DIR = "./mock-sensor-out"
QUIET = False


def log(msg):
    if not QUIET:
        print(time.strftime("%H:%M:%S"), msg, flush=True)


def record(kind, doc):
    with open(os.path.join(OUT_DIR, f"{kind}.jsonl"), "a") as f:
        f.write(json.dumps(doc) + "\n")


def tally(kind, tenant):
    with TALLY_LOCK:
        TALLY[(kind, tenant)] += 1


# ------------------------------------------------------------------ :5200 HTTP JSON
class HttpJsonHandler(BaseHTTPRequestHandler):
    server_version = "MockStellarSensor/1.0"

    def log_message(self, *a):  # silence default access log
        pass

    def do_POST(self):
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length) if length else b""
        tenant_hdr = self.headers.get("Stellar-TenantID")
        try:
            parsed = json.loads(body.decode("utf-8", "replace")) if body else None
            json_ok = parsed is not None
        except json.JSONDecodeError:
            parsed, json_ok = None, False
        tenant_field = parsed.get("tenantid") if isinstance(parsed, dict) else None
        effective = tenant_hdr or tenant_field or "<none: would fall back to sensor tenant>"
        doc = {
            "ts": time.time(), "client": self.client_address[0], "path": self.path,
            "tenant_header": tenant_hdr, "tenant_field": tenant_field,
            "content_type": self.headers.get("Content-Type"), "bytes": length, "json_ok": json_ok,
            "marker": parsed.get("marker") if isinstance(parsed, dict) else None,
            "x_forwarded_for": self.headers.get("X-Forwarded-For"),
        }
        record("http", doc)
        tally("http", effective)
        log(f"HTTP  {self.client_address[0]:>15} POST {self.path:<24} tenant={effective:<12} "
            f"bytes={length:<8} json={'ok' if json_ok else 'INVALID'} xff={doc['x_forwarded_for']}")
        if not json_ok:
            self.send_response(400); self.end_headers(); self.wfile.write(b"invalid json\n"); return
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(b'{"status":"ok"}\n')

    def do_GET(self):
        self.send_response(200); self.end_headers()
        self.wfile.write(b"mock stellar sensor: POST JSON to /httpjson\n")


# ------------------------------------------------------------------ :5564 JSON wrapper
REQUIRED_ORIGIN = ("vendor", "product")
# vendor/product -> the port that parser is ingested on, from Stellar Cyber's parser table.
PARSER_PORTS = {
    ("palo_alto_networks", "firewall"): 5515,
    ("sonicwall", "firewall"): 5152,
    ("cisco", "meraki"): 5172,
    ("fortinet", "fortigate"): 5517,
    ("checkpoint", "firewall"): 5519,
    ("sophos", "firewall"): 5520,
    ("snare", "snare_agent"): 5590,
    ("windows", "dns_server"): 5599,
    ("nxlog", "nxlog"): 5601,
    ("cisco", "custom_vpn"): 5176,
    ("cisco", "asa"): 5518,          # not in the wrapper-capable list; the experiment source
}
CEF_PORT = 5143          # every CEF parser shares one port, whatever the vendor
# The sensor's stellar_capture listener. A wrapped record here is routed by KEYWORD from its
# msg_origin instead of by the port it arrived on. That is the second of the two delivery methods,
# not an error: records are tallied by method so the two can be compared.
CAPTURE_PORT = 5564
HEX32 = re.compile(r"^[0-9a-f]{32}$")


def validate_wrapper(rec, port=None):
    """Return list of problems with a Method 3 record (empty list = valid).
    If `port` is given, also check it is the right parser port for msg_origin."""
    problems = []
    if not isinstance(rec, dict):
        return ["record is not a JSON object"]
    st = rec.get("stellar")
    if not isinstance(st, dict):
        problems.append('missing "stellar" object')
    else:
        tid = st.get("tenantid")
        if not tid:
            problems.append('missing stellar.tenantid (sensor would use its own tenant)')
        elif not HEX32.match(str(tid)):
            problems.append(f'tenantid "{tid}" is not a 32-char hex ID (sensor ignores it)')
        mo = st.get("msg_origin")
        if not isinstance(mo, dict):
            problems.append('missing stellar.msg_origin')
        else:
            # The doc names vendor/product/format for the four wrapper ports. Every other parser has
            # its own dedicated port and its own msg_origin.source in Stellar Cyber's published
            # parser table, which is what a forwarder sends there: one name instead of three. That is
            # a different shape, not a broken record, so only demand vendor/product when there is no
            # source. Whether the sensor honours the tenant ID on those ports is the open question.
            if mo.get("source") and not mo.get("vendor"):
                pass
            else:
                for k in REQUIRED_ORIGIN:
                    if not mo.get(k):
                        problems.append(f"missing stellar.msg_origin.{k}")
            fmt = mo.get("format") or "syslog"
            expected = CEF_PORT if fmt == "cef" else PARSER_PORTS.get((mo.get("vendor"), mo.get("product")))
            # Port 5564 is the capture method, which is meant to take any msg_origin: not an error.
            if port is not None and port != CAPTURE_PORT and expected is not None and port != expected:
                problems.append(f"arrived on port {port} but {mo.get('vendor')}/{mo.get('product')}/{fmt} is parsed on {expected}")
    raw = rec.get("parser_raw_msg")
    if not raw:
        problems.append('missing parser_raw_msg (sensor discards the record)')
    elif not isinstance(raw, str):
        problems.append("parser_raw_msg is not a string")
    elif raw.count("\n") > 0:
        problems.append("parser_raw_msg contains a newline: several logs concatenated?")
    return problems


# What a device pointed straight at a parser port sends: its own syslog, no wrapper. The kit's four
# firewall formats are recognizable by shape, so a raw log that lands on another vendor's parser
# port can be called out. (vendor key as the kit names it, that vendor's parser port, tell-tale)
RAW_SIGNATURES = [
    ("fortigate", 5517, re.compile(r'\bdevname="[^"]*" (devid="[^"]*" )?eventtime=\d+')),
    ("paloalto", 5515, re.compile(r'^<\d+>\w{3} +\d+ \d\d:\d\d:\d\d \S+ 1,[\d/]+ [\d:]+,[^,]*,(TRAFFIC|THREAT|SYSTEM|CONFIG|HIPMATCH|USERID|GLOBALPROTECT|DECRYPTION),')),
    ("meraki", 5172, re.compile(r'^<\d+>1 \d+\.\d+ \S+ (flows|urls|ids-alerts|events|security_event|air_marshal_events)\b')),
    ("sonicwall", 5152, re.compile(r'^<\d+>\s*id=firewall sn=\S+')),
    ("checkpoint", 5519, re.compile(r'^<\d+>1 \S+ \S+ CheckPoint \S+ - \[action:"')),
    ("sophos", 5520, re.compile(r'^<\d+>device="SFW" date=\S+ time=\S+')),
    ("cisco_asa", 5518, re.compile(r'^<\d+>\w{3} \d\d \d{4} [\d:]+ \S+ : %ASA-\d-\d+:')),
]
# how to read the device identity out of a raw log, per vendor (the fields stellar-send `fields` lists)
RAW_IDENTITY = {
    "fortigate": [("devid", re.compile(r'\bdevid="?([^" ]+)"?')), ("devname", re.compile(r'\bdevname="?([^" ]+)"?'))],
    "paloalto": [("serial", re.compile(r'^<\d+>\w{3} +\d+ [\d:]+ \S+ 1,[^,]*,([^,]*),')), ("hostname", re.compile(r'^<\d+>\w{3} +\d+ [\d:]+ (\S+) 1,'))],
    "meraki": [("hostname", re.compile(r'^<\d+>1 \S+ (\S+) '))],
    "sonicwall": [("sn", re.compile(r'\bsn=(\S+)'))],
    "checkpoint": [("hostname", re.compile(r'^<\d+>1 \S+ (\S+) CheckPoint')), ("origin", re.compile(r'origin:"([^"]+)"'))],
    "sophos": [("device_id", re.compile(r'\bdevice_id=(\S+)')), ("device_name", re.compile(r'\bdevice_name="([^"]+)"'))],
    "cisco_asa": [("hostname", re.compile(r'^<\d+>\w{3} \d\d \d{4} [\d:]+ (\S+) : %ASA-'))],
}
MARKER_RE = re.compile(r"STELLAR-MT-TEST-\d+")


def validate_raw(raw, port=None):
    """A raw (unwrapped) log on a parser port: which vendor it looks like, the device identity it carries,
    the test marker, and any problems (a log on another vendor's parser port; no syslog priority header).
    The real sensor parses such a log under its own tenant unless a sensor-side mapping reads the identity."""
    looks, expected = None, None
    for v, p, rx in RAW_SIGNATURES:
        if rx.search(raw):
            looks, expected = v, p
            break
    problems = []
    if not raw.startswith("<"):
        problems.append("no syslog <PRI> header")
    if looks and port is not None and port != expected and port in PARSER_PORTS.values():
        problems.append(f"looks like a {looks} log but arrived on :{port}; the {looks} parser is on :{expected}")
    identity = {}
    for field, rx in RAW_IDENTITY.get(looks, []):
        m = rx.search(raw)
        if m:
            identity[field] = m.group(1)
    m = MARKER_RE.search(raw)
    return {"looks_like": looks, "expected_port": expected, "identity": identity, "marker": m.group(0) if m else None, "problems": problems}


class WrapperHandler(socketserver.StreamRequestHandler):
    rbufsize = 1 << 20

    def handle(self):
        peer = self.client_address[0]
        port = self.server.server_address[1]
        log(f"JSON  {peer:>15} connected on :{port}")
        try:
            self._read_records(peer, port)
        except (OSError, ssl.SSLError) as e:
            log(f"JSON  {peer:>15} :{port} connection dropped by client ({e.__class__.__name__})")
        log(f"JSON  {peer:>15} disconnected from :{port}")

    def _raw(self, peer, port, text, nbytes):
        """A device's own syslog, unwrapped: what arrives when a firewall (or `stellar-send direct`) is pointed
        straight at the parser port. No tenant travels with it; this mock records what it can see."""
        info = validate_raw(text, port)
        doc = {"ts": time.time(), "client": peer, "port": port, "bytes": nbytes, "head": text[:80], **info}
        record("raw", doc)
        tally(f"raw:{port}", "<sensor's own tenant>")
        ident = " ".join(f"{k}={v}" for k, v in info["identity"].items()) or "identity=?"
        status = "OK" if not info["problems"] else "BAD: " + "; ".join(info["problems"])
        log(f"RAW   {peer:>15} :{port} as-is looks_like={info['looks_like'] or '?'} {ident} bytes={nbytes:<8} marker={info['marker']} {status}")

    def _read_records(self, peer, port):
        for line in self.rfile:
            line = line.rstrip(b"\r\n")
            if not line:
                continue
            text = line.decode("utf-8", "replace")
            if not text.lstrip().startswith("{"):
                self._raw(peer, port, text, len(line))
                continue
            try:
                rec = json.loads(text)
                problems = validate_wrapper(rec, port)
            except json.JSONDecodeError as e:
                rec, problems = None, [f"not JSON: {e}"]
            st = (rec or {}).get("stellar", {}) if isinstance(rec, dict) else {}
            mo = st.get("msg_origin", {}) if isinstance(st, dict) else {}
            tenant = st.get("tenantid") if isinstance(st, dict) else None
            raw = (rec or {}).get("parser_raw_msg", "") if isinstance(rec, dict) else ""
            # which of the two delivery methods this record used, so a test run can compare them
            method = "capture" if port == CAPTURE_PORT else "parser"
            doc = {
                "ts": time.time(), "client": peer, "port": port, "method": method, "bytes": len(line), "tenant": tenant,
                "vendor": mo.get("vendor"), "product": mo.get("product"), "format": mo.get("format"), "source": mo.get("source"),
                "srcip": mo.get("srcip"), "raw_len": len(raw or ""), "raw_head": (raw or "")[:80],
                "problems": problems,
            }
            record("wrapper", doc)
            tally(f"wrapper:{port}({method})", tenant or "<none>")
            status = "OK" if not problems else "BAD: " + "; ".join(problems)
            origin = (f"{mo.get('vendor')}/{mo.get('product')}/{mo.get('format')}"
                      if mo.get("vendor") else f"source={mo.get('source')}")
            log(f"JSON  {peer:>15} :{port} tenant={str(tenant)[:12]:<12} {origin} "
                f"srcip={mo.get('srcip')} bytes={len(line):<8} raw={len(raw or '')} {status}")


HANDSHAKE_TIMEOUT = 15  # seconds a client may take to complete TLS before we drop it


class TLSInThreadMixin:
    """Do the TLS handshake inside the per-connection thread, with a timeout.

    socketserver's default (wrapping the *listening* socket) performs the
    handshake in accept(), on the one thread that accepts everything. A client
    that connects and never sends ClientHello (a probe, a half-open syslog-ng
    connection, a port scanner) then blocks every other client on that port.
    """
    ssl_context = None

    def finish_request(self, request, client_address):
        if self.ssl_context is not None:
            try:
                request.settimeout(HANDSHAKE_TIMEOUT)
                request = self.ssl_context.wrap_socket(request, server_side=True)
                request.settimeout(None)
            except (ssl.SSLError, OSError) as e:
                port = self.server_address[1]
                msg = str(e)
                if "timed out" in msg:
                    # syslog-ng opens a TCP connection to every parser port at start-up but only
                    # runs the TLS handshake when it has a record to send; idle ones look like this.
                    log(f"TLS   {client_address[0]:>15} :{port} idle connection dropped after {HANDSHAKE_TIMEOUT}s "
                        f"with no TLS handshake (normal for syslog-ng ports with no traffic yet)")
                else:
                    log(f"TLS   {client_address[0]:>15} :{port} handshake failed: {msg[:90]}"
                        f"{'  (client sent plain TCP/HTTP to a TLS port?)' if 'HTTP_REQUEST' in msg or 'WRONG_VERSION' in msg else ''}")
                try:
                    request.close()
                except OSError:
                    pass
                return
        super().finish_request(request, client_address)


class ThreadedTCP(TLSInThreadMixin, socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


class ThreadedHTTP(TLSInThreadMixin, ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


# ------------------------------------------------------------------ TLS helpers
def make_cert(cert_dir):
    """A real sensor keeps its certificate across restarts; so does this one when --cert-dir is given.
    A forwarder that PINS the certificate would otherwise refuse a restarted sensor - correctly."""
    crt, key = os.path.join(cert_dir, "mock.crt"), os.path.join(cert_dir, "mock.key")
    if not (os.path.exists(crt) and os.path.exists(key)):
        subprocess.run(["openssl", "req", "-x509", "-nodes", "-newkey", "rsa:2048", "-days", "30",
                        "-subj", "/CN=mock-stellar-sensor", "-keyout", key, "-out", crt],
                       check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(crt, key)
    return ctx


def main():
    global OUT_DIR, QUIET
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--http-port", type=int, default=5200)
    ap.add_argument("--json-ports", default="5515,5152,5172,5517,5519,5520,5143",
                    help="comma-separated parser ports for wrapped or raw records "
                         "(default: PAN, SonicWall, Meraki, FortiGate, Check Point, Sophos, CEF)")
    ap.add_argument("--legacy-5564", "--capture-port", dest="legacy_5564", action="store_true",
                    help="also listen on the capture port 5564, the second delivery method")
    ap.add_argument("--bind", default="0.0.0.0")
    ap.add_argument("--plain", action="store_true", help="plain HTTP/TCP instead of TLS")
    ap.add_argument("--out-dir", default=OUT_DIR)
    ap.add_argument("--quiet", action="store_true")
    ap.add_argument("--cert-dir", default=None, help="keep the TLS certificate here so a restart presents the same one (default: a fresh one each start)")
    args = ap.parse_args()
    OUT_DIR, QUIET = args.out_dir, args.quiet
    # An IPv6 bind address (::1) needs IPv6 sockets; both server classes default to IPv4. Two mock sensors on
    # one machine share the same parser ports by binding IPv4 loopback and IPv6 loopback, so without this a
    # "second sensor" never listens and every failover scene silently becomes "no sensor reachable".
    fam = socket.AF_INET6 if ":" in args.bind else socket.AF_INET
    ThreadedHTTP.address_family = fam
    ThreadedTCP.address_family = fam
    os.makedirs(OUT_DIR, exist_ok=True)

    ctx = None
    if not args.plain:
        cert_dir = args.cert_dir or tempfile.mkdtemp(prefix="mock-sensor-")
        os.makedirs(cert_dir, exist_ok=True)
        ctx = make_cert(cert_dir)

    httpd = ThreadedHTTP((args.bind, args.http_port), HttpJsonHandler)
    httpd.ssl_context = ctx
    ports = [int(p) for p in args.json_ports.split(",") if p.strip()]
    if args.legacy_5564 and CAPTURE_PORT not in ports:
        ports.append(CAPTURE_PORT)
    wrapds = []
    for port in ports:
        w = ThreadedTCP((args.bind, port), WrapperHandler)
        w.ssl_context = ctx
        wrapds.append(w)

    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    for w in wrapds:
        threading.Thread(target=w.serve_forever, daemon=True).start()
    scheme = "plain" if args.plain else "TLS"
    print(f"mock sensor up: {scheme} HTTP JSON on {args.bind}:{args.http_port}, "
          f"{scheme} wrapper ports {','.join(map(str, ports))}; recording to {OUT_DIR}/", flush=True)

    def stop(*_):
        print("\n--- tally (kind, tenant) -> count")
        for (kind, tenant), n in sorted(TALLY.items()):
            print(f"  {kind:<8} {tenant:<40} {n}")
        httpd.shutdown()
        for w in wrapds:
            w.shutdown()
        sys.exit(0)

    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)
    while True:
        time.sleep(3600)


if __name__ == "__main__":
    main()
