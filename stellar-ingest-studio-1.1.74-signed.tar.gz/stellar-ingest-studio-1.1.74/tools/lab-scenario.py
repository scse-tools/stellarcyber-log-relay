#!/usr/bin/env python3
"""
lab-scenario.py  -  build, apply and check a named test scenario for the relay.

Each scenario is one way of answering "which tenant does this log belong to, and which sensor
should it go to". They are the things we have to be able to demonstrate, so each one here is a
single command rather than a page of setup.

  lab-scenario.py list                          the scenarios and what each proves
  lab-scenario.py show   <name>                 what it configures and what to expect
  lab-scenario.py estate <name> [--profile ...] generate a SYNTHETIC tenant map for it
  lab-scenario.py render <name>                 render + lint the relay config offline (no root)
  lab-scenario.py apply  <name>                 write the map and settings on this relay (root)
  lab-scenario.py send   <name>                 drive traffic that matches the scenario
  lab-scenario.py verify <name>                 read the relay's forwarded log, report what landed

All estate data is generated, never copied from a customer. Serial numbers use an FGTLAB prefix
and tenant IDs are derived from a seed, so nothing here can be mistaken for production data and
two people running the same command get the same estate.

Typical use on the relay host:

    lab-scenario.py estate field-single --profile customer --out /tmp/map.csv
    sudo lab-scenario.py apply field-single --estate /tmp/map.csv
    lab-scenario.py send   field-single --target <relay ip> --count 200
    lab-scenario.py verify field-single
"""
import argparse
import collections
import hashlib
import importlib.util
import json
import os
import random
import re
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RELAY_ENV = os.environ.get("RELAY_ENV", "/etc/stellar-relay/syslog-ng.env")
CSV_SRC = os.environ.get("SYSLOG_CSV_SRC", "/etc/syslog-ng/stellar-tenants.csv.src")
FWD_LOG = os.environ.get("FORWARDED_LOG", "/var/log/stellar-relay/forwarded.jsonl")
RENDER = os.environ.get("RENDER_CONFIG", os.path.join(ROOT, "syslog-ng", "render-config.py"))
if not os.path.exists(RENDER):
    RENDER = "/usr/local/lib/stellar-relay/render-config.py"

# ---------------------------------------------------------------- scenarios
# key_mode / sensor_mode are what the relay is set to. `shape` drives the generated estate.
SCENARIOS = {
    "ip-single": {
        "title": "Tenant by source IP, one sensor",
        "proves": "The documented default (Approach 3, log processor keyed on the address).",
        "key_mode": "srcip", "sensor_mode": "single", "shape": "per-ip",
        "expect": "Every tenant's logs arrive from that tenant's own source address.",
    },
    "field-single": {
        "title": "Tenant by a field in the log, one sensor",
        "proves": "One source address can carry many tenants, because the tenant travels in the log. "
                  "This is the shape a customer migrating off a customised parser ends up with.",
        "key_mode": "field", "sensor_mode": "single", "shape": "per-device",
        "expect": "All logs share one source address and still split into the right tenants.",
    },
    "field-fallback": {
        "title": "Tenant by field, with devices that do not carry it",
        "proves": "A log with no key field is not lost: it falls back to a source-IP row, then to the "
                  "catch-all tenant. This is the failure mode a customised parser has and we do not.",
        "key_mode": "field", "sensor_mode": "single", "shape": "per-device-mixed",
        "expect": "Mapped devices land in their tenant; unmapped ones land in the catch-all, visibly.",
    },
    "two-failover": {
        "title": "Two sensors, failover",
        "proves": "All traffic goes to sensor 1; sensor 2 takes over only while sensor 1 is down. "
                  "No tenant is ever split across sensors.",
        "key_mode": "srcip", "sensor_mode": "failover", "shape": "per-ip",
        "expect": "Connections to sensor 1 only. Stop sensor 1 and they move to sensor 2, then back.",
    },
    "two-split": {
        "title": "Two sensors, each source pinned to one",
        "proves": "Reproduces a manual firewall-to-sensor split in one place, and adds failover to it.",
        "key_mode": "srcip", "sensor_mode": "split", "shape": "per-ip-split",
        "expect": "Roughly half the sources on each sensor, each device always on the same one.",
    },
    "field-split": {
        "title": "Two sensors, pinned, tenant by field",
        "proves": "The combination a large MSSP estate actually needs: tenancy from the log, load "
                  "spread across sensors, one device always on one sensor.",
        "key_mode": "field", "sensor_mode": "split", "shape": "per-device-split",
        "expect": "One source address, many tenants, split across two sensors by device.",
    },
}
PROFILES = {
    "small":    {"devices": 6,   "tenants": 3,   "desc": "quick smoke test"},
    "medium":   {"devices": 40,  "tenants": 40,  "desc": "one firewall per tenant"},
    "customer": {"devices": 136, "tenants": 132, "desc": "MSSP scale: a few tenants with two firewalls"},
}
VENDOR = ("fortinet", "fortigate", "syslog", "5517")


def fail(msg):
    print(f"ERROR: {msg}", file=sys.stderr); sys.exit(1)


def scenario(name):
    if name not in SCENARIOS:
        fail(f"unknown scenario {name!r}. Try: {', '.join(SCENARIOS)}")
    return SCENARIOS[name]


# ---------------------------------------------------------------- synthetic estate
def synth_tenant(seed, i):
    """A valid 32-hex tenant ID, derived so the same seed always gives the same estate."""
    return hashlib.sha256(f"stellar-lab-tenant:{seed}:{i}".encode()).hexdigest()[:32]


def synth_device(i):
    """Visibly synthetic, but the right shape and length for a FortiGate serial."""
    return f"FGTLAB{i:010d}"


def build_estate(name, profile, seed, base_ip, default_tenant=None):
    """Return (rows, devices) where rows are CSV lines and devices describe what to send."""
    sc = scenario(name)
    prof = PROFILES[profile]
    n_dev, n_ten = prof["devices"], prof["tenants"]
    rng = random.Random(seed)
    vendor, product, fmt, port = VENDOR
    default_tenant = default_tenant or synth_tenant(seed, "catchall")

    tenants = [synth_tenant(seed, i) for i in range(n_ten)]
    devices = []
    for i in range(n_dev):
        # the first n_ten devices get their own tenant; any extras double up, as a real estate does
        t = tenants[i] if i < n_ten else tenants[rng.randrange(n_ten)]
        devices.append({"devid": synth_device(i + 1), "tenant": t, "n": i})

    shape = sc["shape"]
    octet3, octet4 = 100, 10
    rows = [f"# Generated by lab-scenario.py: scenario={name} profile={profile} seed={seed}",
            "# SYNTHETIC DATA. Serial numbers use an FGTLAB prefix and tenant IDs are derived from the",
            "# seed, so nothing in this file is a real device or a real tenant.",
            f"# selector = {'device id' if sc['key_mode'] == 'field' else 'source IP'}",
            "#",
            f"default,tenantid,{default_tenant}", f"default,vendor,{vendor}",
            f"default,product,{product}", f"default,format,{fmt}", f"default,port,{port}"]

    for d in devices:
        # every device gets an address; in per-device shapes they all share one
        if shape.startswith("per-ip"):
            b = base_ip.split(".")
            d["src"] = f"{b[0]}.{b[1]}.{octet3 + (d['n'] // 250)}.{octet4 + (d['n'] % 250)}"
            selector = d["src"]
        else:
            d["src"] = base_ip
            selector = d["devid"]
        d["selector"] = selector
        # field-fallback: every fifth device sends no devid at all
        d["send_devid"] = not (shape == "per-device-mixed" and d["n"] % 5 == 4)
        d["mapped"] = True
        if shape == "per-device-mixed" and not d["send_devid"]:
            d["mapped"] = False          # deliberately left out of the map: must hit the catch-all
            continue
        rows += [f"{selector},tenantid,{d['tenant']}", f"{selector},vendor,{vendor}",
                 f"{selector},product,{product}", f"{selector},format,{fmt}", f"{selector},port,{port}"]
        if shape.endswith("split"):
            d["sensor"] = "1" if d["n"] % 2 == 0 else "2"
            rows.append(f"{selector},sensor,{d['sensor']}")
    return rows, devices, default_tenant


def estate_paths(name):
    d = os.environ.get("LAB_SCENARIO_DIR") or os.path.expanduser("~/.stellar-lab-scenarios")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, f"{name}.csv"), os.path.join(d, f"{name}.json")


# ---------------------------------------------------------------- commands
def cmd_list(a):
    print("Scenarios:\n")
    for k, v in SCENARIOS.items():
        print(f"  {k:16s} {v['title']}")
        print(f"  {'':16s} key={v['key_mode']:6s} sensors={v['sensor_mode']}")
        print(f"  {'':16s} {v['proves']}\n")
    print("Estate profiles:\n")
    for k, v in PROFILES.items():
        print(f"  {k:10s} {v['devices']:>4} devices, {v['tenants']:>4} tenants   {v['desc']}")


def cmd_show(a):
    sc = scenario(a.name)
    print(f"{a.name}: {sc['title']}\n")
    print(f"  proves      {sc['proves']}")
    print(f"  key mode    {sc['key_mode']}" + (f" (field: devid)" if sc["key_mode"] == "field" else ""))
    print(f"  sensors     {sc['sensor_mode']}")
    print(f"  expect      {sc['expect']}\n")
    print("  run it:")
    print(f"    lab-scenario.py estate {a.name} --profile {a.profile}")
    print(f"    sudo lab-scenario.py apply {a.name}")
    print(f"    lab-scenario.py send {a.name} --target <relay ip> --count 200")
    print(f"    lab-scenario.py verify {a.name}")


def cmd_estate(a):
    rows, devices, default_tenant = build_estate(a.name, a.profile, a.seed, a.base_ip, a.default_tenant)
    csv_path, meta_path = estate_paths(a.name)
    if a.out:
        csv_path = a.out
    with open(csv_path, "w") as f:
        f.write("\n".join(rows) + "\n")
    with open(meta_path, "w") as f:
        json.dump({"scenario": a.name, "profile": a.profile, "seed": a.seed, "csv": csv_path,
                   "default_tenant": default_tenant, "devices": devices}, f, indent=1)
    sc = scenario(a.name)
    mapped = [d for d in devices if d["mapped"]]
    srcs = sorted({d["src"] for d in devices})
    print(f"wrote {csv_path}")
    print(f"  {len(devices)} devices, {len(set(d['tenant'] for d in mapped))} tenants, "
          f"{len(devices) - len(mapped)} deliberately unmapped")
    print(f"  source addresses: {len(srcs)}" + (f" ({srcs[0]})" if len(srcs) == 1 else f" ({srcs[0]} … {srcs[-1]})"))
    if sc["sensor_mode"] == "split":
        c = collections.Counter(d.get("sensor") for d in mapped)
        print(f"  pinned: sensor 1 = {c.get('1', 0)}, sensor 2 = {c.get('2', 0)}")
    print(f"  catch-all tenant: {default_tenant}")
    print(f"  state: {meta_path}")
    if len(srcs) > 1:
        print("\n  NOTE: this scenario uses one source address per device. Each must exist on the sending\n"
              "        host AND on its ENI in AWS. Use --profile small unless you have added them.")


def render_args(name, csv_path, sensor_ip, sensor_ip_2, db_path=None):
    sc = scenario(name)
    args = [sys.executable, RENDER, "--csv", csv_path, "--sensor-ip", sensor_ip, "--debug-log"]
    if db_path:
        args += ["--db-path", db_path]
    if sc["key_mode"] == "field":
        args += ["--key-mode", "field", "--key-field", "devid"]
    if sc["sensor_mode"] != "single":
        if not sensor_ip_2:
            fail(f"scenario {name} needs a second sensor: pass --sensor-ip-2")
        args += ["--sensor-ip-2", sensor_ip_2, "--sensor-mode", sc["sensor_mode"]]
        # syslog-ng's failover() clause is off by default since 24 Sep 2026 (it crashes 4.8.1 on reload while a
        # sensor is unreachable); the failover scenario exists to exercise exactly that clause, so it asks for it
        if sc["sensor_mode"] == "failover":
            args.append("--failover-clause")
    return args


def cmd_render(a):
    csv_path = a.estate or estate_paths(a.name)[0]
    if not os.path.exists(csv_path):
        fail(f"no estate for {a.name}. Run: lab-scenario.py estate {a.name}")
    clean = csv_path + ".clean"
    with open(csv_path) as f, open(clean, "w") as g:
        g.writelines(l for l in f if l.strip() and not l.lstrip().startswith("#"))
    try:
        args = render_args(a.name, clean, a.sensor_ip, a.sensor_ip_2)
        p = subprocess.run(args + ["--check"], capture_output=True, text=True)
        sys.stderr.write(p.stderr)
        if p.returncode:
            fail("the map did not lint cleanly (see above)")
        conf = subprocess.run(args, capture_output=True, text=True)
        if conf.returncode:
            sys.stderr.write(conf.stderr); fail("render failed")
        text = conf.stdout
        sc = scenario(a.name)
        keyed, two = sc["key_mode"] == "field", sc["sensor_mode"] != "single"
        def want(label_yes, label_no, present, expected):
            return ((label_yes if expected else label_no), present == expected)
        checks = [("braces balanced", text.count("{") == text.count("}")),
                  want("single log path with a junction (parses each log once)",
                       "one log path per destination (no parsing needed)",
                       text.count("\nlog {") == 1 and "junction {" in text, keyed),
                  want("tenant selected by the devid field", "tenant selected by source IP",
                       'selector("${.kv.devid}")' in text, keyed),
                  want("falls back to a source-IP row", "no fallback needed (source IP is the key)",
                       "p_stellar_by_srcip" in text, keyed),
                  # a second sensor. syslog-ng's failover() clause only in the failover scenario: on 4.8.1 it crashes the
                  # process on every reload while a sensor is unreachable (24 Sep 2026), so split must NOT carry it
                  want("failover() to the second sensor", "no failover() clause (a down sensor's records wait in its disk buffer)",
                       "failover(servers(" in text, sc["sensor_mode"] == "failover"),
                  want("per-sensor filters (sources pinned)", "no per-sensor filters",
                       "f_stellar_sensor_2" in text, sc["sensor_mode"] == "split")]
        if a.out:
            with open(a.out, "w") as f:
                f.write(text)
            print(f"wrote {a.out} ({len(text.splitlines())} lines)")
        for label, ok in checks:
            print(f"  [{'ok' if ok else 'FAIL'}] {label}")
        if not all(ok for _, ok in checks):
            sys.exit(1)
        print(f"\n{len(text.splitlines())} lines, {text.count('destination d_stellar')} destinations. "
              f"Validate against the real syslog-ng with: sudo syslog-ng -s")
    finally:
        os.remove(clean)


def cmd_apply(a):
    if os.geteuid() != 0:
        fail("apply changes the live relay: run it with sudo")
    csv_path = a.estate or estate_paths(a.name)[0]
    if not os.path.exists(csv_path):
        fail(f"no estate for {a.name}. Run: lab-scenario.py estate {a.name}")
    sc = scenario(a.name)
    # keep whatever is there now, so a scenario is always reversible
    if os.path.exists(CSV_SRC):
        shutil.copy2(CSV_SRC, CSV_SRC + ".before-scenario")
    if os.path.exists(RELAY_ENV):
        shutil.copy2(RELAY_ENV, RELAY_ENV + ".before-scenario")
        print(f"previous map and settings saved as *.before-scenario")
    shutil.copy2(csv_path, CSV_SRC)
    env = {}
    if os.path.exists(RELAY_ENV):
        for line in open(RELAY_ENV):
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.strip().split("=", 1); env[k] = v
    env["KEY_MODE"] = sc["key_mode"]
    env["KEY_FIELD"] = "devid"
    env["SENSOR_MODE"] = "" if sc["sensor_mode"] == "single" else sc["sensor_mode"]
    if a.sensor_ip:
        env["SENSOR_IP"] = a.sensor_ip
    if sc["sensor_mode"] != "single":
        if not (a.sensor_ip_2 or env.get("SENSOR_IP_2")):
            fail(f"scenario {a.name} needs a second sensor: pass --sensor-ip-2")
        if a.sensor_ip_2:
            env["SENSOR_IP_2"] = a.sensor_ip_2
    else:
        env["SENSOR_IP_2"] = ""
    env.setdefault("DEBUG_LOG", "yes")
    with open(RELAY_ENV, "w") as f:
        f.write("# Settings used by 'stellar-syslog-relay apply-tenants' to regenerate the config.\n")
        for k, v in env.items():
            f.write(f"{k}={v}\n")
    print(f"map -> {CSV_SRC}\nsettings -> {RELAY_ENV} (key_mode={sc['key_mode']}, sensors={sc['sensor_mode']})")
    helper = shutil.which("stellar-syslog-relay") or "/usr/local/sbin/stellar-syslog-relay"
    if os.path.exists(helper):
        p = subprocess.run([helper, "apply-tenants"], capture_output=True, text=True)
        sys.stdout.write(p.stdout); sys.stderr.write(p.stderr)
        if p.returncode:
            fail("apply-tenants failed; the previous config is still running. Restore with:\n"
                 f"  sudo cp {CSV_SRC}.before-scenario {CSV_SRC} && sudo cp {RELAY_ENV}.before-scenario {RELAY_ENV}")
    else:
        print(f"\n{helper} not found. Apply by hand: sudo stellar-syslog-relay apply-tenants")


def load_send_module():
    for c in (os.path.join(HERE, "stellar-send.py"), "/usr/local/bin/stellar-send"):
        if os.path.exists(c):
            spec = importlib.util.spec_from_file_location("stellar_send", c)
            m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
            return m
    fail("stellar-send.py not found next to this script")


def cmd_send(a):
    _, meta_path = estate_paths(a.name)
    if not os.path.exists(meta_path):
        fail(f"no estate for {a.name}. Run: lab-scenario.py estate {a.name}")
    meta = json.load(open(meta_path))
    SS = load_send_module()
    devices = meta["devices"]
    per = max(1, a.count // len(devices))
    srcs = {d["src"] for d in devices}
    if len(srcs) > 1 and not a.bind:
        print(f"NOTE: this scenario gives each device its own source address, and the relay keys the\n"
              f"      tenant on that address. Without --bind every log leaves from one address and the\n"
              f"      relay can only use the 'default' row. Pass --bind (the {len(srcs)} addresses must\n"
              f"      exist on this host and on its ENI), or use a field-keyed scenario instead.\n")
    print(f"sending {per} event(s) from each of {len(devices)} devices to {a.target}:{a.port} ({a.proto})")
    sent = failed = 0
    scene = SS.Scene(seed=meta["seed"])
    for d in devices:
        # "" makes the generator omit devid entirely, which is what the fallback path needs
        payloads = [SS.build_syslog("fortigate", i, 0, scene=scene,
                                    devid=d["devid"] if d["send_devid"] else "") for i in range(per)]
        try:
            sent += SS.send_batch(payloads, a.target, a.port, a.proto, bind=d["src"] if a.bind else None) \
                if hasattr(SS, "send_batch") else _send_simple(payloads, a, d)
        except Exception as e:  # noqa: BLE001
            failed += per
            print(f"  {d['devid']} from {d['src']}: {e.__class__.__name__}: {e}")
    print(f"sent {sent}, failed {failed}")
    print(f"\nnow: lab-scenario.py verify {a.name}")


def _send_simple(payloads, a, d):
    """Minimal sender: one socket per device, so a scenario needs no extra machinery."""
    import socket
    import ssl
    n = 0
    if a.proto == "udp":
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        if a.bind:
            s.bind((d["src"], 0))
        for p in payloads:
            s.sendto(p, (a.target, a.port)); n += 1
        s.close()
        return n
    s = socket.create_connection((a.target, a.port), timeout=10,
                                 source_address=(d["src"], 0) if a.bind else None)
    if a.proto == "tls":
        ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        s = ctx.wrap_socket(s)
    for p in payloads:
        frame = (str(len(p)) + " ").encode() + p if a.port in (601, 6514) else p + b"\n"
        s.sendall(frame); n += 1
    s.close()
    return n


def cmd_verify(a):
    _, meta_path = estate_paths(a.name)
    if not os.path.exists(meta_path):
        fail(f"no estate for {a.name}. Run: lab-scenario.py estate {a.name}")
    meta = json.load(open(meta_path))
    path = a.log or FWD_LOG
    if not os.path.exists(path):
        fail(f"{path} not found. The relay's debug copy must be on: DEBUG_LOG=yes in {RELAY_ENV}")
    want = {d["devid"]: d for d in meta["devices"]}
    by_tenant = collections.Counter()
    by_src = collections.Counter()
    right = wrong = catchall = noraw = unknown = fellback = 0
    examples = []
    with open(path, errors="replace") as f:
        for line in f:
            try:
                rec = json.loads(line)
                st = rec["stellar"]; mo = st.get("msg_origin") or {}
            except Exception:  # noqa: BLE001
                continue
            raw = rec.get("parser_raw_msg") or ""
            if not raw:
                noraw += 1; continue
            m = re.search(r'devid="?([A-Za-z0-9._:-]+)"?', raw)
            devid = m.group(1) if m else None
            tid = st.get("tenantid") or ""
            by_tenant[tid] += 1
            by_src[str(mo.get("srcip") or "?")] += 1
            if devid and devid in want:
                d = want[devid]
                if not d["mapped"]:
                    if tid == meta["default_tenant"]:
                        catchall += 1
                    else:
                        wrong += 1
                elif tid == d["tenant"]:
                    right += 1
                else:
                    wrong += 1
                    if len(examples) < 5:
                        examples.append(f"{devid} expected {d['tenant'][:12]}… got {tid[:12]}…")
            elif tid == meta["default_tenant"]:
                fellback += 1          # no key in the log: the source-IP/default fallback caught it
            else:
                unknown += 1

    sc = scenario(a.name)
    total = right + wrong + catchall + unknown + fellback
    print(f"{a.name}: {sc['title']}")
    print(f"expect: {sc['expect']}\n")
    print(f"  records read            {total + noraw}")
    print(f"  correct tenant          {right}")
    print(f"  wrong tenant            {wrong}")
    if any(not d["mapped"] for d in meta["devices"]):
        print(f"  correctly caught-all    {catchall}   (devices deliberately left out of the map)")
    if fellback:
        print(f"  no devid -> catch-all   {fellback}   (fallback worked: these are not lost)")
    print(f"  no devid, wrong tenant  {unknown}")
    if noraw:
        print(f"  EMPTY parser_raw_msg    {noraw}   <- the sensor discards these")
    print(f"  distinct tenants seen   {len(by_tenant)}")
    print(f"  distinct source IPs     {len(by_src)}")
    for e in examples:
        print(f"    mismatch: {e}")
    want_srcs = {d["src"] for d in meta["devices"]}
    if sc["key_mode"] == "srcip" and len(want_srcs) > 1 and len(by_src) == 1:
        print(f"\n  DIAGNOSIS: the estate expects {len(want_srcs)} source addresses but every record arrived from\n"
              f"  {next(iter(by_src))}. The sender did not bind to each device's address, so the relay had nothing\n"
              f"  to key on and used the catch-all. Re-send with --bind, after adding those addresses to the\n"
              f"  host and its ENI. This is the weakness that the field-keyed scenarios remove.")
    if sc["key_mode"] == "field" and len(by_src) == 1 and len(by_tenant) > 1:
        print(f"\n  PROVEN: {len(by_tenant)} tenants arrived from a single address ({next(iter(by_src))}).")
    ok = wrong == 0 and noraw == 0 and unknown == 0 and right > 0
    print(f"\n  {'PASS' if ok else 'FAIL'}")
    sys.exit(0 if ok else 1)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list").set_defaults(fn=cmd_list)

    def add_name(p):
        p.add_argument("name", help="scenario name (see: lab-scenario.py list)")

    s = sub.add_parser("show"); add_name(s); s.add_argument("--profile", default="small", choices=PROFILES); s.set_defaults(fn=cmd_show)

    s = sub.add_parser("estate", help="generate a synthetic tenant map for the scenario")
    add_name(s)
    s.add_argument("--profile", default="small", choices=PROFILES)
    s.add_argument("--seed", default="lab", help="same seed = same estate (default 'lab')")
    s.add_argument("--base-ip", default="172.31.85.200", help="source address, or the first of a range")
    s.add_argument("--default-tenant", help="catch-all tenant ID (default: derived from the seed)")
    s.add_argument("--out", help="write the CSV here instead of the scenario directory")
    s.set_defaults(fn=cmd_estate)

    s = sub.add_parser("render", help="render and lint the relay config, no root, no changes")
    add_name(s)
    s.add_argument("--estate"); s.add_argument("--out")
    s.add_argument("--sensor-ip", default="10.0.1.50"); s.add_argument("--sensor-ip-2", default="10.0.1.51")
    s.set_defaults(fn=cmd_render)

    s = sub.add_parser("apply", help="write the map and settings on this relay and reload")
    add_name(s)
    s.add_argument("--estate"); s.add_argument("--sensor-ip"); s.add_argument("--sensor-ip-2")
    s.set_defaults(fn=cmd_apply)

    s = sub.add_parser("send", help="drive traffic matching the scenario")
    add_name(s)
    s.add_argument("--target", required=True); s.add_argument("--port", type=int, default=514)
    s.add_argument("--proto", choices=["udp", "tcp", "tls"], default="udp")
    s.add_argument("--count", type=int, default=100, help="total events, spread over the devices")
    s.add_argument("--bind", action="store_true", help="bind to each device's source address")
    s.set_defaults(fn=cmd_send)

    s = sub.add_parser("verify", help="read the relay's forwarded log and report what landed")
    add_name(s); s.add_argument("--log", help=f"default {FWD_LOG}")
    s.set_defaults(fn=cmd_verify)

    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
