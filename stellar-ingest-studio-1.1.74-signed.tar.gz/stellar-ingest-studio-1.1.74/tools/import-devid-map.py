#!/usr/bin/env python3
"""
import-devid-map.py  -  move a sensor-side device-to-tenant table into the Log Relay Manager.

A customer on "parser mapping" keeps the tenant assignment inside a customized parser on the
sensor, as a hash of FortiGate serial (devid) -> tenant ID:

    DEVID_TO_TENANTID_MAPPING = {
      "FGTLAB0000000002" => "11111111111111111111111111111111",   # illustrative, not real
      ...
    }

That table is the same thing the relay's tenant map holds, in the wrong place. This tool reads it and
writes the Log Relay Manager's LOG SOURCE CSV: one row per firewall, recognized by `devid` (the serial
in every FortiGate log), sent to the same tenant. No address is needed per device - the relay learns
where each one sends from when its first log arrives. Upload the file on the Tenancy page
(Add > Log source CSV import / export) and the relay checks every row before writing anything.

Inputs, any combination:
  --from PARSER          the customized parser file (the hash inside it is what the sensor runs TODAY)
  --workbook SHEET.xlsx  the onboarding workbook (Stellar Tenant / Stellar Tenant ID / Fortigate Serial #1, #2 ...):
                         tenant NAMES, and a cross-check of what was onboarded against what is live
  --pairs FILE.csv       a plain two-column file: serial,tenant_id
  --tenants EXPORT.csv   the platform's Tenant Management export (Name, ID, Tenant Group): names the tenants and
                         reports any tenant ID in the table that no longer exists on the platform
  --names FILE.csv       serial,name - what to call each device in the console (a host name); optional

Examples:
  import-devid-map.py --from customized_forti_fortigate --tenants tenants-export.csv --out log-sources.csv
  import-devid-map.py --from customized_forti_fortigate --workbook "Multi tenant setup.xlsx" --check
  import-devid-map.py --from parser.rb --format map --default-tenant <32 hex> > stellar-tenants.csv.src

Standard library only (the .xlsx is read as the zip of XML it is). Nothing here talks to a relay or a
sensor; the output is a file a person reads and then uploads.
"""
import argparse
import collections
import csv
import datetime
import io
import re
import sys
import zipfile
import xml.etree.ElementTree as ET

HEX32 = re.compile(r"^[0-9a-f]{32}$")
# "SERIAL" => "tenantid"   (Ruby hash) and "SERIAL": "tenantid"   (JSON/YAML-ish), both seen
PAIR = re.compile(r'["\']([^"\']{1,128})["\']\s*(?:=>|:)\s*["\']([0-9a-fA-F]{32})["\']')
SELECTOR_OK = re.compile(r"^[A-Za-z0-9._:-]{1,128}$")
FORTI_SERIAL = re.compile(r"^F[A-Z0-9]{15}$")            # FGT60F..., FG100E..., FWF60E... : 16 characters
NOT_A_VALUE = {"", "-", "n/a", "na", "none", "null", "pending", "tbd", "tba", "?", "unknown"}

# The Log Relay Manager's log source CSV. The header must match apps/relay-monitor/app.py SOURCE_CSV_COLUMNS;
# apps/tests/test_apps.py uploads this tool's output to a real relay, so a drift fails a test.
SOURCE_COLUMNS = ["name", "device_type", "seen_address", "match", "identity_field", "identity_value", "tenant_id",
                  "split_field", "split_value", "split_tenant_id", "sensor_port", "delivery", "sensor", "note",
                  "field_note", "split_note", "enabled", "options"]


# ----------------------------------------------------------------------------- readers
def extract_pairs(text, hash_name="DEVID_TO_TENANTID_MAPPING"):
    """Every device -> tenant pair, in file order, from the named hash (or the whole text when hash_name is None)."""
    if hash_name:
        i = text.find(hash_name)
        if i < 0:
            raise ValueError(f"no '{hash_name}' found in the file")
        text = text[i:]
        end = re.search(r"\n\s*\}", text)
        if end:
            text = text[:end.start()]
    return [(d.strip(), t.lower()) for d, t in PAIR.findall(text)]


def read_pairs_csv(path):
    """serial,tenant_id (a header row is fine; extra columns are ignored)."""
    out = []
    with open(path, newline="", encoding="utf-8-sig") as f:
        for row in csv.reader(f):
            if len(row) < 2:
                continue
            a, b = row[0].strip(), row[1].strip().lower()
            if not a or a.startswith("#") or a.lower() in ("serial", "devid", "device_id"):
                continue
            out.append((a, b))
    return out


def _col_index(ref):
    n = 0
    for ch in ref:
        if ch.isalpha():
            n = n * 26 + (ord(ch.upper()) - 64)
        else:
            break
    return n - 1


def read_workbook(path, sheet=None):
    """Rows of cell strings from an .xlsx, first sheet unless named. Standard library: it is a zip of XML."""
    NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
          "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
          "p": "http://schemas.openxmlformats.org/package/2006/relationships"}
    try:
        z = zipfile.ZipFile(path)
    except zipfile.BadZipFile:
        raise ValueError(f"{path} is not a readable .xlsx workbook (an old .xls must be saved as .xlsx or .csv)")
    with z:
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        targets = {r.get("Id"): r.get("Target") for r in rels.findall("p:Relationship", NS)}
        sheets = [(s.get("name"), targets.get(s.get(f"{{{NS['r']}}}id"), "")) for s in wb.findall("m:sheets/m:sheet", NS)]
        if not sheets:
            raise ValueError("the workbook has no sheets")
        if sheet:
            pick = [t for n, t in sheets if n == sheet]
            if not pick:
                raise ValueError(f"no sheet named {sheet!r}; the workbook has: {', '.join(n for n, _ in sheets)}")
            target = pick[0]
        else:
            target = sheets[0][1]
        target = target.lstrip("/")
        if not target.startswith("xl/"):
            target = "xl/" + target
        shared = []
        if "xl/sharedStrings.xml" in z.namelist():
            for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("m:si", NS):
                shared.append("".join(t.text or "" for t in si.iter(f"{{{NS['m']}}}t")))
        rows = []
        for row in ET.fromstring(z.read(target)).findall("m:sheetData/m:row", NS):
            cells = {}
            for c in row.findall("m:c", NS):
                idx = _col_index(c.get("r") or "")
                t = c.get("t")
                v = c.find("m:v", NS)
                if t == "s" and v is not None and v.text is not None and v.text.isdigit():
                    val = shared[int(v.text)] if int(v.text) < len(shared) else ""
                elif t == "inlineStr":
                    val = "".join(x.text or "" for x in c.iter(f"{{{NS['m']}}}t"))
                else:
                    val = v.text if v is not None and v.text is not None else ""
                cells[idx] = str(val).strip()
            width = max(cells) + 1 if cells else 0
            rows.append([cells.get(i, "") for i in range(width)])
    return rows


def workbook_pairs(rows, header_row=None):
    """(pairs, names, notes) from an onboarding sheet: the header is found by its words (serial / tenant id)."""
    def is_serial_head(h):
        h = h.lower()
        return "serial" in h or "devid" in h or "device id" in h or h.strip() in ("s/n", "sn")

    def is_tid_head(h):
        h = h.lower()
        return "tenant" in h and "id" in h.replace("tenant", "")

    hi = None
    if header_row:
        hi = header_row - 1
    else:
        for i, row in enumerate(rows[:25]):
            if any(is_serial_head(c) for c in row) and any(is_tid_head(c) for c in row):
                hi = i
                break
    if hi is None or hi >= len(rows):
        raise ValueError("no header row with a 'Tenant ID' column and at least one 'Serial' column in the first 25 rows "
                         "(name it with --header-row, or give --pairs serial,tenant_id instead)")
    head = rows[hi]
    serial_cols = [i for i, h in enumerate(head) if is_serial_head(h)]
    tid_col = next(i for i, h in enumerate(head) if is_tid_head(h))
    name_col = next((i for i, h in enumerate(head) if "tenant" in h.lower() and i != tid_col and not is_tid_head(h)), None)
    pairs, names, notes = [], {}, []
    for n, row in enumerate(rows[hi + 1:], start=hi + 2):
        get = lambda i: row[i].strip() if i is not None and i < len(row) else ""
        tid = get(tid_col).lower()
        tname = get(name_col)
        serials = [get(i) for i in serial_cols]
        if not tid and not any(serials) and not tname:
            continue
        usable = [s for s in serials if s.lower() not in NOT_A_VALUE]
        if not tid:
            if usable:
                notes.append(f"row {n}: {', '.join(usable)} has no tenant ID (tenant {tname or '?'}); skipped")
            continue
        if not usable:
            notes.append(f"row {n}: tenant {tname or tid} has no usable serial ({', '.join(serials) or 'blank'}); NOT onboarded")
            continue
        for s in usable:
            s2 = re.sub(r"\s+", "", s).upper()
            pairs.append((s2, tid))
            if tname:
                names[s2] = tname
    return pairs, names, notes


def read_tenant_export(path):
    """{tenant_id: {"name", "group"}} from the platform's Tenant Management export (or this console's tenant CSV)."""
    norm = lambda h: re.sub(r"[\s\-]+", "_", (h or "").strip().lower()).strip("_")
    out = {}
    with open(path, newline="", encoding="utf-8-sig") as f:
        lines = [l for l in f if l.strip() and not l.lstrip().startswith("#")]
    reader = csv.DictReader(io.StringIO("".join(lines)))
    cols = {norm(h): h for h in (reader.fieldnames or [])}
    idc = next((cols[k] for k in ("id", "tenant_id", "tenant_uuid", "cust_id") if k in cols), None)
    namec = next((cols[k] for k in ("name", "tenant_name", "tenant", "cust_name") if k in cols), None)
    groupc = next((cols[k] for k in ("tenant_group", "group", "tenant_group_name", "group_name") if k in cols), None)
    if not idc or not namec:
        raise ValueError(f"{path} has no ID and Name columns (found: {', '.join(cols) or 'none'})")
    for row in reader:
        tid = (row.get(idc) or "").strip().strip('"').lower()
        if HEX32.match(tid):
            out[tid] = {"name": (row.get(namec) or "").strip(), "group": (row.get(groupc) or "").strip() if groupc else ""}
    return out


def read_names(path):
    """serial,name -> {serial: name}."""
    out = {}
    with open(path, newline="", encoding="utf-8-sig") as f:
        for row in csv.reader(f):
            if len(row) >= 2 and row[0].strip() and not row[0].startswith("#") and row[0].strip().lower() not in ("serial", "devid"):
                out[re.sub(r"\s+", "", row[0]).upper()] = row[1].strip()
    return out


# ----------------------------------------------------------------------------- the merge, and what it found
class Plan:
    def __init__(self):
        self.rows = []            # (serial, tenant_id) in first-seen order, one per device
        self.problems = []        # things a person must decide (the run refuses to write)
        self.warnings = []        # things to know
        self.notes = []           # counts and facts
        self.names = {}           # serial -> device name
        self.tenants = {}         # tenant_id -> {"name", "group"}

    def ok(self):
        return not self.problems


def build(pairs, resolve="refuse", tenants=None, names=None, workbook_pairs_=None, workbook_names=None):
    """One device per serial. A serial listed twice with the SAME tenant is a repeat; with DIFFERENT tenants it is a
    conflict the run refuses unless --resolve says which line to take (the Ruby hash silently took the LAST)."""
    p = Plan()
    p.tenants = dict(tenants or {})
    seen = collections.OrderedDict()
    counts = collections.Counter(d for d, _ in pairs)
    for dev, tid in pairs:
        if not HEX32.match(tid):
            p.problems.append(f"{dev}: tenant ID {tid!r} is not 32 lowercase hex characters (the sensor ignores such an ID; it was never routing)")
            continue
        if not SELECTOR_OK.match(dev):
            p.problems.append(f"{dev!r}: not usable as a device identifier (one token: letters, digits, . _ : -)")
            continue
        if not FORTI_SERIAL.match(dev):
            p.warnings.append(f"{dev}: does not look like a FortiGate serial (16 characters starting with F); kept as written")
        if dev in seen:
            if seen[dev] != tid:
                if resolve == "last":
                    p.warnings.append(f"{dev}: listed with two tenants; --resolve last took {tid} (what the parser's hash did)")
                    seen[dev] = tid
                elif resolve == "first":
                    p.warnings.append(f"{dev}: listed with two tenants; --resolve first kept {seen[dev]}")
                else:
                    p.problems.append(f"{dev}: listed with DIFFERENT tenants ({seen[dev]} then {tid}). In a Ruby hash the last line "
                                      f"wins silently; decide which is right (--resolve first|last, or fix the file)")
            continue
        seen[dev] = tid
    for d, n in counts.items():
        if n > 1 and d in seen:
            p.notes.append(f"{d} appears {n} times in the table (one device; the repeat is dropped)")
    p.rows = list(seen.items())
    by_tenant = collections.Counter(t for _, t in p.rows)
    p.notes.insert(0, f"{len(pairs)} entries read, {len(p.rows)} devices, {len(by_tenant)} tenants, "
                      f"{sum(1 for n in by_tenant.values() if n > 1)} tenant(s) with more than one device")
    if tenants:
        missing = sorted(t for t in by_tenant if t not in tenants)
        for t in missing:
            devs = [d for d, x in p.rows if x == t]
            p.warnings.append(f"tenant {t} is not in the platform's tenant list; {', '.join(devs)} would go to a tenant "
                              f"that does not exist there (a removed or renamed tenant?)")
        p.notes.append(f"{len(by_tenant) - len(missing)} of {len(by_tenant)} tenant IDs found in the platform's tenant list")
    if workbook_pairs_ is not None:
        live = {d for d, _ in p.rows}
        wb = collections.OrderedDict()
        for d, t in workbook_pairs_:
            wb.setdefault(d, t)
        only_wb = [d for d in wb if d not in live]
        only_live = [d for d in live if d not in wb]
        moved = [d for d in wb if d in dict(p.rows) and wb[d] != dict(p.rows)[d]]
        if only_wb:
            p.warnings.append(f"{len(only_wb)} serial(s) in the workbook are NOT in the live table (never onboarded, or removed): {', '.join(only_wb[:20])}"
                              + (" ..." if len(only_wb) > 20 else ""))
        if only_live:
            p.warnings.append(f"{len(only_live)} live serial(s) are NOT in the workbook (added by hand?): {', '.join(only_live[:20])}"
                              + (" ..." if len(only_live) > 20 else ""))
        for d in moved:
            p.warnings.append(f"{d}: the workbook says tenant {wb[d]}, the live table says {dict(p.rows)[d]}; the live table is what routes today")
        p.notes.append(f"workbook: {len(wb)} serial(s), {len(only_wb)} not live, {len(only_live)} live but not listed, {len(moved)} with a different tenant")
    # device names: an explicit list wins; then "<tenant name> · <serial>"; then the serial itself
    tenant_name = {}
    for d, nm in (workbook_names or {}).items():
        t = dict(p.rows).get(d)
        if t and nm:
            tenant_name.setdefault(t, nm)
    for t, info in p.tenants.items():
        if info.get("name"):
            tenant_name[t] = info["name"]
    for d, t in p.rows:
        if names and d in names and names[d]:
            p.names[d] = names[d]
        elif tenant_name.get(t):
            p.names[d] = f"{tenant_name[t]} · {d}"
        else:
            p.names[d] = d
    unnamed = sum(1 for d in p.names if p.names[d] == d)
    if unnamed:
        p.notes.append(f"{unnamed} device(s) named by their serial only (give --tenants or --names for readable names)")
    return p


# ----------------------------------------------------------------------------- writers
def sources_csv(plan, device_type="fortigate", field="devid", port="", sensor="", when=None, source_note=""):
    when = when or datetime.date.today().isoformat()
    buf = io.StringIO()
    buf.write("# Stellar Cyber Log Relay Manager - log sources, generated by import-devid-map.py on %s\n" % when)
    buf.write("# %d device(s), each recognized by %s (the serial in every log) and sent to the tenant the sensor-side table gave it.\n" % (len(plan.rows), field))
    buf.write("# seen_address is left blank on purpose: the relay records where each device sends from when its first log arrives.\n")
    buf.write("# Upload on the Tenancy page: Add > Log source CSV import / export. Every row is checked before anything is written.\n")
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(SOURCE_COLUMNS)
    note = source_note or f"migrated from the sensor-side parser mapping on {when}"
    for dev, tid in plan.rows:
        w.writerow([plan.names.get(dev, dev), device_type, "", "field", field, dev, tid, "", "", "", port, "", sensor,
                    note, "the appliance serial, the same key the sensor-side parser mapped", "", "yes", "predefined"])
    return buf.getvalue()


def map_csv(plan, vendor, product, fmt, port, field="devid", default_tenant=None, sensor=None, src=""):
    """The raw relay map (selector,name,value) with field selectors, for a relay managed without the console."""
    out = [f"# Generated by import-devid-map.py from {src}",
           f"# {len(plan.rows)} devices. Each selector is {field}=<serial>: the relay reads the field out of the log itself.", "#"]
    if default_tenant:
        out += [f"default,tenantid,{default_tenant.lower()}", f"default,vendor,{vendor}",
                f"default,product,{product}", f"default,format,{fmt}", f"default,port,{port}"]
    for dev, tid in plan.rows:
        sel = f"{field}={dev}"
        out += [f"{sel},tenantid,{tid}", f"{sel},vendor,{vendor}", f"{sel},product,{product}", f"{sel},format,{fmt}", f"{sel},port,{port}"]
        if sensor:
            out.append(f"{sel},sensor,{sensor}")
    return "\n".join(out) + "\n"


def report_text(plan, fmt):
    lines = ["import-devid-map: what the table holds"]
    lines += [f"  {n}" for n in plan.notes]
    if plan.warnings:
        lines.append(f"{len(plan.warnings)} warning(s), worth reading:")
        lines += [f"  WARNING: {w}" for w in plan.warnings]
    if plan.problems:
        lines.append(f"{len(plan.problems)} problem(s): nothing was written. Decide, then run again:")
        lines += [f"  PROBLEM: {p}" for p in plan.problems]
    else:
        lines.append("next: " + ("upload the file on the relay's Tenancy page (Add > Log source CSV import / export), read the "
                                 "review, then point each firewall at the relay" if fmt == "sources" else
                                 "install the map on the relay and run stellar-syslog-relay apply-tenants"))
    return "\n".join(lines)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--from", dest="src", help="the customized parser file holding the hash")
    ap.add_argument("--hash", default="DEVID_TO_TENANTID_MAPPING", help="name of the mapping hash in --from (default DEVID_TO_TENANTID_MAPPING)")
    ap.add_argument("--workbook", help="the onboarding .xlsx (tenant name, tenant ID, serial columns)")
    ap.add_argument("--sheet", help="sheet name inside --workbook (default: the first)")
    ap.add_argument("--header-row", type=int, help="the workbook's header row number, when it is not found by its words")
    ap.add_argument("--pairs", help="a serial,tenant_id CSV")
    ap.add_argument("--tenants", help="the platform's Tenant Management export (Name, ID, Tenant Group), or this console's tenant CSV")
    ap.add_argument("--names", help="serial,name CSV: what to call each device")
    ap.add_argument("--resolve", choices=["refuse", "first", "last"], default="refuse", help="a serial listed with two tenants: refuse (default), or take the first or the last line")
    ap.add_argument("--format", choices=["sources", "map"], default="sources", dest="fmt", help="sources = the console's log source CSV (default); map = the raw relay map")
    ap.add_argument("--device-type", default="fortigate", help="the console's device type key (default fortigate)")
    ap.add_argument("--field", default="devid", help="the field that names the device in its logs (default devid)")
    ap.add_argument("--vendor", default="fortinet")
    ap.add_argument("--product", default="fortigate")
    ap.add_argument("--log-format", default="syslog")
    ap.add_argument("--port", default="", help="the parser port on the sensor (blank = the device type's own; the map format needs one, default 5517)")
    ap.add_argument("--default-tenant", help="(map format) 32-hex catch-all tenant for devices not in the table")
    ap.add_argument("--sensor", choices=["1", "2"], help="pin every device to this sensor (split sensor mode)")
    ap.add_argument("--note", default="", help="the note written on every log source (default: migrated from ... on <date>)")
    ap.add_argument("--out", help="write the CSV here (default: stdout)")
    ap.add_argument("--report", help="also write the report here")
    ap.add_argument("--check", action="store_true", help="report only, write nothing")
    a = ap.parse_args(argv)

    if not (a.src or a.workbook or a.pairs):
        ap.error("give --from PARSER, --workbook SHEET.xlsx or --pairs FILE.csv")
    try:
        pairs, wb_pairs, wb_names, wb_notes = None, None, {}, []
        if a.src:
            with open(a.src, errors="replace") as f:
                pairs = extract_pairs(f.read(), a.hash)
            if not pairs:
                sys.exit("ERROR: no device-to-tenant pairs found in the parser file. Check --hash, or the file format.")
        if a.workbook:
            wb_pairs, wb_names, wb_notes = workbook_pairs(read_workbook(a.workbook, a.sheet), a.header_row)
            if pairs is None:
                pairs = wb_pairs
                wb_pairs = None            # the workbook IS the table; nothing to cross-check it against
        if a.pairs:
            extra = read_pairs_csv(a.pairs)
            pairs = (pairs or []) + extra
        tenants = read_tenant_export(a.tenants) if a.tenants else None
        names = read_names(a.names) if a.names else None
    except (OSError, ValueError) as e:
        sys.exit(f"ERROR: {e}")
    plan = build(pairs, a.resolve, tenants, names, wb_pairs, wb_names)
    plan.warnings = wb_notes + plan.warnings
    if a.fmt == "map" and not a.default_tenant:
        plan.warnings.append("no --default-tenant: a device missing from this table has no tenant and its logs land in the "
                             "sensor's own tenant, silently. Give the catch-all tenant, or choose it on the Tenancy page.")
    rep = report_text(plan, a.fmt)
    print(rep, file=sys.stderr)
    if a.report:
        with open(a.report, "w") as f:
            f.write(rep + "\n")
    if a.check:
        return 2 if plan.problems else 0
    if plan.problems:
        return 2
    if a.fmt == "sources":
        text = sources_csv(plan, a.device_type, a.field, a.port, a.sensor or "", source_note=a.note)
    else:
        text = map_csv(plan, a.vendor, a.product, a.log_format, a.port or "5517", a.field, a.default_tenant, a.sensor, a.src or a.workbook or a.pairs)
    if a.out:
        with open(a.out, "w") as f:
            f.write(text)
        print(f"wrote {a.out}: {len(plan.rows)} device(s)", file=sys.stderr)
    else:
        sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
