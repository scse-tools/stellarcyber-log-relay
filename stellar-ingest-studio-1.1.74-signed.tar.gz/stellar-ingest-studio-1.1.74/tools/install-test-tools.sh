#!/usr/bin/env bash
#############################################################################
# install-test-tools.sh
#
# Prepares a Ubuntu box as the "sender / mock sensor" host for the
# Stellar Cyber multi-tenant lab. Installs only what the tools need
# (python3, openssl, curl, tcpdump, netcat) and puts the tools on PATH.
#
# Usage:  sudo ./install-test-tools.sh [--add-ip 10.0.1.22 --add-ip 10.0.1.23]
#
#   --add-ip IP    Add a secondary private IP to the primary interface so
#                  stellar-send.py --bind IP can impersonate another tenant.
#                  The IP must ALSO be assigned to the instance's ENI in AWS
#                  (EC2 > Network interfaces > Manage IP addresses) or AWS
#                  will drop the packets.
#############################################################################
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ADD_IPS=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --add-ip) ADD_IPS+=("$2"); shift 2 ;;
    -h|--help) sed -n '2,16p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "Unknown option $1" >&2; exit 1 ;;
  esac
done
[[ $EUID -eq 0 ]] || { echo "Run as root: sudo $0" >&2; exit 1; }


# Freshly booted Ubuntu runs unattended-upgrades and apt-daily for several
# minutes; apt-get fails immediately if any of these locks is held. Wait instead.
wait_for_apt() {
  local waited=0
  while fuser /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/lib/apt/lists/lock >/dev/null 2>&1; do
    [[ $waited -eq 0 ]] && echo "    apt is busy (unattended-upgrades / apt-daily); waiting up to 15 min ..."
    sleep 5; waited=$((waited+5))
    [[ $waited -ge 900 ]] && { echo "    still locked after 15 min; see: ps -ef | grep -E 'apt|dpkg'" >&2; return 1; }
  done
  return 0
}
echo "==> Installing python3, openssl, curl, tcpdump, netcat"
export DEBIAN_FRONTEND=noninteractive
wait_for_apt || exit 1
apt-get update -qq
apt-get install -y -qq python3 openssl curl tcpdump netcat-openbsd >/dev/null
python3 --version

echo "==> Installing tools to /usr/local/bin"
install -m 0755 "$SCRIPT_DIR/stellar-send.py"     /usr/local/bin/stellar-send
install -m 0755 "$SCRIPT_DIR/mock-sensor.py"      /usr/local/bin/mock-sensor
install -m 0755 "$SCRIPT_DIR/lab-scenario.py"     /usr/local/bin/lab-scenario
install -m 0755 "$SCRIPT_DIR/import-devid-map.py" /usr/local/bin/import-devid-map
install -m 0755 "$SCRIPT_DIR/make-sensor-cert.sh"  /usr/local/bin/make-sensor-cert

if [[ ${#ADD_IPS[@]} -gt 0 ]]; then
  IFACE="$(ip -o -4 route show to default | awk '{print $5}' | head -1)"
  echo "==> Adding secondary IPs to $IFACE (non-persistent; re-run after reboot)"
  for ip in "${ADD_IPS[@]}"; do
    ip addr add "$ip/32" dev "$IFACE" 2>/dev/null && echo "    added $ip" || echo "    $ip already present"
  done
  echo "    Reminder: assign the same IPs to this instance's ENI in the AWS console."
fi

echo "==> Installing systemd unit for the mock sensor (not started)"
cat > /etc/systemd/system/mock-sensor.service <<'EOF'
[Unit]
Description=Mock Stellar Cyber Modular Sensor (test only)
After=network.target
[Service]
ExecStart=/usr/local/bin/mock-sensor --out-dir /var/log/mock-sensor
Restart=on-failure
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload

cat <<SUMMARY

Done.
  stellar-send --help            traffic generator (syslog | http | wrapped | direct | probe | fields)
  mock-sensor  --help            fake sensor on :5200 (HTTPS) and the parser ports (TLS): wrapper records and raw logs
  make-sensor-cert --help        mint a certificate to upload to the sensor for TLS testing
  sudo systemctl start mock-sensor   run the mock sensor in the background
                                     (output in /var/log/mock-sensor/*.jsonl,
                                      live view: journalctl -u mock-sensor -f)
SUMMARY
