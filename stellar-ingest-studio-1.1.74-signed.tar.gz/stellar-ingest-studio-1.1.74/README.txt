Stellar Cyber Ingest Studio 1.1.74  (build a9c10c5)

The sender-side app of the Stellar Cyber multi-tenant log relay lab. It plays the firewalls: realistic
FortiOS, PAN-OS, Meraki, SonicOS, Check Point and Sophos events with a unique marker per run, sent to the
syslog-ng relay's listeners exactly as the real devices send them. A log source here is configured the way
the real device is - what it is, how it sends, the address it sends from, how it identifies itself in its
logs. It carries NO tenant and NO delivery method: those live in the relay's own log-source row, made on
the Log Relay Manager. Ingest Studio never writes the relay's configuration, in either edition.

Install on the sender host (Ubuntu), as root:

    sudo bash install.sh                 the standard edition; asks for an admin password
    sudo bash install.sh --advanced      adds the read connection to the relay and packet capture
    sudo bash install.sh --help          every option

Re-run it to upgrade: the password, the secrets, the database and the edition are kept.

The two editions:

    standard (default)  defines log sources and sends their logs. No management connection to the relay
                        at all: it does not read the relay's state, cannot capture packets on it, and has
                        no manager URL or API token to set, so nothing here can be pointed at a production
                        relay by accident. The syslog-ng path only.
    advanced            adds a READ connection to the Log Relay Manager (status, map, what it forwarded,
                        which sensor ports it reaches), packet capture around a run, and the nginx and
                        direct-to-sensor paths. Needs the advanced code. Still never writes the relay.

Afterwards: open https://<this host>:8443 (self-signed certificate; accept the browser warning), sign in,
then Settings (the relay's IP or host name and the sensor address; advanced also the Log Relay Manager URL
https://<relay host>:8444 and its API token). Add a log source per simulated firewall, create the same log
source on the relay - that row decides the tenant and the sensor port - then Send.

Files:
    install.sh              checks this bundle, installs the test tools, runs the app's own installer
    apps/ingest-studio/     the app, its installer, the stellar-lab-ip and stellar-studio-password helpers
    apps/common/            the stdlib micro-framework and the shared static files
    tools/                  the traffic generator, the mock sensor, install-test-tools.sh
    SHA256SUMS              checksums of every file above

Permissions: install.sh runs as root (sudo) to install the packages the tools need, create the
unprivileged service user "stellarlab", write under /opt/stellar-lab, /etc/stellar-lab and
/etc/sudoers.d, and enable the ingest-studio service. Afterwards the app runs as stellarlab and may run
only two allow-listed root commands: /usr/local/sbin/stellar-lab-ip (secondary source addresses) and
systemctl start|stop|restart mock-sensor. Open TCP 8443 to this host from your browser only.

Forgotten the sign-in password: there is no mail on this host, so nothing can be sent. Be root here
and run `sudo stellar-studio-password`. It asks twice, never takes the password as an argument, and
keeps the log sources, the run history and the settings. The sign-in page says the same.

Logs: journalctl -u ingest-studio -f      Config: /etc/stellar-lab/ingest-studio.env

This bundle is SIGNED. Its SHA256SUMS.sig is an Ed25519 signature by Stellar Cyber's
release key over SHA256SUMS, which covers every other file here. A console installs it
only if that signature verifies against the public key installed on the host.
