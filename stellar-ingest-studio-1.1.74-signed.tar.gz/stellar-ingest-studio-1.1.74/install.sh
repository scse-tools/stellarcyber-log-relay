#!/usr/bin/env bash
#############################################################################
# Stellar Cyber Ingest Studio 1.1.74 - install on the sender host.
#
#   sudo bash install.sh [--port 8443] [--advanced|--standard] [--no-prompt]
#                        [--skip-tools] [--add-ip IP]
#
# Ingest Studio plays the firewalls: it defines log sources and sends their
# logs to the syslog-ng relay's listeners exactly as the real devices do.
# It NEVER writes the relay's configuration, in either edition.
#
#   --standard    the default: no management connection to the relay at all,
#                 the syslog-ng path only, no packet capture. Each log source
#                 defined here must also be created on the relay, by a person.
#   --advanced    adds a READ connection to the Log Relay Manager (its status,
#                 its map, what it forwarded, which sensor ports it reaches)
#                 and packet capture around a run. Needs the advanced code:
#                 $STELLAR_ADVANCED_CODE, or typed when asked.
#   --port N      the console's port (default 8443).
#   --no-prompt   unattended: generates an admin password and prints it.
#   --skip-tools  do not run tools/install-test-tools.sh (apt + /usr/local/bin).
#   --add-ip IP   add a secondary source address to this host (repeatable).
#                 Add the same address to the instance's network interface in
#                 AWS as well, or the replies are dropped.
#
# Re-run to upgrade: the password, the secrets, the database and the edition
# are kept. With no edition flag the host keeps the edition it has.
#############################################################################
set -euo pipefail
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ARGS=(); TOOLS=yes; ADD_IPS=()
while [[ $# -gt 0 ]]; do
  case $1 in
    --skip-tools) TOOLS=no; shift ;;
    --add-ip) ADD_IPS+=(--add-ip "$2"); shift 2 ;;
    -h|--help) sed -n '3,/^#####/p' "$0" | sed '$d' | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) ARGS+=("$1"); shift ;;
  esac
done
[[ $EUID -eq 0 ]] || { echo "run with sudo: sudo bash install.sh" >&2; exit 1; }
cd "$HERE"

echo "==> Checking this bundle against SHA256SUMS"
if command -v sha256sum >/dev/null; then
  sha256sum -c --quiet SHA256SUMS
elif command -v shasum >/dev/null; then
  shasum -a 256 -c SHA256SUMS >/dev/null
else
  echo "    neither sha256sum nor shasum is on this host: the bundle was NOT checked" >&2
fi

if [[ "$TOOLS" == yes ]]; then
  echo "==> Test tools (python3, openssl, curl, tcpdump, netcat; stellar-send, mock-sensor)"
  bash "$HERE/tools/install-test-tools.sh" ${ADD_IPS[@]+"${ADD_IPS[@]}"}
elif [[ ${#ADD_IPS[@]} -gt 0 ]]; then
  echo "--add-ip is part of the test tools step; drop --skip-tools" >&2; exit 2
fi

echo "==> Ingest Studio"
exec bash "$HERE/apps/ingest-studio/install.sh" ${ARGS[@]+"${ARGS[@]}"}
